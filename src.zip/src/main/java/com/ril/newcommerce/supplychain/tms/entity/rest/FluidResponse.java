package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/**
 * 
 * @author Asha1.Rani
 *
 */

@JsonDeserialize
@JsonSerialize
public class FluidResponse {
	@JsonProperty("fluidLoad")
	private FluidLoad fluidLoad;
	private String status;
	private String message;
	private List<Object> errors;
	
	public FluidLoad getFluidLoad() {
		return fluidLoad;
	}
	public void setFluidLoad(FluidLoad fluidLoad) {
		this.fluidLoad = fluidLoad;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<Object> getErrors() {
		return errors;
	}
	public void setErrors(List<Object> errors) {
		this.errors = errors;
	}
}
