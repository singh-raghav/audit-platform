package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.entity.ArticleInfo;
import com.ril.newcommerce.supplychain.tms.entity.DeliveryChallan;
import com.ril.newcommerce.supplychain.tms.entity.Party;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.PdfCreationException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.pdf.PDFGenerator;
import com.ril.newcommerce.supplychain.tms.service.ChallanService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.util.DeliveryChallanConfig;
import com.ril.newcommerce.supplychain.tms.util.GenericUtils;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */

@Service
public class ChallanRetriver {
	
	private static final Logger log = LoggerFactory.getLogger(ChallanRetriver.class);
	
	@Autowired
	@Qualifier(Constants.STRING_UTIL)
	private GenericUtils<String> util;
	
	@Autowired
	private InboundDAO inboundDAO;
	
	@Autowired
	private ChallanPdfExecutorService challanPdfExecutorService;
	
	@Autowired
	private TripService tripService;
	
	@Autowired
	private NodeAddressAccumulator addressAccumulator;
	
	@Autowired
	private DeliveryChallanConfig dcConfig;
	
	@Autowired
	private ChallanService challanService;
	
	@Autowired
	private PDFGenerator pdfGenerator;
	
    @Value("${pdf.deliveryChallan}")
    private String challanTemplatePath;
    
	@Autowired
	private ChallanPdfMerger challanPdfMerger;

    
	
	public ResponseEntity<InputStreamSource> getDeliveryChallan(String challanId,String hubId , String tripId) {
		return getChallans(util.getList(challanId), tripId, hubId);
	}
	
	/**
	 * dest - destination is always FC.
	 * src  - hub / kirana(if it is PDR)
	 */
	public ResponseEntity<InputStreamSource> getAllChallansByTrip(String tripId,String  hubId){
		List<String> challanIds = inboundDAO.getChallanIds(tripId,hubId);
		return getChallans(challanIds, tripId, hubId);
	}
	
	
	private ResponseEntity<InputStreamSource> getChallans(List<String> challanIds, String tripId, String hubId) {
			
		if(CollectionUtils.isNotEmpty(challanIds)) {
			
			//Load Trip 
			Trip trip = tripService.getTrip(tripId);
			if(trip==null)
				throw new ValidationException("Invalid TripId!!");
			
			Map<String, List<ChallanArticle>> challanArticleMap =   challanService.getChallanArticles(challanIds,tripId);  //Fetch existing articles for delivery-challan..
			
			if(MapUtils.isEmpty(challanArticleMap))
				throw new ValidationException("No articles associated with given challanids  " + challanIds);
			
			//Filter out all PDR orders.
			List<ChallanArticle> challanArticles = challanArticleMap.values().stream().flatMap(articles-> articles.stream()).collect(Collectors.toList());
			
			List<String> pdrOrderIds = challanArticles.stream()
													.filter(article-> OrderStatus.CR_RETURNED.getValue().equals(article.getReturnType()))
													.map(article -> article.getReturnOrderId()).collect(Collectors.toList());
			
			List<String> returnOrderIds = challanArticles.stream().map(article -> article.getReturnOrderId()).collect(Collectors.toList());
			
			Map<String,String> orderIdsAndSrcNode = inboundDAO.getSourceNode(returnOrderIds); 
					
			Set<String> srcNodes=new HashSet<>();
			if(MapUtils.isNotEmpty(orderIdsAndSrcNode)) 
				srcNodes = orderIdsAndSrcNode.values().stream().collect(Collectors.toSet());
			
			log.info("OrderId and src Node : {} " , orderIdsAndSrcNode);
			
			srcNodes.add(hubId);
			srcNodes.add(trip.getSourceNode());//For assets...
			
			Map<String,Party> partyMapping = addressAccumulator.getAddress(srcNodes, pdrOrderIds);
			
			Set<Callable<String>> tasks = new HashSet<>(); //Returns PDF Name.
			for(Entry<String, List<ChallanArticle>> article : challanArticleMap.entrySet()) {
				
				DeliveryChallan challan =  new DeliveryChallan(article.getValue().get(0).getChallanId());
				String returnOrderId= article.getKey(); 
				String srcId = (orderIdsAndSrcNode==null || orderIdsAndSrcNode.get(returnOrderId)==null)?trip.getSourceNode():orderIdsAndSrcNode.get(returnOrderId);
				Party consignee = partyMapping.get(srcId); //Consignee is always the order source node.
				Party consignor = null;
				if(OrderStatus.CR_RETURNED.getValue().equals(article.getValue().get(0).getReturnType()))
					consignor = partyMapping.get(article.getValue().get(0).getReturnOrderId());
				else 
					consignor = partyMapping.get(hubId);
				
				consignee.setVehicleNo(trip.getAssignedVehicle());
				
				ChallanUtils.populateChallanArticleDetails(challanService.getAvailableAssets(),dcConfig,challan, consignee, consignor , article.getValue(), hubId);
				
				//Add tasks to generate pdf
				for(Entry<String, ArticleInfo> entry  : challan.getOrderWiseInfo().entrySet()) {
					ChallanPdfGenerator challanPdf = new ChallanPdfGenerator(challan, challanTemplatePath, pdfGenerator, entry.getValue());
					tasks.add(challanPdf);
				}
			}
					
			List<String> challanPdfNames = new ArrayList<>();
			try {
				List<Future<String>> futures = challanPdfExecutorService.getPdfChallanExecutor().invokeAll(tasks);
				for(Future<String> future : futures){
					String res = future.get();
					if(StringUtils.isNotBlank(res))
						challanPdfNames.add(res);
				}
			} catch (PdfCreationException | InterruptedException  | ExecutionException e ) {
				log.error("Exception occured on creating challan : " +  e);
				throw new TripApplicationException("Unable to create Delivery challan pdf");
			}			
			return challanPdfMerger.mergePdfs(challanPdfNames); //Generate PDF now.			
		}
		return ResponseEntityFactory.getPDFResponseFailure("Unable to generate Pdf!");
	}
}
