package com.ril.newcommerce.supplychain.tms.service;


/**
 * 
 * @author Jeevi.Natarajan
 *
 */

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ril.newcommerce.supplychain.tms.entity.AssetMasterData;
import com.ril.newcommerce.supplychain.tms.entity.MetaData;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;

public interface ChallanService {
		
	public List<AssetMasterData> getAvailableAssets();
	
	public Set<String> getAvailableOrders(String nodeId , String orderSrcNodeId);
	
	public List<String> getAvailableOrdersByOrderId(List<String> orderIds);
	
	public List<ReturnItem> getAvailableReturnItems(List<String> returnOrderIds);
	
	public List<MetaData> getReturnItemQualities();
	
	public Map<String, List<ChallanArticle>> getChallanArticles(List<String> challanIds,String tripId);
	
	public boolean hasReturnOrders(String tripId);
	
	public Map<String,Map<String , Set<String>>> getchallanIdsPerNode(List<String> tripIds);
}
