package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;

/**
 * B1.Divya
 */

public class OrderDetailsMapper implements ResultSetExtractor<List<OrderDetails>> {

	@Override
	public List<OrderDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<OrderDetails> orderDetailsList = new ArrayList<OrderDetails>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			OrderDetails order = new OrderDetails();
			order.setOrderId(rs.getString("ORDER_ID"));
			order.setShipmentNo(rs.getString("SHIPMENT_NO"));
			order.setOrderType(rs.getString("ORDER_TYPE"));
			order.setSourceNode(rs.getString("SOURCE_NODE"));
			order.setCustomerAddress(rs.getString("CUSTOMER_ADDRESS"));
			order.setSlotStartTime(rs.getTimestamp("SLOT_START_TIME"));
			order.setSlotEndTime(rs.getTimestamp("SLOT_END_TIME"));
			order.setCustomerPONumber(rs.getString("CUSTOMER_PO_NUMBER"));
			//order.setCustomerId(rs.getString("CUSTOMER_ID"));
			//order.setPincode(rs.getString("PINCODE"));
			order.setOrderStatus(rs.getString("ORDER_STATUS"));

			orderDetailsList.add(order);
		}
		return orderDetailsList;
	}
}
