package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;

public class AccumulatedReturnItemsMapper implements RowMapper<ReturnItem> {

	@Override
	public ReturnItem mapRow(ResultSet rs, int arg1) throws SQLException {
		
		ReturnItem  returnItem = new ReturnItem();
		
		returnItem.setItemId(rs.getString("ITEM_ID"));		
		returnItem.setItemName(rs.getString("ITEM_NAME"));
		returnItem.setOrderedQuantity(rs.getDouble("EXPECTED_QTY"));
		returnItem.setRecievedQuantity(rs.getDouble("QUANTITY"));
		
		return returnItem;
	}
}
