package com.ril.newcommerce.supplychain.tms.entity.rest;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LoginResponse {

    @JsonProperty("access_token")
    String accessToken;

    @JsonProperty("expires_at")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    LocalDateTime expiresAt;

    @JsonIgnore
    String errorMessage;

    int invalidAttemptLeft;


}
