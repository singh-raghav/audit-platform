package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;

public class ChallanHubMapper implements ResultSetExtractor<Map<String,Map<String , Set<String>>>> {

	private static final Logger log = LoggerFactory.getLogger(ChallanHubMapper.class);
	
	@Override
	public Map<String,Map<String , Set<String>>> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String,Map<String , Set<String>>>  hubChallansMapping = new HashMap<>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			String tripId = rs.getString("TRIP_ID");
			String nodeId = rs.getString("NODE_ID");
			String challanId = rs.getString("CHALLAN_ID");
			
			hubChallansMapping.putIfAbsent(tripId,new HashMap<>());
			hubChallansMapping.get(tripId).putIfAbsent(nodeId, new HashSet<>());
			
			hubChallansMapping.get(tripId).get(nodeId).add(challanId);
		}
		log.info("hubchallanMapping : {} " , hubChallansMapping);
		return hubChallansMapping;
	}
}