package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.entity.UserDetails;
import com.ril.newcommerce.supplychain.tms.enums.AccountStatus;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;
import com.ril.newcommerce.supplychain.tms.enums.UserRoles;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDetailMapper implements ResultSetExtractor<List<UserDetails>> {

    @Override
    public List<UserDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {

        List<UserDetails> userDetailsList = new ArrayList<>();
        while (rs.next()) {
            UserDetails userDetails = UserDetails.builder()
                    .userName(rs.getString("USER_NAME"))
                    .id(rs.getString("ID"))
                    .firstName(rs.getString("FIRST_NAME"))
                    .lastName(rs.getString("LAST_NAME"))
                    .emailId(rs.getString("EMAIL_ID"))
                    .mobileNo(rs.getString("MOBILE_NO"))
                    .address(rs.getString("ADDRESS"))
                    .accountStatus(AccountStatus.valueOf(rs.getString("ACCOUNT_STATUS")))
                    .lastLoggedIn(rs.getTimestamp("LAST_LOGGED_IN")==null?null:rs.getTimestamp("LAST_LOGGED_IN").toLocalDateTime())
                    .altContactNo(rs.getString("ALT_CONTACT_NO"))
                    .altContactPerson(rs.getString("ALT_CONTACT_PERSON"))
                    .nodeId(rs.getString("NODE_ID"))
                    .clusterId(rs.getString("CLUSTER_ID"))
                    .nodeType(NodeType.valueOf(rs.getString("NODE_TYPE")))
                    .role(UserRoles.valueOf(rs.getString("ROLE")))
                    .updatedBy(rs.getString("UPDATED_BY"))
                    .updatedAt(rs.getTimestamp("UPDATED_AT").toLocalDateTime())
                    .invalidAttempts(rs.getInt("INVALID_ATTEMPTS"))
                    .state(rs.getString("STATE"))
                    .pincode(rs.getInt("PINCODE"))
                    .build();
            userDetailsList.add(userDetails);
        }
        return userDetailsList;
    }

}
