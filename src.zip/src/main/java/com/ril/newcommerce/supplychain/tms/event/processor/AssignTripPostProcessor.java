package com.ril.newcommerce.supplychain.tms.event.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.PublishFlowName;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.tibco.entity.VehicleState;
import com.ril.newcommerce.supplychain.tms.util.Utility;
/**
 * 
 * This class will handle assign specific post-processing.
 * 
 * @author jeevi.natarajan
 *
 */

@Component
@Qualifier(Constants.ASSIGN_TRIP_POST_PROCESSOR)
public class AssignTripPostProcessor implements IPostProcessor {

	private static final Logger log = LoggerFactory.getLogger(AssignTripPostProcessor.class);
	
	@Autowired
	private JMSPublisher publisher;
	
	@Value("${trip.assignment.vms.queue}")
	private String queueName;
	
	@Override
	public void postProcessEvent(TripEventInput event, Trip trip) { //After i commit my txn. I am letting VMS know that the vehicle is assigned successfully.
		
		publisher.publishMessage(queueName,  Utility.createVehicleState(event.getVehicle().getVehicleNo(),
				trip.getTripId() ,event.getModifiedBy() , Constants.ASSIGN), PublishFlowName.VEHICLE_STATE.getValue(),  
				Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.VEHICLE_NUMBER , 
						Constants.BUSINESS_VALUE_ONE, event.getVehicle().getVehicleNo(),Constants.BUSINESS_KEY_TWO, Constants.TRIP_NUMBER , Constants.BUSINESS_VALUE_TWO, event.getTripId()),VehicleState.class);
		
		log.info(" Succesfully Published Vehicle assignment status to VMS ");
	}
	
	
	
}
