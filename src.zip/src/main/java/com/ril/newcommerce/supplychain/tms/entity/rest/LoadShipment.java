package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"ShipmentNo",
"Shipment"
})*/
public class LoadShipment {

	@JsonProperty("ShipmentNo")
	private String shipmentNo;
	@JsonProperty("Shipment")
	private Shipment shipment;

	@JsonProperty("ShipmentNo")
	public String getShipmentNo() {
		return shipmentNo;
	}

	@JsonProperty("ShipmentNo")
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}

	@JsonProperty("Shipment")
	public Shipment getShipment() {
		return shipment;
	}

	@JsonProperty("Shipment")
	public void setShipment(Shipment shipment) {
		this.shipment = shipment;
	}

}