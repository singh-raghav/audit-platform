package com.ril.newcommerce.supplychain.tms.entity;


import com.ril.newcommerce.supplychain.tms.enums.ReturnItemQuality;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class ItemCondition {
	
	private ReturnItemQuality quality;
	private double quantity;
	
	
	public ItemCondition() {}
	
	public ItemCondition(ReturnItemQuality quality , double quantity) {
		this.quality = quality;
		this.quantity = quantity;
	}
	
	public ReturnItemQuality getQuality() {
		return quality;
	}
	
	public void setQuality(ReturnItemQuality quality) {
		this.quality = quality;
	}
	
	public double getQuantity() {
		return quantity;
	}
	
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "ItemCondition [quality=" + quality + ", quantity=" + quantity + "]";
	}

}
