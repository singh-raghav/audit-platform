package com.ril.newcommerce.supplychain.tms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.dao.NodeOrderRouteDAO;
import com.ril.newcommerce.supplychain.tms.entity.NodeOrdeRoute;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.NodeOrderRouteService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge.Trips.Trip.Orders;

@Service
public class NodeOrderRouteServiceImpl implements NodeOrderRouteService {

	private static final Logger log = LoggerFactory.getLogger(NodeOrderRouteServiceImpl.class);

	@Autowired
	NodeOrderRouteDAO nodeOrderRouteDAO;

	@Override
	public List<NodeOrdeRoute> getRouteIdsByNodeAndOrder(String nodeId, List<String> orderId) {
		List<NodeOrdeRoute> nodeOrderRoute = new ArrayList<>();
		try {
			if(!StringUtils.isEmpty(nodeId) && !CollectionUtils.isEmpty(orderId))
			{
			nodeOrderRoute = nodeOrderRouteDAO.getRouteIdsByNodeAndOrder(nodeId, orderId);
			}
		} catch (Exception e) {
			log.error("Exception occured while fetching node order route info ", e);
			throw new TripApplicationException("Exception occured while fetching node order route info ", e);
		}

		return nodeOrderRoute;
	}

	@Override
	public void updateCurrentRouteId(String nodeId, String routeId, List<String> orderIds) {
		nodeOrderRouteDAO.updateCurrentRouteId(nodeId, routeId, orderIds);

	}

	@Override
	public void updatePreviousRouteId(String routeId, String preRoutId, List<String> orderIds) {

		if (!CollectionUtils.isEmpty(orderIds)) {
			try {
				nodeOrderRouteDAO.updatePreviousRouteId(routeId, preRoutId, orderIds);
			} catch (Exception e) {
				log.error("Exception occured while updating pre route id {}", e);
				throw new TripApplicationException("Exception occured while updating pre route id", e);
			}
		}

	}

	@Override
	public void updateNextRouteId(String routeId, String nextRoutId, List<String> orderIds) {

		if (!CollectionUtils.isEmpty(orderIds)) {
			try {
				nodeOrderRouteDAO.updateNextRouteId(routeId, nextRoutId, orderIds);
			} catch (Exception e) {
				log.error("Exception occured while updating next route id {}", e);
				throw new TripApplicationException("Exception occured while updating next route id", e);
			}
		}

	}

	@Override
	public void updateNextRouteId(Map<String, List<String>> tripWithOrders, String newExternalRouteId) {
		try {
			nodeOrderRouteDAO.updateNextRouteId(tripWithOrders, newExternalRouteId);
		} catch (Exception e) {
			log.error("Exception occured while updating next route id {}", e);
			throw new TripApplicationException("Exception occured while updating next route id", e);
		}
	}

	@Override
	public void updatePreviousRouteId(Map<String, List<String>> tripWithOrders, String newExternalRouteId) {
		try {
			nodeOrderRouteDAO.updatePreviousRouteId(tripWithOrders, newExternalRouteId);
		} catch (Exception e) {
			log.error("Exception occured while updating next route id {}", e);
			throw new TripApplicationException("Exception occured while updating next route id", e);
		}
	}

	@Override
	public void createNodeOrderRoute(List<NodeOrdeRoute> nodeOrders) {
		try
		{
			if(!CollectionUtils.isEmpty(nodeOrders))
			{
			nodeOrderRouteDAO.insertNodeOrderRoute(nodeOrders);
			}
		}
		catch (Exception e) {
			log.error("Got Exception while inserting in node order route", e);
			throw new DataProcessingException("Got Exception while inserting in node order route", e);
		}
		
	}

}
