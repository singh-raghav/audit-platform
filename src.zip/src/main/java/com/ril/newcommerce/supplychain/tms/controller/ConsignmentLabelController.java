package com.ril.newcommerce.supplychain.tms.controller;

import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.service.ConsignmentLabelService;
import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/trip-mgmt/v1/label")
public class ConsignmentLabelController {
    @Autowired
    ConsignmentLabelService consignmentLabelService;

    @GetMapping(value = "/shipment/{shipmentNo}")
    public ResponseEntity<ResponseMessage> getLabelList(@PathVariable(value = "shipmentNo", required = true) String shipmentNo) {

        try {
            List<ConsignmentLabel> consignmentLabel = consignmentLabelService.getConsignmentLabel(shipmentNo);
            return Utility.getSuccessMsg(consignmentLabel);

        } catch (Exception e) {
            return Utility.getfailureMsg(e.getMessage());
        }
    }
}
