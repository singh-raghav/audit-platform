package com.ril.newcommerce.supplychain.tms.entity;

import java.sql.Timestamp;

public class WayPointUpdates
{
	private String tripId;
	private String wayPointId;
	private String nodeId;
	private String orderId;
	private String orderClassification;
	private String Status;
	private char shouldReconcile;
	private String createdBy;
	private String modifiedBy;
	private Timestamp createdTs;
	private Timestamp modifiedTs;
	private String flowName;
	private Double amountPaid;
	private Double roundOffAmount;
	private String mop;
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public String getWayPointId() {
		return wayPointId;
	}
	public void setWayPointId(String wayPointId) {
		this.wayPointId = wayPointId;
	}
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderClassification() {
		return orderClassification;
	}
	public void setOrderClassification(String orderClassification) {
		this.orderClassification = orderClassification;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public char getShouldReconcile() {
		return shouldReconcile;
	}
	public void setShouldReconcile(char shouldReconcile) {
		this.shouldReconcile = shouldReconcile;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}
	public Timestamp getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Timestamp modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}

	public Double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(Double amountPaid) {
		this.amountPaid = amountPaid;
	}

	public Double getRoundOffAmount() {
		return roundOffAmount;
	}

	public void setRoundOffAmount(Double roundOffAmount) {
		this.roundOffAmount = roundOffAmount;
	}

	public String getMop() {
		return mop;
	}

	public void setMop(String mop) {
		this.mop = mop;
	}

}
