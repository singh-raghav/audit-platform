package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.entity.Seal;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;

/**
B1.Divya
*/

public class TripSealMapper implements ResultSetExtractor<List<TripAdditionalDetail>>  {

	@Override
	public List<TripAdditionalDetail> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<TripAdditionalDetail> tripAdditionalDetails = new ArrayList<TripAdditionalDetail>();
		
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			
			TripAdditionalDetail additionalDetails=new TripAdditionalDetail(rs.getString("TRIP_ID"), rs.getString("NODE_ID"), rs.getString("KEY"), rs.getString("VALUE"));
			tripAdditionalDetails.add(additionalDetails);
		}
		return tripAdditionalDetails;
	}

}
