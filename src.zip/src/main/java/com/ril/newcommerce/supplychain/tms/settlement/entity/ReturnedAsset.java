package com.ril.newcommerce.supplychain.tms.settlement.entity;

public class ReturnedAsset {
	private Integer serialNo;
	private String returnDocument;
	private String from;
	private String type;
	private Integer picked;
	private Integer delivered;

	public Integer getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(Integer serialNo) {
		this.serialNo = serialNo;
	}

	public String getReturnDocument() {
		return returnDocument;
	}

	public void setReturnDocument(String returnDocument) {
		this.returnDocument = returnDocument;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getPicked() {
		return picked;
	}

	public void setPicked(Integer picked) {
		this.picked = picked;
	}

	public Integer getDelivered() {
		return delivered;
	}

	public void setDelivered(Integer delivered) {
		this.delivered = delivered;
	}

	@Override
	public String toString() {
		return "ReturnedAsset [serialNo=" + serialNo + ", returnDocument=" + returnDocument + ", from=" + from
				+ ", type=" + type + ", picked=" + picked + ", delivered=" + delivered + "]";
	}
}
