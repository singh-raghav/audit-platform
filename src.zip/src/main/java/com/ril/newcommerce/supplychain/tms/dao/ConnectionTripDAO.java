/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.ConnectionTrip;

/**
 * @author Raghav1.Singh
 *
 */

public interface ConnectionTripDAO {
	
	public void insertToTrip(ConnectionTrip connectionTrip);
	
	public void insertToTripSequence(ConnectionTrip connectionTrip);
	
	public void insertToTripSequence(ConnectionTrip connectionTrip, int size);
	
	public int getCountOfConnections(String tripId);
	
	public List<String> getConnections(String tripId);
	
}
