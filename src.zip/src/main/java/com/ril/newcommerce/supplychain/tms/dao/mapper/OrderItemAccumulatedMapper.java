package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;

public class OrderItemAccumulatedMapper implements RowMapper<ReturnItem> {

	@Override
	public ReturnItem mapRow(ResultSet rs, int arg1) throws SQLException {
		
		ReturnItem  returnItem = new ReturnItem();
		
		returnItem.setReturnOrderId(rs.getString("RETURN_ORDER_ID"));		
		returnItem.setItemId(rs.getString("ITEM_ID"));
		returnItem.setInvoicedQuanity(rs.getDouble("QTY"));
		
		return returnItem;
	}
}
