package com.ril.newcommerce.supplychain.tms.dao;

import com.ril.newcommerce.supplychain.tms.entity.UserDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.UserListResponse;
import com.ril.newcommerce.supplychain.tms.enums.UserRoles;

import java.util.Map;

public interface UserDetailDAO {

    UserListResponse getUserList(String nodeId, String clusterId, boolean ignoreNodeIdHeader,
                                 boolean ignoreDeletedUsers, Integer pageSize, Integer pageIndex,
                                 String searchKeyword, UserRoles userRole, String lastLoginFrom,
                                 String lastLoginTo) throws  Exception;

    UserDetails getUser(Map<String, Object> whereMap);
}
