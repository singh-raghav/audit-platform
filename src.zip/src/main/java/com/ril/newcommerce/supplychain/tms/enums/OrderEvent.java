package com.ril.newcommerce.supplychain.tms.enums;

public enum OrderEvent {
    CREATE("CREATE"),
    CANCEL("CANCEL"),
    FC_DELAY("FC_DELAY"),
    INVOICE("INVOICE"),
    SHIPMENT("SHIPMENT"),
    DELIVERY("DELIVERY"),
    PICKUP("PICKUP"),
    STAGING("STAGING");

    private String value;

    private OrderEvent(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

}
