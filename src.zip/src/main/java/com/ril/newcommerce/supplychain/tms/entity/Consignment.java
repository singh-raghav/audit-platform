package com.ril.newcommerce.supplychain.tms.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


public class Consignment {
	
	private String orderId;
	private String shipmentNo;
	private String shipmentStatus;
	private String orderStatus;
	private String nextNodeId;
	private String flowName;
	private String createdBy;
	private String modifiedBy;
	private Timestamp slotStart;
	private Timestamp slotEnd;
	private BigDecimal latitude;
	private BigDecimal longitute;
	private String orderType;
	private List<ConsignmentLabel> label;
	private Invoice invoice;
	private String orderClassification;
	private Customer Customer;
	private Timestamp orderDate;
	private String deliveryZoneId;
	private String sourceNode;

	public Timestamp getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Timestamp orderDate) {
		this.orderDate = orderDate;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getShipmentNo() {
		return shipmentNo;
	}
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}
	public String getShipmentStatus() {
		return shipmentStatus;
	}
	public void setShipmentStatus(String shipmentStatus) {
		this.shipmentStatus = shipmentStatus;
	}
	public String getNextNodeId() {
		return nextNodeId;
	}
	public void setNextNodeId(String nodeId) {
		this.nextNodeId = nodeId;
	}
	public List<ConsignmentLabel> getLabel() {
		return label;
	}
	public void setLabel(List<ConsignmentLabel> label) {
		this.label = label;
	}

	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Invoice getInvoice() {
		return invoice;
	}
	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}
	public Timestamp getSlotStart() {
		return slotStart;
	}
	public void setSlotStart(Timestamp slotStart) {
		this.slotStart = slotStart;
	}
	public Timestamp getSlotEnd() {
		return slotEnd;
	}
	public void setSlotEnd(Timestamp slotEnd) {
		this.slotEnd = slotEnd;
	}
	public BigDecimal getLatitude() {
		return latitude;
	}
	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}
	public BigDecimal getLongitute() {
		return longitute;
	}
	public void setLongitute(BigDecimal longitute) {
		this.longitute = longitute;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getOrderClassification() {
		return orderClassification;
	}
	public void setOrderClassification(String orderClassification) {
		this.orderClassification = orderClassification;
	}
	public Customer getCustomer() {
		return Customer;
	}
	public void setCustomer(Customer customer) {
		Customer = customer;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getDeliveryZoneId() {
		return deliveryZoneId;
	}
	public void setDeliveryZoneId(String deliveryZoneId) {
		this.deliveryZoneId = deliveryZoneId;
	}
	public String getSourceNode() {
		return sourceNode;
	}
	public void setSourceNode(String sourceNode) {
		this.sourceNode = sourceNode;
	}
}
