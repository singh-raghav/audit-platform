package com.ril.newcommerce.supplychain.tms.entity.rest.hawkeye;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
public class Result {

    @JsonProperty("id")
    private String id;
}
