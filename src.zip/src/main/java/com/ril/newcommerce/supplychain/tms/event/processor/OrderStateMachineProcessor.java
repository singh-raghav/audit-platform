package com.ril.newcommerce.supplychain.tms.event.processor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.OrderEvent;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.exception.ActionExecutionException;
import com.ril.newcommerce.supplychain.tms.exception.EventOutOfOrderException;
import com.ril.newcommerce.supplychain.tms.exception.StateMachineProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.UpdatedOrderUtilService;
import com.ril.newcommerce.supplychain.tms.service.impl.OrderDetailsServiceImpl;
import com.ril.newcommerce.supplychain.tms.statemachine.OrderStateMachineHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.statemachine.StateMachine;
import org.springframework.stereotype.Service;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.*;

@Service
@Qualifier(ORDER_STATE_MACHINE_PROCESSOR)
public class OrderStateMachineProcessor implements BasicSMOrderUpdateProcessor {


    private static final Logger log = LoggerFactory.getLogger(OrderStateMachineProcessor.class);

    @Autowired
    private OrderStateMachineHandler smHandler;

    @Autowired
    private OrderDetailsServiceImpl orderDetailsService;

    @Autowired
    private UpdatedOrderUtilService updatedOrderUtilService;


    @Override
    public void processOrder(String orderId, OrderState toState, String flowName) {

        try {
            OrderEvent orderEvent = getOrderEvent(toState);

            String fromState = orderDetailsService.getOrderDetail(orderId).getOrderStatus();

            StateMachine<OrderState, OrderEvent> stateMachine = smHandler.initializeAndStart(orderId, OrderState.valueOf(fromState));

            //pass the event , trip object to Action.
            stateMachine.getExtendedState().getVariables().put(ORDER_ID, orderId);
            stateMachine.getExtendedState().getVariables().put(ORDER_STATE, toState);
            stateMachine.getExtendedState().getVariables().put(FLOWNAME, flowName);

            if (stateMachine.hasStateMachineError()) {
                log.error("----State machine is in invalid state.. throw error..");
                throw new TripApplicationException("State machine in Invalid state!");
            }

            //Fire the event
            boolean isEventAccepted = smHandler.fireEvent(stateMachine, orderEvent); //Blocking..

            if (!isEventAccepted) {
                throw new EventOutOfOrderException("No transition allowed from " + fromState + " to state " + toState.getValue() + "  for event " + orderEvent.getValue());
            }

            //And the action itself failing
            if (stateMachine.hasStateMachineError()) {
                log.error("Exception occurred on executing Action : {}  for orderId : {}", orderEvent, orderId);
                throw ((ActionExecutionException) stateMachine.getExtendedState().getVariables().get(Constants.EXCEPTION));
            }

            updatedOrderUtilService.update(orderId, fromState);

        } catch (Exception e) {
            throw new StateMachineProcessingException(e);
        }
    }

    private OrderEvent getOrderEvent(OrderState toState) {
        OrderEvent orderEvent = null;
        switch (toState) {
            case INVOICED:
                orderEvent = OrderEvent.INVOICE;
                break;
            case STAGED:
                orderEvent = OrderEvent.STAGING;
                break;
            case CANCELLED:
                orderEvent = OrderEvent.CANCEL;
                break;
            case FC_DELAYED:
                orderEvent = OrderEvent.FC_DELAY;
                break;
            case SHIPPED:
                orderEvent = OrderEvent.SHIPMENT;
                break;
            case DELIVERED:
            case RESCHEDULED:
            case PARTIALLY_DELIVERED:
            case FULL_DSR:
                orderEvent = OrderEvent.DELIVERY;
                break;
            case PICKED:
                orderEvent = OrderEvent.PICKUP;
                break;
            default:
                throw new EventOutOfOrderException("No transition allowed to state " + toState);

        }
        return orderEvent;
    }
}