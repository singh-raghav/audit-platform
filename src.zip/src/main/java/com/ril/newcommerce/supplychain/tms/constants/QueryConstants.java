package com.ril.newcommerce.supplychain.tms.constants;


public class QueryConstants {
	
	private QueryConstants() {}
	
	public static final String INSERT_TO_ORDER_DETAILS="INSERT INTO ORDER_DETAILS (ORDER_ID,SHIPMENT_NO,ORDER_TYPE,ORDER_CLASSIFICATION,SOURCE_NODE,CUSTOMER_NAME,CUSTOMER_ADDRESS,CUSTOMER_PINCODE,SELLER_ORG_CODE,ORDER_STATUS,SLOT_START_TIME,SLOT_END_TIME,CREATED_TIME,CREATED_BY,FLOW_NAME,CUSTOMER_PO_NUMBER,CUSTOMER_ID,CUSTOMER_STATE_CODE,CUSTOMER_GSTN,CUSTOMER_STATE,MODIFIED_TIME,MODIFIED_BY,ORDER_DATE,DELIVERY_ZONE_ID) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String INSERT_TO_TRIP="INSERT INTO TRIP(TRIP_ID,TYPE,SOURCE_NODE,PLANNED_START,PLANNED_END,STATUS,FLEET_TYPE,SUGGESTED_VEHICLE_TYPE,SUGGESTED_VEHICLE_NO,EXTERNAL_REF_ID,FLOW_NAME,CREATED_BY,MODIFIED_BY,LATITUDE,LONGITUDE,PLANNED_KM,CREATED_TS,MODIFIED_TS,MOVEMENT_TYPE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String INSERT_TO_TRIP_CONSIGNMENTS="INSERT INTO TRIP_CONSIGNMENTS (TRIP_ID,SHIPMENT_NO,NODE_ID,SHIPMENT_STATUS,SLOT_START,SLOT_END,LATITUDE,LONGITUDE,CREATED_BY,MODIFIED_BY,FLOW_NAME,CREATED_TS,MODIFIED_TS,DELIVERY_ZONE_ID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String INSERT_TO_TRIP_SEQUENCE="INSERT INTO TRIP_SEQUENCE (TRIP_ID,NODE_ID,SEQUENCE_NO,PLANNED_ARRIVAL,PLANNED_DISPATCH,CREATED_BY,MODIFIED_BY,FLOW_NAME,CREATED_TS,MODIFIED_TS) VALUES(?,?,?,?,?,?,?,?,?,?)";
	public static final String INSERT_TO_TRIP_HIERARCHY="INSERT INTO TRIP_HIERARCHY (TRIP_ID,CHILD_TRIP_ID,SYSTEM) VALUES(?,?,?)";
	public static final String INSERT_TO_CONSIGNMENT_INVOICE="INSERT INTO CONSIGNMENT_INVOICE (ORDER_NO,INVOICE_NO,SHIPMENT_NO,INVOICE_VALUE,INVOICED_DATE,EWB_STATUS,CREATED_BY,FLOW_NAME,AMOUNT_TO_BE_COLLECTED,CREATED_TS, MOP) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
    
	public static final String UPDATE_TO_ORDER_DETAILS="UPDATE ORDER_DETAILS SET SLOT_START_TIME=?, SLOT_END_TIME=? WHERE ORDER_ID=? AND SHIPMENT_NO=?";
	
	public static final String GET_TRIP="SELECT TRIP_ID,TYPE,SOURCE_NODE,PLANNED_START,PLANNED_END,ACTUAL_START,ACTUAL_END,STATUS,ASSIGNED_VEHICLE,START_KM,VRN_ID,END_KM, "
			+ " DP_ID,CREATED_BY,CREATED_TS, MODIFIED_TS, FLEET_TYPE,SUGGESTED_VEHICLE_TYPE,SUGGESTED_VEHICLE_NO, DP_NAME, EXTERNAL_REF_ID,FLOW_NAME, SUGGESTED_VEHICLE_NO, VERSION,LATITUDE,LONGITUDE,PLANNED_KM, CREATED_BY,MOVEMENT_TYPE FROM TRIP ";

	public static final String UPDATE_TRIP_STATUS="UPDATE TRIP SET STATUS=?,MODIFIED_TS=CURRENT_TIMESTAMP WHERE TRIP_ID=?";
	public static final String GET_TRIP_CONSIGNMENT_LABEL="SELECT TC.TRIP_ID,CL.SHIPMENT_NO,CL.LABEL_TYPE,TC.NODE_ID," +
			"CL.LABEL_ID,CL.STATUS, CL.PARENT_LABEL_ID FROM CONSIGNMENT_LABEL CL , TRIP_CONSIGNMENTS TC , TRIP T "
			+ "WHERE  TC.TRIP_ID=T.TRIP_ID AND T.SOURCE_NODE IN(:sourceNode) AND TC.TRIP_ID IN(:tripIds) AND TC.SHIPMENT_STATUS IN ('Active','Rescheduled') "
			+ " AND TC.SHIPMENT_NO=CL.SHIPMENT_NO";
	public static final String GET_TRIPS="SELECT T.TRIP_ID,T.TYPE,T.SOURCE_NODE,T.PLANNED_START,T" +
			".PLANNED_END,T.ACTUAL_START,T.ACTUAL_END,T.STATUS,T.ASSIGNED_VEHICLE, "
			+ "T.VRN_ID,T.DP_ID,T.DP_NAME,T.CREATED_TS,T.FLEET_TYPE,T.SUGGESTED_VEHICLE_TYPE, T.START_KM, T.END_KM, T" +
			".SUGGESTED_VEHICLE_NO, T.PLANNED_KM, T.EXTERNAL_REF_ID,T.MODIFIED_TS,T.VERSION,T.CREATED_BY,T" +
			".MOVEMENT_TYPE FROM TRIP T  WHERE T.SOURCE_NODE IN(:nodeIds)";

	public static final String GET_TRIPS_JOIN_WAYPOINT="SELECT T.TRIP_ID,T.TYPE,T.SOURCE_NODE,T.PLANNED_START, " +
			"T.PLANNED_END,T.ACTUAL_START,T.ACTUAL_END,T.STATUS,T.ASSIGNED_VEHICLE, " +
			"T.VRN_ID,T.DP_ID,T.DP_NAME,T.CREATED_TS,T.FLEET_TYPE,T.SUGGESTED_VEHICLE_TYPE, T.START_KM, T.END_KM, " +
			"T.SUGGESTED_VEHICLE_NO, T.PLANNED_KM, T.EXTERNAL_REF_ID,T.MODIFIED_TS,T.VERSION,T.CREATED_BY, " +
			"T.MOVEMENT_TYPE , sum(wu.AMOUNT_PAID) AMOUNT_PAID_SUM , sum(wu.ROUND_OFF_AMOUNT) ROUND_OFF_AMOUNT_SUM  " +
			"FROM TRIP T " +
			"left join waypoint_updates wu on t.trip_id = wu.trip_id " +
			"WHERE T.SOURCE_NODE IN(:nodeIds)  ";

	public static final String GET_TRIPS_JOIN_ADDITIONAL_DETAILS = "SELECT T.TRIP_ID,T.TYPE,T.SOURCE_NODE,T.PLANNED_START, " +
			"T.PLANNED_END,T.ACTUAL_START,T.ACTUAL_END,T.STATUS,T.ASSIGNED_VEHICLE, " +
			"T.VRN_ID,T.DP_ID,T.DP_NAME,T.CREATED_TS,T.FLEET_TYPE,T.SUGGESTED_VEHICLE_TYPE, T.START_KM, T.END_KM, " +
			"T.SUGGESTED_VEHICLE_NO, T.PLANNED_KM, T.EXTERNAL_REF_ID,T.MODIFIED_TS,T.VERSION,T.CREATED_BY, " +
			"T.MOVEMENT_TYPE , tad.VALUE AMOUNT_PAID_SUM, 0 as  ROUND_OFF_AMOUNT_SUM " +
			"FROM TRIP T " +
			"left join trip_additional_details tad on t.trip_id = tad.trip_id " +
			"WHERE T.SOURCE_NODE IN(:nodeIds) and tad.key in ('CASH_COLLECTED') ";

	public static final String GET_INBOUND_TRIPS="SELECT T.TRIP_ID, T.TYPE,T.SOURCE_NODE, "
			+ "T.PLANNED_START,T.PLANNED_END,T.ACTUAL_START,T.ACTUAL_END,T.STATUS,T.ASSIGNED_VEHICLE,T.DP_ID,T.DP_NAME,T.CREATED_TS,T.FLEET_TYPE,T.SUGGESTED_VEHICLE_TYPE, T.VRN_ID, T.START_KM, "
			+ " T.END_KM, T.SUGGESTED_VEHICLE_NO, T.PLANNED_KM, T.CREATED_BY,T.EXTERNAL_REF_ID,T.VERSION,T" +
			".MOVEMENT_TYPE FROM TRIP T ,TRIP_SEQUENCE TS WHERE TS.NODE_ID IN" +
			"(:nodeIds) AND T.STATUS IN (:status) AND T.CREATED_TS BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
			+ "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') AND TS.TRIP_ID=T.TRIP_ID  ";

	public static final String GET_TRIP_ADDITIONAL_DETAILS="SELECT * FROM TRIP_ADDITIONAL_DETAILS WHERE TRIP_ID IN (:tripId)";
	public static final String GET_HUB_SEQUENCE="SELECT TRIP_ID, NODE_ID, SEQUENCE_NO, PLANNED_ARRIVAL, PLANNED_DISPATCH, ACTUAL_ARRIVAL, ACTUAL_DISPATCH FROM TRIP_SEQUENCE WHERE TRIP_ID IN (:tripIds)";
	public static final String GET_CHILD_ROUTE_ID_COUNT="SELECT TRIP_ID, CHILD_TRIP_ID FROM TRIP_HIERARCHY WHERE TRIP_ID IN(:tripIds)";
	public static final String GET_CHILD_TRIP_IDS =" SELECT T.TRIP_ID ,T1.TRIP_ID AS CHILD_TRIP_ID FROM TRIP T ,TRIP T1 , TRIP_HIERARCHY TH WHERE T.EXTERNAL_REF_ID=TH.TRIP_ID " 
			+" AND T1.EXTERNAL_REF_ID=TH.CHILD_TRIP_ID AND TH.TRIP_ID IN(:referenceIds) ";
	public static final String GET_TRIP_COUNT_ON_STATUS="SELECT STATUS,COUNT(*) AS TRIP_COUNT FROM TRIP T WHERE T.SOURCE_NODE IN(:nodeIds) AND T.CREATED_TS BETWEEN "
			+ "TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ";
	public static final String GET_TRIP_COUNT_ON_STATUS_ON_INBOUND="SELECT STATUS,COUNT(*) AS TRIP_COUNT FROM TRIP T,TRIP_SEQUENCE TS WHERE TS.NODE_ID IN(:nodeIds) AND "
			+ "T.TRIP_ID=TS.TRIP_ID AND T.CREATED_TS BETWEEN "
			+ "TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ";
	public static final String INSERT_INTO_CONSIGNMENT_LABEL="INSERT INTO CONSIGNMENT_LABEL (LABEL_ID, PARENT_LABEL_ID,LABEL_TYPE,SHIPMENT_NO,STATUS,CREATED_TS) VALUES(?,?,?,?,?,?)";
	//public static final String UPDATE_STATUS_OF_SHIPMENT_LABEL="UPDATE CONSIGNMENT_LABEL SET STATUS =:status, MODIFIED_TS=CURRENT_TIMESTAMP, MODIFIED_BY=:modifiedBy WHERE LABEL_ID IN(:labelIds) AND SHIPMENT_NO=:shipmentNo";
	public static final String UPDATE_STATUS_OF_SHIPMENT_LABEL="UPDATE CONSIGNMENT_LABEL SET STATUS =?, MODIFIED_TS=CURRENT_TIMESTAMP, MODIFIED_BY=? WHERE LABEL_ID =? AND SHIPMENT_NO=?";
	public static final String GET_INVOICE_DETAILS_FOR_TRIP ="SELECT TC.SHIPMENT_NO, CI.ORDER_NO, CI.INVOICE_NO, CI.INVOICE_VALUE, CI.INVOICED_DATE, CI.EWB_NO, CI.EWB_STATUS, CI.AMOUNT_TO_BE_COLLECTED "
			+"FROM TRIP_CONSIGNMENTS TC, CONSIGNMENT_INVOICE CI, ORDER_DETAILS OD WHERE TC.SHIPMENT_NO=OD.SHIPMENT_NO AND "
			+"TC.SHIPMENT_NO=CI.SHIPMENT_NO  ";
	public static final String UPDATE_EWAYBILL_NUMBER_AND_STATUS="UPDATE CONSIGNMENT_INVOICE SET EWB_NO=?, EWB_STATUS=?,MODIFIED_BY=?,MODIFIED_TS=CURRENT_TIMESTAMP WHERE ORDER_NO=?";

	public static final String UPDATE_START_KM = "update trip set start_km=? ,modified_by=?, actual_start=SYSTIMESTAMP,modified_ts=SYSTIMESTAMP where trip_id=?";
	public static final String UPDATE_END_KM = "update trip set end_km=? ,modified_by=?,actual_end=SYSTIMESTAMP,modified_ts=SYSTIMESTAMP where trip_id=?";
	public static final String IS_EWAY_BILL_GENERATED="select shipment_no From consignment_invoice where shipment_no in (select shipment_no from trip_consignments where trip_id=?) and ewb_status in ('NOT GENERATED','FAILED')";
	public static final String UPDATE_DRIVER_DETAILS="update trip set assigned_vehicle=? , dp_id =?, dp_name=? , fleet_type=? , suggested_vehicle_type=? , vrn_id=?,modified_by=?,modified_ts=CURRENT_TIMESTAMP  where trip_id=?";
	public static final String ADD_TRIP_ADDITIONAL_DETAILS="insert into trip_additional_details (trip_id,node_id,key,value) values(?,?,?,?)";
	public static final String GET_VEHICLE_ASSIGNMENT="select assigned_vehicle from trip where assigned_vehicle in (:vehicles)";
	public static final String LOG_TRIP_EVENT="INSERT INTO TRIP_EVENT_LOG(TRIP_ID,NODE_ID,EVENT,FLOW_NAME,EVENT_CREATION_TIME,CREATED_BY,LAST_UPDATED_ON) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)";
	
	public static final String GET_TRIP_BY_REF_ID="SELECT TRIP_ID,TYPE,SOURCE_NODE,PLANNED_START,PLANNED_END,ACTUAL_START,ACTUAL_END,STATUS,ASSIGNED_VEHICLE,DP_ID,CREATED_TS,FLEET_TYPE,PLANNED_ORDER_COUNT,SUGGESTED_VEHICLE_TYPE FROM TRIP WHERE EXTERNAL_REF_ID IN(:externalRefId) AND FLOW_NAME= :flowName";
	public static final String GET_COUNT_OF_TRIPS_ON_GIVEN_DAY="SELECT COUNT(*) FROM TRIP WHERE TO_CHAR(PLANNED_START,'DD-MM-YY') = ? AND SOURCE_NODE=? AND MOVEMENT_TYPE=?";
	public static final String UPDATE_TRIP_MODIFIED_DETAILS="UPDATE TRIP SET MODIFIED_BY=?, FLOW_NAME=?, MODIFIED_TS=CURRENT_TIMESTAMP WHERE TRIP_ID=?";
	
	public static final String GET_TRIP_CONSIGNMENT_DETAILS="SELECT OD.ORDER_ID,TC.SHIPMENT_NO,TC.NODE_ID,TC.SHIPMENT_STATUS FROM TRIP_CONSIGNMENTS TC, ORDER_DETAILS OD WHERE TC.SHIPMENT_NO "
			+"IN(:shipmentNos) AND TC.SHIPMENT_NO=OD.SHIPMENT_NO AND TRIP_ID=:tripId";
	
	//public static final String UPDATE_SHIPMENT_STATUS_TRIP_CONSIGNMENT = "UPDATE TRIP_CONSIGNMENTS SET SHIPMENT_STATUS=:status, MODIFIED_BY=:modifiedBy, MODIFIED_TS=CURRENT_TIMESTAMP WHERE SHIPMENT_NO IN(:shipmentNos) AND TRIP_ID=:tripId";
	public static final String GET_ORDER_DETAILS="SELECT OD.ORDER_ID, OD.ORDER_DATE, OD.ORDER_TYPE, OD.ORDER_CLASSIFICATION,OD.ORDER_STATUS,C.ID,C.PINCODE,C.NAME,C.ADDRESS,TC.SHIPMENT_NO,TC.NODE_ID,TC.SHIPMENT_STATUS,TC.SLOT_START,TC.SLOT_END,TC.LATITUDE,"
			+ "TC.LONGITUDE, TC.DELIVERY_ZONE_ID FROM TRIP_CONSIGNMENTS TC, TRIP T, ORDER_DETAILS OD, CUSTOMER_DETAILS C WHERE "
			+"OD.ORDER_ID=C.ORDER_ID AND TC.SHIPMENT_NO=OD.SHIPMENT_NO AND TC.TRIP_ID=T.TRIP_ID";
	public static final String UPDATE_SHIPMENT_STATUS_TRIP_CONSIGNMENT="UPDATE TRIP_CONSIGNMENTS SET SHIPMENT_STATUS=:status, FLOW_NAME=:flowName, MODIFIED_BY=:modifiedBy,"
			+ " MODIFIED_TS=CURRENT_TIMESTAMP WHERE SHIPMENT_NO IN(:shipmentNos)";
	
	public static final String UPDATE_SHIPMENTS_TRIP_CONSIGNMENT="UPDATE TRIP_CONSIGNMENTS SET MODIFIED_TS=MODIFIED_TS "
			+ " WHERE SHIPMENT_NO IN(:shipmentNos)";
	
	public static final String UPDATE_SHIPMENT_STATUS ="UPDATE TRIP_CONSIGNMENTS SET SHIPMENT_STATUS=:status, MODIFIED_BY=:modifiedBy, FLOW_NAME=:flowName, MODIFIED_TS=CURRENT_TIMESTAMP WHERE SHIPMENT_NO"
			+ " IN( SELECT SHIPMENT_NO FROM ORDER_DETAILS WHERE ORDER_ID IN(:orderIds))";
		
	public static final String GET_STATE_WISE_BUSINESS_DETAILS=	"SELECT ID,NAME,GSTIN,ADDRESS,CODE FROM STATE_WISE_BUSINESS_DETAILS WHERE CODE in (:stateCodes)";

	public static final String GET_DELIVERY_CHALLAN_SEQ ="select delivery_challan_seq.nextval as id from dual connect by level <= ?";
	
	public static final String GET_PICKUP_CHALLAN_SEQ ="select pickup_challan_seq.nextval as id from dual connect by level <= ?";

	public static final String GET_CHALLANS_HUB_ID_BY_TRIP="select trip_id, node_id , challan_id from delivery_challan_articles where trip_id in (:tripIds)";
	
	public static final String DELETE_TRIP_CONSIGNMENTS="DELETE FROM TRIP_CONSIGNMENTS WHERE SHIPMENT_NO IN(:shipmentNos) AND TRIP_ID IN(SELECT T.TRIP_ID FROM "
			+ " TRIP T, TRIP_CONSIGNMENTS TC WHERE T.SOURCE_NODE=:nodeId AND TC.TRIP_ID=T.TRIP_ID) AND  SHIPMENT_STATUS=:status";
	public static final String UPDATE_TRIP_DETAILS="UPDATE TRIP SET TRIP_ID=?,TYPE=?,SOURCE_NODE=?,PLANNED_START=?,PLANNED_END=?,STATUS=?,MODIFIED_BY=?,FLEET_TYPE=?,SUGGESTED_VEHICLE_TYPE=?,FLOW_NAME=?,SUGGESTED_VEHICLE_NO=?,MODIFIED_TS=CURRENT_TIMESTAMP WHERE ID=?";

	public static final String GET_INITIAL_AMOUNT = "SELECT VALUE FROM TRIP_ADDITIONAL_DETAILS WHERE TRIP_ID=? AND KEY='INITIAL_AMOUNT'";

	public static final String ORDER_DETAILS=" SELECT * FROM ORDER_DETAILS WHERE ";
	public static final String GET_ORDER_DETAILS_COUNT = "select distinct(od.order_id) orderId,  od.CREATED_TIME " +
			"from order_details od " +
			"left join customer_details cd  on od.order_id = cd.order_id  and od.shipment_no = cd.shipment_no " +
			"left join trip_consignments tc on  od.shipment_no =tc.shipment_no " +
			"left join trip on tc.trip_id = trip.trip_id " +
			"WHERE od.order_date BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "+
			"AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ";

	public static final String ORDER_DETAILS_PAGINATION="select cd.name name, trip.type, od.order_id, od.shipment_no, od.order_date, od.slot_start_time, od.order_type, od.order_classification, cd.pincode, cd.address, od.order_status, od.modified_time, cd.id mid, tc.node_id next_node, tc.shipment_status, tc.delivery_zone_id  " +
			"from order_details od " +
			"left join customer_details cd  on od.order_id = cd.order_id  and od.shipment_no = cd.shipment_no " +
			"left join trip_consignments tc on  od.shipment_no =tc.shipment_no " +
			"left join trip on tc.trip_id = trip.trip_id " +
			"WHERE od.order_date BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "+
			"AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ";

	public static final String GET_LIST_OF_TRIP = "SELECT T.TRIP_ID,T.TYPE,T.SOURCE_NODE,T.PLANNED_START,T.PLANNED_END,T.VRN_ID,T.START_KM,T.END_KM,T.ACTUAL_START,T.PLANNED_KM,T.ACTUAL_END,T.STATUS,T.ASSIGNED_VEHICLE,T.DP_ID,T.DP_NAME,T.CREATED_TS,T.FLEET_TYPE,T.SUGGESTED_VEHICLE_TYPE,T.SUGGESTED_VEHICLE_NO, T.VERSION,T.EXTERNAL_REF_ID,T.CREATED_BY,T.MOVEMENT_TYPE FROM TRIP T WHERE T.TRIP_ID IN(:tripId)";
	
	public static final String UPDATE_FCTRIP_DETAILS_ONSETTLE= "UPDATE TRIP SET END_KM=? ,MODIFIED_BY=?,FLOW_NAME=?, MODIFIED_TS=CURRENT_TIMESTAMP WHERE TRIP_ID=?";
		
	public static final String ADD_RETURN_ITEMS="insert into return_items(forward_order_id,return_order_id ,prime_line_no,item_id,item_name,ordered_qty,hsn_code,unit_price,uom,received_qty,invoiced_qty,return_type,flow_name)  values (?,?,?,?,?,?,?,?,?,?,?,?,?) ";
	
	public static final String UPDATE_TRIP_SEQUENCE_ACTUAL_ARRIVAL="UPDATE TRIP_SEQUENCE SET ACTUAL_ARRIVAL=?,MODIFIED_BY=?,MODIFIED_TS=CURRENT_TIMESTAMP, FLOW_NAME=? WHERE TRIP_ID=? AND NODE_ID=?";
	
	public static final String UPDATE_TRIP_SEQUENCE_ACTUAL_DISPATCH="UPDATE TRIP_SEQUENCE SET ACTUAL_DISPATCH=:dispatchTime,MODIFIED_BY=:flowname,MODIFIED_TS=CURRENT_TIMESTAMP, FLOW_NAME=:flowname WHERE TRIP_ID=:tripId ";
	
	public static final String UPDATE_ADDITIONAL_DETAILS="UPDATE TRIP_ADDITIONAL_DETAILS SET VALUE=? WHERE TRIP_ID=? AND KEY=? AND NODE_ID=?";
	
	public static final String DELETE_ADDITIONAL_DETAILS="DELETE TRIP_ADDITIONAL_DETAILS WHERE TRIP_ID=:tripId AND KEY=:key AND NODE_ID=:nodeId";
	
	public static final String DELETE_ADDITIONAL_DETAILS_BY_TRIP="DELETE TRIP_ADDITIONAL_DETAILS WHERE TRIP_ID=:tripId AND KEY in (:key) ";
	
	public static final String GET_AVAILABLE_DRIVERS = "select user_name as DP_ID, first_name|| ' ' ||last_name as DP_Name  from user_details where user_name in (select user_name from user_details where role='DeliveryPartner' and node_id=:nodeId minus select trip.dp_id from trip where status not in('SETTLED','CANCELLED')) AND ACCOUNT_STATUS='ACTIVE' ";
	
	public static final String GET_SHIPMENT_LABEL_TRIP_MAPPING="select seq.node_id , seq.sequence_no , consignment.shipment_no , label.label_id , label.label_type , label.status " + 
			"from trip_sequence seq , trip_consignments consignment , consignment_label label " + 
			"where seq.node_id=consignment.node_id and " + 
			"seq.trip_id=consignment.trip_id and " + 
			"consignment.shipment_no = label.shipment_no and " + 
			"consignment.shipment_status in('Active','Rescheduled') and " +
			"label.label_type in ('Tote','HU') and " + 
			"seq.trip_id=? order by seq.sequence_no asc";
	
	public static final String GET_TRIP_CONSIGNMENT_INFO=" SELECT TC.TRIP_ID,T.STATUS,T.SOURCE_NODE,T.VERSION,CI.INVOICE_NO,OD.ORDER_ID,TC.SHIPMENT_NO,TC.NODE_ID,TC.SHIPMENT_STATUS,TC.SLOT_START,"
			+ "TC.SLOT_END,TC.LONGITUDE ,TC.LATITUDE FROM TRIP_CONSIGNMENTS TC INNER JOIN TRIP T ON TC.TRIP_ID=T.TRIP_ID INNER JOIN ORDER_DETAILS OD ON "
			+ "OD.SHIPMENT_NO=TC.SHIPMENT_NO LEFT JOIN CONSIGNMENT_INVOICE CI ON CI.SHIPMENT_NO=TC.SHIPMENT_NO ";
			
             
	
	public static final String GET_TRIP_CONSIGNMENT_INFO_="SELECT TC.TRIP_ID,OD.ORDER_ID,TC.SHIPMENT_NO,TC.NODE_ID,TC.SHIPMENT_STATUS,TC.SLOT_START,TC.SLOT_END,TC.LONGITUDE"
			+ ",TC.LATITUDE FROM TRIP_CONSIGNMENTS TC, ORDER_DETAILS OD, TRIP T WHERE TC.SHIPMENT_NO IN(:shipmentNos) AND OD.SHIPMENT_NO=TC.SHIPMENT_NO AND TC.TRIP_ID=T.TRIP_ID AND T.SOURCE_NODE =:nodeId ";
	
	public static final String UPDATE_TRIP_VERSION="UPDATE TRIP SET VERSION=VERSION+1 , MODIFIED_TS=CURRENT_TIMESTAMP , FLOW_NAME =?, MODIFIED_BY=? WHERE TRIP_ID =?";
	
	public static final String GET_NODE_ORDER_ROUTE="SELECT NODE_ID, ORDER_ID, PRE_ROUTE_ID, NEXT_ROUTE_ID FROM NODE_ORDER_ROUTE WHERE NODE_ID=:nodeId AND ORDER_ID IN(:orderIds)";
	public static final String GET_ACTUAL_DISPATCH_TIME="select node_id from trip_sequence where actual_dispatch is null and trip_id=?";
	
	public static final String GET_AVAILABLE_RETURN_ORDERS_ON_NODE="select ri.return_order_id from return_items  ri , order_details od where ri.return_order_id = od.order_id and od.source_node=? and ri.node_id=? and ri.invoiced_qty>0 and ri.challan_id is null ";
	
	public static final String GET_AVAILABLE_RETURN_ORDERS_BY_ID="select return_order_id from return_items where return_order_id in (:returnOrderIds) and challan_id is null";
	
	public static final String GET_AVAILABLE_RETURN_ITEMS_BY_ORDER_ID="select item_id , item_name , sum(invoiced_qty) as expected_qty, sum(received_qty) as quantity from return_items where return_order_id in (:returnOrderIds) group by item_id , item_name ";
	
	public static final String GET_RETURN_ITEMS_BY_ORDER_ID="select challan_id , return_order_id , forward_order_id,prime_line_no , item_id , item_name ,"+
			"ordered_qty , hsn_code , unit_price , uom , RECEIVED_QTY , invoiced_qty , return_type from return_items where ";
	
	public static final String GET_ITEMS_ACCUMULATED_BY_ORDER="select return_order_id , item_id , sum(invoiced_qty) as qty from return_items where  return_order_id in (:returnOrderIds) group by return_order_id, item_id";
	
	public static final String UPDATE_RETURN_ITEMS_CHALLAN_ID_CONSTRAINED="update return_items set challan_Id=? , last_updated_on=CURRENT_TIMESTAMP where return_order_id=? and challan_id is null";
	
	public static final String UPDATE_RETURN_ITEMS_CHALLAN_ID="update return_items set challan_Id=? , last_updated_on=CURRENT_TIMESTAMP where return_order_id=?";
	
	public static final String UPDATE_RETURN_ITEMS_CHALLAN_ID_BY_ORDER_IDS="update return_items set challan_Id=:challanId , last_updated_on=CURRENT_TIMESTAMP where return_order_id in (:returnOrderIds)";
	
	public static final String INSERT_DELIVERY_CHALLAN_ARTICLES="insert into delivery_challan_articles(challan_id, trip_id, return_order_id, article_id, quality , article_type,qty,created_by,node_id, created_on,last_updated_on) values(?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)";
	
	public static final String DELETE_DELIVERY_CHALLAN_ARTICELS="delete from delivery_challan_articles where return_order_id in (:returnOrderIds)";
	
	public static final String GET_ARTICLES_BY_CHALLAN_ID= "select challan_id , trip_id , return_order_id , article_id , article_type , sum(qty) qty  from  delivery_challan_articles " + 
			"where challan_id in (:challanIds) and trip_id=:tripId " + 
			"group by challan_id , trip_id , return_order_id , article_id,article_type ";
	
	public static final String GET_DELIVERY_CHALLAN_ARTICLES_FOR_TRIP="select challan_id , trip_id , return_order_id , article_id , " + 
			"sum (qty) as qty from delivery_challan_articles where article_type=:articleType and trip_id=:tripId " + 
			"and quality in (:qualities) group by challan_id, trip_id, return_order_id, article_id";
	
	public static final String GET_DELIEVERY_CHALLAN_ARTICLES_BY_ID=" select challan.challan_id , challan.trip_id , challan.return_order_id , challan.article_id , return.return_type , " + 
			" challan.article_type , challan.qty  from delivery_challan_articles challan  Left join return_items return " + 
			" ON challan.challan_id = return.challan_id and return.return_order_id=challan.return_order_id and " + 
			" challan.article_id= return.item_id where challan.challan_id=? ";
	
	public static final String GET_CHALLAN_ARTICLE_QUALITY="select challan_id ,  return_order_id , article_id , quality from delivery_challan_articles where article_type='RETURN_ITEM' and return_order_id in (:returnOrderId)";
	
	public static final String INSERT_TO_WAYPOINT_UPDATE="INSERT INTO WAYPOINT_UPDATES(TRIP_ID,WAY_POINT_ID,NODE_ID,FWD_ORDER_ID,ORDER_CLASSIFICATION,STATUS,SHOULD_RECONCILE,CREATED_BY,CREATED_TS,FLOW_NAME,AMOUNT_PAID, ROUND_OFF_AMOUNT) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

	public static final String UPDATE_ORDER_STATUS="UPDATE ORDER_DETAILS SET ORDER_STATUS=:status , MODIFIED_BY=:modifiedBy, FLOW_NAME=:flowName, MODIFIED_TIME=CURRENT_TIMESTAMP WHERE ORDER_ID IN(:orderIds)";

	
	public static final String DEASSOCIATE_TRIP_HIERARCHY="DELETE FROM TRIP_HIERARCHY WHERE TRIP_ID=? AND CHILD_TRIP_ID=?";
	public static final String UPDATE_ORDER_DETAILS_GENERIC="UPDATE ORDER_DETAILS SET ";

	public static final String GET_WAY_POINT_UPDATES="SELECT TRIP_ID, WAY_POINT_ID, NODE_ID,FWD_ORDER_ID, ORDER_CLASSIFICATION, SHOULD_RECONCILE, STATUS, AMOUNT_PAID, ROUND_OFF_AMOUNT FROM WAYPOINT_UPDATES WHERE TRIP_ID=?";

	public static final String GET_WAYPOINT_TRIP_ORDER_CUSTOMER_INVOICE = "SELECT WU.TRIP_ID, WU.FWD_ORDER_ID, WU.ORDER_CLASSIFICATION, WU.AMOUNT_PAID, WU.ROUND_OFF_AMOUNT, TRUNC(WU.CREATED_TS) DELIVERED_DATE, " +
			"CI.MOP," +
			"OD.ORDER_STATUS," +
			"CD.ID, CD.NAME, " +
			"T.ASSIGNED_VEHICLE, T.DP_ID " +
			"FROM WAYPOINT_UPDATES WU  " +
			"LEFT JOIN CONSIGNMENT_INVOICE CI on WU.fwd_order_id = CI.ORDER_NO  " +
			"LEFT JOIN ORDER_DETAILS OD on WU.fwd_order_id = OD.ORDER_ID " +
			"LEFT JOIN CUSTOMER_DETAILS CD on WU.fwd_order_id = CD.ORDER_ID " +
			"LEFT JOIN TRIP T on WU.TRIP_ID = T.TRIP_ID " +
			"WHERE WU.TRIP_ID=? ";

	public static final String DEASSOCIATE_TRIP_SEQUENCE="DELETE FROM TRIP_SEQUENCE WHERE TRIP_ID =? AND NODE_ID=?";
	public static final String UPDATE_CURRENT_ROUTE_ID="UPDATE NODE_ORDER_ROUTE SET CURRENT_ROUTE_ID= :routeId WHERE NODE_ID= :nodeId AND ORDER_ID in (:orderIds)";
	public static final String UPDATE_PRE_ROUTE_ID ="UPDATE NODE_ORDER_ROUTE SET PRE_ROUTE_ID =:routeId WHERE ORDER_ID IN(:orderIds)"
			+ " AND PRE_ROUTE_ID=:preRouteId ";
	public static final String UPDATE_NEXT_ROUTE_ID ="UPDATE NODE_ORDER_ROUTE SET NEXT_ROUTE_ID =:routeId WHERE ORDER_ID IN(:orderIds)"
			+ " AND NEXT_ROUTE_ID=:nextRouteId ";
	public static final String INSERT_TO_ADHOC_TRIP_REQUEST="INSERT INTO ADHOC_TRIP_REQUEST(NODE_ID,ORDER_ID,TRIP_ID,STATUS,FLOWNAME,CREATED_BY,CREATED_TS) VALUES(?,?,?,?,?,?,?)";
	public static final String GET_ADHOC_TRIP_REQUEST="SELECT NODE_ID,ORDER_ID,TRIP_ID,STATUS FROM ADHOC_TRIP_REQUEST WHERE ORDER_ID IN(:orderIds) AND NODE_ID =:nodeId AND STATUS=:status";
	public static final String ADHOC_TRIP_REQUEST_STATUS_UPDATE ="UPDATE ADHOC_TRIP_REQUEST SET STATUS=:status WHERE ORDER_ID IN(:orderIds) AND NODE_ID=:nodeId";
	public static final String INSERT_TO_NODE_ORDER_ROUTE="INSERT INTO NODE_ORDER_ROUTE(NODE_ID,ORDER_ID,PRE_ROUTE_ID,NEXT_ROUTE_ID) VALUES(?,?,?,?)";
	
	
	/*public static final String GET_DELIVERY_CHALLAN_ARTICLES_FOR_TRIP_WITH_HUB="SELECT CHALLAN.RETURN_ORDER_ID, CHALLAN.ARTICLE_ID,CHALLAN.QTY,"
			+ "CHALLAN.QUALITY,RETURN.ITEM_NAME,RETURN.UNIT_PRICE,RETURN.INVOICED_QUANTITY, RETURN.RETURN_TYPE FROM DELIVERY_CHALLAN_ARTICLES CHALLAN , RETURN_ITEMS "
			+ "RETURN WHERE RETURN.RETURN_ORDER_ID = CHALLAN.RETURN_ORDER_ID AND CHALLAN.ARTICLE_ID=RETURN.ITEM_ID AND CHALLAN.TRIP_ID=? AND CHALLAN.NODE_ID=?"
			+ " AND CHALLAN.ARTICLE_TYPE=?";*/
	public static final String GET_DELIVERY_CHALLAN_ARTICLES_FOR_TRIP_ID="select challan_id , trip_id , return_order_id , article_id ,quality, qty as qty from "
			+ "delivery_challan_articles where article_type=:articleType and trip_id =:tripId and node_id in (:nodeId)";
			
	public static final String DELETE_TRIP_SEQUENCE ="DELETE FROM TRIP_SEQUENCE WHERE TRIP_ID= :tripId AND NODE_ID IN(:nodeIds)";
	
	public static final String INSERT_RETURN_ITEM_V2 = "INSERT INTO return_items (FORWARD_ORDER_ID, RETURN_ORDER_ID, PRIME_LINE_NO, ITEM_ID, ITEM_NAME, INVOICED_QTY, HSN_CODE, UNIT_PRICE, UOM, RETURN_TYPE, FLOW_NAME, CREATED_BY,CREATED_ON) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)";
	
	public static final String GET_DELIVERED_ORDERS="SELECT FWD_ORDER_ID FROM WAYPOINT_UPDATES WHERE TRIP_ID=:tripId AND SHOULD_RECONCILE='Y'";
	
	public static final String GET_RETURN_ITEM="SELECT FORWARD_ORDER_ID, RETURN_ORDER_ID, PRIME_LINE_NO, ITEM_NAME, ITEM_ID, HSN_CODE, INVOICED_QTY, UNIT_PRICE, UOM, RETURN_TYPE FROM return_items WHERE FORWARD_ORDER_ID IN (:orderId) and INVOICED_QTY > 0";
	
	public static final String UPDATE_RETURN_ITEM = "UPDATE return_items SET RECEIVED_QTY=?, NODE_ID=? ,LAST_UPDATED_ON=CURRENT_TIMESTAMP WHERE RETURN_ORDER_ID=? and ITEM_ID=? and PRIME_LINE_NO=?";

	public static final String UPDATE_TRIP_DELIVERY_CHALLAN_ARTICLES="update delivery_challan_articles set received_qty=? , last_updated_on=CURRENT_TIMESTAMP where return_order_id=? and article_id=? and trip_id=? and quality=?";

	public static final String UPDATE_DELIVERY_CHALLAN_TRIP_ID="update delivery_challan_articles set trip_id=:tripId , last_updated_on=CURRENT_TIMESTAMP where return_order_id in (:returnOrderIds)";

	public static final String GET_CHALLAN_IDS_BY_TRIP = "select challan_id from delivery_challan_articles where trip_id=? and node_id=?";
	
	public static final String GET_CHALLAN_ID_BY_ORDER_ID = "select challan_id from delivery_challan_articles where return_order_id=?";
	
	public static final String GET_USER_DETAILS_BY_TRIP="select user_name , mobile_no from user_details where user_name in (select dp_id from trip where trip_id in (:tripIds) and dp_id is not null)";
	
	public static final String GET_ORDER_IDS_TRIP_CLASSIFICATION="select source_node,order_id from order_details where order_classification=? and shipment_no in (select shipment_no from trip_consignments where trip_id=?)";

	public static final String GET_RETURN_ORDERS_COUNT="select tc.trip_id , count(od.shipment_no) as count from trip_consignments tc , order_details od where tc.shipment_no=od.shipment_no "+ 
			"and od.order_classification='Return' and tc.trip_id in (:tripIds) group by tc.trip_id ";

	public static final String GET_ORDER_IDS_FOR_GIVEN_TRIP="select od.* " +
			"from order_details od  " +
			"join trip_consignments tc on tc.shipment_no = od.shipment_no " +
			"where tc.trip_id =:tripId and tc.shipment_status='Active' ";

	public static final String GET_TRIPS_FOR_GIVEN_SHIPMENT = "select trip.source_node, trip.trip_id, trip.type, trip.status,trip.movement_type,trip.modified_ts, tc.shipment_status, tc.node_id  from trip " +
			"join trip_consignments tc on trip.trip_id = tc.trip_id " +
			"where tc.shipment_no = :shipmentNo  and tc.shipment_status='Active' ";

	public static final String GET_UNASSIGNMENT_INITIATED_TRIPS = "SELECT TA.TRIP_ID, TA.STATUS,TA.VEHICLE_ID, TA.DRIVER_ID FROM TRIP_ACTIVITY TA WHERE TA.CREATED_TS > SYSDATE-(:reservedThreshold/24*60) AND TA.STATUS=:status AND ROWNUM<=:rowNum ORDER BY TA.CREATED_TS ASC";

	public static final String GET_TRIP_ACTIVITY ="select trip_id , vehicle_id , driver_id , status from trip_activity where trip_id=? and status=? ";
	
	public static final String UPDATE_TRIPACTIVITY_STATUS ="UPDATE TRIP_ACTIVITY SET STATUS=:status, MODIFIED_BY=:modifiedBy, MODIFIED_TS=CURRENT_TIMESTAMP WHERE TRIP_ID=:tripId and status=:oldStatus";

	public static final String INSERT_TRIP_ACTIVITY="insert into trip_activity(trip_id,vehicle_id,driver_id,status,created_by,modified_by,created_ts,modified_ts) values (?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)";
	
	public static final String GET_CUSTOMER_INFO_BY_ORDER_ID="select order_id,customer_id,customer_name,customer_address,customer_pincode,customer_state,customer_state_code,customer_gstn from order_details where order_id in (:orderIds)";

	public static final String UPDATE_CHALLAN_ARTICLE_DETAILS="update delivery_challan_articles set qty=? ,trip_id=? , last_updated_on=CURRENT_TIMESTAMP where return_order_id =? and article_id=? and quality=?";
	
	public static final String GET_SOURCE_NODE_BY_ORDER_IDS="select order_id,source_node from order_details where order_id in (:orderIds)";

	public static final String UPDATE_INVOICED_QTY_RETURN_ITEM = "UPDATE return_items SET INVOICED_QTY=?, LAST_UPDATED_ON=CURRENT_TIMESTAMP WHERE RETURN_ORDER_ID=? and ITEM_ID=? and PRIME_LINE_NO=?";
	
	public static final String INSERT_TO_ADDRESS_DETAILS = "INSERT INTO CUSTOMER_DETAILS (ORDER_ID,SHIPMENT_NO,SOURCE_NODE,NAME,ADDRESS,PINCODE,ID,STATE_CODE,GSTN,STATE,CREATED_TS,CREATED_BY,FLOW_NAME,CITY,PHONE_NUMBER) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String GET_ORDER_DETAIL_FOR_MANIFEST = "SELECT TS.SEQUENCE_NO, OD.ORDER_ID, TC.SHIPMENT_NO, OD.ORDER_TYPE, OD.ORDER_CLASSIFICATION, CD.NAME, "
			+ "CD.ADDRESS, CD.PINCODE, CI.INVOICE_NO, CI.INVOICE_VALUE, CI.AMOUNT_TO_BE_COLLECTED, CI.EWB_NO, CI.EWB_STATUS, CI.MOP, CD.PHONE_NUMBER "
			+ " FROM TRIP_CONSIGNMENTS TC " +
			"INNER JOIN ORDER_DETAILS OD ON TC.SHIPMENT_NO=OD.SHIPMENT_NO " +
			"LEFT JOIN CONSIGNMENT_INVOICE CI ON TC.SHIPMENT_NO=CI.SHIPMENT_NO  " +
			"LEFT JOIN CUSTOMER_DETAILS CD ON OD.ORDER_ID=CD.ORDER_ID AND OD.SHIPMENT_NO=CD.SHIPMENT_NO "
			+ "LEFT JOIN TRIP_SEQUENCE TS ON TC.NODE_ID=TS.NODE_ID AND TC.TRIP_ID=TS.TRIP_ID "
			+ " WHERE TC.SHIPMENT_STATUS IN (:status) AND TC.TRIP_ID=:tripId ORDER BY ts.sequence_no asc";
	
	public static final String GET_TRIP_ORDERS_BY_TRIPID="SELECT TC.TRIP_ID,TC.SHIPMENT_NO,TC.NODE_ID,TC.LATITUDE,TC.LONGITUDE,TC.SLOT_START,TC.SLOT_END,TC.DELIVERY_ZONE_ID,TS.SEQUENCE_NO,"
			+ "TS.PLANNED_ARRIVAL, TS.PLANNED_DISPATCH,O.ORDER_ID,O.ORDER_CLASSIFICATION FROM TRIP T, TRIP_CONSIGNMENTS TC,ORDER_DETAILS O, TRIP_SEQUENCE "
			+ "TS WHERE T.TRIP_ID= :tripId AND TC.TRIP_ID=T.TRIP_ID AND TC.SHIPMENT_STATUS IN(:status) AND TC.SHIPMENT_NO=O.SHIPMENT_NO AND "
			+ "TS.TRIP_ID=TC.TRIP_ID AND TS.NODE_ID=TC.NODE_ID";
	
	public static final String DELETE_TRIP_CONSIGNMENTS_BY_TRIPID="DELETE FROM TRIP_CONSIGNMENTS WHERE TRIP_ID=:tripId AND SHIPMENT_NO IN(:shipmentNos)";

	public static final String INSERT_TO_ORDER_INTERMEDIARIES = "insert into order_intermediaries (ORDER_ID, NODE_ID) values(?,?)";
	public static final String GET_CONSIGNMENT_LABEL = "select * from consignment_label where shipment_no=:shipmentNo";

	public static final String UPDATE_VEHICLE_DETAILS="update trip set assigned_vehicle=? , dp_id =?, dp_name=? , modified_by=?,modified_ts=CURRENT_TIMESTAMP  where trip_id=?";

	public static final String GET_COUNT_OF_INVOICE_FOR_GIVEN_ORDER = "select count(*) from consignment_invoice  where order_no =:orderNo ";

	public static final String GET_TRIPS_SHIPMENT = "select * from trip " +
			"join trip_consignments tc on tc.trip_id  = trip.trip_id " +
			"where  tc.shipment_no=:shipmentNo";

	public static final String GET_LAST_WAY_POINT_UPDATE_FOR_ORDER = "select status from waypoint_updates " +
			"where fwd_order_id = :orderId " +
			"order by created_ts desc " +
			"fetch next 1 rows only";

	public static final String SUSPENDED_ORDER_COUNT = "select count(*) from trip_consignments where shipment_status='Suspend'  ";
	
	public static final String GET_TRIPS_TOBE_CANCELLED ="SELECT T.TRIP_ID,T.TYPE,T.SOURCE_NODE,T.PLANNED_START,T.PLANNED_END,T.VRN_ID,T.START_KM,T.END_KM,T.ACTUAL_START,"
			+ "T.PLANNED_KM,T.ACTUAL_END,T.STATUS,T.ASSIGNED_VEHICLE,T.DP_ID,T.DP_NAME,T.CREATED_TS,T.FLEET_TYPE,T.SUGGESTED_VEHICLE_TYPE,T.SUGGESTED_VEHICLE_NO, T.VERSION,T.EXTERNAL_REF_ID,"
			+ "T.CREATED_BY,T.MOVEMENT_TYPE from  trip t where t.trip_id not in(select trip_id from trip_consignments where shipment_status  in "
			+ "(:shipmentStatus))  and t.status in(:status) and t.movement_type=:movementType AND T.MODIFIED_TS < SYSTIMESTAMP - numtodsinterval(:interval,:unit) "
			+ " AND ROWNUM<=:fetchSize  ORDER BY T.MODIFIED_TS ASC";
	
	public static final String SETTLEMENT_UPDATE_GET_ORDER_DETAILS = "select w.fwd_order_id,od.shipment_no,w.amount_paid,w.round_off_amount from waypoint_updates w, order_details od where"
			+ " w.fwd_order_id=od.order_id and w.trip_id=? and amount_paid>0";
	
	public static final String SETTLEMENT_UPDATE_GET_TRIP_DETAILS = "select * from trip_additional_details where"
			+ " key in ('CASH_COLLECTED','CASH_TO_BE_COLLECTED') and trip_id=?";

	public static final String COLLECTED_AMOUNT_FOR_TRIP = "select ad.KEY, ad.VALUE,  to_char(t.MODIFIED_TS, 'dd-mm-yyyy') TRIP_SETTLED_DATE from  trip_additional_details ad " +
			"join trip t on ad.trip_id =  t.trip_id  " +
			"where T.MODIFIED_TS BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') " +
			"and ad.KEY in ('CASH_TO_BE_COLLECTED','CASH_COLLECTED') " +
			"and t.SOURCE_NODE=:nodeId " +
			"order by TRIP_SETTLED_DATE desc ";
	
	public static final String INSERT_CONNECTION_TRIP="insert into trip(trip_id,type,source_node,planned_start,created_ts,status,created_by,external_ref_id,flow_name,movement_type) " + 
			"values (?,?,?,?,?,?,?,?,?,?)";
	
	public static final String INSERT_CONNECTION_TRIP_SEQUENCE="insert into trip_sequence(trip_id,node_id,sequence_no,created_by,created_ts,flow_name) " + 
			"values (?,?,?,?,?,?)";
	
	public static final String GET_COUNT_OF_CONNECTIONS="select trip_id from trip_sequence where trip_id = ?";
	
	public static final String GET_CONNECTIONS="select node_id from trip_sequence where trip_id = ?";

	public static final String TRIP_COUNT_SDP = "select   sum(case when t.status='CREATED' then 1 else 0 end)  as TRIPS_CREATED, " +
			" sum(case when t.status='LOADING_INPROGRESS' then 1 else 0 end) as LOADING_IN_PROGRESS, " +
			" ts.node_id SDP_ID " +
			" from trip t " +
			" join trip_sequence ts on t.trip_id = ts.trip_id " +
			" where t.status in ('CREATED','ASSIGNED', 'LOADING_INPROGRESS') " +
			" and ts.node_id in (:sdpIds) ";

	public static final String ORDER_COUNT_FOR_SDP = " select count(od.order_id) as TOTAL_ORDERS, " +
			" sum(case when od.order_status='INVOICED' then 1 else 0 end) as TOTAL_INVOICED, " +
			" sum(case when od.order_status='STAGED' then 1 else 0 end) as TOTAL_STAGED, " +
			" oi.node_id SDP_ID" +
			" from ORDER_DETAILS od " +
			" join order_intermediaries oi on od.order_id = oi.order_id  " +
			" WHERE od.order_status in ('CREATED','INVOICED','STAGED') " +
			" AND  ( oi.node_id in (:sdpIds) )  ";

	public static final String HU_COUNT_FOR_SDP = "select od.order_id, oi.node_id SDP_ID, count(cl.label_id) HU_COUNT, " +
			" sum(case when cl.status='Damaged' or  cl.status='Missed' then 1 else 0 end) as MISSED_COUNT  " +
			" from order_intermediaries oi " +
			" left join order_details od on od.order_id = oi.order_id " +
			" left join consignment_label cl on cl.shipment_no =od.shipment_no " +
			" where ( oi.node_id in (:nodeIds) OR od.source_node in (:nodeIds))  " +
			" and  od.order_status in ('STAGED') " +
			" and cl.label_type in ('HU')";

	public static final String ORDER_DETAILS_FOR_FLUID_LOADING = "select  od.order_id,  od.order_date, od.slot_start_time, od.order_type, od.order_classification, cd.pincode, cd.address, od.order_status,  cd.id mid, cd.name,  od.delivery_zone_id, oi.node_id hubId " +
			" from ORDER_DETAILS od " +
			" join order_intermediaries oi on od.order_id = oi.order_id  " +
			" join customer_details cd on od.order_id = cd.order_id " +
			" WHERE od.order_status in ('CREATED','INVOICED','STAGED') " +
			" and ( oi.node_id in (:nodeIds) OR od.source_node in (:nodeIds)) ";

	public static final String ORDER_COUNT_FOR_FLUID_LOADING = "select count(  od.order_id)  total" +
			" from ORDER_DETAILS od " +
			" join order_intermediaries oi on od.order_id = oi.order_id  " +
			" join customer_details cd on od.order_id = cd.order_id " +
			" WHERE od.order_status in ('CREATED','INVOICED','STAGED') " +
			" AND ( oi.node_id in (:nodeIds) OR od.source_node in (:nodeIds)) ";

	public static final String GET_LOADED_ORDER_COUNT = "SELECT count(order_id) total FROM " +
			"ORDER_DETAILS od LEFT JOIN TRIP_CONSIGNMENTS tc ON tc.shipment_no = od.shipment_no " +
			"WHERE od.order_status IN('STAGED', 'SHIPPED', 'DELIVERED', 'PARTIALLY_DELIVERED', 'FULL_DSR') and " +
			"tc.shipment_status In('Active', 'Rescheduled') and tc.trip_id = :tripId";

	public static final String GET_LOADED_HU_COUNT = "select count(cl.label_id) total FROM " +
			"ORDER_DETAILS od LEFT JOIN CONSIGNMENT_LABEL cl ON cl.shipment_no = od.shipment_no " +
			"LEFT JOIN  TRIP_CONSIGNMENTS tc ON cl.shipment_no = tc.shipment_no " +
			"WHERE od.order_status IN ('STAGED', 'SHIPPED', 'DELIVERED', 'PARTIALLY_DELIVERED', 'FULL_DSR') and " +
			"cl.label_type in ('HU') and tc.shipment_status In('Active', 'Rescheduled') and tc.trip_id = :tripId";

	public static final String GET_UNPLANNED_RETURN_ORDER = "select od.order_id,od.order_date,od.order_classification,od.order_type,od.order_status,od.shipment_no,od.source_node,oi.node_id,c.id,c.name,c.address,c.pincode from order_details od JOIN order_intermediaries oi on od.order_id=oi.order_id JOIN customer_details c on od.order_id=c.order_id where od.order_classification='Return' and od.shipment_no is not null and oi.node_id=:nodeId and od.shipment_no not in (select trip_consignments.shipment_no from trip_consignments)";


	public static final String GET_DELIVERY_ZONE_IDS_DESTINATION_NODES_FOR_TRIPS = "SELECT TC.trip_id," +
			" TC.delivery_zone_id,  TC.node_id FROM TRIP_CONSIGNMENTS TC LEFT JOIN TRIP T ON TC.trip_id = T.trip_id " +
			"WHERE T.SOURCE_NODE IN(:nodeIds) ";

	public static final String GET_RESCHEDULED_ORDER = "select od.order_id,od.order_date,od.order_classification,od.order_type,od.order_status,od.shipment_no,od.source_node,oi.node_id,c.id,c.name,c.address,c.pincode from order_details od JOIN order_intermediaries oi on od.order_id=oi.order_id JOIN customer_details c on od.order_id=c.order_id JOIN trip_consignments tc on od.shipment_no=tc.shipment_no where order_status = 'RESCHEDULED' and oi.node_id=:nodeId and tc.shipment_status='Rescheduled'";

	public static final String UPDATE_LABEL_STATUS = "UPDATE CONSIGNMENT_LABEL SET STATUS=:status, MODIFIED_BY=:modifiedBy,  MODIFIED_TS=CURRENT_TIMESTAMP " +
			"WHERE SHIPMENT_NO =:shipmentNo and LABEl_ID IN( :labelIds)";

	public static final String STAGING_PENDING_LABEL_COUNT_FOR_SHIPMENT = "select count(*) from CONSIGNMENT_LABEL where Label_Type not in 'IN-PL' and shipment_no=:shipmentNo and status not in 'Staged' ";

	public static final String GET_ORDER_ID_FOR_SHIPMENT = "select Order_id from order_details where shipment_no=:shipmentNo  ";
}
