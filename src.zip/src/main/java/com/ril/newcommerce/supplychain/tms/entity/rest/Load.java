package com.ril.newcommerce.supplychain.tms.entity.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"LoadShipments",
"LoadNo"
})*/
public class Load {

	@JsonProperty("LoadShipments")
	private LoadShipments loadShipments;
	@JsonProperty("LoadNo")
	private String loadNo;

	@JsonProperty("LoadShipments")
	public LoadShipments getLoadShipments() {
		return loadShipments;
	}

	@JsonProperty("LoadShipments")
	public void setLoadShipments(LoadShipments loadShipments) {
		this.loadShipments = loadShipments;
	}

	@JsonProperty("LoadNo")
	public String getLoadNo() {
		return loadNo;
	}

	@JsonProperty("LoadNo")
	public void setLoadNo(String loadNo) {
		this.loadNo = loadNo;
	}

}
