package com.ril.newcommerce.supplychain.tms.service;

import com.ril.newcommerce.supplychain.tms.tibco.entity.Order;

import java.util.List;

public interface OrderIntermediariesService {
    public void insertRow(List<Order.Shipments.Shipment.Intermediaries> intermediaries, String orderId) ;
}
