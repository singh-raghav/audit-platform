package com.ril.newcommerce.supplychain.tms.enums;

public enum UserRoles {
    ClusterManager,
    DeliveryPartner,
    LoaderUnloader,
    NodeManager,
    Admin,
    Developer,
    FcManager,
    Putaway;
}
