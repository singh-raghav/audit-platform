package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Qualifier(Constants.ORDER_PROCESSOR.CANCELLED_PRE_PROCESSOR)
@Service
public class OrderStatusCancelledPreProcessor implements OrderStatusUpdatePreProcessor {

    @Autowired
    private TripOrdersService tripOrdersService;

    @Override
    public boolean validateUpdate(OrderStatusFeed.Order order) {
        if (!isShipmentSuspended(order.getShipmentNo(), order.getOrderId())) {
            throw new TripApplicationException("Order status update to CANCELLED/FC_DELAYED failed as Trip_consignments.shipment_status is NOT in 'Suspended' state. Order Id : " + order.getOrderId() + " Shipment No : " + order.getShipmentNo());
        }
        return false;
    }

    private boolean isShipmentSuspended(String shipmentNo, String orderId) {

        return tripOrdersService.isShipmentSuspended(shipmentNo, orderId);
    }
}
