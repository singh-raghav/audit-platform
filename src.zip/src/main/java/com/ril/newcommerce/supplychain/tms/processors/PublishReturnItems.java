package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.addverb.entity.Challan;
import com.ril.newcommerce.supplychain.tms.addverb.entity.ReturnDetails;
import com.ril.newcommerce.supplychain.tms.addverb.entity.ReturnedProductDetails;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripSequenceDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.Audit;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.ItemCondition;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.ReturnItemQuality;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.KafkaRestProxyService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanRequest;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate.Labels.Label;
import com.ril.newcommerce.supplychain.tms.util.RestClient;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * B1.Divya
 */
@Service
@Qualifier(Constants.RETURN_ITEM_TO_SAP)
public class PublishReturnItems implements Processor {
	
	private static final Logger log = LoggerFactory.getLogger(PublishReturnItems.class);
	
	@Autowired 
	private JAXBContextConfig jAXBContextConfig;
	
	@Autowired
	private RestClient restClient;
	
	@Autowired
	private InboundDAO inboundDAO;
	
	@Autowired
	private TripsDAO tripDAO;
	
	@Value("${common.audit.url}")
	private String auditUrl;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Value("${returnorder.url}")
	private String returnURL;
	
	@Value("${returnorder.username}")
	private String userName;
	
	@Value("${returnorder.password}")
	private String password;
	
	@Autowired
    private KafkaRestProxyService commonAuditEventPublisher;
	
	@Autowired
	private TripSequenceDAO tripSequenceDAO;


	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception 
	{
		StringReader reader = new StringReader(((TextMessage) message).getText());
		Challan challan = (Challan) jAXBContextConfig.getJaxbContextInstance(Challan.class).createUnmarshaller()
				.unmarshal(reader);

		String tripId = challan.getId();
		String hubId = challan.getHubId();
		String destinationNodeId=challan.getDestinationNodeId();
		
		Trip trip = tripDAO.getTripById(tripId);
		
		List<String> tripIds = new ArrayList<>();
		tripIds.add(tripId);
		List<String> nodeIds = getNodeIds(trip,hubId,destinationNodeId);
		
		

		List<ChallanArticle> articles=validateAndGetChalanArticles(tripIds, nodeIds, tripId, hubId);
		List<String> challanIds=articles.stream().map(m->m.getChallanId()).collect(Collectors.toList());
		Map<String,List<ReturnItem>> returnItem =inboundDAO.getReturnItemsByReturnOrderId(null, challanIds);
		List<ReturnItem> returnItems =new ArrayList<>();
		returnItem.entrySet().stream().forEach(entry -> {
			returnItems.addAll(entry.getValue());
		});

		log.info("creating return itmes infor to send to SAP for tripid {} at hub {}",tripId,hubId);
		
		


			/*Set<String> returnOrderIds = articles.stream().map(m->m.getReturnOrderId()).collect(Collectors.toSet());
			List<String> returnOrderIdList=new ArrayList<>(returnOrderIds);

			Map<String, ReturnItem> returnItems = inboundDAO.getReturnItemById(returnOrderIdList);*/
			
			Map<String,List<ChallanArticle>> challanDetails=articles.stream().collect(Collectors
					.groupingBy(ChallanArticle::getArticleCode, HashMap::new, Collectors.toCollection(ArrayList::new)));
			
			Map<String,List<ReturnItem>> returnDetailsMap=returnItems.stream().collect(Collectors
					.groupingBy(ReturnItem::getItemId, HashMap::new, Collectors.toCollection(ArrayList::new)));
			
			Map<String,List<ReturnItem>> map=getReturnArticleMap(returnDetailsMap);
			
			Map<String, List<ChallanArticle>> challanMap=getChallanMap(challanDetails);
			
			ReturnDetails returnDetails = getReturnDetails(trip, challanMap,map, hubId,destinationNodeId);

			String request = objectMapper.writeValueAsString(returnDetails);
			
			sendtoAudit(request,trip,hubId);
			
			log.info("Request to SAP for return items for trip {} and hubId {} with request {} ",tripId,hubId,request);

			String response = restClient.post(returnURL, getHeaders(), null, request);

			log.info("Return items sent to addverb for trip id {} at hub {} and got response {} ", tripId,hubId, response);
		}
	
	private Map<String, List<ChallanArticle>> getChallanMap(Map<String,List<ChallanArticle>> challanDetails)
	{
		Map<String, List<ChallanArticle>> challanMap=new HashMap<>();
		for(Entry<String,List<ChallanArticle>> e: challanDetails.entrySet())
		{
		Map<ReturnItemQuality, List<ChallanArticle>> challanArticleByQuality = e.getValue().stream().collect(Collectors
				.groupingBy(ChallanArticle::getQuality, HashMap::new, Collectors.toCollection(ArrayList::new)));
		
		List<ChallanArticle> list=new ArrayList<>();
		for(Entry<ReturnItemQuality, List<ChallanArticle>> entry: challanArticleByQuality.entrySet())
		{
			Double qty=entry.getValue().stream().mapToDouble(i->i.getQuantity()).sum();
			ChallanArticle c=entry.getValue().get(0);
			c.setQuantity(qty);
			list.add(c);
		}
		challanMap.put(e.getKey(), list);
		}
		return challanMap;
	}
	
	private Map<String,List<ReturnItem>> getReturnArticleMap(Map<String,List<ReturnItem>> returnDetailsMap)
	{
		Map<String,List<ReturnItem>> map=new HashMap<>();
		for(Entry<String,List<ReturnItem>> e: returnDetailsMap.entrySet())
		{
			Map<Double, List<ReturnItem>> challanArticleByRate = e.getValue().stream().collect(Collectors
					.groupingBy(ReturnItem::getUnitPrice, HashMap::new, Collectors.toCollection(ArrayList::new)));
			List<ReturnItem> list=new ArrayList<>();
			for(Entry<Double, List<ReturnItem>> entry: challanArticleByRate.entrySet())
			{
				Double qty=entry.getValue().stream().mapToDouble(i->i.getInvoicedQuanity()).sum();
				ReturnItem r= entry.getValue().get(0);
				r.setInvoicedQuanity(qty);
				list.add(r);
			}
			map.put(e.getKey(), list);
			
		}
		
		return map;
	}
	private List<String> getNodeIds(Trip trip, String hubId, String destinationNodeId)
	{
		List<String> nodeIds=new ArrayList<>();
		if(MovementType.SHUTTLE.equals(trip.getMovementType()))
			nodeIds.add(destinationNodeId);
		else
			nodeIds.add(hubId);
		
		return nodeIds;
	}

	private void sendtoAudit(String request, Trip trip,String hubId)  {
		try{
		commonAuditEventPublisher.publishToCommonAuditPlatform(Constants.TRIP_APP, trip.getTripId()+"|"+hubId, Constants.RETURN_TO_SAP, System.currentTimeMillis(), request);
		}
		catch(Exception ex)
		{
			log.error(ex.getMessage());
		}
		
	}
	private Map<String, String> getHeaders()
	{
		String base64Creds = Utility.getBase64EncodedString(userName + ":" + password);
		Map<String, String> headers=new HashMap<>();
		headers.put(Constants.AUTHORIZATION,Constants.BASIC+" " + base64Creds);
		
		return headers;
	}
	
	private List<ChallanArticle> validateAndGetChalanArticles(List<String> tripIds,List<String> nodeIds,String tripId,String hubId)
	{
		Map<String, List<Hub>> tripSequenceDetails = tripSequenceDAO.getTripSequence(tripIds, nodeIds);
		List<ChallanArticle> challanReturnItem = inboundDAO.getChallanArticlesAgainstTrip(tripId, hubId);

		if (!CollectionUtils.isEmpty(tripSequenceDetails.get(tripId)) && tripSequenceDetails.get(tripId).size() != 0) {
			List<Hub> hub = tripSequenceDetails.get(tripId);

			if (null != hub.get(0).getActualDispatchTime()) {
				if (CollectionUtils.isEmpty(challanReturnItem)) {
					throw new ValidationException(
							"Return items are not there in this trip " + tripId + " at hub " + hubId);
				}

			} else {
				throw new TripApplicationException(
						"Unloading is not yet done for trip " + tripId + " at node  " + hubId);
			}
		} else {
			throw new ValidationException("No entry of trip " + tripId + "hub " + nodeIds + " in sequence");
		}
		return challanReturnItem;
	}
	
	private ReturnDetails getReturnDetails(Trip trip,Map<String, List<ChallanArticle>> challanDetails,Map<String, List<ReturnItem>> returnDetailsMap, String hubId, String destinationNodeId)
	{
		ReturnDetails returnDetails=new ReturnDetails();
		returnDetails.setTripId(trip.getTripId());
		returnDetails.setHubId(hubId);
		returnDetails.setFcID(destinationNodeId);
		returnDetails.setVehicle(trip.getAssignedVehicle());
		returnDetails.setDeliveryPartner(trip.getAssignedDp());
		returnDetails.setDate(new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
		List<ReturnedProductDetails> returnProductList=new ArrayList<>();
		
		for(Entry<String , List<ChallanArticle>> challan: challanDetails.entrySet())
		{
				for (ChallanArticle c : challan.getValue()) {
					Double qty = c.getQuantity();
					while (qty > 0) {
						List<ReturnItem> item = returnDetailsMap.get(challan.getKey());
						Iterator iterator = item.iterator();
						while (iterator.hasNext()) {
							ReturnItem r = (ReturnItem) iterator.next();
							if (qty >= r.getInvoicedQuanity()) {
								ReturnedProductDetails returnProduct = new ReturnedProductDetails();
								returnProduct.setProductID(challan.getKey());
								returnProduct.setQuantityReturned(r.getInvoicedQuanity());
								returnProduct.setPrice(r.getUnitPrice());
								returnProduct.setAmount(r.getInvoicedQuanity() * r.getUnitPrice());
								returnProduct.setReturnType(r.getReturnType());

								if (c.getQuality().equals(ReturnItemQuality.GOOD))
									returnProduct.setGood((int) Math.round(r.getInvoicedQuanity()));

								if (c.getQuality().equals(ReturnItemQuality.BAD))
									returnProduct.setDamaged((int) Math.round(r.getInvoicedQuanity()));

								if (c.getQuality().equals(ReturnItemQuality.UGLY)
										|| c.getQuality().equals(ReturnItemQuality.DAMAGED)
										|| c.getQuality().equals(ReturnItemQuality.LOST))
								{
									returnProduct.setShortaged((int) Math.round(r.getInvoicedQuanity()));
								}

								returnProductList.add(returnProduct);
								qty -= r.getInvoicedQuanity();
								iterator.remove();
							} else if (qty > 0 && qty < r.getInvoicedQuanity()) {
								ReturnedProductDetails returnProduct = new ReturnedProductDetails();
								returnProduct.setProductID(challan.getKey());
								returnProduct.setQuantityReturned(qty);
								returnProduct.setPrice(r.getUnitPrice());
								returnProduct.setAmount(qty * r.getUnitPrice());
								returnProduct.setReturnType(r.getReturnType());

								if (c.getQuality().equals(ReturnItemQuality.GOOD))
									returnProduct.setGood((int) Math.round(qty));

								if (c.getQuality().equals(ReturnItemQuality.BAD))
									returnProduct.setDamaged((int) Math.round(qty));

								if (c.getQuality().equals(ReturnItemQuality.UGLY)
										|| c.getQuality().equals(ReturnItemQuality.DAMAGED)
										|| c.getQuality().equals(ReturnItemQuality.LOST))
								{
									returnProduct.setShortaged((int) Math.round(qty));
								}

								returnProductList.add(returnProduct);

								Double actual = r.getInvoicedQuanity();
								r.setInvoicedQuanity(actual - qty);
								qty -= actual;

							}
						}
					
				}
			}
		}
		
		
		
		
		/*for(Entry<String , List<ChallanArticle>> challan: challanDetails.entrySet())
		{
			List<ChallanArticle> listOfArticles =challan.getValue();
			
				
			
			Map<Double, List<ChallanArticle>> challanArticle=challan.getValue().stream().collect(Collectors
							.groupingBy(ChallanArticle::getRate, HashMap::new, Collectors.toCollection(ArrayList::new)));
			
			for(Entry<Double, List<ChallanArticle>> entry: challanArticle.entrySet())
			{
				ReturnedProductDetails returnProduct=new ReturnedProductDetails();
				returnProduct.setProductID(challan.getKey());
				Double quantity=entry.getValue().stream().mapToDouble(i -> i.getQuantity()).sum();
				returnProduct.setQuantityReturned(quantity);
				returnProduct.setPrice(entry.getKey());
				returnProduct.setAmount(returnProduct.getQuantityReturned()*entry.getKey());
				returnProduct.setReturnType(entry.getValue().get(0).getReturnType());
				
				Double good=entry.getValue().stream().filter(f->ReturnItemQuality.GOOD.equals(f.getQuality())).mapToDouble(i->i.getQuantity()).sum();
				Double bad=entry.getValue().stream().filter(f->ReturnItemQuality.BAD.equals(f.getQuality())).mapToDouble(i->i.getQuantity()).sum();
				Double ugly=entry.getValue().stream().filter(f->ReturnItemQuality.UGLY.equals(f.getQuality())).mapToDouble(i->i.getQuantity()).sum();
				Double damaged=entry.getValue().stream().filter(f->ReturnItemQuality.DAMAGED.equals(f.getQuality())).mapToDouble(i->i.getQuantity()).sum();
				Double lost=entry.getValue().stream().filter(f->ReturnItemQuality.LOST.equals(f.getQuality())).mapToDouble(i->i.getQuantity()).sum();
				
				
				if(good!=0.0)
					returnProduct.setGood(good.intValue());
				
				if(bad!=0.0)
					returnProduct.setDamaged(bad.intValue());
				
				if(ugly!=0.0|| damaged!=0.0 || lost!=0.0)
					returnProduct.setShortaged(ugly.intValue() + damaged.intValue() +lost.intValue());
				
				returnProductList.add(returnProduct);
				
			}
			
		}*/
		returnDetails.setReturnedProducts(returnProductList);
		return returnDetails;
	}
}
