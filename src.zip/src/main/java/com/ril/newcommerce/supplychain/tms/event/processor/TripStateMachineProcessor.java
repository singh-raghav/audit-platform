package com.ril.newcommerce.supplychain.tms.event.processor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.statemachine.StateMachine;
import org.springframework.statemachine.transition.Transition;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.ActionExecutionException;
import com.ril.newcommerce.supplychain.tms.exception.EventAlreadyProcessedException;
import com.ril.newcommerce.supplychain.tms.exception.EventOutOfOrderException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.notification.NotificationEngine;
import com.ril.newcommerce.supplychain.tms.statemachine.TripStateMachineHandler;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

@Component
@Qualifier(Constants.TRIP_STATE_MACHINE_PROCESSOR)
public class TripStateMachineProcessor extends BasicProcessor{


	private static final Logger log = LoggerFactory.getLogger(TripStateMachineProcessor.class);
		
	@Autowired
	private TripStateMachineHandler smHandler;
	
	@Autowired
	private NotificationEngine notificationEngine;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Override
	public void processEvent(TripEventInput event , Trip trip) {
		
		super.processEvent(event, trip);
	
		//build a state machine for this event.. set the current state.
		StateMachine<TripState, TripEvent>  statemachine = smHandler.initializeAndStart(trip,TripState.get(trip.getStatus()));
		
		//pass the event , trip object to Action.
		statemachine.getExtendedState().getVariables().put(Constants.EVENT, event); 
		statemachine.getExtendedState().getVariables().put(Constants.TRIP, trip);
		
		if(statemachine.hasStateMachineError()) {
			log.error("----State machine is in invalid state.. throw error..");
			throw new TripApplicationException("State machine in Invalid state!" );
		}
			
		//Fire the event
		boolean isEventAccepted = smHandler.fireEvent(statemachine, event.getAction()); //Blocking.. 
		
		//We are handing out of sync event .. handled by interceptor.
		if(!isEventAccepted) {
			
			List<Transition<TripState,TripEvent>> transitions =(List<Transition<TripState, TripEvent>>) statemachine.getTransitions();
			if(isEventProcessedAlready(transitions, event.getAction(), TripState.get(trip.getStatus()))) {
				throw new EventAlreadyProcessedException("Current state is beyond requested state");
			}
			else {
				try {
					String eventPayload = objectMapper.writeValueAsString(event);				
					log.info("Out of sync Event  : {} " , eventPayload);
					notificationEngine.triggerAlert(Constants.OUT_OF_ORDER_MESSAGE, eventPayload, trip.getTripId() + " -- " + event.getAction() + " -- Out of order Message for stateMachine");
				}
				catch (Exception e) {
					log.error("Unable to trigger alert : " + e);
				}
				
				throw new EventOutOfOrderException("Current state is below the requested state. So Requested Transition Not allowed!");
			}
		}
		
		//And the action itself failing
		if(statemachine.hasStateMachineError()) {
			log.error("Exception occurred on executing Action : {}  for trip : {}" , event.getAction().name() ,trip.getTripId()  );
			throw ((ActionExecutionException)statemachine.getExtendedState().getVariables().get(Constants.EXCEPTION));
		}
	
	}
	
	private boolean isEventProcessedAlready(List<Transition<TripState,TripEvent>> transitions,TripEvent reqAction , TripState curState) {

		for(Transition<TripState,TripEvent> transition : transitions) {
		
			if(transition.getTrigger().getEvent() == reqAction) {
				TripState requestedState = transition.getSource().getId();
				
				if(curState.getOrder() > requestedState.getOrder()) 
					return true;
			}
		}
		return false;
	}

}
