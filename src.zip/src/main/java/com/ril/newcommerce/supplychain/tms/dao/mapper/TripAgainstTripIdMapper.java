package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;

public class TripAgainstTripIdMapper   implements ResultSetExtractor<Trip>{

	@Override
	public Trip extractData(ResultSet rs) throws SQLException, DataAccessException {
		Trip trip=new Trip();
		while (rs.next()) {
			trip.setTripId(rs.getString("TRIP_ID"));
			trip.setTripType(rs.getString("TYPE"));
			trip.setSourceNode(rs.getString("SOURCE_NODE"));
			trip.setPlannedStartTime(rs.getTimestamp("PLANNED_START"));
			trip.setPlannedEndTime(rs.getTimestamp("PLANNED_END"));
			trip.setStartKm(rs.getDouble("START_KM"));
			trip.setEndKm(rs.getDouble("END_KM"));
			trip.setActualStartTime(rs.getTimestamp("ACTUAL_START"));
			trip.setActualEndTime(rs.getTimestamp("ACTUAL_END"));
			trip.setStatus(rs.getString("STATUS"));
			trip.setAssignedVehicle(rs.getString("ASSIGNED_VEHICLE"));
			trip.setAssignedDpId(rs.getString("DP_ID"));
			trip.setCreatedTime(rs.getTimestamp("CREATED_TS"));
			trip.setFleetType(rs.getString("FLEET_TYPE"));
			trip.setVehicleModel(rs.getString("SUGGESTED_VEHICLE_TYPE"));
			trip.setMovementType(Enum.valueOf(MovementType.class, rs.getString("MOVEMENT_TYPE")));
		}	
		return trip;
	}

}
