package com.ril.newcommerce.supplychain.tms.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.TripActivityDAO;
import com.ril.newcommerce.supplychain.tms.entity.TripActivityDetails;
import com.ril.newcommerce.supplychain.tms.service.TripActivityService;

@Service
public class TripActivityServiceImpl implements TripActivityService {

	@Autowired
	private TripActivityDAO tripActivityDAO;
	
	@Override
	@Transactional(rollbackFor = Exception.class , propagation = Propagation.REQUIRES_NEW)
	public void insertTripActivity(String tripId , String vehicleId , String driverId, String status) {
		
		TripActivityDetails activity = new TripActivityDetails();
		activity.setTripId(tripId);
		activity.setStatus(status);
		activity.setVehiclePartner(driverId);
		activity.setAssignedVehicle(vehicleId);
		tripActivityDAO.insertTripActivity(activity);
		
	}

	@Override
	public void updateTripActivity(String tripId,String status) {
		
		TripActivityDetails activity = new TripActivityDetails();
		activity.setTripId(tripId);
		activity.setStatus(status);

		tripActivityDAO.updateTripActivityStatus(activity, Constants.UNASSIGNMENT_INITIATED);
		
	}

}
