package com.ril.newcommerce.supplychain.tms.entity.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"PrimeLineNo",
"Item",
"OrderedQty"
})*/
public class OrderLine {

	@JsonProperty("PrimeLineNo")
	private String primeLineNo;
	@JsonProperty("Item")
	private Item item;
	@JsonProperty("LinePriceInfo")
	private LinePriceInfo linePriceInfo;
	@JsonProperty("OrderedQty")
	private String orderedQty;

	@JsonProperty("PrimeLineNo")
	public String getPrimeLineNo() {
		return primeLineNo;
	}

	@JsonProperty("PrimeLineNo")
	public void setPrimeLineNo(String primeLineNo) {
		this.primeLineNo = primeLineNo;
	}

	@JsonProperty("Item")
	public Item getItem() {
		return item;
	}

	@JsonProperty("Item")
	public void setItem(Item item) {
		this.item = item;
	}
	
	@JsonProperty("LinePriceInfo")
	public LinePriceInfo getLinePriceInfo() {
		return linePriceInfo;
	}

	@JsonProperty("LinePriceInfo")
	public void setLinePriceInfo(LinePriceInfo linePriceInfo) {
		this.linePriceInfo = linePriceInfo;
	}

	@JsonProperty("OrderedQty")
	public String getOrderedQty() {
		return orderedQty;
	}

	@JsonProperty("OrderedQty")
	public void setOrderedQty(String orderedQty) {
		this.orderedQty = orderedQty;
	}

}