package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.WayPointUpdates;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;

public class ReturnItemCheck {

	private boolean returnMissMatch;
	
	private String failureMessage;
	
	private List<ReconcileArticle> reconcileArticles;
	
	private List<WayPointUpdates> wayPointUpdates;

	public boolean isReturnMissMatch() {
		return returnMissMatch;
	}

	public void setReturnMissMatch(boolean returnMissMatch) {
		this.returnMissMatch = returnMissMatch;
	}

	public String getFailureMessage() {
		return failureMessage;
	}

	public void setFailureMessage(String failureMessage) {
		this.failureMessage = failureMessage;
	}

	public List<ReconcileArticle> getReconcileArticles() {
		return reconcileArticles;
	}

	public void setReconcileArticles(List<ReconcileArticle> reconcileArticles) {
		this.reconcileArticles = reconcileArticles;
	}

	public List<WayPointUpdates> getWayPointUpdates() {
		return wayPointUpdates;
	}

	public void setWayPointUpdates(List<WayPointUpdates> wayPointUpdates) {
		this.wayPointUpdates = wayPointUpdates;
	}

}
