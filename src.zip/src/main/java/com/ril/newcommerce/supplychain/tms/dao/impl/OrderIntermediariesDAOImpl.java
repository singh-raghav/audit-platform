package com.ril.newcommerce.supplychain.tms.dao.impl;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.OrderIntermediariesDAO;
import com.ril.newcommerce.supplychain.tms.entity.OrderIntermediaries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
public class OrderIntermediariesDAOImpl implements OrderIntermediariesDAO {

    private static Logger log = LoggerFactory.getLogger(OrderIntermediariesDAOImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void insertRow(List<OrderIntermediaries> orderIntermediaries) {
        log.info("Adding order intermediaries");

            jdbcTemplate.batchUpdate(QueryConstants.INSERT_TO_ORDER_INTERMEDIARIES, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int i) throws SQLException {
                    ps.setString(1, orderIntermediaries.get(i).getOrderId());
                    ps.setString(2, orderIntermediaries.get(i).getNodeId());
                }

                @Override
                public int getBatchSize() {
                    return orderIntermediaries.size();
                }
            });


    }
}
