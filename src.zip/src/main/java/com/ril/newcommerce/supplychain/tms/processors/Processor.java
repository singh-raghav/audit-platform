package com.ril.newcommerce.supplychain.tms.processors;

import javax.jms.Message;

import com.ril.newcommerce.supplychain.tms.exception.ParsingException;

/**
B1.Divya
*/

public interface Processor {
	
	public void processMessage(Message message, String flowName) throws ParsingException,Exception;

}
