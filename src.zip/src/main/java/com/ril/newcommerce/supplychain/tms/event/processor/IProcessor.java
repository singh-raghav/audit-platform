package com.ril.newcommerce.supplychain.tms.event.processor;

import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

public interface IProcessor {
	public void processEvent(TripEventInput event,Trip trip);
}
