package com.ril.newcommerce.supplychain.tms.entity;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class ArticleInfo {
	
	private List<ChallanArticle> articles;
	private double totalQuantity;
	private double totalInvoiceValue;
	
	public ArticleInfo() {
		this.articles = new ArrayList<>();
		this.totalQuantity =0;
		this.totalInvoiceValue=0;
	}
	
	public List<ChallanArticle> getArticles() {
		return articles;
	}
	public void setArticles(List<ChallanArticle> articles) {
		this.articles = articles;
	}

	public double getTotalQuantity() {
		
		if(CollectionUtils.isNotEmpty(articles)) {
			this.totalQuantity = articles.stream().map(article-> article.getQuantity()).reduce(0.0, Double::sum);
		}
		return this.totalQuantity;
	}
	
	public void setTotalQuantity(double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	
	public double getTotalInvoiceValue() {
		if(CollectionUtils.isNotEmpty(articles)) {
			this.totalInvoiceValue = articles.stream().filter( article -> article.getBaseValue()!=null).map(article-> article.getBaseValue()).reduce(0.0, Double::sum);
		}
		return this.totalInvoiceValue;
	}
	
	public void setTotalInvoiceValue(double totalInvoiceValue) {
		this.totalInvoiceValue = totalInvoiceValue;
	}

}
