/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.transaction.Transactional;

import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.ConnectionTripDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.ConnectionTrip;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripAdditionalDetails;
import com.ril.newcommerce.supplychain.tms.entity.TripIdDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.Node;
import com.ril.newcommerce.supplychain.tms.enums.EwayBillStatus;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * @author Raghav1.Singh
 *
 */

@Service
public class ConnectionTripServiceImpl implements ConnectionTripService {
	
	private static final Logger log = LoggerFactory.getLogger(ConnectionTripServiceImpl.class);
	
	@Autowired
	private ConnectionTripDAO connectionTripDAO;
	
	@Autowired
	private TripsDAO tripsDAO;
	
	@Autowired
	private TripService tripService;
	
	@Autowired
	private NodeService nodeService;
	
	@Value("${tripapp.queue}")
	private String queueName;
	
	@Autowired
	private JMSPublisher jmsPublisher;
	
    @Transactional
	@Override
	public ConnectionTrip createConnection(List<String> connectionList, String startNodeId) {
		
		ConnectionTrip connectionTrip = null;
		
		try {
			
			connectionTrip = setConnectionTripData(connectionList, startNodeId);
			
			TripAdditionalDetail tripAdditionalDetail = gettripAdditionalDetails(connectionTrip);
			
			connectionTripDAO.insertToTrip(connectionTrip);
			
			connectionTripDAO.insertToTripSequence(connectionTrip);
			
			if(null!=tripAdditionalDetail) {
				tripService.insertTripAdditionalDetails(tripAdditionalDetail);
			}			
			
			TripPublish tripPublishMessage=Utility.createMessageToPublishTrip(connectionTrip.getTripId(),Constants.ONE,false);
			
			publishTripMessage(tripPublishMessage);
			
			log.info("Created connection successfully with tripId {}", connectionTrip.getTripId());
			
		} catch (Exception e) {
			
			throw new TripApplicationException("Exception occured while creating connection", e);
		}
		
		return connectionTrip;					

	}
	
	private ConnectionTrip setConnectionTripData(List<String> connectionList, String startNodeId) {
		
		ConnectionTrip trip = new ConnectionTrip();
		
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		
	    getMovementType(connectionList, trip, startNodeId);
		
		TripIdDetails tripIdDetails =  getTripDetails(currentTime.toInstant().toString(), startNodeId, trip.getMovementType().getValue());
		
		String tripId = Utility.createTripId(startNodeId, tripIdDetails.getTripDate(), tripIdDetails.getSequence()+1, trip.getMovementType());
		
		String uuid = UUID.randomUUID().toString();
		
		trip.setTripId(tripId);
		trip.setConnections(connectionList);
		trip.setTripType("FC-HUB");
		trip.setSourceNodeId(startNodeId);
		trip.setTripCreationTime(currentTime);
		trip.setExternalRefId(uuid);
		trip.setSequence(connectionList.size());
		trip.setStatus(TripState.CREATED.getValue());
		trip.setFlowname("CreateConnection");
		trip.setCreatedBy("TripUI");
		trip.setVersion(1);
		
		return trip;
	}
	
	private void getMovementType(List<String> nodeIds, ConnectionTrip trip, String sourceNodeId) {
		
		StringBuilder nodeType=new StringBuilder();
		Map<String, Node> nodeTypes=nodeService.getNodesByID(nodeIds);
		if(!MapUtils.isEmpty(nodeTypes))
		{
			if(null!=nodeTypes.get(sourceNodeId))
				nodeType.append(nodeTypes.get(sourceNodeId).getNodeType().toUpperCase());
			nodeType.append(Constants.DASH);
			if(null!=nodeTypes.get(nodeIds.get(0)))
			{
				String type=nodeTypes.get(nodeIds.get(0)).getNodeType().toUpperCase();
				type=NodeType.get(type);
				nodeType.append(type);
				
				Node node= nodeTypes.get(nodeIds.get(0));
				if(null!=node.getCoHostId() && node.getCoHostId().equals(sourceNodeId))
					trip.setMovementType(MovementType.SHUTTLE);
				else
					trip.setMovementType(MovementType.FTL);
			}
			else
			{
				log.error("Node id not present in node details {}",nodeIds.get(0));
				throw new ValidationException("Node not present in node details service "+nodeIds);
			}
		}
	}
	
	private TripIdDetails getTripDetails( String date, String nodeId,String movementType) {
		
		String plannedStart = DateUtility.convertStringToFormattedDate(date, Constants.EXTERNAL_SYSTEMS_DATE_FORMAT,
					Constants.DATE_FORMAT);
		int sequence = tripService.getTripCountByGivenDate(plannedStart, nodeId,movementType);
		String tripDate = DateUtility.convertStringToFormattedDate(date, Constants.EXTERNAL_SYSTEMS_DATE_FORMAT,
					Constants.FORMAT_FOR_CREATE_TRIP_ID);
			
		TripIdDetails details=new TripIdDetails();
		details.setSequence(sequence);
		details.setTripDate(tripDate);
		
		return details;
	}
	
	private TripAdditionalDetail gettripAdditionalDetails(ConnectionTrip trip)
	{
		TripAdditionalDetail additionalDetails = new TripAdditionalDetail();
		 additionalDetails.setTripId(trip.getTripId());
		 additionalDetails.setNodeId(trip.getSourceNodeId());
		 additionalDetails.setKey(Constants.EWAYBILL);
		 additionalDetails.setValue(EwayBillStatus.PENDING.value());
		 return additionalDetails;
	}
		
    @Transactional
	@Override
	public void addConnection(List<String> connectionList, String nodeId, String tripId) {
		
		ConnectionTrip connectionTrip = null;	
		
		int count;
		
		try {
			
			connectionTrip = updateConnectionTripData(connectionList,nodeId,tripId);
			
			count = connectionTripDAO.getCountOfConnections(tripId);
			
			connectionTripDAO.insertToTripSequence(connectionTrip,count);
			
			tripsDAO.updateTripVersion(connectionTrip.getTripId(), "AddConnection", "TripUI");
			
            TripPublish tripPublishMessage=Utility.createMessageToPublishTrip(connectionTrip.getTripId(),2,false);
			
			publishTripMessage(tripPublishMessage);
			
			log.info("Added connections successfully to tripId {}", connectionTrip.getTripId());
			
		} catch (Exception e) {
			
			throw new TripApplicationException("Exception occured while adding connection", e);
		}
		
	}
	
	private ConnectionTrip updateConnectionTripData(List<String> connectionList, 
			                                        String nodeId, String tripId) {
		
		ConnectionTrip obj = new ConnectionTrip();
		
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		
		obj.setConnections(connectionList);
		obj.setSourceNodeId(nodeId);
		obj.setTripId(tripId);
		obj.setTripCreationTime(currentTime);
		obj.setCreatedBy("TripUI");
		obj.setFlowname("AddConnection");
		
		return obj;
		
	}
	
	private void publishTripMessage(TripPublish tripPublishRequest) throws Exception
	{
		jmsPublisher.inputToQueue(queueName, tripPublishRequest, FlowName.PUBLISHCONNECTIONTRIP.getValue(),
				Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
						tripPublishRequest.getTrip().getId()),TripPublish.class);	
	}

}
