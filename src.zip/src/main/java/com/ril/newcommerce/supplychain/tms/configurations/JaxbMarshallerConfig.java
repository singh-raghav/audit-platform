package com.ril.newcommerce.supplychain.tms.configurations;

import java.util.HashMap;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class JaxbMarshallerConfig {

	
	@Bean
	public Jaxb2Marshaller getJaxbMarshaller() {
	
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath(com.ril.newcommerce.supplychain.tms.tibco.entity.RFStartTrip.class.getPackage().getName());
		
		marshaller.setMarshallerProperties(new HashMap<String, Object>() {
				
	
			private static final long serialVersionUID = -2484552364688045606L;

			{
				put(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, true);
			}
		});
	    
		return marshaller;
	}
	    
}
