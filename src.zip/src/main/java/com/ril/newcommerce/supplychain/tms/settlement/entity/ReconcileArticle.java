package com.ril.newcommerce.supplychain.tms.settlement.entity;

public class ReconcileArticle {	
	private Integer serialNo;
	private String articleId;
	private String orderId;
	private String status;
	private Double quantity;
	private Double updateQuantity;
	private String articleName;
	private String primeLineNo;
	private Double pricePerItem;
	private String returnType;
	private String uom;
	private String hsnCode;
	private String fwdOrderId;
	private String quality;
	
	public Integer getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(Integer serialNo) {
		this.serialNo = serialNo;
	}
	public String getArticleId() {
		return articleId;
	}
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public Double getUpdateQuantity() {
		return updateQuantity;
	}
	public void setUpdateQuantity(Double updateQuantity) {
		this.updateQuantity = updateQuantity;
	}
	public String getArticleName() {
		return articleName;
	}
	public void setArticleName(String articleName) {
		this.articleName = articleName;
	}
	public String getPrimeLineNo() {
		return primeLineNo;
	}
	public void setPrimeLineNo(String primeLineNo) {
		this.primeLineNo = primeLineNo;
	}
	public Double getPricePerItem() {
		return pricePerItem;
	}
	public void setPricePerItem(Double pricePerItem) {
		this.pricePerItem = pricePerItem;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public String getHsnCode() {
		return hsnCode;
	}
	public void setHsnCode(String hsnCode) {
		this.hsnCode = hsnCode;
	}
	public String getFwdOrderId() {
		return fwdOrderId;
	}
	public void setFwdOrderId(String fwdOrderId) {
		this.fwdOrderId = fwdOrderId;
	}
	public String getQuality() {
		return quality;
	}
	public void setQuality(String quality) {
		this.quality = quality;
	}
	
	@Override
	public String toString() {
		return "ReconcileArticle [serialNo=" + serialNo + ", articleId=" + articleId + ", orderId=" + orderId
				+ ", status=" + status + ", quantity=" + quantity + ", updateQuantity=" + updateQuantity
				+ ", articleName=" + articleName + ", primeLineNo=" + primeLineNo + ", pricePerItem=" + pricePerItem
				+ ", returnType=" + returnType + ", uom=" + uom + ", hsnCode=" + hsnCode + ", fwdOrderId=" + fwdOrderId
				+ "]";
	}
	
}
