package com.ril.newcommerce.supplychain.tms.notification;

public class Body {
	private Notification notification;

	@Override
	public String toString() {
		return "[notification = " + notification + "]";
	}

	public Notification getNotification() {
		return notification;
	}

	public void setNotification(Notification notification) {
		this.notification = notification;
	}

}
