package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.ManifestOrderDetails;

public class ManifestOrdersMapper implements ResultSetExtractor<List<ManifestOrderDetails>> {

	@Override
	public List<ManifestOrderDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<ManifestOrderDetails> ordersList = new ArrayList<ManifestOrderDetails>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			ManifestOrderDetails order=new ManifestOrderDetails();
			order.setSeqNo(rs.getInt("SEQUENCE_NO"));
			order.setOrderId(rs.getString("ORDER_ID"));
			order.setShipmentNo(rs.getString("SHIPMENT_NO"));
			order.setOrderType(rs.getString("ORDER_TYPE"));
			order.setCustomerName(rs.getString("NAME"));
			order.setCustomerAddress(rs.getString("ADDRESS"));
			order.setCustomerPincode(rs.getString("PINCODE"));
			order.setInvoiceNo(rs.getString("INVOICE_NO"));
			order.setInvoiceValue(rs.getDouble("INVOICE_VALUE"));
			order.setAmountToBeCollected(rs.getDouble("AMOUNT_TO_BE_COLLECTED"));
			order.setEwbNo(rs.getString("EWB_NO"));
			order.setEwbStatus(rs.getString("EWB_STATUS"));
			order.setPhoneNumber(rs.getString("PHONE_NUMBER"));
			order.setMop(rs.getString("ORDER_CLASSIFICATION").equalsIgnoreCase(Constants.ORDER_RETURN) ? Constants.NA : rs.getString("MOP"));
			ordersList.add(order);
		}
		return ordersList;
	}

}