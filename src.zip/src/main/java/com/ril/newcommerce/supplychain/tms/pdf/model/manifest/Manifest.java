package com.ril.newcommerce.supplychain.tms.pdf.model.manifest;

public class Manifest {
    private String tripNumber;
    private String tripLocationCode;
    private String mode;
    private String vehicle;
    private String driverNameAndMobile;
    private String truckOperator;
    private String startKm;
    private String endKm;
    private String vehicleType;
    private String totalOrders;
    private String totalTotes;
    private TripDetailSummary tripDetailSummary;

    public String getTripNumber() {
        return tripNumber;
    }

    public void setTripNumber(String tripNumber) {
        this.tripNumber = tripNumber;
    }

    public String getTripLocationCode() {
        return tripLocationCode;
    }

    public void setTripLocationCode(String tripLocationCode) {
        this.tripLocationCode = tripLocationCode;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getVehicle() {
        return vehicle;
    }

    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }

    public String getDriverNameAndMobile() {
        return driverNameAndMobile;
    }

    public void setDriverNameAndMobile(String driverNameAndMobile) {
        this.driverNameAndMobile = driverNameAndMobile;
    }

    public String getTruckOperator() {
        return truckOperator;
    }

    public void setTruckOperator(String truckOperator) {
        this.truckOperator = truckOperator;
    }

    public String getStartKm() {
        return startKm;
    }

    public void setStartKm(String startKm) {
        this.startKm = startKm;
    }

    public String getEndKm() {
        return endKm;
    }

    public void setEndKm(String endKm) {
        this.endKm = endKm;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getTotalOrders() {
        return totalOrders;
    }

    public void setTotalOrders(String totalOrders) {
        this.totalOrders = totalOrders;
    }

    public String getTotalTotes() {
        return totalTotes;
    }

    public void setTotalTotes(String totalTotes) {
        this.totalTotes = totalTotes;
    }

    public TripDetailSummary getTripDetailSummary() {
        return tripDetailSummary;
    }

    public void setTripDetailSummary(TripDetailSummary tripDetailSummary) {
        this.tripDetailSummary = tripDetailSummary;
    }
}
