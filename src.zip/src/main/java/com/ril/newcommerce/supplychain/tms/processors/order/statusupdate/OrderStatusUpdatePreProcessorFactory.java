package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusUpdatePreProcessorFactory {


    @Qualifier(Constants.ORDER_PROCESSOR.INVOICED_PRE_PROCESSOR)
    @Autowired
    private OrderStatusInvoicedPreProcessor orderStatusInvoicedPreprocessor;

    @Qualifier(Constants.ORDER_PROCESSOR.SHIPPED_PRE_PROCESSOR)
    @Autowired
    private OrderStatusShippedPreProcessor orderStatusShippedPreprocessor;

    @Qualifier(Constants.ORDER_PROCESSOR.DELIVERED_PRE_PROCESSOR)
    @Autowired
    private OrderStatusDeliveredPreProcessor orderStatusDeliveredPreProcessor;

    @Qualifier(Constants.ORDER_PROCESSOR.CANCELLED_PRE_PROCESSOR)
    @Autowired
    private OrderStatusCancelledPreProcessor orderStatusCancelledPreProcessor;

    @Qualifier(Constants.ORDER_PROCESSOR.DO_NOTHING_PRE_PROCESSOR)
    @Autowired
    private OrderStatusDoNothingPreProcessor orderStatusDoNothingPreProcessor;


    public OrderStatusUpdatePreProcessor getProcessor(OrderState orderState) {

        OrderStatusUpdatePreProcessor processor;
        switch (orderState) {
            case INVOICED:
                processor = orderStatusInvoicedPreprocessor;
                break;
            case SHIPPED:
                processor = orderStatusShippedPreprocessor;
                break;
            case DELIVERED:
            case PICKED:
            case RESCHEDULED:
            case FULL_DSR:
            case PARTIALLY_DELIVERED:
                processor = orderStatusDeliveredPreProcessor;
                break;
            case FC_DELAYED:
            case CANCELLED:
                processor = orderStatusCancelledPreProcessor;
                break;
            default:
                processor = orderStatusDoNothingPreProcessor;
                break;
        }
        return processor;
    }
}
