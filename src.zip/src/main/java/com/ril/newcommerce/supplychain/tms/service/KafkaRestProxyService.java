package com.ril.newcommerce.supplychain.tms.service;

public interface KafkaRestProxyService {

    void publishToCommonAuditPlatform(String eventSource, String trackingId, String businessOperation,
                                      long eventCreationTime, String event) throws Exception;
}
