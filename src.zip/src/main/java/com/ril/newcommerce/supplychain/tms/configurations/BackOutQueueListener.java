package com.ril.newcommerce.supplychain.tms.configurations;

import javax.jms.JMSException;
import javax.jms.Message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;


@Component
public class BackOutQueueListener {
	
	private static final Logger log = LoggerFactory.getLogger(BackOutQueueListener.class);

	@Value("${tripapp.queue}")
	private String eventQueue;

	@Autowired
	@Qualifier(Constants.JMSTEMPLATE_WITH_DELAY)
	private JmsTemplate jmsTemplate;

	@JmsListener(destination = "${tripapp.backout.queue}")
	public void recieveMessage(Message message, @Header(value = Constants.FLOWNAME) String flowName,
			@Header(required = false, value = Constants.RETRY_COUNT) Integer retryCount) {

		try {
			String jmsMsgId = message.getJMSMessageID();
			log.info("Recieved a message with id : {} and retryCount : {}  ",jmsMsgId, retryCount);

			setMessageProperties(message, flowName, retryCount);
			jmsTemplate.convertAndSend(eventQueue, message);
			sendAck(message);

			log.info("Sucessfully pushed  message {} back to original eventQueue ", jmsMsgId);
		} catch (JMSException e) {
			log.error("Error in retrying failed message to queue :",e.getMessage());
		}

	}

	private void setMessageProperties(Message message, String flowName, Integer retryCount) {

		try {
			int retry = (retryCount == null) ? 0 : retryCount;
			String tripId=message.getStringProperty(Constants.TRIP_NUMBER);
			message.clearProperties();
			message.setStringProperty(Constants.FLOWNAME, flowName);
			message.setIntProperty(Constants.RETRY_COUNT, retry + 1);
		} catch (JMSException e) {
			log.error("Unable to connect TIBCO!");
		}

	}

	private void sendAck(Message message) {
		try {
			message.acknowledge();
			log.info("Backout Q Ack sent..");
		} catch (JMSException e) {
			log.error("Unable to connect TIBCO!");
		}
	}
}
