package com.ril.newcommerce.supplychain.tms.notification;

public class FormattedMessage {
	private String emailMessage;
	private String smsMessage;

	@Override
	public String toString() {
		return " [emailMessage = " + emailMessage + ", smsMessage = "
				+ smsMessage + "]";
	}

	public String getEmailMessage() {
		return emailMessage;
	}

	public void setEmailMessage(String emailMessage) {
		this.emailMessage = emailMessage;
	}

	public String getSmsMessage() {
		return smsMessage;
	}

	public void setSmsMessage(String smsMessage) {
		this.smsMessage = smsMessage;
	}

}
