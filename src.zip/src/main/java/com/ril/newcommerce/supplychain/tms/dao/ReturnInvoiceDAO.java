package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.ItemDetails;

public interface ReturnInvoiceDAO {

	void saveReturnItems(List<ItemDetails> items);

	void updateReturnItemsOnInvoice(List<ItemDetails> items);

}
