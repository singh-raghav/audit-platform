package com.ril.newcommerce.supplychain.tms.response;

import java.sql.Timestamp;

import com.ril.newcommerce.supplychain.tms.enums.MovementType;

public class TripLazyLoadResponse {
    private String tripId;
    private String status;
    private Timestamp updatedTime;
    private String rePlanFlag;
    private String nextNode;
    private boolean isSplitAllowed;
    private boolean isPrimaryTrip;
    private MovementType movementType;

    public String getNextNode() {
        return nextNode;
    }

    public void setNextNode(String nextNode) {
        this.nextNode = nextNode;
    }

   public boolean isPrimaryTrip() {
        return isPrimaryTrip;
    }

    public void setPrimaryTrip(boolean primaryTrip) {
        isPrimaryTrip = primaryTrip;
    }

    public boolean isSplitAllowed() {
        return isSplitAllowed;
    }

    public void setSplitAllowed(boolean splitAllowed) {
        isSplitAllowed = splitAllowed;
    }

    public void setTripId(String tripId) {
        this.tripId = tripId;
    }

    public String getTripId() {
        return tripId;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setUpdatedTime(Timestamp updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Timestamp getUpdatedTime() {
        return updatedTime;
    }

    public void setRePlanFlag(String rePlanFlag) {

        this.rePlanFlag = rePlanFlag;
    }

    public String getRePlanFlag() {
        return rePlanFlag;
    }

	public MovementType getMovementType() {
		return movementType;
	}

	public void setMovementType(MovementType movementType) {
		this.movementType = movementType;
	}

	
    
}
