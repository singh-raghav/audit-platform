package com.ril.newcommerce.supplychain.tms.pdf.model.hubmanifest;

import org.xml.sax.InputSource;

public class HubManifestInputSource extends InputSource {
    private HubManifest hubManifest;

    public HubManifest getHubManifest() {
        return hubManifest;
    }

    public void setHubManifest(HubManifest hubManifest) {
        this.hubManifest = hubManifest;
    }

    public HubManifestInputSource(HubManifest hubManifest) {
        this.hubManifest = hubManifest;
    }
}
