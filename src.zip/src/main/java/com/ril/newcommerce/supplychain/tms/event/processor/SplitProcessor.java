package com.ril.newcommerce.supplychain.tms.event.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.OrderDetailsDAO;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.exception.InvalidActionException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.service.KafkaRestProxyService;
import com.ril.newcommerce.supplychain.tms.service.OrderDetailsService;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripSequenceService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanCreator;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipment;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipments;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Split;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Split.Trip.Orders;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Split.Trip.Orders.Order;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.util.Utility;

@Component
@Qualifier(Constants.SPLIT_PROCESSOR)
public class SplitProcessor implements IUpdateOnlyProcessor {
	
	private static final Logger log = LoggerFactory.getLogger(SplitProcessor.class);
	
	@Autowired
	TripOrdersService tripOrdersService;
	
	@Autowired
	TripService tripService;

	@Autowired
	private JMSPublisher jmsPublisher;
	
	@Value("${tripapp.queue}")
	private String queueName;
	
	@Autowired
	private OrderDetailsDAO orderDetails;
	
	@Autowired
    private KafkaRestProxyService commonAuditEventPublisher;
	
	@Autowired
	private TripSequenceService tripSequence;
	
	@Override
	public void processEvent(TripEventInput event, Trip trip) 
	{
		if(CollectionUtils.isEmpty(event.getConsignments()))
		{
			throw new ValidationException("Orders cannot be empty");
		}
		else
		{
			List<String> shipmentNos = event.getConsignments().stream().map(mapper -> mapper.getShipmentNo())
					.collect(Collectors.toList());
			try {
				int count = tripOrdersService.updateShipmentStatus(OrderStatus.INPROGRESS.getValue(), shipmentNos, event.getTripId(),
						event.getModifiedBy(), event.getFlowName(), event.getNodeId(), OrderStatus.ACTIVE.getValue());
				if(count==shipmentNos.size())
				{
					log.info("Spliting shipments from trip id {}",trip.getTripId());
					
				tripService.updateTripVersion(event.getTripId(),event.getFlowName(),event.getModifiedBy());
					
				log.info("Splitting from trip {} ",trip.getTripId());
				
				tripOrdersService.updateShipmentStatus(OrderStatus.INACTIVE.getValue(), shipmentNos, event.getTripId(),
						event.getModifiedBy(), FlowName.SPLIT.getValue(), event.getNodeId(),null);
				
				deassociateOrCancelTrip( trip,  event);
				
				sendtoAudit(event,trip);
				
				Split splitMessage=Utility.createPostSplitMessage(trip,event.getConsignments());
				
				TripPublish tripPublishMeaage=Utility.createMessageToPublishTrip(event.getTripId(),trip.getVersion()+1,false);
				
				jmsPublisher.inputToQueue(queueName, splitMessage, FlowName.SPLIT.getValue(),
						Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
								tripPublishMeaage.getTrip().getId()),Split.class);	
				
				jmsPublisher.inputToQueue(queueName, tripPublishMeaage, FlowName.PUBLISHTRIP.getValue(),
						Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
								tripPublishMeaage.getTrip().getId()),TripPublish.class);	
				log.info("shipemnt successfulyy splitted ",trip.getTripId());
				}
				else
				{
					throw new InvalidActionException("This trip entity cannot be modified right now");
				}
				
			} catch (Exception e) {
				
				log.error("exception occured during spliting shipments from trip {}  {}",event.getTripId(),e.getMessage());
				throw new TripApplicationException(e.getMessage());
			}
		}
		
	}
	
	private void sendtoAudit(TripEventInput event, Trip trip)  {
		try{
		ObjectMapper objectMapper = new ObjectMapper();
	    String request = objectMapper.writeValueAsString(event);
		commonAuditEventPublisher.publishToCommonAuditPlatform(Constants.TRIP_APP, trip.getTripId(), Constants.SPLIT, System.currentTimeMillis(), request);
		}
		catch(Exception ex)
		{
			log.error(ex.getMessage());
		}
		
	}
	
	private void deassociateOrCancelTrip(Trip trip, TripEventInput event)
	{
		List<String> status=new ArrayList<>();
		status.add(OrderStatus.ACTIVE.getValue());
		List<Consignment> consignments = orderDetails.getTripOrderDetails(trip.getTripId(), trip.getSourceNode(),
				status, null, null);
		
		tripSequence.deassociateTripSequence(trip,consignments,event.getConsignments(), event.getModifiedBy());
	}


}
