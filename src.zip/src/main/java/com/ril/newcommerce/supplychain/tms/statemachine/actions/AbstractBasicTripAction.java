package com.ril.newcommerce.supplychain.tms.statemachine.actions;

import org.springframework.statemachine.StateContext;
import org.springframework.statemachine.action.Action;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.ActionExecutionException;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

public abstract class AbstractBasicTripAction implements Action<TripState, TripEvent> {
	
	@Override
	public void execute(StateContext<TripState, TripEvent> context) {
		
		try {
			
			TripEventInput event = (TripEventInput) context.getExtendedState().getVariables().get(Constants.EVENT);
			
			Trip trip = (Trip) context.getExtendedState().getVariables().get(Constants.TRIP);
			
			doExecute(trip, event);
			
		}
		catch (ActionExecutionException e) {
			context.getStateMachine().setStateMachineError(e); //Now intercepter will take care of setting the exception. 
		}
		catch (Exception e) { //Just for safety.. No other exception is expected from the action... still wrapping it to ActionExecutionException.
			context.getStateMachine().setStateMachineError(new ActionExecutionException(e.getMessage())); 
		}
	}
	
	public abstract void doExecute(Trip trip, TripEventInput event) throws ActionExecutionException; //Forcing Actions to throw this exception.

}
