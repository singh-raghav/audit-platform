package com.ril.newcommerce.supplychain.tms.controller;


import java.io.IOException;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author jeevi.natarajan
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping(value = "/")
public class VersionController {
	
	private static final Logger log = LoggerFactory.getLogger(VersionController.class);

    private Properties version = new Properties();

    @GetMapping(value = "/version")
    public String displayVersionOfDeployedArtifact( ){
        return version.getProperty("version.number");
    }

    @PostConstruct
    private void initialize(){
        Resource resource = new ClassPathResource("/version.properties");
        try {
            version = PropertiesLoaderUtils.loadProperties(resource);
        } catch (IOException e) {
            log.error("Unable to load version.properties" , e);
        }

        log.info("Loaded version.properties");
    }
}
