package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;

public class ChallanReturnItemMapper implements RowMapper<ChallanArticle> {

	@Override
	public ChallanArticle mapRow(ResultSet rs, int arg1) throws SQLException {
	
		ChallanArticle article = new ChallanArticle();
		article.setChallanId(rs.getString("CHALLAN_ID"));
		article.setTripId(rs.getString("TRIP_ID"));
		article.setReturnOrderId(rs.getString("RETURN_ORDER_ID"));
		article.setArticleCode(rs.getString("ARTICLE_ID"));
		article.setArticleType(rs.getString("ARTICLE_TYPE"));
		article.setQuantity(rs.getDouble("QTY"));
		article.setReturnType(rs.getString("RETURN_TYPE"));
		
		return article;	
	}
	
}