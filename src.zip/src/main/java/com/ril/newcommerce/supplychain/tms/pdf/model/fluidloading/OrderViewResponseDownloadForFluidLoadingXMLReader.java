package com.ril.newcommerce.supplychain.tms.pdf.model.fluidloading;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.pdf.tools.AbstractObjectReader;
import com.ril.newcommerce.supplychain.tms.response.OrderListResponseFluidLoading;
import com.ril.newcommerce.supplychain.tms.response.OrderViewResponseForFluidLoading;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import org.springframework.util.CollectionUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.util.List;

public class OrderViewResponseDownloadForFluidLoadingXMLReader extends AbstractObjectReader {
    public void parse(InputSource input) throws SAXException {
        if (input instanceof OrderListResponseFluidLoading) {
            parse(((OrderListResponseFluidLoading) input).getOrderList());
        } else {
            throw new SAXException("Unsupported InputSource specified. "
                    + "Must be a OrderListResponseFluidLoading");
        }
    }

    private void parse(List<OrderViewResponseForFluidLoading> orderList) throws SAXException {
        if (CollectionUtils.isEmpty(orderList)) {
            return;
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        //Start the document
        handler.startDocument();

        //Generate SAX events for the ProjectTeam
        generateFor(orderList);

        //End the document
        handler.endDocument();
    }

    private void generateFor(List<OrderViewResponseForFluidLoading> orderList) throws SAXException {
        if (CollectionUtils.isEmpty(orderList)) {
            throw new NullPointerException("Parameter order list must not be empty or null");
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        handler.startElement("orderDetails");
        for (OrderViewResponseForFluidLoading order : orderList) {
            if(order.getHuTotalCount() == null)
                order.setHuTotalCount(0);
            if(order.getHuMissingCount() == null){
                order.setHuMissingCount(0);
            }
            generateFor(order);
        }
        handler.endElement("orderDetails");
    }

    private void generateFor(OrderViewResponseForFluidLoading order) throws SAXException {
        handler.startElement("orderDetail");
        handler.element("orderId", order.getOrderId());
        handler.element("deliveryPromisedDate", DateUtility.convertTimeStampToString(order.getDeliveryPromisedDate(),
                Constants.DATE_FORMAT_dd_MM_yyyy));
        handler.element("orderDate", DateUtility.convertTimeStampToString(order.getOrderPlacedDate(),
                Constants.DATE_FORMAT_dd_MM_yyyy));
        handler.element("orderType", order.getOrderType());
        handler.element("pincode", order.getCustomerPincode());
        handler.element("mid", order.getMid());
        handler.element("customerName", order.getCustomerName());
        handler.element("deliveryZoneId", order.getDeliveryZoneId());
        handler.element("HUCountDeatil", String.join("-", String.valueOf(order.getHuTotalCount()),
                String.valueOf(order.getHuMissingCount())));
        handler.endElement("orderDetail");
    }
}
