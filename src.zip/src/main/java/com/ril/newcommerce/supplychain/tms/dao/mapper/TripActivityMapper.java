package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.entity.TripActivityDetails;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TripActivityMapper implements ResultSetExtractor<List<TripActivityDetails>> {
    @Override
    public List<TripActivityDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<TripActivityDetails> tripActivities = new ArrayList<>();
        while(rs.next()) {
            TripActivityDetails activity = new TripActivityDetails();
            activity.setTripId(rs.getString("TRIP_ID"));
            activity.setStatus(rs.getString("STATUS"));
            activity.setAssignedVehicle(rs.getString("VEHICLE_ID"));
            activity.setVehiclePartner(rs.getString("DRIVER_ID"));
            tripActivities.add(activity);
        }
        return tripActivities;
    }
}
