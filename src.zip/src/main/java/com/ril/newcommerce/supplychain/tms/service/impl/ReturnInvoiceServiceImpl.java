package com.ril.newcommerce.supplychain.tms.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.OrderDetailsDAO;
import com.ril.newcommerce.supplychain.tms.dao.OrderInvoiceDAO;
import com.ril.newcommerce.supplychain.tms.dao.ReturnInvoiceDAO;
import com.ril.newcommerce.supplychain.tms.entity.ItemDetails;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.service.ReturnInvoiceService;
import com.ril.newcommerce.supplychain.tms.tibco.invoice.entity.InvoiceDetail;

@Component
@Service
public class ReturnInvoiceServiceImpl implements ReturnInvoiceService{
	
	private static final Logger log = LoggerFactory.getLogger(ReturnInvoiceServiceImpl.class);
	
	@Autowired
	ReturnInvoiceDAO returnInvoiceDao;
	
	@Autowired
	OrderDetailsDAO orderDetailsDAO;
	
	@Autowired
	OrderInvoiceDAO orderInvoiceDAO;

	@Override
	public void persistReturnItems(InvoiceDetail invoiceDetails) throws Exception{
		List<ItemDetails> items = new ArrayList<ItemDetails>();
		if(null!=invoiceDetails && null!=invoiceDetails.getInvoiceHeader() && null!=invoiceDetails.getInvoiceHeader().getLineDetails() && null!=invoiceDetails.getInvoiceHeader().getLineDetails().getLineDetail()) {			
			List<InvoiceDetail.InvoiceHeader.Order.References.Reference> reference = invoiceDetails.getInvoiceHeader().getOrder().getReferences().getReference().stream().filter(ref -> ref.getName().equalsIgnoreCase("B2BMID")).collect(Collectors.toList());
			String customerId = reference.get(0).getValue();
			for(InvoiceDetail.InvoiceHeader.LineDetails.LineDetail lineDetails:invoiceDetails.getInvoiceHeader().getLineDetails().getLineDetail()) {
				ItemDetails item = new ItemDetails();
				item.setItemId(lineDetails.getItemID());
				item.setScrNodeId(customerId);
				String orderType = invoiceDetails.getInvoiceHeader().getOrder().getOrderType();
				if(OrderStatus.CR_RETURNED.getValue().equalsIgnoreCase(orderType)) {
					item.setOrderId(invoiceDetails.getInvoiceHeader().getOrderNo());
					item.setReturnType(OrderStatus.CR_RETURNED.getValue());
				}
				else if(OrderStatus.DSR_RETURNED.getValue().equalsIgnoreCase(orderType)) {
						item.setOrderId(invoiceDetails.getInvoiceHeader().getSalesOrderNo());
						item.setReturnType(OrderStatus.DSR_RETURNED.getValue());					
				}				
				item.setReturnOrderId(invoiceDetails.getInvoiceHeader().getOrderNo());
				item.setQuantity(lineDetails.getQuantity().doubleValue());
				item.setItemName(lineDetails.getOrderLine().getItem().getItemDesc());
				item.setPrimeLineNo(lineDetails.getPrimeLineNo());
				item.setUom(lineDetails.getUnitOfMeasure());
				item.setHsnCode(lineDetails.getOrderLine().getItem().getTaxProductCode());
				item.setUnitPrice(lineDetails.getLineTotal().abs().doubleValue()/lineDetails.getQuantity().doubleValue());
				items.add(item);
			}
//			returnInvoiceDao.saveReturnItems(items);
			if(invoiceDetails.getInvoiceHeader().getOrder().getOrderType().equalsIgnoreCase(OrderStatus.DSR_RETURNED.getValue())) {
				returnInvoiceDao.saveReturnItems(items);
				saveReturnOrderDetails(invoiceDetails);
			} else if (invoiceDetails.getInvoiceHeader().getOrder().getOrderType().equalsIgnoreCase(OrderStatus.CR_RETURNED.getValue())){
				returnInvoiceDao.updateReturnItemsOnInvoice(items);
			}
			saveReturnConsignmentInvoice(invoiceDetails);
		}
	}

	private void saveReturnConsignmentInvoice(InvoiceDetail invoiceDetails) {
		try {
			int count = orderInvoiceDAO.insertConsignmentInvoiceDetails(invoiceDetails);
			log.info("Added consignment invoice for return orders");
		} catch (Exception e) {
			log.error("Error occured in inserting return consignment invoice details ", e);
			throw new DataProcessingException("Got Exception in ReturnInvoiceServiceImpl saveReturnConsignmentInvoice", e);
		}
		
	}

	private void saveReturnOrderDetails(InvoiceDetail invoiceDetails) {
		List<OrderDetails> orderDetails = null;
		try {
			orderDetails = getOrderDetails(invoiceDetails);
			orderDetailsDAO.insertOrderDetails(orderDetails);
			log.info("Added order details");
			orderDetailsDAO.insertCustomerDetails(orderDetails);
			log.info("Added customer details");
		} catch (Exception e) {
			log.error("Error occured in inserting return order details ", e);
			throw new DataProcessingException("Got Exception in ReturnInvoiceServiceImpl saveReturnOrderDetails", e);
		}
	}

	private List<OrderDetails> getOrderDetails(InvoiceDetail invoiceDetails) {
		List<OrderDetails> orderDetails = new ArrayList<OrderDetails>();
		OrderDetails orderDetail = new OrderDetails();
		
		StringBuilder frmAddress = new StringBuilder(null!=invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine1() && !invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine1().isEmpty()?invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine1()+" ,":"");
		frmAddress.append(null!=invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine2() && !invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine2().isEmpty()?invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine2()+" ,":"");
		frmAddress.append(null!=invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine3() && !invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine3().isEmpty()?invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine3():"");
		frmAddress.append(null!=invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine4() && !invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine4().isEmpty()?invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine4()+" ,":"");
		frmAddress.append(null!=invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine5() && !invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine5().isEmpty()?invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine5()+" ,":"");
		frmAddress.append(null!=invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine6() && !invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine6().isEmpty()?invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getAddressLine6():"");
		if (!StringUtils.isBlank(frmAddress)) {
			frmAddress.append(invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getCity());
		}

		StringBuilder customerName = new StringBuilder(null!=invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getFirstName() && !invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getFirstName().isEmpty()?invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getFirstName()+" ":"");
		customerName.append(null!=invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getMiddleName() && !invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getMiddleName().isEmpty()?invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getMiddleName()+" ":"");
		customerName.append(null!=invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getLastName() && !invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getLastName().isEmpty()?invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getLastName()+" ":"");
		orderDetail.setOrderId(invoiceDetails.getInvoiceHeader().getOrderNo());
		orderDetail.setOrderType(invoiceDetails.getInvoiceHeader().getOrder().getReferences().getReference().stream().filter(i->i.getName().equalsIgnoreCase("B2BOrderType")).findFirst().get().getValue());
		orderDetail.setSourceNode(invoiceDetails.getInvoiceHeader().getOrder().getShipNodes().getShipNode().getShipNode());
		orderDetail.setCustomerName(customerName.toString());
		orderDetail.setCustomerAddress(frmAddress.toString());
		orderDetail.setCustomerId(invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getPersonID());
		orderDetail.setCity(invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getCity());
		for(InvoiceDetail.InvoiceHeader.Order.References.Reference ref:invoiceDetails.getInvoiceHeader().getOrder().getReferences().getReference()){
			if(ref.getName().equalsIgnoreCase(Constants.TOGSTN_B2BGSTNO)) {
				orderDetail.setCustomerGstn(ref.getValue());
			}
		}
		if(null==orderDetail.getCustomerGstn()) {
			orderDetail.setCustomerGstn(Constants.UNREGISTERED_PERSON);
		}
		orderDetail.setCustomerPincode(String.valueOf(invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getZipCode()));
		orderDetail.setCustomerState(invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getState());
		orderDetail.setCustomerStateCode(invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoShipTo().getTaxGeoCode());
		orderDetail.setOrderClassification(Constants.ORDER_RETURN);
		orderDetail.setCreatedTime(new Timestamp(System.currentTimeMillis()));
		orderDetail.setCreatedBy(Constants.RETURN_INVOICE);
		orderDetail.setFlowName(Constants.RETURN_INVOICE);
		orderDetail.setPhoneNumber(String.valueOf(invoiceDetails.getInvoiceHeader().getOrder().getPersonInfoBillTo().getMobilePhone()));
		orderDetails.add(orderDetail);
		
	 return orderDetails;
	}

}
