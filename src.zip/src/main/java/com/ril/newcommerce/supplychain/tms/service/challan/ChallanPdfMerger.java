package com.ril.newcommerce.supplychain.tms.service.challan;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.PDF_EXT;
import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.PDF_FOLDER;

import java.io.File;
import java.util.List;
import java.util.UUID;

import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.exception.PdfCreationException;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;

@Service
public class ChallanPdfMerger {
	
	public ResponseEntity<InputStreamSource> mergePdfs(List<String> pdfNames) {
		   String mergedFileName = Constants.DELIVERY_CHALLAN_PREFIX +UUID.randomUUID()+ PDF_EXT;
           mergePdf(pdfNames, mergedFileName);
           return ResponseEntityFactory.getPDFResponseSuccess(mergedFileName);
	}

	 private void mergePdf(List<String> pdfList, String destinationFileName) throws PdfCreationException {

	        PDFMergerUtility pdfMerger = new PDFMergerUtility();
	        File baseDir = new File(".");
	        File outFolder = new File(baseDir, PDF_FOLDER);
	        try {

	            for (String pdf : pdfList) {
	                pdfMerger.addSource(new File(outFolder.getPath() + "/" + pdf));
	            }
	            pdfMerger.setDestinationFileName(outFolder + "/" + destinationFileName);
	            pdfMerger.mergeDocuments();

	        } catch (Exception e) {
	            throw new PdfCreationException("Exception while merging files, number of files: " + pdfList.size());
	        }
	    }
}
