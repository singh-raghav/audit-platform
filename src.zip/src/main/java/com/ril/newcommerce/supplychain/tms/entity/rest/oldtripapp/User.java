package com.ril.newcommerce.supplychain.tms.entity.rest.oldtripapp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class User {

	private String role;
	private String firstName;
	private String lastName;
	private String roleID;
	private String mobileNo;
	private String address;
	private String DOJ;
	private String emailID;
	private String altContactPerson;
	private String altContactNo;
	private String password;
	private String rePassword;
	private String accountStatus;
	private String lastLogin;
	private String loginID;
	private String ezetap;
	private String store;
	private String storeName;
	private String dcID;
	private String dcName;
	private String clusterId;
	private String clusterName;
	private String isDeleted;
	private String imeii;
	private String nodeType;
	private String fullName;
	private String username;

}
