package com.ril.newcommerce.supplychain.tms.settlement.entity;

public class AdditionalCharges {
	private Double toll;
	private Double handling;
	private Double other;

	public Double getToll() {
		return toll;
	}

	public void setToll(Double toll) {
		this.toll = toll;
	}

	public Double getHandling() {
		return handling;
	}

	public void setHandling(Double handling) {
		this.handling = handling;
	}

	public Double getOther() {
		return other;
	}

	public void setOther(Double other) {
		this.other = other;
	}

	@Override
	public String toString() {
		return "AdditionalCharges [toll=" + toll + ", handling=" + handling + ", other=" + other + "]";
	}
}
