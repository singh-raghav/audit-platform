package com.ril.newcommerce.supplychain.tms.externalApis;

import com.ril.newcommerce.supplychain.tms.entity.rest.oldtripapp.OldTripAppCreateUserRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.oldtripapp.OldTripAppCreateUserResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "oldTripAppService", url = "${oldTripApp.endpoint}")
public interface OldTripAppFeign {

    @PostMapping(value="/api/ui/user/createUser", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    OldTripAppCreateUserResponse createUser(@RequestBody OldTripAppCreateUserRequest oldTripAppCreateUserRequest);
}
