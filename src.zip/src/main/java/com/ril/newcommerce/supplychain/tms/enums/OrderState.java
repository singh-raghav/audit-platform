package com.ril.newcommerce.supplychain.tms.enums;

import java.util.HashMap;
import java.util.Map;

public enum OrderState {
    CREATED("CREATED"),
    CANCELLED("CANCELLED"),
    FC_DELAYED("FC_DELAYED"),
    INVOICED("INVOICED"),
    SHIPPED("SHIPPED"),
    DELIVERED("DELIVERED"),
    FULL_DSR("FULL_DSR"),
    PARTIALLY_DELIVERED("PARTIALLY_DELIVERED"),
    RESCHEDULED("RESCHEDULED"),
    PICKED("PICKED"),
    STAGED("STAGED");

    private String value;

    private OrderState(String value){
        this.value=value;
    }

    public String getValue(){
        return this.value;
    }

    private static final Map<String, TripState> lookup = new HashMap<>();

    static {
        for (TripState reasonCode : TripState.values())
            lookup.put(reasonCode.getValue(), reasonCode);
    }
    public static TripState get(String value) {
        return lookup.get(value);
    }
}
