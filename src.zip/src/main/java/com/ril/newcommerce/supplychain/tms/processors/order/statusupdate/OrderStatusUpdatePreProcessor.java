package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;

public interface OrderStatusUpdatePreProcessor {

    boolean validateUpdate(OrderStatusFeed.Order orderStatusFeedOrder );
}
