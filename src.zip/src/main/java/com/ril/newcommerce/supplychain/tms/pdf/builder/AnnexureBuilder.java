package com.ril.newcommerce.supplychain.tms.pdf.builder;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.rest.HubAnnexure;
import com.ril.newcommerce.supplychain.tms.entity.rest.Invoice;
import com.ril.newcommerce.supplychain.tms.entity.rest.TripAnnexure;
import com.ril.newcommerce.supplychain.tms.pdf.model.annexure.Annexure;
import com.ril.newcommerce.supplychain.tms.pdf.model.annexure.InvoiceDetails;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AnnexureBuilder {
    public Annexure build(TripAnnexure tripAnnexure, HubAnnexure hubAnnexure) {

        Annexure annexure = new Annexure();
        annexure.setDriverName(tripAnnexure.getDriverName());
        annexure.setFcName(tripAnnexure.getFcName());
        annexure.setHubName(hubAnnexure.getHubName());
        annexure.setTotalHULoaded(String.valueOf(hubAnnexure.getTotalInvoiceHUs()));
        annexure.setTripDate(DateUtility.convertDateToString(tripAnnexure.getTripDate(), Constants.DATE_FORMAT_DD_MM_YYYY));
        annexure.setTotalInvoiceLoaded(String.valueOf(hubAnnexure.getInvoices().size()));
        annexure.setTripNumber(tripAnnexure.getTripId());
        annexure.setVehicleNumber(tripAnnexure.getVehicleNo());
        List<InvoiceDetails> invoiceDetailsList = new ArrayList<>();
        InvoiceDetails invoiceDetails;
        for (Invoice invoice : hubAnnexure.getInvoices()) {
            invoiceDetails = new InvoiceDetails();
            invoiceDetails.setCnNumber(invoice.getShipmentNo());
            invoiceDetails.setOrderNum(invoice.getOrderNo());
            invoiceDetails.setCountOfBags(String.valueOf(invoice.getBagIds().size()));
            invoiceDetails.setCountOfTotes(String.valueOf(invoice.getToteIds().size()+invoice.getHuIds().size()));
            invoiceDetails.setCustomerName(StringUtils.join(Arrays.stream(StringUtils.split(invoice.getCustomerName(), ",")).filter(s -> !StringUtils.isBlank(s)).collect(Collectors.toList()), ", "));
            invoiceDetails.seteWayBillNum(invoice.getEwayBillNo());
            invoiceDetails.setInvoiceDate(DateUtility.convertDateToString(invoice.getInvoiceDate(), Constants.DATE_FORMAT_DD_MM_YYYY));
            invoiceDetails.setInvoiceNum(invoice.getInvoiceNo());
            invoiceDetails.setInvoiceValue(String.valueOf(invoice.getInvoiceAmount()));
            invoiceDetailsList.add(invoiceDetails);
        }
        annexure.setInvoiceDetails(invoiceDetailsList);
        return annexure;
    }
}
