package com.ril.newcommerce.supplychain.tms.service;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public interface TripActivityService {
	
	public void insertTripActivity(String tripId , String vehicleId , String driverId, String status);

	public void updateTripActivity(String tripId,String status);
}
