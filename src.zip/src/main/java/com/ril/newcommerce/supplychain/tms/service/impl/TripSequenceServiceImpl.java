/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.OrderDetailsDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripSequenceDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.event.processor.TripEventProcessor;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.TripSequenceService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

/**
 * @author Raghav1.Singh
 *
 */

@Service
public class TripSequenceServiceImpl implements TripSequenceService {
	
	private static final Logger log = LoggerFactory.getLogger(TripSequenceServiceImpl.class);
	
	@Autowired
	TripService tripService;
	
	@Autowired
	private TripSequenceDAO tripSequenceDAO;
	

	@Override
	public void deassociateTripSequence(Trip trip,List<Consignment> actualConsignment, List<Consignment> removedConsignment,String modifiedBy) {
	
		List<String> deasscoiateHub =new ArrayList<>();
		Set<String> existingNode=actualConsignment.stream().map(m->m.getNextNodeId()).collect(Collectors.toSet());
		
		Set<String> splitNode=removedConsignment.stream().map(m->m.getNextNodeId()).collect(Collectors.toSet());		
		
		splitNode.removeAll(existingNode);
		if(!CollectionUtils.isEmpty(splitNode))
			deasscoiateHub.addAll(splitNode);
		
		if(!CollectionUtils.isEmpty(deasscoiateHub))
			tripSequenceDAO.deassociateTripSequence(trip.getTripId(),deasscoiateHub);
		
		//cancelTripIfNoActiveOrders(consignments,trip,modifiedBy);

	}
	
	@Override
	public Map<String, List<Hub>> getTripSequence(String tripId) {
		try {

			if (!StringUtils.isEmpty(tripId)) {
				List<String> tripIds = new ArrayList<>();
				tripIds.add(tripId);
				return getTripSequence(tripIds,null);
			}
		}
		catch (Exception e) {
			log.error("Exception occured while fetching trip sequence in getTripSequence by tripid of TripServiceImpl ", e);
			throw new TripApplicationException("Exception occured on getTripSequence by trip id TripServiceImpl ", e);
		}
		return null;
	}
	
	@Override
	public Map<String, List<Hub>> getTripSequence(List<String> tripIds,List<String> nodeIds) {
		Map<String, List<Hub>> tripSequence = new HashMap<>();
		try {
			tripSequence = tripSequenceDAO.getTripSequence(tripIds,nodeIds);
		} catch (Exception e) {
			log.error("Exception occured while fetching trip sequence in getTripSequence of TripServiceImpl ", e);
			throw new TripApplicationException("Exception occured on getTripSequence of TripServiceImpl ", e);
		}
		return tripSequence;
	}
	
	@Override
	public void deassociateTripSequence(String tripId, List<String> nodeIds) {
		try {
			if (StringUtils.isNotBlank(tripId) && !CollectionUtils.isEmpty(nodeIds)) {
				tripSequenceDAO.deassociateTripSequence(tripId, nodeIds);
			}
		} catch (Exception e) {
			throw new TripApplicationException(
					"Exception occured while inserting trip hierarchy in insertToTripHierarchy of TripServiceImpl ", e);
		}
	}


}
