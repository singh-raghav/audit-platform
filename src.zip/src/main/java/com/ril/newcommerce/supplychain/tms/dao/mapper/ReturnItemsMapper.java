package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class ReturnItemsMapper implements RowMapper<ChallanArticle> {

	@Override
	public ChallanArticle mapRow(ResultSet rs, int arg1) throws SQLException {
		
		ChallanArticle article = new ChallanArticle();
		
		String orderId = rs.getString("ORDER_ID");
		String itemId = rs.getString("ITEM_ID");
		String primeLineNumber = rs.getString("PRIME_LINE_NUMBER");
		
		article.setArticleCode(orderId+Constants.SLASH+itemId+Constants.SLASH+primeLineNumber); //Uniquely identifies an return item.
		article.setArticleDesc(rs.getString("ITEM_NAME"));
		article.setHsnCode(rs.getString("HSN_CODE"));
		article.setQuantity(rs.getDouble("QUANTITY"));
		article.setUOM(rs.getString("UOM"));
		article.setRate(Double.valueOf(rs.getString("PRICE_PER_ITEM")));
		article.setBaseValue(article.getQuantity() * article.getRate());
		article.setArticleType(ArticleType.RETURN_ITEM.name());
		
		return article;
	}

}
