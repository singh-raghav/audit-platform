package com.ril.newcommerce.supplychain.tms.enums;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public enum ArticleType {
	
	ASSET , RETURN_ITEM;

}
