package com.ril.newcommerce.supplychain.tms.event.processor;




import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

/**
 * Idea is handle all the Trip related event processing ... 
 * @author jeevi.natarajan
 *
 */
@Component
@Qualifier(Constants.TRIP_EVENT_PROCESSOR)
public class TripEventProcessor {
	
	private static final Logger log = LoggerFactory.getLogger(TripEventProcessor.class);
	
	@Autowired
	private TripsDAO tripDao;
	
	@Autowired
	private PreProcessorFactory preProcessorFactory;
	
	@Autowired
	private TripProcessorFactory processorFactory;
	
	@Autowired
	private PostProcessorFactory postProcessorFactory;
	
	
	public void processEvent(TripEventInput event) {
		//Load Trip
		Trip trip = new Trip();
		if(null!=event.getTripId())
		trip = tripDao.getTripById(event.getTripId());

		if(trip==null && !event.getAction().name().equalsIgnoreCase(TripEvent.SHUTTLE_TRIP.name()) && !event.getAction().name().equalsIgnoreCase(TripEvent.MANUAL_TRIP.name())) 
			throw new ValidationException("Invalid Trip");
		
		if(null!=trip) {
		  handleReassignEvent(event, trip);
	      preProcessorFactory.getPreProcessor(event.getAction()).preProcessEvent(event, trip); // Excepted to throw Validation Exception.
		}
		processorFactory.getProcessor(event.getAction()).processEvent(event, trip);
		
		postProcessorFactory.getPostProcessor(event.getAction()).postProcessEvent(event, trip);
		
		log.info("Done with processing..");
		
	}
		
	private void handleReassignEvent(TripEventInput event, Trip trip) {
		//handle re-assign
		if(TripEvent.ASSIGN == event.getAction()) { //It could be reassign..
			int currOrder = TripState.get(trip.getStatus()).getOrder();
			if(currOrder >= TripState.ASSIGNED.getOrder()  && currOrder < TripState.LOADING_COMPLETED.getOrder()) { //Trip state is more than assigned & less than start  		
				//Reassign is possible...		
				event.setAction(TripEvent.REASSIGN);	
				event.setFlowName(TripEvent.REASSIGN.name());
			}
		}
	}
}
