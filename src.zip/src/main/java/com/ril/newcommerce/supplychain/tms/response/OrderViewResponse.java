package com.ril.newcommerce.supplychain.tms.response;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class OrderViewResponse {
    private String orderId;
    private String shipmentNo;
    private Timestamp orderPlacedDate;
    private Timestamp deliveryPromisedDate;
    private String orderType;
    private String movementType;
    private String customerPincode;
    private String customerAddress;
    private String orderStatus;
    private Timestamp lastUpdatedTime;
    private String mid;
    private String destination;
    private String isRePlanned;
    private String customerName;
    private String deliveryZoneId;
}
