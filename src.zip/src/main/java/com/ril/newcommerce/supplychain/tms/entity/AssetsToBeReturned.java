/**
 * @author satya1.prakash
 *
 **/
package com.ril.newcommerce.supplychain.tms.entity;

public class AssetsToBeReturned {	
	
	private String assetType;
	
	private String count;

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "AssetsToBeReturned [assetType=" + assetType + ", count=" + count + "]";
	}
	
}
