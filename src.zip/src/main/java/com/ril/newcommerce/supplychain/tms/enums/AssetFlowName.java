package com.ril.newcommerce.supplychain.tms.enums;

public enum AssetFlowName {
	IN , OUT
}
