package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.dao.OrderInvoiceDAO;
import com.ril.newcommerce.supplychain.tms.entity.Invoice;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.OrderInvoiceService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill.Trip.TripOrders.TripOrder;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * B1.Divya
 */
@Component
@Service
public class OrderInvoiceServiceImpl implements OrderInvoiceService {

	private static final Logger log = LoggerFactory.getLogger(OrderInvoiceServiceImpl.class);
	
	@Autowired
	OrderInvoiceDAO orderInvoiceDAO;

	@Override
	public void addOrderInvoiceDetails(Invoice invoice) {
		log.info("Insert orderInvoice details");
		try {
			if (invoice != null) {
				orderInvoiceDAO.insertOrderInvoiceDetails(invoice);
			}
		} catch (Exception e) {
			log.error("Exception occured in addOrderInvoiceDetails of OrderInvoiceServiceImpl ",e);
			throw new DataProcessingException("Got Exception in addOrderInvoiceDetails OrderInvoiceServiceImpl",e);
		}
		log.info("successfully inserted invoice details");
	}

	@Override
	public List<Invoice> getAllInvoiceForTrip(String tripId,List<String> status) {
		log.info("Fetching all invoices for trip with triId :{}",tripId);
		List<Invoice> invoiceList = new ArrayList<>();
		try {
			if (tripId != null) {
				invoiceList=orderInvoiceDAO.getInvoicesForTrip(tripId,status);
			}
		} catch (Exception e) {
			log.error("Exception occured in getAllInvoiceForTrip of OrderInvoiceServiceImpl ",e);
			throw new TripApplicationException("Exception occured in getAllInvoiceForTrip of OrderInvoiceServiceImpl ",
					e);
		}
		return invoiceList;
	}

	@Override
	public void updateEwayBillStatusForOrders(List<TripOrder> tripOrders) {

		if (!tripOrders.isEmpty()) {
			try {
				orderInvoiceDAO.updateEwayBillStatus(tripOrders);
			} catch (Exception e) {
				log.error("Exception occured in updateEwayBillStatusForOrders of OrderInvoiceServiceImpl ", e);
				throw new TripApplicationException(
						"Exception occured in updateEwayBillStatusForOrders of OrderInvoiceServiceImpl ", e);
			}
		}
	}

	@Override
	public boolean isOrderInvoiced(String orderId) {

		if (!StringUtils.isBlank(orderId) ) {
			return orderInvoiceDAO.getInvoiceCount(orderId) > 0;
		}

		log.error("Exception occurred while fetching invoice count from consignment_invoice ");
		throw new TripApplicationException("Exception occurred while fetching invoice count from consignment_invoice ");
	}
}
