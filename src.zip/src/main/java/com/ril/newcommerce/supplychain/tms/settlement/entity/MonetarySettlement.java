package com.ril.newcommerce.supplychain.tms.settlement.entity;

public class MonetarySettlement {

	private Double initialCash;
	private Double cashBalance;
	private Double cashToBeCollected;
	private Double cashCollected;
	private Integer bagToBeCollected;
	private Integer bagCollected;
	private Integer toteToBeCollected;
	private Integer toteCollected;

	public Double getInitialCash() {
		return initialCash;
	}

	public void setInitialCash(Double initialCash) {
		this.initialCash = initialCash;
	}

	public Double getCashBalance() {
		return cashBalance;
	}

	public void setCashBalance(Double cashBalance) {
		this.cashBalance = cashBalance;
	}

	public Double getCashToBeCollected() {
		return cashToBeCollected;
	}

	public void setCashToBeCollected(Double cashToBeCollected) {
		this.cashToBeCollected = cashToBeCollected;
	}

	public Double getCashCollected() {
		return cashCollected;
	}

	public void setCashCollected(Double cashCollected) {
		this.cashCollected = cashCollected;
	}

	public Integer getBagToBeCollected() {
		return bagToBeCollected;
	}

	public void setBagToBeCollected(Integer bagToBeCollected) {
		this.bagToBeCollected = bagToBeCollected;
	}

	public Integer getBagCollected() {
		return bagCollected;
	}

	public void setBagCollected(Integer bagCollected) {
		this.bagCollected = bagCollected;
	}

	public Integer getToteToBeCollected() {
		return toteToBeCollected;
	}

	public void setToteToBeCollected(Integer toteToBeCollected) {
		this.toteToBeCollected = toteToBeCollected;
	}

	public Integer getToteCollected() {
		return toteCollected;
	}

	public void setToteCollected(Integer toteCollected) {
		this.toteCollected = toteCollected;
	}

	@Override
	public String toString() {
		return "MonetarySettlement [initialCash=" + initialCash + ", cashBalance=" + cashBalance
				+ ", cashToBeCollected=" + cashToBeCollected + ", cashCollected=" + cashCollected
				+ ", bagToBeCollected=" + bagToBeCollected + ", bagCollected=" + bagCollected + ", toteToBeCollected="
				+ toteToBeCollected + ", toteCollected=" + toteCollected + "]";
	}

}