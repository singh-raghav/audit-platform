package com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Address implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;

    private String addLine1;
    private String addLine2;
    private String addLine3;
    private String city;
    private String state;
    private String pincode;
}
