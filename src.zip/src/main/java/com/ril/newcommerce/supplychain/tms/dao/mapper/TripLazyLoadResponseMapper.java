package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.response.TripLazyLoadResponse;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.FC_TRIP_TYPE;

public class TripLazyLoadResponseMapper implements ResultSetExtractor<List<TripLazyLoadResponse>> {

    private String nodeId;

    public TripLazyLoadResponseMapper(String nodeId) {
        this.nodeId = nodeId;
    }

    @Override
    public List<TripLazyLoadResponse> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<TripLazyLoadResponse> tripLazyLoadResponses = new ArrayList<TripLazyLoadResponse>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            TripLazyLoadResponse tripLazyLoadResponse = new TripLazyLoadResponse();
            tripLazyLoadResponse.setTripId(rs.getString("TRIP_ID"));
            tripLazyLoadResponse.setStatus(rs.getString("STATUS"));
            tripLazyLoadResponse.setUpdatedTime(rs.getTimestamp("MODIFIED_TS"));
            tripLazyLoadResponse.setRePlanFlag(isRePlanned(rs.getString("SHIPMENT_STATUS")));
            tripLazyLoadResponse.setNextNode(rs.getString("NODE_ID"));
            tripLazyLoadResponse.setSplitAllowed(isSplitAllowed(rs.getString("SOURCE_NODE"), rs.getString("STATUS")));
            tripLazyLoadResponse.setPrimaryTrip(isPrimaryTrip(rs.getString("TYPE")));
            tripLazyLoadResponse.setMovementType(Enum.valueOf(MovementType.class, rs.getString("MOVEMENT_TYPE")));
            tripLazyLoadResponses.add(tripLazyLoadResponse);
        }
        return tripLazyLoadResponses;
    }

    private boolean isPrimaryTrip(String type) {
        return type.trim().equalsIgnoreCase(FC_TRIP_TYPE);
    }

    private boolean isSplitAllowed(String sourceNode, String status) {
        return isAuthorised(sourceNode.trim()) && stateValidForSplit(status);
    }

    private boolean stateValidForSplit(String status) {
        return status.equalsIgnoreCase(TripState.CREATED.getValue()) || status.equalsIgnoreCase(TripState.ASSIGNED.getValue());
    }

    private boolean isAuthorised(String nodeIdOfTrip) {
        return this.nodeId.trim().equalsIgnoreCase(nodeIdOfTrip);
    }

    private String isRePlanned(String shipmentStatus) {
        return shipmentStatus.trim().equalsIgnoreCase("InActive") ? "Y" : "N";
    }
}
