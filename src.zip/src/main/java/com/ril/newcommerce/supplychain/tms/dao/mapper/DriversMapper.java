package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.entity.rest.Drivers;

public class DriversMapper  implements ResultSetExtractor<List<Drivers>>  {

	@Override
	public List<Drivers> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<Drivers> drivers = new ArrayList<Drivers>();
		while (rs.next()) {
			Drivers driver = new Drivers();
			driver.setDriverId(rs.getString("DP_ID"));
			driver.setDriverName(rs.getString("DP_NAME"));
			drivers.add(driver);
		}
		return drivers;
	}

}
