package com.ril.newcommerce.supplychain.tms.entity;

public class Party {
	
	private String address;
	private String stateCode;
	private String gstin;
	private String truckOperator;
	private String vehicleNo;
	private String modeOfTransport;
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getTruckOperator() {
		return truckOperator;
	}
	public void setTruckOperator(String truckOperator) {
		this.truckOperator = truckOperator;
	}
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public String getModeOfTransport() {
		return modeOfTransport;
	}
	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}
	
	
}
