package com.ril.newcommerce.supplychain.tms.pdf.model.hubmanifest;

import java.util.ArrayList;
import java.util.List;

public class HubManifestTripDetails  implements Comparable<HubManifestTripDetails> {
    private String slNo;
    private String orderDetails;
    private String destinationDetails;
    private List<String> totesPresent = new ArrayList<>();
    private List<String> totesMissing = new ArrayList<>();
    private String mop;
    private String bill;
    private String prepaid;
    private String balance;
    private String collectedAsCash;
    private String collectedThroughCard;
    private String deliveryStatus;
    private String remarks;
    private String eWayBillNumber;
    private List<String> orderList = new ArrayList<>();
    private List<String> eWayBillList = new ArrayList<>();
    private List<String> statusList = new ArrayList<>();
    private List<String> remarkList = new ArrayList<>();
    private List<String> presentTotesList = new ArrayList<>();
    private List<String> missingTotesList = new ArrayList<>();
    private List< List<String>> dataTable = new ArrayList<>();

    public List<List<String>> getDataTable() {
        return dataTable;
    }

    public void setDataTable(List<List<String>> dataTable) {
        this.dataTable = dataTable;
    }


    public List<String> getPresentTotesList() {
        return presentTotesList;
    }

    public void setPresentTotesList(List<String> presentTotesList) {
        this.presentTotesList = presentTotesList;
    }

    public List<String> getMissingTotesList() {
        return missingTotesList;
    }

    public void setMissingTotesList(List<String> missingTotesList) {
        this.missingTotesList = missingTotesList;
    }

    public List<String> getOrderList() {
        return null== orderList? new ArrayList<>(): orderList;
    }

    public void setOrderList(List<String> orderList) {
        this.orderList = orderList;
    }

    public List<String> geteWayBillList() {
        return null== eWayBillList? new ArrayList<>(): eWayBillList;
    }

    public void seteWayBillList(List<String> eWayBillList) {
        this.eWayBillList = eWayBillList;
    }

    public List<String> getStatusList() {
        return null== statusList? new ArrayList<>(): statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }

    public List<String> getRemarkList() {
        return null== remarkList? new ArrayList<>(): remarkList;
    }

    public void setRemarkList(List<String> remarkList) {
        this.remarkList = remarkList;
    }

    public String geteWayBillNumber() {
        return eWayBillNumber;
    }

    public void seteWayBillNumber(String eWayBillNumber) {
        this.eWayBillNumber = eWayBillNumber;
    }

    public String getSlNo() {
        return slNo;
    }

    public void setSlNo(String slNo) {
        this.slNo = slNo;
    }

    public String getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(String orderDetails) {
        this.orderDetails = orderDetails;
    }

    public String getDestinationDetails() {
        return destinationDetails;
    }

    public void setDestinationDetails(String destinationDetails) {
        this.destinationDetails = destinationDetails;
    }

    public List<String> getTotesPresent() {
        return totesPresent;
    }

    public void setTotesPresent(List<String> totesPresent) {
        this.totesPresent = totesPresent;
    }

    public List<String> getTotesMissing() {
        return totesMissing;
    }

    public void setTotesMissing(List<String> totesMissing) {
        this.totesMissing = totesMissing;
    }

    public String getMop() {
        return mop;
    }

    public void setMop(String mop) {
        this.mop = mop;
    }

    public String getBill() {
        return bill;
    }

    public void setBill(String bill) {
        this.bill = bill;
    }

    public String getPrepaid() {
        return prepaid;
    }

    public void setPrepaid(String prepaid) {
        this.prepaid = prepaid;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getCollectedAsCash() {
        return collectedAsCash;
    }

    public void setCollectedAsCash(String collectedAsCash) {
        this.collectedAsCash = collectedAsCash;
    }

    public String getCollectedThroughCard() {
        return collectedThroughCard;
    }

    public void setCollectedThroughCard(String collectedThroughCard) {
        this.collectedThroughCard = collectedThroughCard;
    }

    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public int compareTo(HubManifestTripDetails o) {
        return Integer.valueOf( this.slNo).compareTo(Integer.valueOf(o.slNo));
    }
}
