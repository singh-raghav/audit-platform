package com.ril.newcommerce.supplychain.tms.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ril.newcommerce.supplychain.tms.entity.rest.Drivers;
import com.ril.newcommerce.supplychain.tms.service.DriverService;
import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;

@RestController
@RequestMapping(value = "/trip-mgmt/v1/drivers")
public class DriversController {
	
	private static final Logger log = LoggerFactory.getLogger(DriversController.class);
	
	@Autowired
	DriverService driverService;
	
	@GetMapping(value = "/{nodeId}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getAvailableDriver(@PathVariable(value = "nodeId", required = true) String nodeId){
		
		List<Drivers> availableDrivers = new ArrayList<Drivers>();
		try {
			availableDrivers = driverService.getAvailableDrivers(nodeId);
		}catch(Exception ex) {
			return Utility.getfailureMsg("Failed to get driver details!");
		}
		if(null!=availableDrivers)
		    return Utility.getSuccessMsg(availableDrivers);
		else
			return Utility.getfailureMsg("Failed to get driver details!");			
	}

}
