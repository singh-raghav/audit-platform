package com.ril.newcommerce.supplychain.tms.entity;

import java.util.Set;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class HubDetail {
	
	private String hubCode;

	private Set<String> loadedOrders;

	private Set<String> loadedHUs;

	private int sequence;

	private String seals;

	private String hubAdderss;

	public String getHubAdderss() {
		return hubAdderss;
	}

	public void setHubAdderss(String hubAdderss) {
		this.hubAdderss = hubAdderss;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public String getHubCode() {
		return hubCode;
	}

	public void setHubCode(String hubCode) {
		this.hubCode = hubCode;
	}

	public Set<String> getLoadedHUs() {
		return loadedHUs;
	}
	
	public Set<String> getLoadedOrders() {
		return loadedOrders;
	}
	
	public void setLoadedHUs(Set<String> loadedHUs) {
		this.loadedHUs = loadedHUs;
	}
	
	public void setLoadedOrders(Set<String> loadedOrders) {
		this.loadedOrders = loadedOrders;
	}
	
	public String getSeals() {
		return seals;
	}
	
	public void setSeals(String seals) {
		this.seals = seals;
	}
	
}
