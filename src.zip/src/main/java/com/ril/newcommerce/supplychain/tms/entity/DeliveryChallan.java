package com.ril.newcommerce.supplychain.tms.entity;

import java.util.Date;
import java.util.Map;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class DeliveryChallan {

	private String placeOfBusiness;
	private String challanId;
	private Party consignor ;
	private Party consignee ;
	private Date createdOn;
	private String regdOffice;
	private String phone;
	private String CIN;
	private String PAN;
	private String website;
	private String modeOfTransport;

	private ArticleInfo articleInfo; //TODO remove this... required only for V1.

	private Map<String, ArticleInfo> orderWiseInfo;
	private String hubId;

	public DeliveryChallan(String challanId) {
		this.challanId = challanId;
	}
	
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Party getConsignor() {
		return consignor;
	}
	public void setConsignor(Party consignor) {
		this.consignor = consignor;
	}
	public String getPlaceOfBusiness() {
		return placeOfBusiness;
	}
	public void setPlaceOfBusiness(String placeOfBusiness) {
		this.placeOfBusiness = placeOfBusiness;
	}
	public String getChallanId() {
		return challanId;
	}
	public void setChallanId(String challanId) {
		this.challanId = challanId;
	}
	public Party getConsignee() {
		return consignee;
	}
	public void setConsignee(Party consignee) {
		this.consignee = consignee;
	}
	public String getRegdOffice() {
		return regdOffice;
	}
	public void setRegdOffice(String regdOffice) {
		this.regdOffice = regdOffice;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCIN() {
		return CIN;
	}
	public void setCIN(String cIN) {
		CIN = cIN;
	}
	public String getPAN() {
		return PAN;
	}
	public void setPAN(String pAN) {
		PAN = pAN;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}

	public ArticleInfo getArticleInfo() {
		return articleInfo;
	}

	public void setArticleInfo(ArticleInfo articleInfo) {
		this.articleInfo = articleInfo;
	}

	public String getModeOfTransport() {
		return modeOfTransport;
	}

	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}
	
	public Map<String, ArticleInfo> getOrderWiseInfo() {
		return orderWiseInfo;
	}
	
	public void setOrderWiseInfo(Map<String, ArticleInfo> orderWiseInfo) {
		this.orderWiseInfo = orderWiseInfo;
	}

	public void setHubId(String hubId) {
		this.hubId = hubId;
	}

	public String getHubId() {
		return hubId;
	}
}
