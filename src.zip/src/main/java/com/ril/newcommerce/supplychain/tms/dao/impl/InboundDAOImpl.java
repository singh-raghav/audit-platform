package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.AccumulatedReturnItemsMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ChallanDetailMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ChallanDetailsMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ChallanHubMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ChallanReturnItemMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ChallanTripArticleMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ItemQualityMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.OrderItemAccumulatedMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ReturnItemListByIdMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ReturnItemsByIdMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ReturnItemsByOrderMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.StateWiseBusinessMapper;
import com.ril.newcommerce.supplychain.tms.entity.BusinessDetail;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.enums.OrderClassification;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
@Repository
public class InboundDAOImpl implements InboundDAO {
	
	private static final Logger log = LoggerFactory.getLogger(InboundDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public BusinessDetail getBusinessDetails(String stateCode) {
		
		log.info("Fetching Business detail for given state : {} " , stateCode);
		List<String> stateCodes = new ArrayList<String>();
		stateCodes.add(stateCode);
		
		List<BusinessDetail> businessDetails = getBusinessDetails(stateCodes);
		
		if(CollectionUtils.isNotEmpty(businessDetails))
			return businessDetails.get(0);
		
		return null;
		
	}
	
	@Override
	public List<BusinessDetail> getBusinessDetails(List<String> stateCodes) {
		
		log.info("Fetching Business deatils for states : {} " ,  stateCodes);
		
		List<BusinessDetail> businessDetails=null;
		
		try {
			
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("stateCodes", stateCodes);
			
			businessDetails =namedParameterJdbcTemplate.query(QueryConstants.GET_STATE_WISE_BUSINESS_DETAILS, parameters,  new StateWiseBusinessMapper());
		}
		catch (Exception e) {
			throw new TripApplicationException("Error on fetchin stateWise Business details",e);
		}
		
		return businessDetails;
	}
	
	@Override
	public Map<String,BusinessDetail> getBusinessDetailsBystateCode(List<String> stateCodes) {
		
		Map<String,BusinessDetail> map = new HashMap<>();
		
		try {
			List<BusinessDetail> businessDetails = getBusinessDetails(stateCodes);
			
			if(!CollectionUtils.isEmpty(businessDetails)) {
				for(BusinessDetail detail :  businessDetails) {
					map.put(detail.getCode(),detail);
				}
			}
		}
		catch (Exception e) {
			throw new TripApplicationException("Error on fetchin stateWise Business details map"+e);
		}
		
		return map;
	}

	
	@Override
	public Map<String, List<ChallanArticle>> getArticlesByReturnOrderId(List<String> challanIds,String tripId){
		
		Map<String, List<ChallanArticle>> challanArticles = new HashMap<>();
		log.info("Fetching delivery challan Articles : {} " , challanIds);
		try {
			
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("challanIds", challanIds);
			parameters.addValue("tripId", tripId);
			
			challanArticles = namedParameterJdbcTemplate.query(QueryConstants.GET_ARTICLES_BY_CHALLAN_ID,parameters,new ChallanDetailsMapper());
		}
		catch(Exception e) {
			log.error("Exception occured on fetching Challan Articles" + e);
			throw new TripApplicationException("Exception occured on fetching delivery challan articles" + e.getMessage());
		}
		
		return challanArticles;
	}
	
	@Override
	public List<ChallanArticle> getReturnItemsAgainstTrip(String tripId,List<String> qualities) {
		List<ChallanArticle> challanArticles = null;
		log.info("Fetching delivery challan Articles details for trip : {} " , tripId);
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripId", tripId);
			parameters.addValue("qualities", qualities);
			parameters.addValue("articleType", ArticleType.RETURN_ITEM.name());
			
			challanArticles = namedParameterJdbcTemplate.query(QueryConstants.GET_DELIVERY_CHALLAN_ARTICLES_FOR_TRIP, parameters , new ChallanTripArticleMapper());
			
			log.info("Fetching delivery challan Articles details for trip : {} - {}  " , tripId , challanArticles);
		}
		catch (Exception e) {
			log.error("Exception occured on fetching Challan Articles -- ",e);
			throw new TripApplicationException(e);
		}
		return challanArticles;
	}

	private List<Long> getDeliveryChallanSeq(int count) {
		log.info("Getting Delivery challan sequence");
		try {
			List<Long> seq = jdbcTemplate.query(QueryConstants.GET_DELIVERY_CHALLAN_SEQ, new Object[] {count}, (rs, arg)->{
				return rs.getLong("ID");
			});
			if(seq==null)
				throw new ValidationException("Unexpected delivery challan id.. Aborting the challan creation..");
			
			return seq;
		}
		catch (ValidationException e) {
			throw e;
		}
		catch (Exception e) {
			throw new TripApplicationException("Exception Occured on generating challan id.."+e);
		}
	}
	
	private List<Long> getPickupChallanSeq(int count) {
		log.info("Getting Pickup challan sequence");
		try {
			List<Long> seq = jdbcTemplate.query(QueryConstants.GET_PICKUP_CHALLAN_SEQ, new Object[] {count}, (rs, arg)->{
				return rs.getLong("ID");
			});
			if(seq==null)
				throw new ValidationException("Unexpected pickup challan id.. Aborting the challan creation..");
			
			return seq;
		}
		catch (ValidationException e) {
			throw e;
		}
		catch (Exception e) {
			throw new TripApplicationException("Exception Occured on generating challan id.."+e);
		}
	}
	
	@Override
	public List<ChallanArticle> insertDeliverychallanArticles(List<ChallanArticle> challanArticles,String nodeId) {
		
		List<ChallanArticle> failedArticles = null;
		try {
			jdbcTemplate.batchUpdate(
					QueryConstants.INSERT_DELIVERY_CHALLAN_ARTICLES,
					new BatchPreparedStatementSetter() {
						
						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {
							ps.setString(1,challanArticles.get(i).getChallanId());
							ps.setString(2,challanArticles.get(i).getTripId());
							ps.setString(3,challanArticles.get(i).getReturnOrderId());
							ps.setString(4,challanArticles.get(i).getArticleCode());
							ps.setString(5,challanArticles.get(i).getQuality().name());
							ps.setString(6,challanArticles.get(i).getArticleType());
							ps.setDouble(7,challanArticles.get(i).getQuantity());
							ps.setString(8,challanArticles.get(i).getCreatedBy());
							ps.setString(9,nodeId);
						}
						
						@Override
						public int getBatchSize() {
							return challanArticles.size();
						}
					});
					
		}
		catch (Exception e) {
			log.error("Exception occured on inserting delivery challan articles " +  e);
			return challanArticles;
		}
		
		return failedArticles;
	}
	
	
	@Override
	public List<ReturnItem> getReturnItems(List<String> returnOrderIds) {
		
		log.info("Fetching return Items for return orders  : {} " ,  returnOrderIds);
		List<ReturnItem> returnItems =null;
		
		try {
			StringBuilder queryBuilder=new StringBuilder();
			queryBuilder.append(QueryConstants.GET_RETURN_ITEMS_BY_ORDER_ID);
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			if(!CollectionUtils.isEmpty(returnOrderIds))
			{
				queryBuilder.append("return_order_id in (:returnOrderIds)");
				parameters.addValue("returnOrderIds", returnOrderIds);
			}
			
			returnItems =namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters,  new ReturnItemsByOrderMapper());
		}
		catch (Exception e) {
			throw new TripApplicationException("Fetching return Items for return orders",e);
		}
		
		return returnItems;
	}
	
	@Override
	public Map<String,ReturnItem> getReturnItemById(List<String> returnOrderIds) {
		
		log.info("Fetching return Items for return orders  : {} " ,  returnOrderIds);
		Map<String,ReturnItem> returnItems =null;
		
		try {
			StringBuilder queryBuilder=new StringBuilder();
			queryBuilder.append(QueryConstants.GET_RETURN_ITEMS_BY_ORDER_ID);
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			if(!CollectionUtils.isEmpty(returnOrderIds))
			{
				queryBuilder.append("return_order_id in (:returnOrderIds)");
				parameters.addValue("returnOrderIds", returnOrderIds);
			}
			
			
			returnItems =namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters,  new ReturnItemsByIdMapper());
		}
		catch (Exception e) {
			throw new TripApplicationException("Error on fetchin stateWise Business details",e);
		}
		
		return returnItems;
	}
	
	@Override
	public Map<String,List<ReturnItem>> getReturnItemsByReturnOrderId(List<String> returnOrderIds,List<String> challanIds) {
		
		log.info("Fetching return Items for return orders  : {} " ,  returnOrderIds);
		Map<String,List<ReturnItem>> returnItems =null;
		
		try {
			StringBuilder queryBuilder=new StringBuilder();
			queryBuilder.append(QueryConstants.GET_RETURN_ITEMS_BY_ORDER_ID);
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			if(!CollectionUtils.isEmpty(returnOrderIds))
			{
				queryBuilder.append("return_order_id in (:returnOrderIds)");
				parameters.addValue("returnOrderIds", returnOrderIds);
			}
			else if(!CollectionUtils.isEmpty(challanIds))
			{
				queryBuilder.append("challan_id in (:challanIds)");
				parameters.addValue("challanIds", challanIds);
			}
			
			returnItems =namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters,  new ReturnItemListByIdMapper());
		}
		catch (Exception e) {
			throw new TripApplicationException("Error on fetchin getReturnItemsById details",e);
		}
		
		return returnItems;
	}
	
	
	@Override
	public void updateChallanIdConstrained(String returnOrderId , String challanId) {
		
		log.info("updating challan id in return items table :  {} - {}  " ,  returnOrderId , challanId);
		
		try {		
			int updatedCount =  jdbcTemplate.update(QueryConstants.UPDATE_RETURN_ITEMS_CHALLAN_ID_CONSTRAINED, new Object[] {challanId,returnOrderId});
	
			if(updatedCount==0)
				throw new ValidationException(returnOrderId);
		}
		catch(ValidationException e) {
			throw e;
		}
		catch (Exception e) {
			throw new TripApplicationException("Error on updating challan Id ",e);
		}
	}
	
	
	@Override
	public void updateChallanId(String returnOrderId , String challanId) {
		
		log.info("updating challan id in return items table :  {} - {}  " ,  returnOrderId , challanId);
		
		try {		
			jdbcTemplate.update(QueryConstants.UPDATE_RETURN_ITEMS_CHALLAN_ID, new Object[] {challanId,returnOrderId});
		}
		catch (Exception e) {
			throw new TripApplicationException("Error on updating challan id",e);
		}
	}
	
	
	@Override
	public Map<String,Map<String , Set<String>>> getChallanIds(List<String> tripIds) {
		log.info("Get challan information per hub for trips : {} " , tripIds);
		Map<String,Map<String , Set<String>>> challanIdsPerHub = new HashMap<>();
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripIds", tripIds);
			challanIdsPerHub = namedParameterJdbcTemplate.query(QueryConstants.GET_CHALLANS_HUB_ID_BY_TRIP, parameters, new ChallanHubMapper());
		}
		catch (Exception e) {
			log.error("EException occured on fetching challan Id vs Hub id "+e);
			throw new TripApplicationException("Exception occured on fetching challan Id vs Hub id " + e);
		}
		
		return challanIdsPerHub;
	}
	
	@Override
	public void updateChallanIdByOrderIds(List<String> returnOrderIds , String challanId) {
		
		log.info("updating challan id in return items table.  : {} " ,  returnOrderIds);
		
		try {
			
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("returnOrderIds", returnOrderIds);
			parameters.addValue("challanId", challanId);
			
			namedParameterJdbcTemplate.update(QueryConstants.UPDATE_RETURN_ITEMS_CHALLAN_ID_BY_ORDER_IDS, parameters);
		}
		catch (Exception e) {
			throw new TripApplicationException("Error on fetchin stateWise Business details",e);
		}
	}

	
	@Override
	public void deleteChallanArticle(List<String> returnOrderIds) {
		
		log.info("Deleting delivery challan article :  -  {}  " , returnOrderIds);
		
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("returnOrderIds", returnOrderIds);
			namedParameterJdbcTemplate.update(QueryConstants.DELETE_DELIVERY_CHALLAN_ARTICELS, parameters);
		} catch (Exception e) {
			log.info("Exception occurred on deleting delivery challan"+e);
			throw new TripApplicationException("Exception occured during deleting delivery challan information  ", e);
		}
	}
	
	@Override
	public void updateChallantripId(List<String> orderIds , String tripId) {
		
		log.info("Deleting delivery challan article :  -  {}  {} " , orderIds , tripId);
		
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("returnOrderIds", orderIds);
			parameters.addValue("tripId", tripId);
			namedParameterJdbcTemplate.update(QueryConstants.UPDATE_DELIVERY_CHALLAN_TRIP_ID, parameters);
		} catch (Exception e) {
			log.info("Exception occured during updating delivery challan tripId "+e);
			throw new TripApplicationException("Exception occured during updating delivery challan tripId  ", e);
		}
	}
	
	@Override
	public List<ChallanArticle> getChallanArticles(String challanId) {
		List<ChallanArticle> challanArticles = null;
		try {
			challanArticles = jdbcTemplate.query(QueryConstants.GET_DELIEVERY_CHALLAN_ARTICLES_BY_ID, new Object[] {challanId} , new ChallanReturnItemMapper());
		}
		catch (Exception e) {
			throw new TripApplicationException("Exception ocurred on fetching delivery challan articles ", e);
		}
		return challanArticles;
	}

	@Override
	public List<ChallanArticle> getChallanArticlesByReturnOrderId(List<String> orderIds) {
		List<ChallanArticle> challanArticles = null;
		try {
			 	NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
				MapSqlParameterSource parameters = new MapSqlParameterSource();
				parameters.addValue("returnOrderId", orderIds);
					
			challanArticles = namedParameterJdbcTemplate.query(QueryConstants.GET_CHALLAN_ARTICLE_QUALITY, parameters , new ItemQualityMapper());
		}
		catch (Exception e) {
			throw new TripApplicationException("Exception ocurred on fetching delivery challan articles quality  ", e);
		}
		return challanArticles;
	}
	
	@Override
	public Set<String> getAvailableOrders(String nodeId, String orderSrcNodeId) {
		Set<String> returnOrderIds = new HashSet<String>();
		try {
			List<String> ids = jdbcTemplate.query(QueryConstants.GET_AVAILABLE_RETURN_ORDERS_ON_NODE, new Object[] {orderSrcNodeId,nodeId}, (ResultSet rs, int rowNum) -> rs.getString("return_order_id"));
			
			if(CollectionUtils.isNotEmpty(ids))
				returnOrderIds.addAll(ids);
		}
		catch (Exception e) {
			log.error("Exception occurred on fetching available orders " + e);
			throw new TripApplicationException("Exception ocurred on fetching available orders ", e);
		}
		return returnOrderIds;
	}

	public void addReturnItems(List<ReturnItem> returnItems,String flowName) {
		
		try {
			jdbcTemplate.batchUpdate(
					QueryConstants.ADD_RETURN_ITEMS,
					new BatchPreparedStatementSetter() {
						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {
							ps.setString(1,returnItems.get(i).getFwdOrderId());
							ps.setString(2,returnItems.get(i).getReturnOrderId());
							ps.setString(3,returnItems.get(i).getPrimeLineNo());
							ps.setString(4,returnItems.get(i).getItemId());
							ps.setString(5,returnItems.get(i).getItemName());
							ps.setDouble(6,returnItems.get(i).getOrderedQuantity());
							ps.setString(7,returnItems.get(i).getHsnCode());
							ps.setDouble(8,returnItems.get(i).getUnitPrice());
							ps.setString(9,returnItems.get(i).getUom());
							ps.setDouble(10,returnItems.get(i).getRecievedQuantity());
							ps.setDouble(11,returnItems.get(i).getInvoicedQuanity());
							ps.setString(12,returnItems.get(i).getReturnType());
							ps.setString(13, flowName);
						}
						
						@Override
						public int getBatchSize() {
							return returnItems.size();
						}
					});
					
		}
		catch (Exception e) {
			throw new TripApplicationException("Exception occured on inserting the return items"+ e);
		}
		
	}

	@Override
	public List<String> getAvailableOrdersByOrderId(List<String> returnOrderIds) {
		List<String> availableOrders = null;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("returnOrderIds", returnOrderIds);
			
			availableOrders = namedParameterJdbcTemplate.query(QueryConstants.GET_AVAILABLE_RETURN_ORDERS_BY_ID, parameters, (ResultSet rs, int rowNum) -> rs.getString("return_order_id"));
			
		}
		catch (Exception e) {
			log.error("Exception occurred on fetching available return orders by id " + e);
			throw new TripApplicationException("Exception occurred on fetching available return orders by id ", e);
		}
		return availableOrders;
	}

	@Override
	public List<String> getChallanIds(String tripId,String nodeId) {
		List<String> challanIds = null;
		try {
			challanIds = jdbcTemplate.query(QueryConstants.GET_CHALLAN_IDS_BY_TRIP, new Object [] {tripId,nodeId}, (ResultSet rs, int rowNum) -> rs.getString("challan_id"));
		}
		catch (Exception e) {
			log.error("Exception occurred on fetching challan ids by tripid " + e);
			throw new TripApplicationException("Exception occurred on  fetching challan ids by tripid ", e);
		}
		return challanIds;
	}
	
	@Override
	public String getChallanId(String returnOrderId) {
		try {
			List<String> challanIds = jdbcTemplate.query(QueryConstants.GET_CHALLAN_ID_BY_ORDER_ID, new Object [] {returnOrderId}, (ResultSet rs, int rowNum) -> rs.getString("challan_id"));
			if(CollectionUtils.isNotEmpty(challanIds))
				return challanIds.get(0);
		}
		catch (Exception e) {
			log.error("Exception occurred on fetching challan ids by tripid " + e);
			throw new TripApplicationException("Exception occurred on  fetching challan ids by tripid ", e);
		}
		return null;
	}
	
	@Override
	public List<ReturnItem> getReturnItemAccumulated(List<String> returnOrderIds) {
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("returnOrderIds", returnOrderIds);
			
			return namedParameterJdbcTemplate.query(QueryConstants.GET_AVAILABLE_RETURN_ITEMS_BY_ORDER_ID, parameters,  new AccumulatedReturnItemsMapper());
		
		}
		catch (Exception e) {
			log.error("Exception occured on fetching Accumulated Item count " + e);
			throw new TripApplicationException("Unable to Fetch Accumulated Return Items ",e);
		}
	}
	
	@Override
	public List<ReturnItem> getItemAccumulatedByOrderId(List<String> returnOrderIds) {
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("returnOrderIds", returnOrderIds);
			
			return namedParameterJdbcTemplate.query(QueryConstants.GET_ITEMS_ACCUMULATED_BY_ORDER, parameters,  new OrderItemAccumulatedMapper());
		
		}
		catch (Exception e) {
			log.error("Exception occured on getItemAccumulatedByOrderId count " + e);
			throw new TripApplicationException("Unable to Fetch Accumulated Return Items ",e);
		}
	}


	@Override
	public void insertIntoDeliveryChalanArticles(List<ReconcileArticle> reconcileArticleList, String tripId) {
		try {
			jdbcTemplate.batchUpdate(
					QueryConstants.UPDATE_TRIP_DELIVERY_CHALLAN_ARTICLES,
					new BatchPreparedStatementSetter() {

						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {
							ps.setDouble(1,reconcileArticleList.get(i).getUpdateQuantity());
							ps.setString(2,reconcileArticleList.get(i).getOrderId());
							ps.setString(3,reconcileArticleList.get(i).getArticleId());
							ps.setString(4,tripId);
							ps.setString(5,reconcileArticleList.get(i).getQuality());
						}

						@Override
						public int getBatchSize() {
							return reconcileArticleList.size();
						}
					});

		}
		catch (Exception e) {
			throw new TripApplicationException("Exception occurred while updating RECEIVED_QTY in DELIVERY_CHALLAN_ARTICLES table ", e);
		}
	}

	@Override
	public String getDeliveryChallanSeq() {
		return String.valueOf(getDeliveryChallanSeq(1).get(0));
	}
	
	@Override
	public String getPickupChallanSeq() {
		return String.valueOf(getPickupChallanSeq(1).get(0));
	}
	
	@Override
	public Map<String,String> getPDRIdAndSourceNode(String tripId) {
		 Map<String,String> orderIds = null;
		try {
			List<Map<String, Object>> res = jdbcTemplate.queryForList(QueryConstants.GET_ORDER_IDS_TRIP_CLASSIFICATION, new Object [] {OrderClassification.Return.getValue(),tripId});
			if(CollectionUtils.isNotEmpty(res))
				orderIds = res.stream().collect(Collectors.toMap(rs-> (String)rs.get("order_id"), rs-> (String)rs.get("source_node")));
		}
		catch (Exception e) {
			log.error("Exception occurred on fetching orderids ids by tripid " + e);
			throw new TripApplicationException("Exception occurred on  fetching challan ids by tripid ", e);
		}
		return orderIds;
	}
	
	@Override
	public Map<String,Integer> getReturnOrderCount(List<String> tripIds) {
		 Map<String,Integer> returnOrderCountsByTrip = null;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripIds", tripIds);
			
			List<Map<String, Object>> res = namedParameterJdbcTemplate.queryForList(QueryConstants.GET_RETURN_ORDERS_COUNT,parameters);
			if(CollectionUtils.isNotEmpty(res))
				returnOrderCountsByTrip = res.stream().collect(Collectors.toMap(rs-> (String)rs.get("trip_id"), rs-> ((BigDecimal)rs.get("count")).intValue()));
		}
		catch (Exception e) {
			log.error("Exception occurred on fetching orderids ids by tripid " + e);
			throw new TripApplicationException("Exception occurred on  fetching challan ids by tripid ", e);
		}
		return returnOrderCountsByTrip;
	}

	
	@Override
	public Map<String,String> getSourceNode(List<String> orderIds) {
		 Map<String,String> orderIdSourceNode = null;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("orderIds", orderIds);
			
			List<Map<String, Object>> res =namedParameterJdbcTemplate.queryForList(QueryConstants.GET_SOURCE_NODE_BY_ORDER_IDS, parameters);
			
			if(CollectionUtils.isNotEmpty(res))
				orderIdSourceNode = res.stream().collect(Collectors.toMap(rs-> (String)rs.get("order_id"), rs-> (String)rs.get("source_node")));
		}
		catch (Exception e) {
			log.error("Exception occurred on fetching orderids ids by tripid " + e);
			throw new TripApplicationException("Exception occurred on  fetching challan ids by tripid ", e);
		}
		return orderIdSourceNode;
	}
	
	@Override
	public void updateDeliverychallanArticles(List<ChallanArticle> challanArticles) {
		try {
			jdbcTemplate.batchUpdate(
					QueryConstants.UPDATE_CHALLAN_ARTICLE_DETAILS,
					new BatchPreparedStatementSetter() {
						
						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {							
							ps.setDouble(1,challanArticles.get(i).getQuantity());
							ps.setString(2,challanArticles.get(i).getTripId());
							ps.setString(3,challanArticles.get(i).getReturnOrderId());
							ps.setString(4,challanArticles.get(i).getArticleCode());
							ps.setString(5,challanArticles.get(i).getQuality().name());
						}
						
						@Override
						public int getBatchSize() {
							return challanArticles.size();
						}
					});
					
		}
		catch (Exception e) {
			log.error("Exception occured on update delivery challan articles " +  e);
			throw new TripApplicationException("Exception occured on updating the delviery challan articles"+ e);
		}
		
	}
	
	@Override
	public List<ChallanArticle> getChallanArticlesAgainstTrip(String tripId,  String hubId) {
		List<ChallanArticle> challanArticles = null;
		log.info("Fetching delivery challan Articles details for trip  and hub id: {} {}" , tripId);
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("articleType", ArticleType.RETURN_ITEM.name());
		parameters.addValue("tripId", tripId);
		parameters.addValue("nodeId",hubId);
		try {
			challanArticles = namedParameterJdbcTemplate.query(QueryConstants.GET_DELIVERY_CHALLAN_ARTICLES_FOR_TRIP_ID, parameters, new ChallanDetailMapper());
		}
		catch (Exception e) {
			log.error("Exception occured on fetching Challan details  -- ",e);
			throw new TripApplicationException("Exception occured on fetching Challan details "+e);
		}
		return challanArticles;
	}
}
