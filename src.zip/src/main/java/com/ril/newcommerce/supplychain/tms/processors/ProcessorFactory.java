package com.ril.newcommerce.supplychain.tms.processors;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.ORDER_INVOICE_DETAILS_PROCESSOR;
import static com.ril.newcommerce.supplychain.tms.constants.Constants.RETURN_INVOICE_DETAILS;

/**
 * B1.Divya
 */
@Component
public class ProcessorFactory {
	
	@Autowired
	@Qualifier("publishConnectionTripProcessor")
    private Processor publishConnectionTripProcessor;
	
	@Autowired
	@Qualifier("tripSettleUpdateProcessor")
    private Processor tripSettleUpdateProcessor;
	
	@Autowired
	@Qualifier("publishTripProcessor")
	private Processor publishTripProcessor;

	@Autowired
	@Qualifier("publishFluidTripProcessor")
	private Processor publishFluidTripProcessor;

	@Autowired
	@Qualifier("createFluidLoadingSecondaryTripProcessor")
	private Processor createFluidLoadingSecondaryTripProcessor;
	
	@Autowired
	@Qualifier("orderDetailsProcessor")
	private Processor orderDetailsProcessor;

	@Autowired
	@Qualifier(ORDER_INVOICE_DETAILS_PROCESSOR)
	private Processor orderInvoiceDetailsProcessor;

	@Autowired
	@Qualifier("tripDetails")
	private Processor tripProcessor;
	
	@Autowired
	@Qualifier("addLabelProcessor")
	private Processor addLabelProcessor;
	
	@Autowired
	@Qualifier("ewayBillResponseProcessor")
	private Processor ewayBillResponseProcessor;
	
	@Autowired
	@Qualifier("tripStatusProcessor")
	private Processor tripStatusProcessor;
	
	@Autowired
	@Qualifier(Constants.POST_SPILT_PROCESSOR)
	private Processor postSplitProcessor;
	
	@Autowired
	@Qualifier(RETURN_INVOICE_DETAILS)
	private Processor returnInvoiceDetails;

	@Autowired
	@Qualifier(Constants.POST_MERGE_PROCESSOR)
	private Processor postMergeProcessor;
	

	@Autowired
	@Qualifier(Constants.POST_LOADING_COMPLETE)
	private Processor postLoadingComplete;

	@Autowired
	@Qualifier(Constants.POST_FLUID_LOADING_COMPLETE)
	private Processor postFluidLoadingComplete;
	
	@Autowired
	@Qualifier(Constants.PUBLISH_TO_GRAB)
	private Processor publishToGrab;
	
	@Autowired
	@Qualifier(Constants.WAYPOINT_UPDATES)
	private Processor wayPointUpdatesProcessor;
	
	@Autowired
	@Qualifier(Constants.ORDER_STATUS_UPDATE_PROCESSOR)
	private Processor orderStatusUpdateProcessor;
	
	@Autowired
	@Qualifier(Constants.RETURN_ITEM_TO_SAP)
	private Processor publishReturnItems;

	@Autowired
	@Qualifier(Constants.DELAYED_SHIPMENT_PROCESSOR)
	private Processor delayedShipmentProcessor;

	@Autowired
	@Qualifier(Constants.CANCEL_ORDER_PROCESSOR)
	private Processor cancelOrderProcessor;
	
	@Autowired
	@Qualifier(Constants.SHUTTLE_TRIP_PROCESSOR)
	private Processor shuttleTripProcessor;

	@Autowired
	@Qualifier(Constants.CANCEL_RETURN_ORDER_PROCESSOR)
	private Processor orderStatusReturnCancelledProcessor;
	
	@Autowired
	@Qualifier(Constants.PACK_FEED_PROCESSOR)
	private Processor packFeedProcessor;

	@Autowired
    @Qualifier(Constants.FLUID_LOADING_PROCESSOR)
	private Processor fluidLoadingProcessor;

	@Autowired
	@Qualifier(Constants.LABEL_STAGING_PROCESSOR)
	private Processor labelStagingProcessor;

	public Processor getProcessor(FlowName flowName) {
		if (flowName == null) {
			return null;
		}

		switch (flowName) {
		case PUBLISHTRIP:
			return publishTripProcessor;

        case FLUIDLOADING_PUBLISHTRIP:
        	return publishFluidTripProcessor;

			case CREATE_FLUIDLOADING_SECONDARYTRIP:
				return createFluidLoadingSecondaryTripProcessor;
			
		case ORDERDETAILS:
			return orderDetailsProcessor;

		case TRIPFEED:
			return tripProcessor;
			
		case ORDERINVOICEDETAILS:
			return orderInvoiceDetailsProcessor;
			
		case ADDLABEL:
			return addLabelProcessor;
			
		case EWAYBILLRESPONSE:
			return ewayBillResponseProcessor;
			
		case SPLIT:
			return postSplitProcessor;
			
		case MERGE:
			return postMergeProcessor;
		
		case LOADINGSTART:
		case LOADINGCOMPLETE:
		case UNLOADINGSTART:
		case UNLOADINGCOMPLETE:
			return tripStatusProcessor;
			
		case POSTLOADINGCOMPLETE:
			return postLoadingComplete;

        case POSTFLUIDLOADINGCOMPLETE:
        	return postFluidLoadingComplete;


		case RETURNINVOICE:
			return returnInvoiceDetails;
	
		case PUBLISHTOGRAB:
			return publishToGrab;
			
		case WAYPOINTUPDATES:
			return wayPointUpdatesProcessor;
			
		case CANCELLEDSTATUS:
			return cancelOrderProcessor;

		case FCDELAYED:
			return delayedShipmentProcessor;

		case ORDER_STATUS_UPDATE:
			return orderStatusUpdateProcessor;
			
		case RETURNITEMSAP:
			return publishReturnItems;
			
		case CREATESHUTTLETRIP:
			return shuttleTripProcessor;

		case RETURN_CANCELLEDSTATUS:
			return orderStatusReturnCancelledProcessor;
			
		case PACKFEED:
			return packFeedProcessor;
			
		case TRIPSETTLEUPDATE:
			return tripSettleUpdateProcessor;
			
		case PUBLISHCONNECTIONTRIP:
			return publishConnectionTripProcessor;

        case FLUIDLOADING:
            return fluidLoadingProcessor;

	  case STAGING_FEED:
            return labelStagingProcessor;

		default:
			return null;

		}

	}

}
