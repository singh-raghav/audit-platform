package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails.NodeDetailsResponse;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;
import com.ril.newcommerce.supplychain.tms.externalApis.NodeDetailsFeign;
import com.ril.newcommerce.supplychain.tms.service.NodeDetailApiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class NodeDetailApiServiceImpl implements NodeDetailApiService {

    private static final Logger LOGGER = LoggerFactory.getLogger(NodeDetailApiServiceImpl.class);

    @Autowired
    private NodeDetailsFeign nodeDetailsFeign;

    @Value("${nodeDetailService.clientId}")
    private String clientId;

    @Value("${nodeDetailService.apiKey}")
    private String apiKey;


    @Override
    public NodeDetailsResponse getNodeList(NodeType nodeType){
        LOGGER.info("Calling NodeDetail service to get node list");

        return nodeDetailsFeign.getNodeListAgainstNodeType(clientId, apiKey, nodeType);
    }

    //TODO: getNodesForLevel is not in use. Ensure with NDS before using it. Now this API is not in production
    @Override
    public NodeDetailsResponse getNodesForLevel(String nodeId, String level) {
        LOGGER.info("Calling NodeDetail service to get nodes with level ");

        return nodeDetailsFeign.getNodeDetailsWithHierarchyWithLevels(clientId, apiKey, nodeId, level);
    }

    @Override
    public NodeDetailsResponse getNodeDetails(String nodeId, NodeType nodeType,boolean hierarchy) {
        NodeDetailsResponse clusterDetailsWithHierarchy = new NodeDetailsResponse();

        LOGGER.info("Calling NodeDetail service to get node details");

        try
		{
			if (hierarchy) {
				if (nodeType.equals(NodeType.CLUSTER)) {
					clusterDetailsWithHierarchy = nodeDetailsFeign.getClusterDetailsWithHierarchy(clientId, apiKey,
							nodeId);

				} else {
					clusterDetailsWithHierarchy = nodeDetailsFeign.getNodeDetailsWithHierarchy(clientId, apiKey,
							nodeId);
				}
			} else {
				if (nodeType.equals(NodeType.CLUSTER)) {
					clusterDetailsWithHierarchy = nodeDetailsFeign.getClusterDetails(clientId, apiKey,
							nodeId);

				} else {
					clusterDetailsWithHierarchy = nodeDetailsFeign.getNodeDetails(clientId, apiKey,
							nodeId);
				}
			}

		} catch (Exception e) {
            LOGGER.error("Exception while calling node service",e);
            clusterDetailsWithHierarchy.setStatusCode(500);
        }
        return clusterDetailsWithHierarchy;
    }

}
