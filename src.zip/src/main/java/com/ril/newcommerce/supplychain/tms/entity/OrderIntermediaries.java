package com.ril.newcommerce.supplychain.tms.entity;

import lombok.Data;

@Data
public class OrderIntermediaries {

    private String orderId;
    private String nodeId;

}
