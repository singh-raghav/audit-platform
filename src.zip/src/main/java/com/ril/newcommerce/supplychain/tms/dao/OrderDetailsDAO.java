package com.ril.newcommerce.supplychain.tms.dao;

import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.response.OrderCountResponse;
import com.ril.newcommerce.supplychain.tms.response.OrderListResponse;
import com.ril.newcommerce.supplychain.tms.response.OrderListResponseFluidLoading;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

/**
B1.Divya
*/

public interface OrderDetailsDAO {

	void insertOrderDetails(List<OrderDetails> orderDetails);
	
	public int updateOrderDetails(Timestamp slotStartTime, Timestamp slotEndTime, String orderId, String shipmentNo);
	
	public List<Consignment> getTripOrderDetails(String tripIds, String nodeId, List<String> status, List<String> shipmentNos,String orderclassification);
	
	public List<OrderDetails> getOrderDetails(List<String> orderId, List<String> shipmentNo);

	public void updateOrderStatus(List<String> orderIds, String status,String flowName,String modifiedBy);

	void updateOrderDetails(Map<String,String> setMap, Map<String,Object> whereMap);

	List<String> getAllOrders(List<String> nodeIds, String fromDate, String toDate, String orderId, List<String> orderStatus, List<String> orderType, List<String> movementType, List<String> destHubs);

	public Map<String,OrderDetails> getCustomerInfo(List<String> orderIds);
	
	public void insertCustomerDetails(List<OrderDetails> orderDetails);

	OrderListResponse getOrders(List<String> nodeIds, int pageSize, int pageIndex, String fromDate,
                                String toDate, String orderId, List<String> orderStatus, List<String> orderType, List<String> movementType, List<String> destHubs);

	OrderListResponseFluidLoading tripOrderViewFluidLoading(List<String> nodeIds, Integer pageSize, Integer pageIndex, String fromDate,
														   String toDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs);


	OrderListResponseFluidLoading consignmentViewFluidLoading(List<String> nodeIds, Integer pageSize, Integer pageIndex, String fromDate,
														   String toDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs);

	List<OrderDetails> getOrderDetails(String tripId);

	List<OrderCountResponse> orderCountForSDP(List<String> nodeIds, List<String> sdpIds, String startDate, String endDate);

	List<Consignment> getUnplannedCustomerReturnOrder(String nodeId);

	List<Consignment> getUnplannedRescheduledOrders(String nodeId);

    String getOrderIdForShipment(String shipmentNo);
}
