package com.ril.newcommerce.supplychain.tms.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.settlement.entity.AdditionalCharges;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReturnedAsset;

/**
 * B1.Divya
 */

public class Trip {
	
	private String tripId;
	private String tripType;
	private String sourceNode;
	private Timestamp plannedStartTime;
	private Timestamp plannedEndTime;
	private Timestamp actualStartTime;
	private Timestamp actualEndTime;
	private Timestamp createdTime;
	private String status;
	private String vehicleModel;
	private String fleetType;
	private String suggestedVehicleNo;
	private String vendorName;
	private String vendorId;
	private String driverMobileNumber;
	private String assignedVehicle;
	private String assignedDp;
	private String assignedDpId;
	private Double startKm;
	private Double endKm;
	private double plannedKm;
	private boolean isAdhocTrip;
	private String vrnId;
	private double prepaidAmount = 0.0;
	private double initialCash=0.0;
	private double cashBalance=0.0;
	private double cashToBeCollected=0.0;
	private double cashCollected=0.0;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String createdBy;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String modifiedBy;
	private List<Consignment> consignment;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private TripCountOnStatus tripCountOnStatus;//??
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer secondaryTripsCount;//??
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private TripConsignmentCount tripConsignmentCount;
	private List<Seal> seal;
	private List<Hub> hub;
	private List<String> associatedTrips;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String externalReferenceId;//??
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String flowName;//??
	private int bagToBeCollected=0;
	private int bagCollected=0;
	private int toteToBeCollected=0;
	private int toteCollected=0;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<ReconcileArticle> reconcileArticles;
	private List<ReturnedAsset> returnedAssets;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private AdditionalCharges additionalCharges;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer unassignedTasks;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer deliveredTasks;
	private Set<LinkDetails> links;
	private String ewayBillStatus;
	private BigDecimal latitude;
	private BigDecimal longitude;
	private int version;
	private Map<String,Set<String>> challanIdsPerHub;
	private boolean hasReturnOrders;
	private MovementType movementType;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer deliveredOrders;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer unDeliveredOrders;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer partiallyDeliveredOrders;

	private Integer totalLoadedHuCount;
	private Integer totalLoadedOrderCount;

	public void setHasReturnOrders(boolean hasReturnOrders) {
		this.hasReturnOrders = hasReturnOrders;
	}
	
	public boolean getHasReturnOrders() {
		return hasReturnOrders;
	}
	
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public String getTripType() {
		return tripType;
	}
	public void setTripType(String tripType) {
		this.tripType = tripType;
	}
	public String getSourceNode() {
		return sourceNode;
	}
	public void setSourceNode(String sourceNode) {
		this.sourceNode = sourceNode;
	}
	public Timestamp getPlannedStartTime() {
		return plannedStartTime;
	}
	public void setPlannedStartTime(Timestamp plannedStartTime) {
		this.plannedStartTime = plannedStartTime;
	}
	public Timestamp getPlannedEndTime() {
		return plannedEndTime;
	}
	public void setPlannedEndTime(Timestamp plannedEndTime) {
		this.plannedEndTime = plannedEndTime;
	}
	public Timestamp getActualStartTime() {
		return actualStartTime;
	}
	public void setActualStartTime(Timestamp actualStartTime) {
		this.actualStartTime = actualStartTime;
	}
	public Timestamp getActualEndTime() {
		return actualEndTime;
	}
	public void setActualEndTime(Timestamp actualEndTime) {
		this.actualEndTime = actualEndTime;
	}
	public Timestamp getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVehicleModel() {
		return vehicleModel;
	}
	public void setVehicleModel(String suggestedVehicleModel) {
		this.vehicleModel = suggestedVehicleModel;
	}
	public String getFleetType() {
		return fleetType;
	}
	public void setFleetType(String fleetType) {
		this.fleetType = fleetType;
	}
	public String getSuggestedVehicleNo() {
		return suggestedVehicleNo;
	}
	public void setSuggestedVehicleNo(String suggestedVehicleNo) {
		this.suggestedVehicleNo = suggestedVehicleNo;
	}
	public String getAssignedVehicle() {
		return assignedVehicle;
	}
	public void setAssignedVehicle(String assignedVehicle) {
		this.assignedVehicle = assignedVehicle;
	}
	public String getAssignedDp() {
		return assignedDp;
	}
	public void setAssignedDp(String assignedDp) {
		this.assignedDp = assignedDp;
	}
	
	public String getAssignedDpId() {
		return assignedDpId;
	}
	public void setAssignedDpId(String assignedDpId) {
		this.assignedDpId = assignedDpId;
	}
	public Double getStartKm() {
		return startKm;
	}
	public void setStartKm(Double startKm) {
		this.startKm = startKm;
	}
	public Double getEndKm() {
		return endKm;
	}
	public void setEndKm(Double endKm) {
		this.endKm = endKm;
	}
	public double getPlannedKm() {
		return plannedKm;
	}
	public void setPlannedKm(double plannedKm) {
		this.plannedKm = plannedKm;
	}
	
	public boolean isAdhocTrip() {
		return isAdhocTrip;
	}

	public void setAdhocTrip(boolean isAdhocTrip) {
		this.isAdhocTrip = isAdhocTrip;
	}

	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public List<Consignment> getConsignment() {
		return consignment;
	}
	public void setConsignment(List<Consignment> consignment) {
		this.consignment = consignment;
	}
	
	public TripCountOnStatus getTripCountOnStatus() {
		return tripCountOnStatus;
	}
	public void setTripCountOnStatus(TripCountOnStatus tripCountOnStatus) {
		this.tripCountOnStatus = tripCountOnStatus;
	}
	public Integer getSecondaryTripsCount() {
		return secondaryTripsCount;
	}
	public void setSecondaryTripsCount(Integer secondaryTripsCount) {
		this.secondaryTripsCount = secondaryTripsCount;
	}

	public TripConsignmentCount getTripConsignmentCount() {
		return tripConsignmentCount;
	}
	public void setTripConsignmentCount(TripConsignmentCount tripConsignmentCount) {
		this.tripConsignmentCount = tripConsignmentCount;
	}
	public List<Seal> getSeal() {
		return seal;
	}
	public void setSeal(List<Seal> seal) {
		this.seal = seal;
	}
	public List<Hub> getHub() {
		return hub;
	}
	public void setHub(List<Hub> hub) {
		this.hub = hub;
	}
	public List<String> getAssociatedTrips() {
		return associatedTrips;
	}
	public void setAssociatedTrips(List<String> associatedTrips) {
		this.associatedTrips = associatedTrips;
	}
	public String getExternalReferenceId() {
		return externalReferenceId;
	}
	public void setExternalReferenceId(String externalReferenceId) {
		this.externalReferenceId = externalReferenceId;
	}
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public List<ReconcileArticle> getReconcileArticles() {
		return reconcileArticles;
	}
	public void setReconcileArticles(List<ReconcileArticle> reconcileArticles) {
		this.reconcileArticles = reconcileArticles;
	}
	public List<ReturnedAsset> getReturnedAssets() {
		return returnedAssets;
	}
	public void setReturnedAssets(List<ReturnedAsset> returnedAssets) {
		this.returnedAssets = returnedAssets;
	}
	public int getBagToBeCollected() {
		return bagToBeCollected;
	}
	public void setBagToBeCollected(int bagToBeCollected) {
		this.bagToBeCollected = bagToBeCollected;
	}
	public int getBagCollected() {
		return bagCollected;
	}
	public void setBagCollected(int bagCollected) {
		this.bagCollected = bagCollected;
	}
	public int getToteToBeCollected() {
		return toteToBeCollected;
	}
	public void setToteToBeCollected(int toteToBeCollected) {
		this.toteToBeCollected = toteToBeCollected;
	}
	public int getToteCollected() {
		return toteCollected;
	}
	public void setToteCollected(int toteCollected) {
		this.toteCollected = toteCollected;
	}
	public AdditionalCharges getAdditionalCharges() {
		return additionalCharges;
	}
	public void setAdditionalCharges(AdditionalCharges additionalCharges) {
		this.additionalCharges = additionalCharges;
	}
	public double getInitialCash() {
		return initialCash;
	}
	public void setInitialCash(double initialCash) {
		this.initialCash = initialCash;
	}
	public double getCashBalance() {
		return cashBalance;
	}
	public void setCashBalance(double cashBalance) {
		this.cashBalance = cashBalance;
	}
	public double getCashToBeCollected() {
		return cashToBeCollected;
	}
	public void setCashToBeCollected(double cashToBeCollected) {
		this.cashToBeCollected = cashToBeCollected;
	}
	public double getCashCollected() {
		return cashCollected;
	}
	public void setCashCollected(double cashCollected) {
		this.cashCollected = cashCollected;
	}
	public Integer getUnassignedTasks() {
		return unassignedTasks;
	}

	public void setUnassignedTasks(Integer unassignedTasks) {
		this.unassignedTasks = unassignedTasks;
	}

	public Integer getDeliveredTasks() {
		return deliveredTasks;
	}

	public void setDeliveredTasks(Integer deliveredTasks) {
		this.deliveredTasks = deliveredTasks;
	}
	public Set<LinkDetails> getLinks() {
		return links;
	}
	public void setLinks(Set<LinkDetails> links) {
		this.links = links;
	}
	public String getEwayBillStatus() {
		return ewayBillStatus;
	}
	public void setEwayBillStatus(String ewayBillStatus) {
		this.ewayBillStatus = ewayBillStatus;
	}
	public BigDecimal getLatitude() {
		return latitude;
	}
	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}
	public BigDecimal getLongitude() {
		return longitude;
	}
	public void setLongitude(BigDecimal longitude) {
		this.longitude = longitude;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getVrnId() {
		return vrnId;
	}
	public void setVrnId(String vrnId) {
		this.vrnId = vrnId;
	}
	
	public double getPrepaidAmount() {
		return prepaidAmount;
	}
	public void setPrepaidAmount(double prepaidAmount) {
		this.prepaidAmount = prepaidAmount;
	}
	
	public Map<String, Set<String>> getChallanIdsPerHub() {
		return challanIdsPerHub;
	}
	
	public void setChallanIdsPerHub(Map<String, Set<String>> challanIdsPerHub) {
		this.challanIdsPerHub = challanIdsPerHub;
	}
	
	public String getDriverMobileNumber() {
		return driverMobileNumber;
	}
	
	public void setDriverMobileNumber(String driverMobileNumber) {
		this.driverMobileNumber = driverMobileNumber;
	}
	
	public String getVendorName() {
		return vendorName;
	}
	
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	
	public String getVendorId() {
		return vendorId;
	}
	
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public MovementType getMovementType() {
		return movementType;
	}

	public void setMovementType(MovementType movementType) {
		this.movementType = movementType;
	}

	
	public Integer getDeliveredOrders() {
		return deliveredOrders;
	}

	public Integer getUnDeliveredOrders() {
		return unDeliveredOrders;
	}

	public Integer getPartiallyDeliveredOrders() {
		return partiallyDeliveredOrders;
	}

	public void setDeliveredOrders(Integer deliveredOrders) {
		this.deliveredOrders = deliveredOrders;
	}

	public void setUnDeliveredOrders(Integer unDeliveredOrders) {
		this.unDeliveredOrders = unDeliveredOrders;
	}

	public void setPartiallyDeliveredOrders(Integer partiallyDeliveredOrders) {
		this.partiallyDeliveredOrders = partiallyDeliveredOrders;
	}

	public Integer getTotalLoadedHuCount() {
		return totalLoadedHuCount;
	}

	public void setTotalLoadedHuCount(Integer totalLoadedHuCount) {
		this.totalLoadedHuCount = totalLoadedHuCount;
	}

	public Integer getTotalLoadedOrderCount() {
		return totalLoadedOrderCount;
	}

	public void setTotalLoadedOrderCount(Integer totalLoadedOrderCount) {
		this.totalLoadedOrderCount = totalLoadedOrderCount;
	}
}