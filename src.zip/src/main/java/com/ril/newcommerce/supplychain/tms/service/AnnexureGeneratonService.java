package com.ril.newcommerce.supplychain.tms.service;

import com.ril.newcommerce.supplychain.tms.entity.rest.TripAnnexure;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public interface AnnexureGeneratonService {


    ResponseEntity cretePdf(TripAnnexure annexure);

    void mergePdf(List<String> pdfList, String destinationFileName);
    
    public TripAnnexure getTripAnnexure(String tripId, String sourceNode)
			throws InterruptedException, ExecutionException, TimeoutException;
}
