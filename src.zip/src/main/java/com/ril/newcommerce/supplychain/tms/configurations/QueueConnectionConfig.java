package com.ril.newcommerce.supplychain.tms.configurations;

import javax.jms.ConnectionFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.tibco.tibjms.TibjmsConnectionFactory;

@Configuration
public class QueueConnectionConfig {

	@Value("${tibco.url}")
	private String url;

	@Value("${tibco.username}")
	private String usrname;

	@Value("${tibco.password}")
	private String pwd;
	
	@Value("${trip.backout.deliveryDelay}")
	private long deliveryDelay;

	@Bean
	public ConnectionFactory connectionFactory() {
		TibjmsConnectionFactory connectionFactory = new TibjmsConnectionFactory(url);
		connectionFactory.setUserName(usrname);
		connectionFactory.setUserPassword(pwd);
		return connectionFactory;
	}
	
	 @Bean(name= Constants.JMSTEMPLATE_PUBLISH)
	    public JmsTemplate jmsTemplateTopic() {
	        JmsTemplate template = new JmsTemplate();
	        template.setConnectionFactory(connectionFactory());
	        template.setPubSubDomain(true);

	        return template;
	    }
	 
	 @Bean(name= Constants.JMSTEMPLATE)
	    public JmsTemplate jmsTemplate() {
	        JmsTemplate template = new JmsTemplate();
	        template.setConnectionFactory(connectionFactory());
	        return template;
	    }

	 @Bean(name= Constants.JMSTEMPLATE_WITH_DELAY)
		public JmsTemplate jmsTemplateWithDelay() {
			JmsTemplate template = new JmsTemplate();
			template.setConnectionFactory(connectionFactory());
			template.setDeliveryDelay(deliveryDelay);
			return template;
		}
	 
	 @Bean
		public DefaultJmsListenerContainerFactory jmsListenerContainerFactory() {
			DefaultJmsListenerContainerFactory connectionFactory = new DefaultJmsListenerContainerFactory();
			connectionFactory.setConnectionFactory(connectionFactory());
			connectionFactory.setSessionAcknowledgeMode(Constants.EXPLICIT_CLIENT_ACKNOWLEDGE); 																							
			return connectionFactory;
		}

}
