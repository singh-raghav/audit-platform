package com.ril.newcommerce.supplychain.tms.exception;

/**
 * 
 * @author jeevi.natarajan
 *
 */
public class ValidationException  extends RuntimeException {
	
	private static final long serialVersionUID = 7201594280665334609L;

	public ValidationException(String message) {
		super(message);
	}
	
	public ValidationException(String message,Throwable th) {
		super(message,th);
	}
	
	public ValidationException(Throwable th) {
		super(th);
	}
}
