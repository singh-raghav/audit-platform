package com.ril.newcommerce.supplychain.tms.entity;

import java.util.List;

/**
B1.Divya
*/

public class Trips {
	private List<Trip> trip;
	private TripCountOnStatus tripCountOnStatus;
	public List<Trip> getTrip() {
		return trip;
	}
	public void setTrip(List<Trip> trip) {
		this.trip = trip;
	}
	public TripCountOnStatus getTripCountOnStatus() {
		return tripCountOnStatus;
	}
	public void setTripCountOnStatus(TripCountOnStatus tripCountOnStatus) {
		this.tripCountOnStatus = tripCountOnStatus;
	}

}
