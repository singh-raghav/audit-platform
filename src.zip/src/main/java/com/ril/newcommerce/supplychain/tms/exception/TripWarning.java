package com.ril.newcommerce.supplychain.tms.exception;

/**
 * 
 * @author jeevi.natarajan
 *
 */
public class TripWarning  extends RuntimeException {
	
	
	private static final long serialVersionUID = 9100385116853703844L;

	public TripWarning(String message) {
		super(message);
	}
	
	public TripWarning(String message,Throwable th) {
		super(message,th);
	}
	
	public TripWarning(Throwable th) {
		super(th);
	}
}
