package com.ril.newcommerce.supplychain.tms.controller;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.Trips;
import com.ril.newcommerce.supplychain.tms.entity.VehicleStatus;
import com.ril.newcommerce.supplychain.tms.entity.rest.ReturnItemCheck;
import com.ril.newcommerce.supplychain.tms.entity.rest.TripAnnexure;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.event.processor.TripEventProcessor;
import com.ril.newcommerce.supplychain.tms.exception.*;
import com.ril.newcommerce.supplychain.tms.request.TripAmountRequest;
import com.ril.newcommerce.supplychain.tms.response.TripAmountResponse;
import com.ril.newcommerce.supplychain.tms.response.TripLazyLoadResponse;
import com.ril.newcommerce.supplychain.tms.service.*;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.ExecutionException;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.MSG_OBJECT_CREATION_FAILED;

@RestController
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(value = "/trip-mgmt/v1/trips")
public class TripController {

	private static final Logger log = LoggerFactory.getLogger(TripController.class);
		
	@Autowired
	@Qualifier(Constants.TRIP_EVENT_PROCESSOR)
	private TripEventProcessor eventProcessor;
	
	@Autowired
	private TripService tripService;
	
	@Autowired
	private OrderDetailsService orderService;

    @Autowired
	private PdfDeletionService pdfDeletionService;
    
    @Autowired
    private AnnexureGeneratonService annexureGeneratonService;

    @Autowired
    private ReconcileService reconcileService;

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getTripsList(@RequestParam(value = "status", required = false) String status,
			@RequestParam(value = "pageSize", required = false) Integer pageSize,
			@RequestParam(value = "pageIndex", required = false) Integer pageIndex,
			@RequestParam(value = "fromDate", required = false) String fromDate,
			@RequestParam(value = "toDate", required = false) String toDate,
			@RequestParam(value = "tripId", required = false) String tripId,
			@RequestParam(value = "statistics", required = false) String statistics,
			@RequestParam(value = "inBound", required = false) String inBound,
			@RequestParam(value = "filterIds", required = false) String filterIds,
			@RequestParam(value = "movementType", required = false) String movementType,
			HttpServletRequest request)
			throws InterruptedException, ExecutionException {
	
		long startTime = System.currentTimeMillis();
		
		Trips trips;
		List<String> nodeIds;

		String s[] = request.getHeader(Constants.NODE_ID).split("\\|");
		String nodeTypes[] = request.getHeader(Constants.NODE_ID).split("\\|");
		String nodeType = nodeTypes[0];

		nodeIds = Arrays.asList(s);
		Map<String,Object> filters=getFilters(status,pageSize,pageIndex,fromDate,toDate,tripId,statistics,inBound,filterIds,movementType, nodeType);
		try {
			boolean rePlanPageDropDownTripListView = Constants.TRUE.equals(filterIds);
			if(rePlanPageDropDownTripListView)
			{
				Map<String, DestinationNodesDeliveryZoneIds> destinationNodesDeliveryZoneIdsMap=
						tripService.getDeliveryZonesAndDestinationNodesForTrips(nodeIds,filters);
				return Utility.getSuccessMsg(destinationNodesDeliveryZoneIdsMap.values());
			}
			trips = tripService.getTrips(nodeIds, filters);
			if (null != trips && !CollectionUtils.isEmpty(trips.getTrip()))
			{
				log.info("getTripsList controller -- [{}]ms", (System.currentTimeMillis() - startTime));
				return Utility.getSuccessMsg(trips);
			}
			else
				return Utility.getSuccessMsg(trips, "No Trips found");

		} catch (Exception e) {
			return Utility.getfailureMsg("Unable to fetch Trips ");
		}

	}
	
	@GetMapping(value = "/{tripId}/annexure", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity getAnnexure(@PathVariable String tripId, @RequestParam("nodeId") String nodeid){

		log.info("Request for Trip Annexure for tripId :{} nodeId:{}", tripId,nodeid);
		TripAnnexure annexure ;
		String errorMessage;

		try {

			annexure = annexureGeneratonService.getTripAnnexure(tripId, nodeid);
			if (null == annexure || annexure.getHubAnnexures().size() == 0) {
				errorMessage ="No Orders available for this trip";
			}else{
				return   annexureGeneratonService.cretePdf(annexure);
			}

		} catch (Exception e) {

			errorMessage = MSG_OBJECT_CREATION_FAILED;
			log.error("{} : {}",errorMessage, e);

		} finally {

			pdfDeletionService.deletePDf();

		}

		return ResponseEntityFactory.getPDFResponseFailure(errorMessage);

	}


	@GetMapping(value = "/daylevelack", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity dayLevelAck(@RequestParam("nodeId") String nodeId, @RequestParam("date") String date, HttpServletRequest request) {

		log.info("Request for day level acknowledgement for nodeId :{} date:{}", nodeId, date);
		try {

			return tripService.getDayLevelAck(date, date, nodeId, request.getHeader(Constants.AUTHORIZATION));

		} catch (Exception e) {

			log.info("Some issue while creating Ack for nodeId :{} date:{}, {}", nodeId, date, e);
			return ResponseEntityFactory.textResponse(String.format("Some issue while creating Ack for nodeId: %s date: %s ", nodeId, date));

		} finally {
			pdfDeletionService.deletePDf();
		}
	}

	@GetMapping(value = "{tripId}/orders", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getTripOrders(@PathVariable String tripId, HttpServletRequest request)
	{

		String nodeId = request.getHeader(Constants.NODE_ID);

		List<String> status = new ArrayList<String>();
		status.add(OrderStatus.ACTIVE.getValue());

		List<Consignment> consignments = new ArrayList<>();
		try {
			consignments = orderService.getTripOrderAndAdditionalDetails(tripId, nodeId, status, null,null);
			if (consignments.isEmpty())
				return Utility.getSuccessMsg(consignments, ErrorMessages.NO_ORDERS_FOUND);

			return Utility.getSuccessMsg(consignments, null);
		} catch (Exception e) {

			return Utility.getfailureMsg(e.getMessage());
		}

	}
	
	@PatchMapping(value = "/{tripId}", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> updateTripState(@PathVariable String tripId , @RequestBody TripEventInput request, HttpServletRequest httpRequest){
		log.info("updating the state of trip {} to {}", tripId , request.getAction());
		
		try {
			request.setTripId(tripId);
			request.setFlowName(request.getAction().name()); 
			
			String nodeId = httpRequest.getHeader(Constants.NODE_ID);
			if(StringUtils.isBlank(nodeId))
				throw new ValidationException("Header nodeId is mandatory..");
			
			request.setNodeId(httpRequest.getHeader(Constants.NODE_ID));
			request.setModifiedBy(httpRequest.getUserPrincipal().getName());

			eventProcessor.processEvent(request);
			
			return Utility.getSuccessMsg("Sucessfully updated the status! ");
		}
		catch(InvalidActionException invalidEx){
			return Utility.getAlreadyProcessedWaring(invalidEx.getMessage());
		}
		catch (EventAlreadyProcessedException e) {
			return Utility.getAlreadyProcessedWaring(e.getMessage());
		}
		catch (TripWarning e) {
			return Utility.getWarningMsg(e.getMessage());
		}
		catch (ValidationException | EventOutOfOrderException | ActionExecutionException e) {
			return Utility.getfailureMsg(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		catch(DuplicateKeyException dupKey){
			return Utility.getfailureMsg(dupKey.getMessage());
		}
		catch (Exception e) {
			return Utility.getfailureMsg(e.getMessage());
		}
	}
	
	@GetMapping(value="/vehiclestatus", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<VehicleStatus>> isVechicleAssigned(@RequestParam(value="vehicleIds" , required=true) String vehicleIds){
		log.info("check if vehicles are assigned {}", vehicleIds);
		
		try {
			List<String> vehicleList = Arrays.asList(vehicleIds.split(","));
			
			List<VehicleStatus> statuses = tripService.getVehicleStatus(vehicleList);
			
			return new ResponseEntity<List<VehicleStatus>>(statuses, HttpStatus.OK);
		}
		catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/{tripId}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getTripDetails(@PathVariable String tripId , @RequestParam(value = "includeRecon", required = false) String includeRecon, HttpServletRequest request){
		log.info("Request for trip details for tripId :{}", tripId);
		List<Trip> trips = null;
		ReturnItemCheck returnItemsCheck = new ReturnItemCheck();
		String nodeId = request.getHeader(Constants.NODE_ID); 
		try {
			if(null!=includeRecon && includeRecon.equalsIgnoreCase("true")) {
			      returnItemsCheck = reconcileService.checkReturnItemMisMatchForHubTrip(tripId);
			if(!returnItemsCheck.isReturnMissMatch())
			     trips = reconcileService.getTripDetails(tripId,includeRecon,nodeId,returnItemsCheck.getReconcileArticles(), returnItemsCheck.getWayPointUpdates());
			else
				return Utility.getfailureMsg(returnItemsCheck.getFailureMessage(), HttpStatus.UNPROCESSABLE_ENTITY);
			} else {
				trips = tripService.getTripDetails(tripId,includeRecon,nodeId,null);
			}
		} catch(Exception ex) {
			return Utility.getfailureMsg("Failed to get trip");
		}			
		return Utility.getSuccessMsg(trips);		
	}

	@PostMapping(value = "/ewayBill",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> retryEwayBill(@RequestBody String payload, HttpServletRequest request) {

		String tripId = null;
		try {
			JSONObject payloadJson = new JSONObject(payload);
			tripId = (String) payloadJson.get(Constants.TRIPID);
			if (tripId != null) {
				Trip trip = tripService.getTrip(tripId);
				String tripType = trip.getTripType();
				tripService.retryEwaybillGeneration(tripId, tripType);
			} else {
				return Utility.getfailureMsg("Trip Id cannot be null", HttpStatus.BAD_REQUEST);
			}
		} catch (InterruptedException e) {
			log.error("Exception occured in ewaybill regenration", e.getMessage());
			return Utility.getfailureMsg(e.getMessage());
		} catch (JSONException ex) {
			log.error("Exception occured in ewaybill regenration", ex.getMessage());
			return Utility.getfailureMsg(ex.getMessage(), HttpStatus.BAD_REQUEST);
		} catch (Exception exp) {
			log.error("Exception occured in ewaybill regenration", exp.getMessage());
			return Utility.getfailureMsg(exp.getMessage());
		}

		return Utility.getSuccessMsg(null, "Request successfully submitted for ewayBill generation");
	}

	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> createTrip(@RequestBody TripEventInput eventInput, HttpServletRequest request)
	{
		try {
			eventInput.setModifiedBy(request.getUserPrincipal().getName());
			eventInput.setNodeId(request.getHeader(Constants.NODE_ID));
			eventInput.setFlowName("Create Trip");
			eventProcessor.processEvent(eventInput);
			if (eventInput.getAction().name().equalsIgnoreCase(TripEvent.SHUTTLE_TRIP.name()))
				return Utility.getSuccessMsg("Shuttle trip created successfully with Trip ID : " + eventInput.getTripId(),HttpStatus.ACCEPTED);
			return Utility.getSuccessMsg("Manual trip request successfully submitted ", HttpStatus.ACCEPTED);
		}
		catch(ValidationException validExp)
		{
			return Utility.getfailureMsg(validExp.getMessage(), HttpStatus.BAD_REQUEST); 
		}
		catch(InvalidActionException invalidEx)
		{
			return Utility.getAlreadyProcessedWaring(invalidEx.getMessage());
		}
		catch(Exception ex)
		{
			return Utility.getfailureMsg("Trip request cannot be processed");
		}
		
	}

	@PostMapping(value = "/cash-collection",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getTripAmount(@RequestBody TripAmountRequest tripAmountRequest, HttpServletRequest request)
	{
		try {
			String nodeId = request.getHeader(Constants.NODE_ID);
			List<TripAmountResponse> tripAmount = tripService.getTripAmount(tripAmountRequest.getStartDate(), tripAmountRequest.getEndDate(), nodeId);

			if (tripAmount.isEmpty()) {
				return Utility.getSuccessMsg(tripAmount, ErrorMessages.NO_ORDERS_FOUND);
			}
			return Utility.getSuccessMsg(tripAmount, null);

		} catch (ValidationException validExp) {
			return Utility.getfailureMsg(validExp.getMessage(), HttpStatus.BAD_REQUEST);
		} catch (Exception ex) {
			return Utility.getfailureMsg("Request processing failed!");
		}

	}

	@GetMapping(value = "/lazyload/shipment/{shipmentNo}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getTripForShipmentNo(@PathVariable String shipmentNo, HttpServletRequest request) {

		String nodeId = request.getHeader(Constants.NODE_ID);
		if (StringUtils.isBlank(nodeId)) {
			throw new ValidationException("Header nodeId is mandatory..");
		}

		List<TripLazyLoadResponse> tripLazyLoadResponses = new ArrayList<>();
		try {

			tripLazyLoadResponses = tripService.getTripForOrder(shipmentNo, nodeId);
			if (tripLazyLoadResponses.isEmpty()) {
				return Utility.getSuccessMsg(tripLazyLoadResponses, ErrorMessages.NO_ORDERS_FOUND);
			}
			return Utility.getSuccessMsg(tripLazyLoadResponses, null);

		} catch (Exception e) {

			return Utility.getfailureMsg(e.getMessage());
		}
	}

	private Map<String,Object> getFilters(String status, Integer pageSize, Integer pageIndex, String fromDate, String toDate, String tripId, String statistics, String inBound, String filterIds, String movementType,String nodeType)
	{
		Map<String,Object> filters=new HashMap<>();
		filters.put(Constants.STATUS, status);
		filters.put(Constants.PAGE_INDEX, pageIndex);
		filters.put(Constants.PAGE_SIZE, pageSize);
		filters.put(Constants.FROM_DATE, fromDate);
		filters.put(Constants.TO_DATE, toDate);
		filters.put(Constants.TRIPID, tripId);
		filters.put(Constants.STATISTICS, statistics);
		filters.put(Constants.INBOUND, inBound);
		filters.put(Constants.FILTER_IDS, filterIds);
		filters.put(Constants.MOVEMENT_TYPE, movementType);
		filters.put(Constants.NODE_TYPE, nodeType);

		return filters;
	}
}
