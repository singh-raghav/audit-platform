package com.ril.newcommerce.supplychain.tms.processors;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.event.processor.OrderStateMachineProcessor;
import com.ril.newcommerce.supplychain.tms.exception.StateMachineProcessingException;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.processors.order.statusupdate.DefaultOrderStatusUpdatePostProcessor;
import com.ril.newcommerce.supplychain.tms.processors.order.statusupdate.OrderStatusUpdatePreProcessorFactory;
import com.ril.newcommerce.supplychain.tms.service.UpdatedOrderUtilService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.jms.Message;
import javax.jms.TextMessage;
import java.io.StringReader;
import java.util.List;

@Qualifier(Constants.ORDER_STATUS_UPDATE_PROCESSOR)
@Service
public class OrderStatusUpdateProcessor implements Processor {

    private Logger log = LoggerFactory.getLogger(OrderStatusUpdateProcessor.class);

    @Autowired
    private JAXBContextConfig jAXBContextConfig;

    @Autowired
    private OrderStateMachineProcessor orderStateMachineProcessor;

    @Autowired
    private OrderStatusUpdatePreProcessorFactory preProcessorFactory;

    @Autowired
    private DefaultOrderStatusUpdatePostProcessor postProcessor;

    @Autowired
    private UpdatedOrderUtilService updatedOrders;

    @Override
    public void processMessage(Message message, String flowName) throws Exception {
        StringReader reader = new StringReader(((TextMessage) message).getText());

        OrderStatusFeed orderStatusFeed = (OrderStatusFeed) jAXBContextConfig.getJaxbContextInstance(OrderStatusFeed.class).createUnmarshaller().unmarshal(reader);

        boolean validatedForBatch = false;
        String orderId;
        List<OrderStatusFeed.Order> orders = orderStatusFeed.getOrder();
        if (!orders.isEmpty()) {
            for (OrderStatusFeed.Order order : orders) {

                orderId = order.getOrderId();
                try {
                    // validatedForBatch : In some scenarios we can have single validation for  given bunch of orders. Eg: Invoiced to shipped using  OrderStatusShippedPreProcessor validator
                    validatedForBatch = validatedForBatch || preProcessorFactory.getProcessor(order.getStateTo()).validateUpdate(order);
                    orderStateMachineProcessor.processOrder(orderId, order.getStateTo(), order.getFlowName());
                    postProcessor.publishToAudit(orderId, updatedOrders.remove(orderId), order.getStateTo().getValue());
                } catch (StateMachineProcessingException e) {
                    //Ignore exception in case state machine status update failure
                    log.error("Order State Machine processing failed for order " + orderId);
                    log.error(e.getMessage());
                } finally {
                    updatedOrders.delete(orderId);
                }
            }
        }
    }
}
