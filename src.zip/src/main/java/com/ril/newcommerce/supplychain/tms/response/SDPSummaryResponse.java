package com.ril.newcommerce.supplychain.tms.response;

import lombok.Data;

@Data
public class SDPSummaryResponse {
    String sdpId;
    Integer totalOrders;
    Integer invoicedOrders;
    Integer readyForLoading;
    Integer tripsCreated;
    Integer loadingInProgress;
    Integer huCount;
}
