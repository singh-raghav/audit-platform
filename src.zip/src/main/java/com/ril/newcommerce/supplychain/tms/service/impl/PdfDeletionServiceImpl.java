package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.service.PdfDeletionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.PDF_FOLDER;

@Service
public class PdfDeletionServiceImpl implements PdfDeletionService {

    @Value("${pdf.file.lifeTime}")
    private long lifeTime;

    private static final Logger log = LoggerFactory.getLogger(PdfDeletionServiceImpl.class);

    @Override
    public void deletePDf() {

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        File baseDir = new File(".");
        File outFolder = new File(baseDir, PDF_FOLDER);

        executorService.execute(new Runnable() {

            public void run() {

                try {

                    deleteFilesOlderThan(lifeTime);

                } catch (Exception e) {
                    log.error("PDF deletion failed. {}", e.getMessage());
                }

                log.info("Executor service completed.");
            }

            private void deleteFilesOlderThan(long lifeTime) {

                for (File file : outFolder.listFiles()) {

                    if (isOlderThan(file, lifeTime)) {
                        log.info("Deleting file {}", file.getName());
                        file.delete();
                    }
                }
            }

            private boolean isOlderThan(File file, long allowedLifeTime) {

                long currentFileLifeTime = new Date().getTime() - file.lastModified();
                return currentFileLifeTime > allowedLifeTime;
            }

        });

        executorService.shutdown();
    }
}
