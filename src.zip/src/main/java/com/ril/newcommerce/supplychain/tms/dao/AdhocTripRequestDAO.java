package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.AdhocTripRequest;

public interface AdhocTripRequestDAO 
{
	public void insertToAdhocTripRequest(List<AdhocTripRequest> tripRequest);
	
	public List<AdhocTripRequest> getAdhoctripRequest(List<String> orders,String node,String status );
	
	public void updateAdhocTripStatus(List<String> orders,String node,String status );
}
