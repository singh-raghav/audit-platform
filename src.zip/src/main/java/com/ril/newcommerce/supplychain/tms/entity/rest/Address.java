package com.ril.newcommerce.supplychain.tms.entity.rest;

import org.apache.commons.lang3.StringUtils;

import com.ril.newcommerce.supplychain.tms.constants.Constants;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class Address {
	
	private String addLine1;
	private String addLine2;
	private String addLine3;
	private String city;
	private String state;
	private String pincode;
	
	public String getAddLine1() {
		return addLine1;
	}
	public void setAddLine1(String addLine1) {
		this.addLine1 = addLine1;
	}
	public String getAddLine2() {
		return addLine2;
	}
	public void setAddLine2(String addLine2) {
		this.addLine2 = addLine2;
	}
	public String getAddLine3() {
		return addLine3;
	}
	public void setAddLine3(String addLine3) {
		this.addLine3 = addLine3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer(); 
		if(StringUtils.isNotBlank(this.addLine1)) {
			buffer.append(this.addLine1);
			buffer.append(Constants.COMMA);
		}	
		
		if(StringUtils.isNotBlank(this.addLine2)) {
			buffer.append(this.addLine2);
			buffer.append(Constants.COMMA);
		}	
		
		if(StringUtils.isNotBlank(this.addLine3)) {
			buffer.append(this.addLine3);
			buffer.append(Constants.COMMA);
		}	
		
		if(StringUtils.isNotBlank(this.city)) {
			buffer.append(this.city);
			buffer.append(Constants.COMMA);
		}	
			
		if(StringUtils.isNotBlank(this.state)) {
			buffer.append(this.state);
			buffer.append(Constants.COMMA);
		}	
			
		if(StringUtils.isNotBlank(this.pincode)) {
			buffer.append(this.pincode);
		}	
		
		return buffer.toString();
	}
}
