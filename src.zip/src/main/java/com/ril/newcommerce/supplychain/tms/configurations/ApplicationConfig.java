package com.ril.newcommerce.supplychain.tms.configurations;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class ApplicationConfig {
	
	@Value("${trip.connection.timeout}")
	private int connectionTimeout;
	
	@Value("${trip.connection.read.timeout}")
	private int readTimeout;
	
	
	@Bean
	public Jaxb2Marshaller marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setPackagesToScan("com.ril", "java.lang");
		return marshaller;
	}
	
	/*@Bean
	public RestTemplate getRestTemplateNormal() {
		return new RestTemplate();
	}*/
	
}
