package com.ril.newcommerce.supplychain.tms.dao;

public interface TripConsignmentsDAO {

    Integer getSuspendedConsignmentsCount(String shipment, String orderId);
}
