package com.ril.newcommerce.supplychain.tms.job;

import java.time.LocalTime;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.impl.TripActivityDAOImpl;
import com.ril.newcommerce.supplychain.tms.entity.TripActivityDetails;
import com.ril.newcommerce.supplychain.tms.enums.PublishFlowName;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.RFAssignTrip;
import com.ril.newcommerce.supplychain.tms.tibco.entity.VehicleState;
import com.ril.newcommerce.supplychain.tms.util.Utility;

@Component
public class TripUnassignmentCronJob {

    private static final Logger logger = LoggerFactory.getLogger(TripUnassignmentCronJob.class);

    @Autowired
    private TripActivityDAOImpl tripActivityDao;
    
    @Autowired
    private TripService tripService;
 
    @Value("${trip.unassignment.time}")
    private int thresholdTime;

    @Value("${trip.unassignment.fetchsize}")
    private int fetchSize;

    @Autowired
    private JMSPublisher jmsPublisher;

    @Value("${trip.assignment.vms.queue}")
    private String vmsTopicName;

    @Value("${trip.status.queue}")
    private String topicName;
    


    @Scheduled(fixedDelayString = "${trip.unassignment.cron.delay}")
    @Transactional(rollbackFor = Exception.class)
    public void handleFailedTripUnassignment() {
    	logger.info("Cron running.... {} ",  LocalTime.now() );
        try {
            List<TripActivityDetails> tripActivities = tripActivityDao.getTripOnActivityStatus(Constants.UNASSIGNMENT_INITIATED, fetchSize, thresholdTime);
            if (!CollectionUtils.isEmpty(tripActivities)){
            	
            	tripActivityDao.batchUpdateTripActivityStatus(tripActivities);
                for(TripActivityDetails activity : tripActivities) {
                	String vendorId = tripService.getVendorId(activity.getTripId());
                    jmsPublisher.publishMessage(topicName,Utility.createVehicleState(activity.getAssignedVehicle(), activity.getTripId(),Constants.ACTIVITY_MODIFIEDBY,Constants.CANCEL_UNASSIGNMENT),
        					PublishFlowName.VEHICLE_STATE.getValue(), Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER , Constants.BUSINESS_VALUE_ONE,  activity.getTripId()),VehicleState.class);
                    
                    jmsPublisher.publishMessage(topicName, Utility.createAssignTripPayload(Constants.DEFAULT_INITIAL_AMT, activity.getTripId(), activity.getAssignedVehicle(), activity.getVehiclePartner(), Constants.ACTIVITY_MODIFIEDBY,vendorId),
        					PublishFlowName.ASSIGN_TRIP.getValue(), 
        					Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER , Constants.BUSINESS_VALUE_ONE, activity.getTripId()),RFAssignTrip.class);
                	
                }
            }
        } catch(Exception e) {
            logger.error("Error in cancelling unassignment ::" , e);
        }
    }
}
