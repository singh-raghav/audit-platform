package com.ril.newcommerce.supplychain.tms.enums;

public enum ExternalSystem {
    STERLING,
    OLDTRIPAPP;
}
