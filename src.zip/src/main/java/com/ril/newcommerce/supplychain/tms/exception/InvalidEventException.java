package com.ril.newcommerce.supplychain.tms.exception;

/**
 * 
 * @author jeevi.natarajan
 *
 */
public class InvalidEventException extends RuntimeException {

	private static final long serialVersionUID = -533452718500791309L;

	public InvalidEventException(String message) {
		super(message);
	}
	
	public InvalidEventException(String message,Throwable th) {
		super(message,th);
	}
	
	public InvalidEventException(Throwable th) {
		super(th);
	}
}
