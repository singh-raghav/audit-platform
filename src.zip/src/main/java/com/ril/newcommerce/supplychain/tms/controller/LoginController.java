package com.ril.newcommerce.supplychain.tms.controller;

import com.ril.newcommerce.supplychain.tms.entity.rest.LoginRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.LoginResponse;
import com.ril.newcommerce.supplychain.tms.service.LoginService;
import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/trip-mgmt/v1")
public class LoginController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    private LoginService loginService;

    @PostMapping(value = "/login", consumes = "application/json", produces = "application/json")
    public ResponseEntity<ResponseMessage> login(@Valid @RequestBody LoginRequest loginRequest) throws Exception {

        long startTime = System.currentTimeMillis();

        ResponseEntity<ResponseMessage> responseEntity;
        LOGGER.info("login request for user {}", loginRequest.getUsername());

        LoginResponse loginResponse = loginService.login(loginRequest);

        if(loginResponse.getErrorMessage()==null){
            responseEntity = Utility.getSuccessMsg(loginResponse);
        }
        else {

            Map<String, Object> moreDetails = new HashMap<>();
            moreDetails.put("invalidAttemptLeft", loginResponse.getInvalidAttemptLeft());

            responseEntity = Utility.getfailureMsg(loginResponse.getErrorMessage(), HttpStatus.UNAUTHORIZED, moreDetails);
        }

        LOGGER.info("login_time -- [{}]ms", (System.currentTimeMillis() - startTime));

        return responseEntity;
    }
}
