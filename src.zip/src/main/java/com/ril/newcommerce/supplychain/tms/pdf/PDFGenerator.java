package com.ril.newcommerce.supplychain.tms.pdf;

import javax.xml.transform.Source;

public interface PDFGenerator {
     void generate(Source src, String destFileName, String xslFile) ;
}
