package com.ril.newcommerce.supplychain.tms.pdf;


import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.exception.PdfCreationException;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.io.OutputStream;


@Service
public class PDFGeneratorImpl implements PDFGenerator {

    private final FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());

    public void generate(Source src, String destFileName, String xslFile) {

        File outDir = new File(new File("."), Constants.PDF.PDF_FOLDER);
        outDir.mkdirs();

        try (OutputStream fileStream = new java.io.FileOutputStream(new File(outDir, destFileName));
             OutputStream bufferedOutputStream = new java.io.BufferedOutputStream(fileStream)) {

            FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
            File xsltfile = ResourceUtils.getFile(xslFile);
            Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, bufferedOutputStream);

            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer(new StreamSource(xsltfile));

            Result res = new SAXResult(fop.getDefaultHandler());

            transformer.transform(src, res);

        } catch (Exception e) {
            throw new PdfCreationException("PDF generation failed!", e);
        }
    }
}
