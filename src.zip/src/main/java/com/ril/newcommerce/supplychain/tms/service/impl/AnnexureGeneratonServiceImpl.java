package com.ril.newcommerce.supplychain.tms.service.impl;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.ANNEXURE_PDF_PREFIX;
import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.MSG_OBJECT_CREATION_FAILED;
import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.PDF_EXT;
import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.PDF_FOLDER;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import javax.xml.transform.Source;

import org.apache.commons.collections.CollectionUtils;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.dao.ConsignmentLabelDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.rest.HubAnnexure;
import com.ril.newcommerce.supplychain.tms.entity.rest.Invoice;
import com.ril.newcommerce.supplychain.tms.entity.rest.Node;
import com.ril.newcommerce.supplychain.tms.entity.rest.TripAnnexure;
import com.ril.newcommerce.supplychain.tms.enums.ConsignmentLabelStatus;
import com.ril.newcommerce.supplychain.tms.enums.LabelType;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.PdfCreationException;
import com.ril.newcommerce.supplychain.tms.pdf.PDFGenerator;
import com.ril.newcommerce.supplychain.tms.pdf.SourceFactory;
import com.ril.newcommerce.supplychain.tms.pdf.builder.AnnexureBuilder;
import com.ril.newcommerce.supplychain.tms.pdf.model.annexure.Annexure;
import com.ril.newcommerce.supplychain.tms.pdf.model.annexure.AnnexureInputSource;
import com.ril.newcommerce.supplychain.tms.pdf.model.annexure.AnnexureXMLReader;
import com.ril.newcommerce.supplychain.tms.service.AnnexureGeneratonService;
import com.ril.newcommerce.supplychain.tms.service.NodeService;
import com.ril.newcommerce.supplychain.tms.service.OrderDetailsService;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;
import com.ril.newcommerce.supplychain.tms.util.Utility;

@Service
public class AnnexureGeneratonServiceImpl implements AnnexureGeneratonService {

    @Autowired
    private AnnexureBuilder annexureBuilder;

    @Autowired
    private PDFGenerator pdfGenerator;

    @Value("${pdf.annexure}")
    private String annexurePdf;
    
    @Autowired
	private NodeService nodeService;
    
    @Autowired
	private TripExecutor executor;

    @Value("${thread.future.timeout}")
	private int timeOut;
    
    @Autowired
	private OrderDetailsService orderService;
    
    @Autowired
	private ConsignmentLabelDAO consignmentLabelDAO;
    
    @Autowired
	TripsDAO tripsDAO;
    
    private static final Logger log = LoggerFactory.getLogger(AnnexureGeneratonServiceImpl.class);

    @Override
    public ResponseEntity cretePdf(TripAnnexure annexure) {
        Annexure eachAnnexure;
        String pdfName;
        Source src;
        String xslSource;
        List<String> pdfList = new ArrayList<>();
        System.currentTimeMillis();
        String errorMessage;

        try {
            for (HubAnnexure hubAnnexure : annexure.getHubAnnexures()) {

                eachAnnexure = annexureBuilder.build(annexure, hubAnnexure);
                src = SourceFactory.getInstance(new AnnexureXMLReader(), new AnnexureInputSource(eachAnnexure));
                pdfName = ANNEXURE_PDF_PREFIX + Utility.generateUniqueFileName() + PDF_EXT;
                xslSource = annexurePdf;
                pdfGenerator.generate(src, pdfName, xslSource);
                pdfList.add(pdfName);

            }

            String mergedFileName = ANNEXURE_PDF_PREFIX + annexure.getTripId() + PDF_EXT;
            mergePdf(pdfList, mergedFileName);
            return ResponseEntityFactory.getPDFResponseSuccess(mergedFileName);

        } catch (PdfCreationException e) {

            errorMessage = e.getMessage();
            log.error("{} : {}", errorMessage, e);

        } catch (Exception e) {

            errorMessage = MSG_OBJECT_CREATION_FAILED;
            log.error("Annexure pdf creation failed! {}", e);

        }
        return ResponseEntityFactory.getPDFResponseFailure(errorMessage);
    }

    @Override
    public void mergePdf(List<String> pdfList, String destinationFileName) throws PdfCreationException {

        PDFMergerUtility pdfMerger = new PDFMergerUtility();
        File baseDir = new File(".");
        File outFolder = new File(baseDir, PDF_FOLDER);
        try {

            for (String pdf : pdfList) {
                pdfMerger.addSource(new File(outFolder.getPath() + "/" + pdf));
            }
            pdfMerger.setDestinationFileName(outFolder + "/" + destinationFileName);
            pdfMerger.mergeDocuments();

        } catch (Exception e) {
            throw new PdfCreationException("Exception while merging files, number of files: " + pdfList.size());
        }
    }
    
    @Override
	public TripAnnexure getTripAnnexure(String tripId, String sourceNode)
			throws InterruptedException, ExecutionException, TimeoutException {
		Collection<Future<?>> futures = new LinkedList<Future<?>>();
		TripAnnexure tripAnnexure = new TripAnnexure();
		if (null != tripId && null != sourceNode) {
			List<String> status = new ArrayList<String>();
			status.add(OrderStatus.ACTIVE.getValue());
			Future<List<Consignment>> consignments = executor.getTripExecutor()
					.submit(() -> orderService.getTripOrderAndAdditionalDetails(tripId, sourceNode, status, null,null));
			Future<Map<String, Map<String, List<ConsignmentLabel>>>> consignmentLabel = executor.getTripExecutor()
					.submit(() -> consignmentLabelDAO.getTripConsignmentLabel(new ArrayList<>(Arrays.asList(tripId)),
							new ArrayList<>(Arrays.asList(sourceNode))));

			Future<Trip> trip = executor.getTripExecutor().submit(() -> tripsDAO.getTripById(tripId));
			futures.add(consignments);
			futures.add(consignmentLabel);
			futures.add(trip);
			for (Future<?> future : futures) {
				future.get(timeOut,TimeUnit.SECONDS);
			}
			log.debug("Executers executed for trip Annexure");
			Map<String, List<Consignment>> hubConsignments = consignments.get().stream().collect(Collectors
					.groupingBy(Consignment::getNextNodeId, HashMap::new, Collectors.toCollection(ArrayList::new)));

			List<HubAnnexure> hubAnnexure = getHubAnnexure(hubConsignments, consignmentLabel.get().get(tripId));
			String originalNode = trip.get().getSourceNode();
			tripAnnexure.setOriginNode(originalNode);
			tripAnnexure.setFcName(getNodeName(originalNode));
			tripAnnexure.setTripDate(trip.get().getCreatedTime());
			tripAnnexure.setTripId(tripId);
			tripAnnexure.setVehicleNo(trip.get().getAssignedVehicle());
			tripAnnexure.setDriverName(trip.get().getAssignedDp());
			tripAnnexure.setHubAnnexures(hubAnnexure);
		}
		return tripAnnexure;

	}
    private List<HubAnnexure> getHubAnnexure(Map<String, List<Consignment>> hubConsignments,
			Map<String, List<ConsignmentLabel>> map)
	{
		List<HubAnnexure> hubAnnexureList = new ArrayList<>();
		String hubId;
		for(Map.Entry<String, List<Consignment>> hubConsignment:hubConsignments.entrySet())
		{
			HubAnnexure hubAnnexure = new HubAnnexure();
			hubId = hubConsignment.getKey();
			hubAnnexure.setHubId(hubId);
			hubAnnexure.setHubName(getNodeName(hubId));
			List<Invoice> invoiceList=new ArrayList<>();
			for(Consignment consignment:hubConsignment.getValue())
			{
				Invoice invoice=new Invoice();
				if(null!=consignment.getInvoice())
				{
					setInvoiceForAnnexure(invoice,consignment,map); //set invoice for every consignment with label info
				}
				invoiceList.add(invoice);
			}
			hubAnnexure.setInvoices(invoiceList);
			log.info("Annexure for hub", hubId, invoiceList.size());
			int totalToteCount=getToteCount(invoiceList);
			int totalHuCount=getHuCount(invoiceList);
			hubAnnexure.setTotalInvoiceHUs(totalToteCount+totalHuCount);
			hubAnnexure.setTotalInvoiceOrders(invoiceList.size());
			hubAnnexureList.add(hubAnnexure);
		}

		return hubAnnexureList;
	}
    
    private int getToteCount(List<Invoice> invoiceList) {
		Set<String> tote=new HashSet<>();
		for(Invoice invoice:invoiceList)
		{
			tote.addAll(invoice.getToteIds());
		}
		return tote.size();
	}
    private int getHuCount(List<Invoice> invoiceList) {
		Set<String> hu=new HashSet<>();
		for(Invoice invoice:invoiceList)
		{
			hu.addAll(invoice.getHuIds());
		}
		return hu.size();
	}

	private String getNodeName(String hubId) {
		Node node =  nodeService.getNodeDetailsByNodeId(hubId);
		return node == null ? "" : node.getName();
	}
    
    private  void setInvoiceForAnnexure(Invoice invoice,Consignment consignment,Map<String, List<ConsignmentLabel>> map)
	{

			invoice.setOrderNo(consignment.getOrderId());
			invoice.setShipmentNo(consignment.getShipmentNo());
			invoice.setEwayBillNo(consignment.getInvoice().getEwayBillNo());
			invoice.setEwayBillStatus(consignment.getInvoice().getEwayBillStatus());
			invoice.setInvoiceAmount(consignment.getInvoice().getInvoiceAmount());
			invoice.setInvoiceDate(consignment.getInvoice().getInvoiceDate());
			invoice.setInvoiceNo(consignment.getInvoice().getInvoiceNo());
			invoice.setCustomerName(consignment.getCustomer().getName());

			if (!CollectionUtils.isEmpty(map.get(consignment.getShipmentNo()))) {
				HashSet<String> presentTotes = new HashSet<>();
				HashSet<String> presentBags = new HashSet<>();
				HashSet<String> presentHus = new HashSet<>();
				for (ConsignmentLabel label : map.get(consignment.getShipmentNo())) {
					if (!(ConsignmentLabelStatus.MISSED.value().equals(label.getStatus())
							|| ConsignmentLabelStatus.DAMAGED.value().equals(label.getStatus()))) {
						if (LabelType.TOTE.getValue().equals(label.getLabelType())) {
							presentTotes.add(label.getLabelId());
						} else if (LabelType.BAG.getValue().equals(label.getLabelType())) {
							presentBags.add(label.getLabelId());
						} else if (LabelType.HU.getValue().equals(label.getLabelType())) {
							presentHus.add(label.getLabelId());
						}
					}
				}
				invoice.setBagIds(presentBags);
				invoice.setToteIds(presentTotes);
				invoice.setHuIds(presentHus);
			}

		}
}
