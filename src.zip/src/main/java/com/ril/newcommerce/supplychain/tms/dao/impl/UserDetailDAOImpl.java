package com.ril.newcommerce.supplychain.tms.dao.impl;

import com.ril.newcommerce.supplychain.tms.dao.UserDetailDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.UserDetailMapper;
import com.ril.newcommerce.supplychain.tms.entity.UserDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.UserListResponse;
import com.ril.newcommerce.supplychain.tms.enums.UserRoles;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class UserDetailDAOImpl implements UserDetailDAO {

    private static final Logger log = LoggerFactory.getLogger(UserDetailDAOImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public UserListResponse getUserList(String nodeId, String clusterId, boolean ignoreNodeIdHeader,
                                        boolean ignoreDeletedUsers, Integer pageSize, Integer pageIndex,
                                        String searchKeyword, UserRoles userRole, String lastLoginFrom,
                                        String lastLoginTo) throws  Exception{

        log.info("Inside getUserList of UserDetailDAOImpl");

        if(pageSize==null){
            pageSize=20;
        }
        if(pageIndex==null){
            pageIndex=0;
        }

        UserListResponse userListResponse = new UserListResponse();
        List<UserDetails> userDetailsList = null;

        NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        MapSqlParameterSource countQueryParameters = new MapSqlParameterSource();

        StringBuilder queryBuilder = new StringBuilder();
        StringBuilder countQueryBuilder = new StringBuilder();

        queryBuilder.append("SELECT * FROM USER_DETAILS UD WHERE UD.CLUSTER_ID = :clusterId");
        parameters.addValue("clusterId", clusterId);

        countQueryBuilder.append("SELECT COUNT(*) FROM USER_DETAILS UD WHERE UD.CLUSTER_ID = :clusterId");
        countQueryParameters.addValue("clusterId", clusterId);


        if(!ignoreNodeIdHeader)
        {
            queryBuilder.append(" AND UD.NODE_ID = :nodeId");
            parameters.addValue("nodeId", nodeId);

            countQueryBuilder.append(" AND UD.NODE_ID = :nodeId");
            countQueryParameters.addValue("nodeId", nodeId);
        }

        if(ignoreDeletedUsers)
        {
            queryBuilder.append(" AND UD.ACCOUNT_STATUS IN ('ACTIVE','LOCKED')");
            countQueryBuilder.append(" AND UD.ACCOUNT_STATUS IN ('ACTIVE','LOCKED')");
        }else {
            queryBuilder.append(" AND UD.ACCOUNT_STATUS IN ('ACTIVE','LOCKED','DELETED')");
            countQueryBuilder.append(" AND UD.ACCOUNT_STATUS IN ('ACTIVE','LOCKED','DELETED')");
        }

        if(userRole!=null)
        {
            queryBuilder.append(" AND UD.ROLE = :userRole");
            parameters.addValue("userRole", userRole.toString());

            countQueryBuilder.append(" AND UD.ROLE = :userRole");
            countQueryParameters.addValue("userRole", userRole.toString());
        }

        if(!StringUtils.isEmpty(lastLoginFrom))
        {
            queryBuilder.append(" AND UD.LAST_LOGGED_IN >= TO_TIMESTAMP(:lastLoginFrom,'DD/MM/YYYY HH24:MI')");
            parameters.addValue("lastLoginFrom", lastLoginFrom);

            countQueryBuilder.append(" AND UD.LAST_LOGGED_IN >= TO_TIMESTAMP(:lastLoginFrom,'DD/MM/YYYY HH24:MI')");
            countQueryParameters.addValue("lastLoginFrom", lastLoginFrom);
        }

        if(!StringUtils.isEmpty(lastLoginTo))
        {
            queryBuilder.append(" AND UD.LAST_LOGGED_IN <= TO_TIMESTAMP(:lastLoginTo,'DD/MM/YYYY HH24:MI')");
            parameters.addValue("lastLoginTo", lastLoginTo);

            countQueryBuilder.append(" AND UD.LAST_LOGGED_IN <= TO_TIMESTAMP(:lastLoginTo,'DD/MM/YYYY HH24:MI')");
            countQueryParameters.addValue("lastLoginTo", lastLoginTo);
        }

        if(!StringUtils.isEmpty(searchKeyword))
        {
            searchKeyword = "%"+searchKeyword+"%";
            queryBuilder.append(" AND ( UD.FIRST_NAME LIKE :searchKeyword OR UD.LAST_NAME LIKE :searchKeyword OR UD.USER_NAME LIKE :searchKeyword OR UD.MOBILE_NO LIKE :searchKeyword )");
            parameters.addValue("searchKeyword", searchKeyword);

            countQueryBuilder.append(" AND ( UD.FIRST_NAME LIKE :searchKeyword OR UD.LAST_NAME LIKE :searchKeyword OR UD.USER_NAME LIKE :searchKeyword OR UD.MOBILE_NO LIKE :searchKeyword )");
            countQueryParameters.addValue("searchKeyword", searchKeyword);
        }

        int userCount = namedParameterJdbcTemplate.queryForObject(countQueryBuilder.toString(), countQueryParameters, Integer.class);

        userListResponse.setUserCount(userCount);

        queryBuilder.append(" ORDER BY ID OFFSET :offset ROWS FETCH NEXT :rowCount ROWS ONLY");
        parameters.addValue("rowCount", pageSize);
        parameters.addValue("offset", pageIndex*pageSize);

         userDetailsList = namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new UserDetailMapper());

        userListResponse.setUserList(userDetailsList);
        return userListResponse;
    }

    @Override
    public UserDetails getUser(Map<String, Object> whereMap) {
        StringBuilder query = new StringBuilder("SELECT * FROM USER_DETAILS WHERE USER_NAME=:");
        List<String> whereList = new ArrayList<>();
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
        for (Map.Entry<String, Object> stringStringEntry : whereMap.entrySet()) {

            Object value = stringStringEntry.getValue();
            if (value instanceof List) {
                whereList.add(stringStringEntry.getKey() + " IN (:" + stringStringEntry.getKey().toLowerCase() + ")");
            } else {
                whereList.add(stringStringEntry.getKey() + "=:" + stringStringEntry.getKey().toLowerCase());
            }
            parameters.addValue(stringStringEntry.getKey().toLowerCase(), stringStringEntry.getValue());

        }
        query.append(String.join(" and ", whereList));
        try {
            List<UserDetails> userDetailsList = namedParameterJdbcTemplate.query(query.toString(), parameters, new UserDetailMapper());
            if (!CollectionUtils.isEmpty(userDetailsList)) {
                return userDetailsList.get(0);
            } else {
                throw new TripApplicationException("No record found ");
            }
        } catch (Exception e) {
            throw new TripApplicationException("Exception on getTripDetailsForGivenOrders ", e);
        }
    }
}
