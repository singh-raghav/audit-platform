package com.ril.newcommerce.supplychain.tms.entity.rest;

public class Drivers {
	
	private String driverId;
	private String driverName;
	
	public String getDriverId() {
		return driverId;
	}
	public void setDriverId(String driverId) {
		this.driverId = driverId;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	@Override
	public String toString() {
		return "Drivers [driverId=" + driverId + ", driverName=" + driverName + "]";
	}

}
