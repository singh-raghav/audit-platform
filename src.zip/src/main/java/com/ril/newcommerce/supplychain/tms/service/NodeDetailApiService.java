package com.ril.newcommerce.supplychain.tms.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails.NodeDetailsResponse;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;

public interface NodeDetailApiService {

    NodeDetailsResponse getNodeDetails(String nodeId, NodeType nodeType, boolean hierarchy) throws JsonProcessingException;

    NodeDetailsResponse getNodeList(NodeType nodeType);

    NodeDetailsResponse getNodesForLevel(String nodeId, String level );
}
