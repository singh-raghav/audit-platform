package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripSequenceService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.DelayedShipment;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import com.ril.newcommerce.supplychain.tms.util.CancelTripUtil;
import com.ril.newcommerce.supplychain.tms.util.OrderStatusFeedFactory;

import lombok.extern.slf4j.Slf4j;

@Qualifier(Constants.DELAYED_SHIPMENT_PROCESSOR)
@Slf4j
@Service
public class DelayedShipmentProcessor implements Processor {

    @Autowired
    private JAXBContextConfig jAXBContextConfig;

    @Autowired
    private TripOrdersService tripOrderService;

    @Autowired
    private JMSPublisher publisher;
    
    @Autowired
    TripSequenceService tripSequenceService;
   
    @Value("${tripapp.queue}")
    private String queueName;
    

    @Override
    public void processMessage(Message message, String flowName) throws Exception {
        StringReader reader = new StringReader(((TextMessage) message).getText());
        DelayedShipment delayedShipment = (DelayedShipment) jAXBContextConfig.getJaxbContextInstance(DelayedShipment.class).createUnmarshaller().unmarshal(reader);

        String orderNo = delayedShipment.getOrderNo();
        tripOrderService.updateShipmentStatus(OrderStatus.SUSPEND.getValue(), Lists.newArrayList(orderNo), flowName, flowName);
        
        publishOrderStatusFeed(orderNo, OrderState.FC_DELAYED);

    }
	
    private void publishOrderStatusFeed(String orderId, OrderState orderState) {
        log.info("Publishing order status update feed for order {}, state {} ", orderId, orderState.getValue());
        OrderDetails orderDetails = new OrderDetails();
        orderDetails.setOrderId(orderId);
        publisher.inputToQueue(queueName, OrderStatusFeedFactory.getInstance(Lists.newArrayList(orderDetails), orderState, Constants.DELAYED_SHIPMENT_PROCESSOR), FlowName.ORDER_STATUS_UPDATE.getValue(), null, OrderStatusFeed.class);
    }
}
