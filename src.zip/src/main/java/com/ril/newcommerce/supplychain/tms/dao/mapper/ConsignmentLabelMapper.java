package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ConsignmentLabelMapper implements ResultSetExtractor<List<ConsignmentLabel>> {

    @Override
    public List<ConsignmentLabel> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<ConsignmentLabel> consignmentLabelList = new ArrayList<ConsignmentLabel>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            ConsignmentLabel consignmentInfo = new ConsignmentLabel();
            consignmentInfo.setLabelType(rs.getString("LABEL_TYPE"));
            consignmentInfo.setLabelId(rs.getString("LABEL_ID"));
            consignmentInfo.setStatus(rs.getString("STATUS"));

            consignmentLabelList.add(consignmentInfo);
        }
        return consignmentLabelList;
    }
}
