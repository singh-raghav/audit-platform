package com.ril.newcommerce.supplychain.tms.pdf;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;

public class SourceFactory {
    public static Source getInstance(XMLReader xmlReader, InputSource inputSource) {
        return new SAXSource(xmlReader, inputSource);
    }
}
