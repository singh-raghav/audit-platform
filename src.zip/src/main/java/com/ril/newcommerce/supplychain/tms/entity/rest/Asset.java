package com.ril.newcommerce.supplychain.tms.entity.rest;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 * @author Jeevi.Natarajan
 *
 * Used to post assets to ATS
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Asset {
	
	public Asset(String articleId, Integer count) {
		this.articleId = articleId;
		this.count = count;
	}
	
	public Asset() {}

	private String articleId;
	private Integer count;
	private String assetType;//used to pass information to ATS.
	
	public String getArticleId() {
		return articleId;
	}
	
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	
	public Integer getCount() {
		return count;
	}
	
	public void setCount(Integer count) {
		this.count = count;
	}
	
	public String getAssetType() {
		return assetType;
	}
	
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	
}