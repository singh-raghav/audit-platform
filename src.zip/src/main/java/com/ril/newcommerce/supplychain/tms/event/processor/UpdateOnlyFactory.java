package com.ril.newcommerce.supplychain.tms.event.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

@Component
public class UpdateOnlyFactory 
{
	@Autowired
	@Qualifier(Constants.SPLIT_PROCESSOR)
	private IUpdateOnlyProcessor splitProcessor;

	@Autowired
	@Qualifier(Constants.MERGE_PROCESSOR)
	private IUpdateOnlyProcessor mergeProcessor;
	
	@Autowired
	@Qualifier(Constants.UNLOADING_COMPLETE_PROCESSOR)
	private IUpdateOnlyProcessor unloadingCompleteProcessor;
	
	@Autowired
	@Qualifier(Constants.CHECK_IN_PROCESSOR)
	private IUpdateOnlyProcessor checkInProcessor;
	
	@Autowired
	@Qualifier(Constants.CHECK_OUT_PROCESSOR)
	private IUpdateOnlyProcessor checkOutProcessor;
	
	@Autowired
	@Qualifier(Constants.REPORT_RECONCILE_PROCESSOR)
	private IUpdateOnlyProcessor reportReconcileProcessor;
	
	@Autowired
	@Qualifier(Constants.MANUAL_TRIP_PROCESSOR)
	private IUpdateOnlyProcessor manualTripProcessor;
	
	@Autowired
	@Qualifier(Constants.REASSIGN_PROCESSOR)
	private IUpdateOnlyProcessor reAssignProcessor;
	
	@Autowired
	@Qualifier(Constants.RETURN_SHUTTLE_TRIP_PROCESSOR_RETURN)
	private IUpdateOnlyProcessor returnShuttleTripProcessor;

	
	public IUpdateOnlyProcessor getProcessor(TripEventInput event) {

		switch (event.getAction()) {
		
			case SPLIT:
				return splitProcessor;
			case MERGE:
				return mergeProcessor;
			case UNLOADING_COMPLETE:
				return unloadingCompleteProcessor;
			case CHECK_IN:
				return checkInProcessor;
			case CHECK_OUT:
				return checkOutProcessor;
			case REPORTRECONCILE:
				return reportReconcileProcessor;
			case MANUAL_TRIP:
				return manualTripProcessor;
			case SHUTTLE_TRIP:
				return returnShuttleTripProcessor;		
			case REASSIGN:
				return reAssignProcessor;
			default:
				return null;
		}
		
	}


}
