package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Qualifier(Constants.ORDER_PROCESSOR.DO_NOTHING_PRE_PROCESSOR)
@Service
public class OrderStatusDoNothingPreProcessor implements OrderStatusUpdatePreProcessor {
    @Override
    public boolean validateUpdate(OrderStatusFeed.Order orderStatusFeedOrder) {
        return true;
    }
}
