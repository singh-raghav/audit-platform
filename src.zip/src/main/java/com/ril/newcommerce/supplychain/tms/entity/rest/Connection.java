/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

/**
 * @author Raghav1.Singh
 *
 */
public class Connection {
	
	List<String> connections;

	public List<String> getConnections() {
		return connections;
	}

	public void setConnections(List<String> connections) {
		this.connections = connections;
	}

	
}
