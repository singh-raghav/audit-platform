package com.ril.newcommerce.supplychain.tms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.dao.DriversDAO;
import com.ril.newcommerce.supplychain.tms.entity.rest.Drivers;
import com.ril.newcommerce.supplychain.tms.service.DriverService;

@Service
public class DriverServiceImpl implements DriverService{
	
	@Autowired
	DriversDAO driverDao;
	
	@Override
	public List<Drivers> getAvailableDrivers(String nodeId) {
		List<Drivers> drivers = new ArrayList<Drivers>();
		drivers = driverDao.getAvailableDrivers(nodeId);
		return drivers;
	}

}
