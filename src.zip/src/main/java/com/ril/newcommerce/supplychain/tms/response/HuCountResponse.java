package com.ril.newcommerce.supplychain.tms.response;

import lombok.Data;

@Data
public class HuCountResponse {
    String sdpId;
    Integer huCount;
    Integer huMissing;
    String orderId;
}
