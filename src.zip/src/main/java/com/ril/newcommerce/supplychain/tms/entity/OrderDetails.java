package com.ril.newcommerce.supplychain.tms.entity;

import java.sql.Timestamp;

/**
B1.Divya
*/

public class OrderDetails {
	
	private String orderId;
	private String shipmentNo;
	private String orderType;
	private String orderClassification;
	private String sourceNode;
	private Timestamp orderDate;
	private Timestamp slotStartTime;
	private Timestamp slotEndTime;
	private String sellerOrgCode;
	private String orderStatus;
	private String customerName;
	private String customerAddress;
	private String customerPincode;
	private Timestamp createdTime;
	private String createdBy;
	private String modifiedBy;
	private Timestamp modifiedTime;
	private String flowName;
	private String customerPONumber;
	private String customerId;
	private String customerState;
	private String customerStateCode;
	private String customerGstn;
	private String city;
	private String phoneNumber;
	private String mid;
	private String nextNode;
	private String shipmentStatus;
	private String tripType;
	private String deliveryZoneId;

	public String getCustomerState() {
		return customerState;
	}
	
	public void setCustomerState(String customerState) {
		this.customerState = customerState;
	}
	
	public String getCustomerStateCode() {
		return customerStateCode;
	}
	
	public void setCustomerStateCode(String customerStateCode) {
		this.customerStateCode = customerStateCode;
	}
	
	public String getCustomerGstn() {
		return customerGstn;
	}
	
	public void setCustomerGstn(String customerGstn) {
		this.customerGstn = customerGstn;
	}
	
	public String getCustomerId() {
		return customerId;
	}
	
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public String getCustomerPONumber() {
		return customerPONumber;
	}

	public void setCustomerPONumber(String customerPONumber) {
		this.customerPONumber = customerPONumber;
	}

	public String getOrderId() {
		return orderId;
	}
	
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getShipmentNo() {
		return shipmentNo;
	}
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getOrderClassification() {
		return orderClassification;
	}
	public void setOrderClassification(String orderClassification) {
		this.orderClassification = orderClassification;
	}
	public String getSourceNode() {
		return sourceNode;
	}
	public void setSourceNode(String sourceNode) {
		this.sourceNode = sourceNode;
	}
	
	public Timestamp getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Timestamp orderDate) {
		this.orderDate = orderDate;
	}

	public Timestamp getSlotStartTime() {
		return slotStartTime;
	}
	public void setSlotStartTime(Timestamp slotStartTime) {
		this.slotStartTime = slotStartTime;
	}
	public Timestamp getSlotEndTime() {
		return slotEndTime;
	}
	public void setSlotEndTime(Timestamp slotEndTime) {
		this.slotEndTime = slotEndTime;
	}
	public String getSellerOrgCode() {
		return sellerOrgCode;
	}
	public void setSellerOrgCode(String sellerOrgCode) {
		this.sellerOrgCode = sellerOrgCode;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerPincode() {
		return customerPincode;
	}
	public void setCustomerPincode(String customerPincode) {
		this.customerPincode = customerPincode;
	}
	public Timestamp getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Timestamp modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getMid() {
		return mid;
	}

	public void setNextNode(String nextNode) {
		this.nextNode = nextNode;
	}

	public String getNextNode() {
		return nextNode;
	}

	public void setShipmentStatus(String shipmentStatus) {
		this.shipmentStatus = shipmentStatus;
	}

	public String getShipmentStatus() {
		return shipmentStatus;
	}

	public void setTripType(String tripType) {
		this.tripType = tripType;
	}

	public String getTripType() {
		return tripType;
	}

	public String getDeliveryZoneId() {
		return deliveryZoneId;
	}

	public void setDeliveryZoneId(String deliveryZoneId) {
		this.deliveryZoneId = deliveryZoneId;
	}
}
