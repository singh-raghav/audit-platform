package com.ril.newcommerce.supplychain.tms.event.processor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.AdhocTripRequest;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.InvalidActionException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.processors.PostSplitProcessor;
import com.ril.newcommerce.supplychain.tms.service.KafkaRestProxyService;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanCreator;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipment;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipments;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Split;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge.Trips;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge.Trips.Trip.Orders;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge.Trips.Trip.Orders.Order;
import com.ril.newcommerce.supplychain.tms.util.Utility;

@Component
@Qualifier(Constants.MERGE_PROCESSOR)
public class MergeProcessor implements IUpdateOnlyProcessor {
	
	private static final Logger log = LoggerFactory.getLogger(MergeProcessor.class);
	
	@Autowired
	TripService tripService;
	
	@Autowired
	private JMSPublisher jmsPublisher;
	
	@Value("${tripapp.queue}")
	private String queueName;
	
	
	@Autowired
	TripOrdersService tripOrderService;
	
	@Autowired
    private KafkaRestProxyService commonAuditEventPublisher;


	@Autowired
	TripsDAO tripsDAO;

	@Override
	public void processEvent(TripEventInput event, Trip trip)
	{
		try{
			
		if(CollectionUtils.isEmpty(event.getConsignments()))
		{
			throw new ValidationException("Orders cannot be empty");
		}
		
		List<String> shipmentNos=event.getConsignments().stream().map(mapper->mapper.getShipmentNo()).collect(Collectors.toList());
		List<String> nodeIds=new ArrayList<>();
		nodeIds.add(event.getNodeId());
	//	System.out.println(event.getConsignments().stream().map(i->i.getOrderStatus()).distinct().collect(Collectors.toList()));
		if(event.getConsignments().stream().map(i->i.getShipmentStatus()).distinct().collect(Collectors.toList()).contains("UnplannedReturn") || event.getConsignments().stream().map(i->i.getShipmentStatus()).distinct().collect(Collectors.toList()).contains("Rescheduled")) {
			//For Fluid Loading merging CR and rescheduled order into existing trip
			List<String> rescheduledShipments = event.getConsignments().stream().filter(i->i.getOrderStatus().equalsIgnoreCase("Rescheduled")).map(mapper->mapper.getShipmentNo()).collect(Collectors.toList());
			
			if(null!=rescheduledShipments && !rescheduledShipments.isEmpty())
				tripOrderService.updateShipmentStatus(OrderStatus.INPROGRESS.getValue(),rescheduledShipments, null,event.getModifiedBy(), event.getFlowName(), event.getNodeId(), OrderStatus.RESCHEDULED.getValue());
			
			tripService.updateTripVersion(event.getTripId(),event.getFlowName(),event.getModifiedBy());
			tripOrderService.mergeTripConsignment(event.getConsignments(), event.getTripId(), event.getModifiedBy(), FlowName.MERGE.getValue(), event.getNodeId(),true);
			//Publishing updated trip version to external system
			TripPublish tripPublishMeaage = Utility.createMessageToPublishTrip(event.getTripId(),trip.getVersion() + 1,false);	
			sendtoAudit(event,trip);
			jmsPublisher.inputToQueue(queueName, tripPublishMeaage, FlowName.PUBLISHTRIP.getValue(),
					Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
							tripPublishMeaage.getTrip().getId()),TripPublish.class);
			//Post Merging order in trip
			/*if(null!=rescheduledShipments && !rescheduledShipments.isEmpty()) {
				List<String> status=new ArrayList<>();
				status.add(OrderStatus.INPROGRESS.getValue());
				
				List<TripConsignmentInfo> tripConsignmentInfo = tripOrderService.getTripConsignmentInfo(null, nodeIds,
						status, null, shipmentNos,null);

				Merge mergeRequest = Utility.createPostMergeRequest(tripConsignmentInfo, event.getNodeId(), trip);
				
				jmsPublisher.inputToQueue(queueName, mergeRequest, FlowName.MERGE.getValue(),
						Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
								tripPublishMeaage.getTrip().getId()),Merge.class);
			}*/			
			
		}else {
			int count = tripOrderService.updateShipmentStatus(OrderStatus.INPROGRESS.getValue(), shipmentNos, null,
					event.getModifiedBy(), event.getFlowName(), event.getNodeId(), OrderStatus.INACTIVE.getValue());
			if(count==shipmentNos.size())
				{
				tripService.updateTripVersion(event.getTripId(),event.getFlowName(),event.getModifiedBy());
				
					log.info("Merging shipments from trip id {}",trip.getTripId());
					List<String> status=new ArrayList<>();
					status.add(OrderStatus.INPROGRESS.getValue());
					
					List<TripConsignmentInfo> tripConsignmentInfo = tripOrderService.getTripConsignmentInfo(null, nodeIds,
							status, null, shipmentNos,null);

					Merge mergeRequest = Utility.createPostMergeRequest(tripConsignmentInfo, event.getNodeId(), trip);

					tripOrderService.mergeTripConsignment(event.getConsignments(), event.getTripId(), event.getModifiedBy(),
							FlowName.MERGE.getValue(), event.getNodeId(),true);

					TripPublish tripPublishMeaage = Utility.createMessageToPublishTrip(event.getTripId(),
							trip.getVersion() + 1,false);
			
					sendtoAudit(event,trip);
			
			jmsPublisher.inputToQueue(queueName, mergeRequest, FlowName.MERGE.getValue(),
					Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
							tripPublishMeaage.getTrip().getId()),Merge.class);	
			
			jmsPublisher.inputToQueue(queueName, tripPublishMeaage, FlowName.PUBLISHTRIP.getValue(),
					Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
							tripPublishMeaage.getTrip().getId()),TripPublish.class);

					
					
					log.info("shipemnt successfulyy merged ",trip.getTripId());
				}
			else
			{
				throw new InvalidActionException("This trip entity cannot be modified right now");
			}
		}
		}
		catch(Exception ex)
		{
			log.error("exception occured during merging shipments in to  trip {}  {}",trip.getTripId(),ex.getMessage());
			throw new TripApplicationException(ex.getMessage());
		}

	}
	
	
	private void sendtoAudit(TripEventInput event, Trip trip)  {
		try{
		ObjectMapper objectMapper = new ObjectMapper();
	    String request = objectMapper.writeValueAsString(event);
		commonAuditEventPublisher.publishToCommonAuditPlatform(Constants.TRIP_APP, trip.getTripId(), Constants.MERGE, System.currentTimeMillis(), request);
		}
		catch(Exception ex)
		{
			log.error(ex.getMessage());
		}
		
	}

}