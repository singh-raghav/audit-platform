package com.ril.newcommerce.supplychain.tms.pdf.model.manifest;

import org.xml.sax.InputSource;

import com.ril.newcommerce.supplychain.tms.entity.FCManifest;

public class ManifestInputSource extends InputSource {
    private FCManifest manifest;

    public ManifestInputSource(FCManifest manifest) {
        this.manifest = manifest;
    }

    public FCManifest getManifest() {
        return manifest;
    }

    public void setManifest(FCManifest manifest) {
        this.manifest = manifest;
    }
}
