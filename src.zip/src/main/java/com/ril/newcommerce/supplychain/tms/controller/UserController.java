package com.ril.newcommerce.supplychain.tms.controller;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.CreateUserRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.UpdateUserRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.UserDetailResponse;
import com.ril.newcommerce.supplychain.tms.enums.UserRoles;
import com.ril.newcommerce.supplychain.tms.service.UserService;
import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;

@RestController
@RequestMapping(value = "/trip-mgmt/v1/user")
public class UserController {

	@Autowired
	private UserService userService;

	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

	@GetMapping(value = "/details", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getUserDetails(Authentication authentication) {

		long startTime = System.currentTimeMillis();

		ResponseEntity<ResponseMessage> responseEntity = null;
		try {
			UserDetailResponse userDetailResponse = userService.getUserDetails(authentication.getName());
			if (userDetailResponse == null) {
				responseEntity= Utility.getfailureMsg("User not found", HttpStatus.NO_CONTENT);
			} else {
				responseEntity = Utility.getSuccessMsg(userDetailResponse);
			}
		}catch(Exception ex){
			LOGGER.error("ERROR_IN_getUserDetails -- ",ex);
			responseEntity = Utility.getfailureMsg(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		LOGGER.info("getUserDetails_time -- [{}]ms", (System.currentTimeMillis() - startTime));
		return responseEntity;
	}

	@PostMapping(value = "/createuser", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseMessage> createUser(@Valid @RequestBody CreateUserRequest createUserRequest, Authentication authentication) throws Exception {

		long startTime = System.currentTimeMillis();

		LOGGER.debug("createuser_input - {}",createUserRequest);

		ResponseEntity<ResponseMessage> responseEntity = null;
		try {
			userService.createUser(createUserRequest, authentication.getName());
			responseEntity = Utility.getSuccessMsg("User Created successfully");
		}catch(Exception ex){
			LOGGER.error("ERROR_IN_createUser -- ",ex);
			responseEntity = Utility.getfailureMsg(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}

		LOGGER.info("createUser_time -- [{}]ms", (System.currentTimeMillis() - startTime));
		return responseEntity;
	}
	
    @PostMapping(value = "/reprocessUser", consumes = "application/json", produces = "application/json")
    public ResponseEntity<ResponseMessage> reprocessUser(@RequestParam("id") String id) throws Exception {

        long startTime = System.currentTimeMillis();

        LOGGER.debug("reprocessUser_input - {}",id);

        ResponseEntity<ResponseMessage> responseEntity = null;
        try {
            String errorMessage = userService.reprocessUser(id);

            if(errorMessage.equals("")){
				responseEntity = Utility.getSuccessMsg("User Created successfully in ExternalSystem");
			}
            else{
				responseEntity = Utility.getfailureMsg(errorMessage, HttpStatus.OK);
			}

        }catch(Exception ex){
            LOGGER.error("ERROR_IN_reprocessUser -- ",ex);
            responseEntity = Utility.getfailureMsg(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }

        LOGGER.info("reprocessUser_time -- [{}]ms", (System.currentTimeMillis() - startTime));
        return responseEntity;
    }

	@GetMapping(value = "/list", produces = "application/json")
    @Validated
	public ResponseEntity<ResponseMessage> listUsers(@RequestHeader(value = Constants.NODE_ID, required = true) String nodeId,
													 @RequestParam(value = "clusterId", required = true) String clusterId,
													 @RequestParam(value = "ignoreNodeIdHeader", required = true) Boolean ignoreNodeIdHeader,
													 @RequestParam(value = "ignoreDeletedUsers", required = true) Boolean ignoreDeletedUsers,
													 @RequestParam(value = "searchKeyword", required = false) String searchKeyword,
													 @RequestParam(value = "userRole", required = false) UserRoles userRole,
													 @RequestParam(value = "lastLoginFrom", required = false) String lastLoginFrom,
													 @RequestParam(value = "lastLoginTo", required = false) String lastLoginTo,
													 @RequestParam(value = "pageIndex", required = true) Integer pageIndex,
													 @RequestParam(value = "pageSize", required = true) Integer pageSize) throws Exception{


		long startTime = System.currentTimeMillis();

		LOGGER.info("listUsers_input - {},{},{},{},{},{},{},{},{},{}",nodeId, clusterId, ignoreNodeIdHeader,
				ignoreDeletedUsers, pageSize, pageIndex,
				searchKeyword, userRole, lastLoginFrom,
				lastLoginTo);

		ResponseEntity<ResponseMessage> responseEntity = null;
		try {
			responseEntity = Utility.getSuccessMsg(userService.getUserList(nodeId, clusterId, ignoreNodeIdHeader,
					ignoreDeletedUsers, pageSize, pageIndex,
					searchKeyword, userRole, lastLoginFrom,
					lastLoginTo));
		}catch(Exception ex){
			LOGGER.error("ERROR_IN_listUsers -- ",ex);
			responseEntity = Utility.getfailureMsg(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}

		LOGGER.info("listUsers_time -- [{}]ms", (System.currentTimeMillis() - startTime));
		return responseEntity;
	}

	@PostMapping(value = "/update", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseMessage> updateUser(@Valid @RequestBody UpdateUserRequest updateUserRequest) throws Exception {

		long startTime = System.currentTimeMillis();

		LOGGER.debug("updateUser_input - {}",updateUserRequest);

		ResponseEntity<ResponseMessage> responseEntity = null;
		try {
			userService.updateUser(updateUserRequest);
			responseEntity = Utility.getSuccessMsg("User Updated successfully");
		}catch(Exception ex){
			LOGGER.error("ERROR_IN_updateUser -- ",ex);
			responseEntity = Utility.getfailureMsg(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}

		LOGGER.info("updateUser_time -- [{}]ms", (System.currentTimeMillis() - startTime));
		return responseEntity;
	}


	@PostMapping(value = "/resetpass", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseMessage> resetPassword(@RequestBody UpdateUserRequest updateUserRequest,
														 Authentication authentication) throws Exception {

		long startTime = System.currentTimeMillis();

		LOGGER.debug("resetPassword_input - {}", updateUserRequest);

		ResponseEntity<ResponseMessage> responseEntity = null;
		try {

			if (StringUtils.isBlank(updateUserRequest.getUserName())) {
				throw new Exception("Username Should not be blank");
			}
			userService.resetPassword(updateUserRequest, authentication.getName());
			responseEntity = Utility.getSuccessMsg("Reset password link successfully sent");

		} catch (Exception ex) {
			LOGGER.error("ERROR_IN_resetPassword -- ", ex);
			responseEntity = Utility.getfailureMsg(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}

		LOGGER.info("resetPassword_time -- [{}]ms", (System.currentTimeMillis() - startTime));
		return responseEntity;
	}

	@PostMapping(value = "/changepass", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseMessage> changePassword(@RequestHeader("Authorization") String token,
														  @Valid @RequestBody UpdateUserRequest updateUserRequest) throws Exception {

		long startTime = System.currentTimeMillis();

		LOGGER.debug("changePassword_input - {}",updateUserRequest);

		ResponseEntity<ResponseMessage> responseEntity = null;
		try {
			userService.changePassword(token, updateUserRequest);
			responseEntity = Utility.getSuccessMsg("Password changed successfully");
		}catch(Exception ex){
			LOGGER.error("ERROR_IN_changePassword -- ",ex);
			responseEntity = Utility.getfailureMsg(ex.getMessage(), HttpStatus.BAD_REQUEST);
		}

		LOGGER.info("changePassword_time -- [{}]ms", (System.currentTimeMillis() - startTime));
		return responseEntity;
	}



}
