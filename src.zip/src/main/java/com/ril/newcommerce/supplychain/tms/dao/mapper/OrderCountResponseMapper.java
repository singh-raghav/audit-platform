package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.response.OrderCountResponse;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderCountResponseMapper implements ResultSetExtractor<List<OrderCountResponse>> {
    @Override
    public List<OrderCountResponse> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<OrderCountResponse> orderCountResponses = new ArrayList<>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            OrderCountResponse orderCountResponse = new OrderCountResponse();
            orderCountResponse.setSdpId(rs.getString("SDP_ID"));
            orderCountResponse.setTotalCount(rs.getInt("TOTAL_ORDERS"));
            orderCountResponse.setInvoicedCount(rs.getInt("TOTAL_INVOICED"));
            orderCountResponse.setStagedCount(rs.getInt("TOTAL_STAGED"));
            orderCountResponses.add(orderCountResponse);
        }
        return orderCountResponses;
    }
}
