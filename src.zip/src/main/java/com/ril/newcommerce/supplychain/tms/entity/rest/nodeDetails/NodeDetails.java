package com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NodeDetails implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;

    private String nodeId;
    private String nodeType;
    private String name;
    private String clusterId;
    private boolean active;
    private String description;
    private String displayName;
    private String phone;
    private Address address;
    private String regionCode;
    private String longitude;
    private String latitude;
    private String coHostId;
    private String parentNodeId;
    private List<String> servesPinCodes;
    private List<NodeDetails> childNodes;
}
