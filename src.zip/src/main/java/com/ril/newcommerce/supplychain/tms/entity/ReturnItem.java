package com.ril.newcommerce.supplychain.tms.entity;
/**
 * 
 * @author Jeevi.Natarajan
 *
 */

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReturnItem {
	
	private String itemId;
	private String returnOrderId;
	private String fwdOrderId;
	private String primeLineNo;
	private String itemName;
	private Double orderedQuantity;
	private String hsnCode;
	private Double unitPrice;
	private String uom;
	private Double recievedQuantity;
	private Double invoicedQuanity;
	private String challanId;
	private String nodeid;
	private String returnType;
	
	private List<ItemCondition> itemsCondition; 
	
	
	public String getReturnType() {
		return returnType;
	}
	
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	
	public String getNodeid() {
		return nodeid;
	}
	
	public void setNodeid(String nodeid) {
		this.nodeid = nodeid;
	}
	
	public String getFwdOrderId() {
		return fwdOrderId;
	}
	
	public void setFwdOrderId(String fwdOrderId) {
		this.fwdOrderId = fwdOrderId;
	}
	
	public Double getInvoicedQuanity() {
		return invoicedQuanity;
	}
	
	public void setInvoicedQuanity(Double invoicedQuanity) {
		this.invoicedQuanity = invoicedQuanity;
	}
	
	public String getItemId() {
		return itemId;
	}
	
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	
	public List<ItemCondition> getItemsCondition() {
		return itemsCondition;
	}
	
	public void setItemsCondition(List<ItemCondition> itemsCondition) {
		this.itemsCondition = itemsCondition;
	}
	
	public void addItemCondition(ItemCondition condition) {
		
		if(this.itemsCondition==null) 
			this.itemsCondition = new ArrayList<>();
		
		this.itemsCondition.add(condition);
	}

	public String getReturnOrderId() {
		return returnOrderId;
	}

	public void setReturnOrderId(String returnOrderId) {
		this.returnOrderId = returnOrderId;
	}

	public String getPrimeLineNo() {
		return primeLineNo;
	}

	public void setPrimeLineNo(String primeLineNo) {
		this.primeLineNo = primeLineNo;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Double getOrderedQuantity() {
		return orderedQuantity;
	}

	public void setOrderedQuantity(Double orderedQuantity) {
		this.orderedQuantity = orderedQuantity;
	}

	public String getHsnCode() {
		return hsnCode;
	}

	public void setHsnCode(String hsnCode) {
		this.hsnCode = hsnCode;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Double getRecievedQuantity() {
		return recievedQuantity;
	}

	public void setRecievedQuantity(Double recievedQuantity) {
		this.recievedQuantity = recievedQuantity;
	}

	public String getChallanId() {
		return challanId;
	}

	public void setChallanId(String challanId) {
		this.challanId = challanId;
	}

	@Override
	public String toString() {
		return "ReturnItem [itemId=" + itemId + ", returnOrderId=" + returnOrderId + ", fwdOrderId=" + fwdOrderId
				+ ", primeLineNo=" + primeLineNo + ", itemName=" + itemName + ", orderedQuantity=" + orderedQuantity
				+ ", hsnCode=" + hsnCode + ", unitPrice=" + unitPrice + ", uom=" + uom + ", recievedQuantity="
				+ recievedQuantity + ", invoicedQuanity=" + invoicedQuanity + ", challanId=" + challanId + ", nodeid="
				+ nodeid + ", returnType=" + returnType + ", itemsCondition=" + itemsCondition + "]";
	}

}
