package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.dao.OrderIntermediariesDAO;
import com.ril.newcommerce.supplychain.tms.dao.impl.OrderIntermediariesDAOImpl;
import com.ril.newcommerce.supplychain.tms.entity.OrderIntermediaries;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.service.OrderIntermediariesService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Order.Shipments;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderIntermediariesServiceImpl implements OrderIntermediariesService {

    private static Logger log = LoggerFactory.getLogger(OrderIntermediariesServiceImpl.class);

    @Autowired
    private OrderIntermediariesDAO orderIntermediariesDAO;

    @Override
    public void insertRow(List<Shipments.Shipment.Intermediaries> intermediariesListGiven, String orderId) {

        List<OrderIntermediaries> orderIntermediariesList = new ArrayList<>();
        try {
            if (!CollectionUtils.isEmpty(intermediariesListGiven)) {
                for (Shipments.Shipment.Intermediaries intermediaries : intermediariesListGiven) {
                    if (null != intermediaries && !CollectionUtils.isEmpty(intermediaries.getIntermediary())) {
                        for (Shipments.Shipment.Intermediaries.Intermediary intermediary : intermediaries.getIntermediary()) {

                            OrderIntermediaries orderIntermediaries = new OrderIntermediaries();
                            orderIntermediaries.setOrderId(orderId);
                            orderIntermediaries.setNodeId(intermediary.getId());
                            orderIntermediariesList.add(orderIntermediaries);
                        }
                    }
                }
                orderIntermediariesDAO.insertRow(orderIntermediariesList);
            }
        } catch (Exception e) {
            log.error("Failed data insert into order_intermediaries");
        }
    }
}
