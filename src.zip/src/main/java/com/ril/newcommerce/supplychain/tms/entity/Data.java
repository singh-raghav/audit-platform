/**
 * @author satya1.prakash
 *
 **/
package com.ril.newcommerce.supplychain.tms.entity;
import java.util.List;

public class Data {
	
	private List<Link> links;
	private String tripId;
	private String tripStartNode;
	private TripAssetInfo assetInfo;
	private List<AssetMasterData> entities;
	
	public List<Link> getLinks() {
		return links;
	}
	public void setLinks(List<Link> links) {
		this.links = links;
	}
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public String getTripStartNode() {
		return tripStartNode;
	}
	public void setTripStartNode(String tripStartNode) {
		this.tripStartNode = tripStartNode;
	}
	public TripAssetInfo getAssetInfo() {
		return assetInfo;
	}
	public void setAssetInfo(TripAssetInfo assetInfo) {
		this.assetInfo = assetInfo;
	}
	
	public List<AssetMasterData> getEntities() {
		return entities;
	}
	
	public void setEntities(List<AssetMasterData> entities) {
		this.entities = entities;
	}
	
	@Override
	public String toString() {
		return "Data [links=" + links + ", tripId=" + tripId + ", tripStartNode=" + tripStartNode + ", assetInfo="
				+ assetInfo + ", getLinks()=" + getLinks() + ", getAssetInfo()=" + getAssetInfo() + "]";
	}

}
