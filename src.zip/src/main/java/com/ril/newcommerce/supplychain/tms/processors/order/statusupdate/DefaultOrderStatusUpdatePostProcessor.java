package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.service.KafkaRestProxyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Qualifier(Constants.ORDER_PROCESSOR.DEFAULT_POST_PROCESSOR)
@Slf4j
@Service
public class DefaultOrderStatusUpdatePostProcessor implements OrderStatusUpdatePostProcessor {

    @Autowired
    private KafkaRestProxyService commonAuditEventPublisher;

    @Override
    public void publishToAudit(String orderId, String fromState, String toState) {

        String message = new StringBuilder("Status changed for order ").append(orderId).append(" from ").append(fromState).append(" to ").append(toState).toString();
        try {
            commonAuditEventPublisher.publishToCommonAuditPlatform(Constants.TRIP_APP, orderId, Constants.ORDER_STATUS_UPDATE, System.currentTimeMillis(), message);
        } catch (Exception e) {
            log.error("Unable to push message to common Audit platform : {}", orderId);
        }
    }
}
