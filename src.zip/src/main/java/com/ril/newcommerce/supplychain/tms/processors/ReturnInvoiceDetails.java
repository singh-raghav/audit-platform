package com.ril.newcommerce.supplychain.tms.processors;

import com.google.common.collect.Lists;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.ReturnInvoiceService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import com.ril.newcommerce.supplychain.tms.tibco.invoice.entity.InvoiceDetail;
import com.ril.newcommerce.supplychain.tms.util.OrderStatusFeedFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.UnmarshalException;
import java.io.StringReader;

@Service
@Qualifier(Constants.RETURN_INVOICE_DETAILS)
public class ReturnInvoiceDetails implements Processor {
	
	private static final Logger log = LoggerFactory.getLogger(ReturnInvoiceDetails.class);

	@Autowired 
	private JAXBContextConfig jAXBContextConfig;
	
	@Autowired
	ReturnInvoiceService returnInvoiceService;

	@Autowired
	private JMSPublisher publisher;

	@Value("${tripapp.queue}")
	private String queueName;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {
		try {
			StringReader reader = new StringReader(((TextMessage) message).getText());
			InvoiceDetail invoiceDetails = (InvoiceDetail) jAXBContextConfig.getJaxbContextInstance(InvoiceDetail.class).createUnmarshaller().unmarshal(reader);
			returnInvoiceService.persistReturnItems(invoiceDetails);
			publishOrderStatusFeed(invoiceDetails);
			log.info("Invoice items saved successfully");
		} catch (UnmarshalException par) {
			throw new ParsingException("Parsing error while parsing return invoice ", par);
		} catch (Exception e) {
			log.error("Error while processing return invoice ", e);
			throw new Exception("Exception occurred while processign return invoice", e);
		}
	}
	private void publishOrderStatusFeed(InvoiceDetail invoice) {

		OrderDetails orderDetails = new OrderDetails();
		orderDetails.setOrderId(invoice.getInvoiceHeader().getOrderNo());

		publisher.inputToQueue(queueName, OrderStatusFeedFactory.getInstance(Lists.newArrayList(orderDetails), OrderState.INVOICED, Constants.RETURN_INVOICE_DETAILS), FlowName.ORDER_STATUS_UPDATE.getValue(), null, OrderStatusFeed.class);
	}
}
