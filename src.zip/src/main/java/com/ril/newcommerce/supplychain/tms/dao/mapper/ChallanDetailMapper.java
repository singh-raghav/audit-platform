package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Invoice;
import com.ril.newcommerce.supplychain.tms.enums.ReturnItemQuality;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;

/**
B1.Divya
*/

public class ChallanDetailMapper implements ResultSetExtractor<List<ChallanArticle>> {

	@Override
	public List<ChallanArticle> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<ChallanArticle> challanDetails = new ArrayList<ChallanArticle>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			ChallanArticle article=new ChallanArticle();
			
			article.setReturnOrderId(rs.getString("RETURN_ORDER_ID"));
			article.setArticleCode(rs.getString("ARTICLE_ID"));
			article.setQuantity(rs.getDouble("QTY"));
			article.setQuality(ReturnItemQuality.valueOf(rs.getString("QUALITY")));
			article.setChallanId(rs.getString("CHALLAN_ID"));
			article.setTripId(rs.getString("TRIP_ID"));
			challanDetails.add(article);
		}
		return challanDetails;
	}
}