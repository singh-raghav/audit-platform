package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.OrderDetailsDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ConsignmentMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.CustomerInfoMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.OrderCountResponseMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.OrderDetailsListMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.OrderDetailsMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.OrderViewResponseForFluidLoadingMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripConsignmentMapper;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.response.OrderCountResponse;
import com.ril.newcommerce.supplychain.tms.response.OrderListResponse;
import com.ril.newcommerce.supplychain.tms.response.OrderListResponseFluidLoading;
import com.ril.newcommerce.supplychain.tms.response.OrderViewResponse;
import com.ril.newcommerce.supplychain.tms.response.OrderViewResponseForFluidLoading;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;

/**
B1.Divya
*/

@Repository
public class OrderDetailsDAOImpl implements OrderDetailsDAO {
	
	private static final Logger log = LoggerFactory.getLogger(OrderDetailsDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void  insertOrderDetails(List<OrderDetails> orderDetails) {
		
		log.info("Adding order details");
		try {
			jdbcTemplate.batchUpdate(QueryConstants.INSERT_TO_ORDER_DETAILS, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, orderDetails.get(i).getOrderId());
					ps.setString(2, orderDetails.get(i).getShipmentNo());
					ps.setString(3, orderDetails.get(i).getOrderType());
					ps.setString(4, orderDetails.get(i).getOrderClassification());
					ps.setString(5, orderDetails.get(i).getSourceNode());
					ps.setString(6, orderDetails.get(i).getCustomerName());
					ps.setString(7, orderDetails.get(i).getCustomerAddress());
					ps.setString(8, orderDetails.get(i).getCustomerPincode());
					ps.setString(9, orderDetails.get(i).getSellerOrgCode());
					ps.setString(10, OrderState.CREATED.getValue());
					ps.setTimestamp(11, orderDetails.get(i).getSlotStartTime());
					ps.setTimestamp(12, orderDetails.get(i).getSlotEndTime());
					ps.setTimestamp(13, orderDetails.get(i).getCreatedTime());
					ps.setString(14, orderDetails.get(i).getCreatedBy());
					ps.setString(15, orderDetails.get(i).getFlowName());
					ps.setString(16, orderDetails.get(i).getCustomerPONumber());
					ps.setString(17, orderDetails.get(i).getCustomerId());
					ps.setString(18, orderDetails.get(i).getCustomerStateCode());
					ps.setString(19, orderDetails.get(i).getCustomerGstn());
					ps.setString(20, orderDetails.get(i).getCustomerState());
					ps.setTimestamp(21, orderDetails.get(i).getCreatedTime());
					ps.setString(22, orderDetails.get(i).getCreatedBy());
					ps.setTimestamp(23, orderDetails.get(i).getOrderDate());
					ps.setString(24, orderDetails.get(i).getDeliveryZoneId());

				}

				@Override
				public int getBatchSize() {
					return orderDetails.size();
				}
			});

		}
		
		catch(DuplicateKeyException ex) {
			throw new DuplicateKeyException("Duplicate unique key found..");
		}
		
		catch (Exception e) {
			throw new DataProcessingException("Got Exception in OrderDetailsDAOImpl insertOrderDetails",e);
		}

	}

	@Override
	public List<Consignment> getTripOrderDetails(String tripId, String nodeId, List<String> status, List<String> shipmentNos,String orderclassification) {
		
		List<Consignment> queryResult = new ArrayList<>();
		StringBuilder query= new StringBuilder(QueryConstants.GET_ORDER_DETAILS);
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		if (StringUtils.isNotBlank(nodeId)) {
			query.append(" AND T.SOURCE_NODE=:nodeId ");
			parameters.addValue("nodeId", nodeId); //mandatory to pass only during publish trip can be exempted
		}
		
		if (StringUtils.isNotBlank(tripId)) {
			query.append(" AND TC.TRIP_ID =:tripId ");
			parameters.addValue("tripId", tripId);
		} 
		if (null!=status && !status.isEmpty()) {
			query.append(" AND (TC.SHIPMENT_STATUS IN(:status))");
			parameters.addValue("status", status);
		}
		if (null !=shipmentNos && !shipmentNos.isEmpty()) {
			query.append(" AND TC.SHIPMENT_NO IN(:shipmentNos)");
			parameters.addValue("shipmentNos", shipmentNos);
		}
		if (StringUtils.isNotBlank(orderclassification)) {
			query.append(" AND OD.ORDER_CLASSIFICATION =:orderclassification");
			parameters.addValue("orderclassification", orderclassification);
			
		}
		
		try {
			queryResult = namedParameterJdbcTemplate.query(query.toString(), parameters, new TripConsignmentMapper());
		} catch (Exception e) {
			
			log.error("Exception in getTripOrderDetails ",e);
			throw new TripApplicationException("Exception occured on getOrderDetails of OrderDetailsDAOImpl", e);
		}
		return queryResult;
	}

	@Override
	public List<OrderDetails> getOrderDetails(List<String> orderIds, List<String> shipmentNos) {
		List<OrderDetails> queryResult = null;
		StringBuilder query= new StringBuilder(QueryConstants.ORDER_DETAILS);
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		if(!CollectionUtils.isEmpty(orderIds))
		{
			query.append(" ORDER_ID IN(:orderIds)");
			parameters.addValue("orderIds", orderIds);
		}
		else if(!CollectionUtils.isEmpty(shipmentNos))
		{
			query.append(" SHIPMENT_NO IN(:shipmentNos)");
			parameters.addValue("shipmentNos", shipmentNos);
		}
		try {
			queryResult = namedParameterJdbcTemplate.query(query.toString(), parameters, new OrderDetailsMapper());
		} catch (Exception e) {
			
			throw new TripApplicationException("Exception occured on getOrderDetails of OrderDetailsDAOImpl", e);
		}
		return queryResult;
	}

	@Override
	public void updateOrderStatus(List<String> orderIds, String status, String flowName, String modifiedBy) {
		if(!CollectionUtils.isEmpty(orderIds))
		{
			try{
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("status", status);
			parameters.addValue("orderIds", orderIds);
			parameters.addValue("modifiedBy", modifiedBy);
			parameters.addValue("flowName", flowName);
			namedParameterJdbcTemplate.update(QueryConstants.UPDATE_ORDER_STATUS, parameters);
			}
			catch (Exception e) 
			{
				throw new TripApplicationException("Exception occured during updating order status ", e);
			}
			log.info("order status updates successfully ");
		}
		
	}

	@Override
	public void updateOrderDetails(Map<String, String> setMap, Map<String, Object> whereMap) {
		if (!MapUtils.isEmpty(setMap) && !MapUtils.isEmpty(whereMap)) {
			StringBuilder query = new StringBuilder(QueryConstants.UPDATE_ORDER_DETAILS_GENERIC);
			try {

				NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
						jdbcTemplate.getDataSource());
				MapSqlParameterSource parameters = new MapSqlParameterSource();
				List<String> setList = new ArrayList<>();
				for (Map.Entry<String, String> stringStringEntry : setMap.entrySet()) {

					setList.add(stringStringEntry.getKey() + "=:" + stringStringEntry.getKey().toLowerCase());
					parameters.addValue(stringStringEntry.getKey().toLowerCase(), stringStringEntry.getValue());
				}

				query.append(String.join(" , ", setList));
				query.append(" where ");

				List<String> whereList = new ArrayList<>();
				for (Map.Entry<String, Object> stringStringEntry : whereMap.entrySet()) {

					Object value = stringStringEntry.getValue();
					if (value instanceof List) {
						whereList.add(stringStringEntry.getKey() + " IN (:" + stringStringEntry.getKey().toLowerCase() + ")");
					} else {
						whereList.add(stringStringEntry.getKey() + "=:" + stringStringEntry.getKey().toLowerCase());
					}
					parameters.addValue(stringStringEntry.getKey().toLowerCase(), stringStringEntry.getValue());

				}
				query.append(String.join(" and ", whereList));
				namedParameterJdbcTemplate.update(query.toString(), parameters);
			} catch (Exception e) {
				throw new TripApplicationException("Exception occurred during updating order details ", e);
			}
			log.info("order details updates successfully, query : {}", query);
		}
	}

	@Override
	public List<String> getAllOrders(List<String> nodeIds, String fromDate, String toDate, String orderId, List<String> orderStatus, List<String> orderType, List<String> movementType, List<String> destHubs) {
		StringBuilder queryBuilder = new StringBuilder( QueryConstants.GET_ORDER_DETAILS_COUNT);
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		parameters.addValue("fromDate", fromDate);
		parameters.addValue("toDate", toDate);

		if (!CollectionUtils.isEmpty(destHubs)) {
			queryBuilder.append(" AND tc.node_id in (:selectedHubs) ");
			parameters.addValue("selectedHubs", destHubs);
		}

		if (!CollectionUtils.isEmpty(nodeIds)) {
			queryBuilder.append(" AND trip.source_node in (:nodeIds) ");
			parameters.addValue("nodeIds", nodeIds);
		}

		if (!StringUtils.isBlank(orderId)) {
			orderId = "%" + orderId + "%";
			queryBuilder.append(" AND od.ORDER_ID LIKE :orderId ");
			parameters.addValue("orderId", orderId);
		}

		if (!CollectionUtils.isEmpty(orderStatus)) {
			queryBuilder.append(" AND  od.order_status in (:orderStatus) ");
			parameters.addValue("orderStatus", orderStatus);
		}

		if (!CollectionUtils.isEmpty(orderType)) {
			queryBuilder.append(" AND  od.order_type in (:OrderType) ");
			parameters.addValue("OrderType", orderType);
		}

		if (!CollectionUtils.isEmpty(movementType)) {
			queryBuilder.append(" AND  od.order_classification in (:movementType) ");
			parameters.addValue("movementType", movementType);
		}

		Map result = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource()).query(queryBuilder.toString(), parameters, new ResultSetExtractor<Map>() {
			@Override
			public Map extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map mapRet = new HashMap();
                List<String> orderIds = new ArrayList<>();
                while (rs.next()) {
                    orderIds.add(rs.getString("orderId"));
                }
                mapRet.put("orderIds", orderIds);
                return mapRet;
			}
		});
		return (List<String>) result.get("orderIds");
	}

	@Override
	public Map<String,OrderDetails> getCustomerInfo(List<String> orderIds) {
		try {
			String query = QueryConstants.GET_CUSTOMER_INFO_BY_ORDER_ID;
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());

			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("orderIds", orderIds);
			return namedParameterJdbcTemplate.query(query, parameters, new CustomerInfoMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred on customerInformation of OrderDetailsDAOImpl", e);
		}
	}


	public void insertCustomerDetails(List<OrderDetails> orderDetails) {
		log.info("Adding customer details");
		try {
			jdbcTemplate.batchUpdate(QueryConstants.INSERT_TO_ADDRESS_DETAILS, new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, orderDetails.get(i).getOrderId());
					ps.setString(2, orderDetails.get(i).getShipmentNo());
					ps.setString(3, orderDetails.get(i).getSourceNode());
					ps.setString(4, orderDetails.get(i).getCustomerName());
					ps.setString(5, orderDetails.get(i).getCustomerAddress());
					ps.setString(6, orderDetails.get(i).getCustomerPincode());
					ps.setString(7, orderDetails.get(i).getCustomerId());
					ps.setString(8, orderDetails.get(i).getCustomerStateCode());
					ps.setString(9, orderDetails.get(i).getCustomerGstn());
					ps.setString(10, orderDetails.get(i).getCustomerState());
					ps.setTimestamp(11, orderDetails.get(i).getCreatedTime());
					ps.setString(12, orderDetails.get(i).getCreatedBy());
					ps.setString(13, orderDetails.get(i).getFlowName());
					ps.setString(14, orderDetails.get(i).getCity());
					ps.setString(15, orderDetails.get(i).getPhoneNumber());
				}

				@Override
				public int getBatchSize() {
					return orderDetails.size();
				}
			});

		} catch (Exception e) {
			throw new DataProcessingException("Got Exception in OrderDetailsDAOImpl insertCustomerDetails",e);
		}

	}
	@Override
	public OrderListResponse getOrders(List<String> nodeIds, int pageSize, int pageIndex, String fromDate, String toDate, String orderId, List<String> orderStatus, List<String> orderType, List<String> movementType, List<String> destHubs) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append(QueryConstants.ORDER_DETAILS_PAGINATION);
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		parameters.addValue("fromDate", fromDate);
		parameters.addValue("toDate", toDate);

        List<String> orderIds;
		if ((orderIds = getAllOrders(nodeIds, fromDate, toDate, orderId, orderStatus, orderType, movementType, destHubs)).isEmpty()) {
			return OrderListResponse.builder()
					.orderList(null)
					.orderCount(orderIds.size())
					.build();
		}

        pageIndex = pageIndex <= 0 ? 1 : pageIndex;
        int startIndex = (pageIndex * pageSize) - pageSize;
        int endIndex;

        if ((endIndex = pageSize * pageIndex) > orderIds.size()) {
            endIndex = orderIds.size();
        }

        List<String> ordersForGivenPageIndex;
        if (startIndex >= orderIds.size() || (ordersForGivenPageIndex = orderIds.subList(startIndex, endIndex)).isEmpty()) {
            return OrderListResponse.builder()
                    .orderList(null)
                    .orderCount(orderIds.size())
                    .build();
        }

		if (!CollectionUtils.isEmpty(destHubs)) {
			queryBuilder.append(" AND tc.node_id in (:selectedHubs) ");
			parameters.addValue("selectedHubs", destHubs);
		}

		if (!CollectionUtils.isEmpty(nodeIds)) {
			queryBuilder.append(" AND trip.source_node in (:nodeIds) ");
			parameters.addValue("nodeIds", nodeIds);
		}

		if (!StringUtils.isBlank(orderId)) {
			orderId = "%" + orderId + "%";
			queryBuilder.append(" AND od.ORDER_ID LIKE :orderId ");
			parameters.addValue("orderId", orderId);
		}

		if (!CollectionUtils.isEmpty(orderStatus)) {
			queryBuilder.append(" AND od.order_status in (:orderStatus) ");
			parameters.addValue("orderStatus", orderStatus);
		}

		if (!CollectionUtils.isEmpty(orderType)) {
			queryBuilder.append(" AND  od.order_type in (:OrderType) ");
			parameters.addValue("OrderType", orderType);
		}

		if (!CollectionUtils.isEmpty(movementType)) {
			queryBuilder.append(" AND  od.order_classification in (:movementType) ");
			parameters.addValue("movementType", movementType);
		}

		queryBuilder.append(" AND  od.order_id in (:ordersForGivenPageIndex) ");
		parameters.addValue("ordersForGivenPageIndex", ordersForGivenPageIndex);

		queryBuilder.append("ORDER BY od.CREATED_TIME DESC ");

		try {

			List<OrderDetails> orderList = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource())
					.query(queryBuilder.toString(), parameters, new OrderDetailsListMapper());

			return OrderListResponse.builder()
					.orderList(createResponse(orderList))
					.orderCount(orderIds.size())
					.build();
		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred on getOrderDetails of OrderDetailsDAOImpl", e);
		}
	}

    @Override
    public OrderListResponseFluidLoading tripOrderViewFluidLoading(List<String> nodeIds, Integer pageSize, Integer pageIndex, String fromDate, String toDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs) {

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append(QueryConstants.ORDER_DETAILS_FOR_FLUID_LOADING);

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("nodeIds", nodeIds);

        if (!StringUtils.isBlank(fromDate) && !StringUtils.isBlank(toDate)) {
            parameters.addValue("fromDate", fromDate);
            parameters.addValue("toDate", toDate);
            queryBuilder.append(" AND od.created_time BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
                    + "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ");
        }

        if (!CollectionUtils.isEmpty(destHubs)) {
            queryBuilder.append(" AND oi.node_id in (:selectedHubs) ");
            parameters.addValue("selectedHubs", destHubs);
        }

        if (!StringUtils.isBlank(orderId)) {
            orderId = "%" + orderId + "%";
            queryBuilder.append(" AND od.ORDER_ID LIKE :orderId ");
            parameters.addValue("orderId", orderId);
        }

        if (!CollectionUtils.isEmpty(orderStatus)) {
            queryBuilder.append(" AND od.order_status in (:orderStatus) ");
            parameters.addValue("orderStatus", orderStatus);
        }

        if (!StringUtils.isEmpty(pinCode)) {
            String pincode = "%" + pinCode + "%";
            queryBuilder.append(" AND  cd.pincode like :pincode ");
            parameters.addValue("pincode", pincode);
        }

        if (!StringUtils.isEmpty(mId)) {
            String mid = "%" + mId + "%";
            queryBuilder.append(" AND  cd.id  LIKE :mId ");
            parameters.addValue("mId", mid);
        }

        queryBuilder.append(" ORDER BY od.CREATED_TIME DESC ");
        List<OrderViewResponseForFluidLoading> orderList = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource())
                .query(queryBuilder.toString(), parameters, new OrderViewResponseForFluidLoadingMapper());

        return OrderListResponseFluidLoading.builder()
                .orderList(orderList)
                .orderCount(0)
                .build();
    }

    @Override
    public OrderListResponseFluidLoading consignmentViewFluidLoading(List<String> nodeIds, Integer pageSize, Integer pageIndex, String fromDate, String toDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs) {
        StringBuilder queryBuilder = new StringBuilder();

        queryBuilder.append("SELECT * FROM (SELECT  V.*, ROW_NUMBER() OVER(ORDER BY ORDER_ID) AS SEQNUM  FROM (");
        queryBuilder.append(QueryConstants.ORDER_DETAILS_FOR_FLUID_LOADING);

        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("nodeIds", nodeIds);

        if (!StringUtils.isBlank(fromDate) && !StringUtils.isBlank(toDate)) {
            parameters.addValue("fromDate", fromDate);
            parameters.addValue("toDate", toDate);
            queryBuilder.append(" AND od.created_time BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
                    + "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ");
        }

        if (!CollectionUtils.isEmpty(destHubs)) {
            queryBuilder.append(" AND oi.node_id in (:selectedHubs) ");
            parameters.addValue("selectedHubs", destHubs);
        }

        if (!StringUtils.isBlank(orderId)) {
            orderId = "%" + orderId + "%";
            queryBuilder.append(" AND od.ORDER_ID LIKE :orderId ");
            parameters.addValue("orderId", orderId);
        }

        if (!CollectionUtils.isEmpty(orderStatus)) {
            queryBuilder.append(" AND od.order_status in (:orderStatus) ");
            parameters.addValue("orderStatus", orderStatus);
        }

        if (!StringUtils.isEmpty(pinCode)) {
            String pincode = "%" + pinCode + "%";
            queryBuilder.append(" AND  cd.pincode like :pincode ");
            parameters.addValue("pincode", pincode);
        }

        if (!StringUtils.isEmpty(mId)) {
            String mid = "%" + mId + "%";
            queryBuilder.append(" AND  cd.id  LIKE :mId ");
            parameters.addValue("mId", mid);
        }

        queryBuilder.append(" AND od.order_status in ('CREATED','INVOICED','STAGED') ORDER BY od.CREATED_TIME DESC ");
        int endIndex = pageSize * pageIndex;
        int startIndex = (endIndex - pageSize) + 1;
        parameters.addValue("startIndex", startIndex);
        parameters.addValue("endIndex", endIndex);
        queryBuilder.append(") V )  WHERE SEQNUM>= :startIndex AND SEQNUM<= :endIndex");

        List<OrderViewResponseForFluidLoading> orderList = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource())
                .query(queryBuilder.toString(), parameters, new OrderViewResponseForFluidLoadingMapper());
        int orderCount = getOrderCount(nodeIds, fromDate, toDate, orderId, destHubs, orderStatus, pinCode, mId);

        return OrderListResponseFluidLoading.builder()
                .orderList(orderList)
                .orderCount(orderCount)
                .build();
    }

	private int getOrderCount(List<String> nodeIds, String fromDate, String toDate, String orderId, List<String> destHubs, List<String> orderStatus, String pinCode, String mId) {
		StringBuilder queryBuilder = new StringBuilder(QueryConstants.ORDER_COUNT_FOR_FLUID_LOADING);
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeIds", nodeIds);

		if (!StringUtils.isBlank(fromDate) && !StringUtils.isBlank(toDate)) {
			parameters.addValue("fromDate", fromDate);
			parameters.addValue("toDate", toDate);
			queryBuilder.append(" AND od.created_time BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
					+ "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ");
		}

		if (!CollectionUtils.isEmpty(destHubs)) {
			queryBuilder.append(" AND oi.node_id in (:selectedHubs) ");
			parameters.addValue("selectedHubs", destHubs);
		}

		if (!StringUtils.isBlank(orderId)) {
			orderId = "%" + orderId + "%";
			queryBuilder.append(" AND od.ORDER_ID LIKE :orderId ");
			parameters.addValue("orderId", orderId);
		}

		if (!CollectionUtils.isEmpty(orderStatus)) {
			queryBuilder.append(" AND od.order_status in (:orderStatus) ");
			parameters.addValue("orderStatus", orderStatus);
		}

		if (!StringUtils.isEmpty(pinCode)) {
			String pincode = "%" + pinCode + "%";
			queryBuilder.append(" AND  cd.pincode like :pincode ");
			parameters.addValue("pincode", pincode);
		}

		if (!StringUtils.isEmpty(mId)) {
			String mid = "%" + mId + "%";
			queryBuilder.append(" AND  cd.id  LIKE :mId ");
			parameters.addValue("mId", mid);
		}

		Map result = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource()).query(queryBuilder.toString(), parameters, new ResultSetExtractor<Map>() {
			@Override
			public Map extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map mapRet = new HashMap();
				while (rs.next()) {
					mapRet.put("total", rs.getInt("total"));
				}
				return mapRet;
			}
		});
		return (int) result.get("total");
	}

	private List<OrderViewResponse> createResponse(List<OrderDetails> orderList) {
		List<OrderViewResponse> orderViewResponses = new ArrayList<>();
		for (OrderDetails orderDetails : orderList) {
			OrderViewResponse orderViewResponse = new OrderViewResponse();
			orderViewResponse.setOrderId(orderDetails.getOrderId());
			orderViewResponse.setShipmentNo(orderDetails.getShipmentNo());
			orderViewResponse.setOrderPlacedDate(orderDetails.getOrderDate());
			orderViewResponse.setOrderType(orderDetails.getOrderType());
			orderViewResponse.setMovementType(orderDetails.getOrderClassification());
			orderViewResponse.setCustomerPincode(orderDetails.getCustomerPincode());
			orderViewResponse.setCustomerAddress(orderDetails.getCustomerAddress());
			orderViewResponse.setOrderStatus(orderDetails.getOrderStatus());
			orderViewResponse.setLastUpdatedTime(orderDetails.getModifiedTime());
			orderViewResponse.setDeliveryPromisedDate(orderDetails.getSlotStartTime());
			orderViewResponse.setMid(orderDetails.getMid());
			orderViewResponse.setDestination(orderDetails.getTripType().equalsIgnoreCase(Constants.FC_TRIP_TYPE) ? orderDetails.getNextNode() : "NA");
			orderViewResponse.setIsRePlanned(orderDetails.getShipmentStatus().equalsIgnoreCase(OrderStatus.ACTIVE.getValue()) ? "N" : "Y");
			orderViewResponse.setCustomerName(orderDetails.getCustomerName());
			orderViewResponse.setDeliveryZoneId(orderDetails.getDeliveryZoneId());
			orderViewResponses.add(orderViewResponse);
		}
		return orderViewResponses;
	}

	@Override
	public List<OrderDetails> getOrderDetails(String tripId) {
		if (!StringUtils.isBlank(tripId)) {
			try {
				String query = QueryConstants.GET_ORDER_IDS_FOR_GIVEN_TRIP;
				NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
						jdbcTemplate.getDataSource());

				MapSqlParameterSource parameters = new MapSqlParameterSource();
				parameters.addValue("tripId", tripId);
				return namedParameterJdbcTemplate.query(query, parameters, new OrderDetailsMapper());
			} catch (Exception e) {
				throw new TripApplicationException("Exception occurred on getOrderDetailsJoinTrip of OrderDetailsDAOImpl", e);
			}
		}
		log.error("Invalid argument for tripId: {}", tripId);
		return new ArrayList<>();
	}

	@Override
	public List<OrderCountResponse> orderCountForSDP(List<String> nodeIds, List<String> sdpIds, String fromDate, String toDate) {

		if ((null != fromDate) && (null != toDate)) {
			fromDate = DateUtility.getToDate(fromDate);
			toDate = DateUtility.getFromDate(toDate);
		}

        StringBuilder query = new StringBuilder(QueryConstants.ORDER_COUNT_FOR_SDP);
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("sdpIds", sdpIds);

		if (!StringUtils.isBlank(fromDate) && !StringUtils.isBlank(toDate)) {
			parameters.addValue("fromDate", fromDate);
			parameters.addValue("toDate", toDate);
			query.append(" AND od.created_time BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
					+ "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ");
		}

		if (!CollectionUtils.isEmpty(sdpIds)) {
			query.append(" AND oi.node_id in (:selectedHubs) ");
			parameters.addValue("selectedHubs", sdpIds);
		}
		query.append("group by oi.node_id");

		List<OrderCountResponse> orderCountResponses;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			orderCountResponses = namedParameterJdbcTemplate.query(query.toString(), parameters, new OrderCountResponseMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred while executing orderCountForSDP ", e);
		}
		log.info("ORDER_COUNT_FOR_SDP query has been executed successfully, fetched Rows: {} ", orderCountResponses.size());
		return orderCountResponses;
	}

    @Override
	public int updateOrderDetails(Timestamp slotStartTime, Timestamp slotEndTime, String orderId, String shipmentNo) {	
		
		
		int result=0;
		try {
			result=jdbcTemplate.update(QueryConstants.UPDATE_TO_ORDER_DETAILS, slotStartTime, slotEndTime, orderId, shipmentNo);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating order details slotTimings ", e);
		}
		return result;
	}

	@Override
	public List<Consignment> getUnplannedCustomerReturnOrder(String nodeId) {
		List<Consignment> queryResult = new ArrayList<>();
		StringBuilder query= new StringBuilder(QueryConstants.GET_UNPLANNED_RETURN_ORDER);
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeId", nodeId);		
		try {
			queryResult = namedParameterJdbcTemplate.query(query.toString(), parameters, new ConsignmentMapper());
			queryResult.forEach(i->i.setShipmentStatus("UnplannedReturn"));
		} catch (Exception e) {			
			log.error("Exception in getUnplannedCustomerReturnOrder ",e);
			throw new TripApplicationException("Exception occured on getUnplannedCustomerReturnOrder of OrderDetailsDAOImpl", e);
		}
		return queryResult;
	}

	@Override
	public List<Consignment> getUnplannedRescheduledOrders(String nodeId) {
		List<Consignment> queryResult = new ArrayList<>();
		StringBuilder query= new StringBuilder(QueryConstants.GET_RESCHEDULED_ORDER);
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeId", nodeId);		
		try {
			queryResult = namedParameterJdbcTemplate.query(query.toString(), parameters, new ConsignmentMapper());
			queryResult.forEach(i->i.setShipmentStatus("Rescheduled"));
		} catch (Exception e) {			
			log.error("Exception in getUnplannedRescheduledOrders ",e);
			throw new TripApplicationException("Exception occured on getUnplannedRescheduledOrders of OrderDetailsDAOImpl", e);
		}
		return queryResult;
	}

	@Override
	public String getOrderIdForShipment(String shipmentNo) {

		if (StringUtils.isBlank(shipmentNo)) {
			return "";
		}
		try {
			return jdbcTemplate.queryForObject(QueryConstants.GET_ORDER_ID_FOR_SHIPMENT,
					new Object[]{shipmentNo}, String.class);

		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred while getting order for Shipment" + shipmentNo, e);
		}
	}

}
