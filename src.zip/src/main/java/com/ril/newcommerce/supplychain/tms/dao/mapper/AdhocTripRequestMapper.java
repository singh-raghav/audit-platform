package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.entity.AdhocTripRequest;

public class AdhocTripRequestMapper implements ResultSetExtractor<List<AdhocTripRequest>>  {

	@Override
	public List<AdhocTripRequest> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<AdhocTripRequest> requests = new ArrayList<AdhocTripRequest>();
		while (rs.next()) {
			AdhocTripRequest request=new AdhocTripRequest();
			request.setNodeId(rs.getString("NODE_ID"));
			request.setOrderId(rs.getString("ORDER_ID"));
			request.setTripId(rs.getString("TRIP_ID"));
			request.setStatus(rs.getString("STATUS"));
			requests.add(request);
		}
		return requests;
	}

}
