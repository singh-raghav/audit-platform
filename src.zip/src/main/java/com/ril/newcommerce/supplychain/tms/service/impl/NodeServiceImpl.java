package com.ril.newcommerce.supplychain.tms.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.rest.FetchNodeResponse;
import com.ril.newcommerce.supplychain.tms.entity.rest.Node;
import com.ril.newcommerce.supplychain.tms.exception.NetworkCommunicationException;
import com.ril.newcommerce.supplychain.tms.service.NodeService;
import com.ril.newcommerce.supplychain.tms.util.RestClient;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
B1.Divya
*/

@Service
public class NodeServiceImpl implements NodeService{

	@Autowired
	private RestClient restClient;
	
	@Value("${node.service.get.nodes.url}")
	private String nodeUrl;
	
	@Value("${node.service.clientId}")
	private String clientId;
	
	@Value("${node.service.apiKey}")
	private String apiKey;
	
	@Override
	public Node getNodeDetailsByNodeId(String nodeId) {
		
		if(StringUtils.isNotBlank(nodeId)) {
			List<String> nodeIds = new ArrayList<String>();
			nodeIds.add(nodeId);
			
			List<Node> nodes = getNodes(nodeIds);
			if(nodes!=null)
				return nodes.get(0);
		 
		}
		 
		 return null;
	}

	@Override
	public List<Node> getNodes(List<String> nodeIds) {

		if (!CollectionUtils.isEmpty(nodeIds)) {

			// Make a call to NodeService..
			String finalUrl = nodeUrl+String.join(Constants.COMMA, nodeIds);
			try {
				FetchNodeResponse nodes = (FetchNodeResponse) restClient.get(finalUrl, Utility.getNodeServiceHeaders(clientId, apiKey) , null ,FetchNodeResponse.class,null);

				// TODO think abt fallback.. Hystrix...
				if (nodes != null)
					return nodes.getNodeDetails();

			} catch (NetworkCommunicationException e) {
				throw e;
			}
		}

		return null;
	}

	@Override
	public Map<String, Node> getNodesByID(List<String> nodeIds) {
		List<Node> nodes = getNodes(nodeIds);
		Map<String,Node> map = new HashMap<>();
		
		if(!CollectionUtils.isEmpty(nodes)) {
			
			for(Node node : nodes) {
				map.put(node.getNodeId(), node);
			}
		}
		
		return map;
	}

}
