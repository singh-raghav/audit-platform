package com.ril.newcommerce.supplychain.tms.dao.impl;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.TripConsignmentsDAO;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class TripConsignmentsDAOImpl implements TripConsignmentsDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public Integer getSuspendedConsignmentsCount(String shipmentNo, String orderId) {

        if (StringUtils.isBlank(shipmentNo) && StringUtils.isBlank(orderId)) {
            return 0;
        }
        String where;
        String param = "";
        if (!StringUtils.isBlank(shipmentNo)) {
            param = shipmentNo;
            where = "  and shipment_no in ( :shipmentNo ) ";
        } else {
            param = orderId;
            where = "  and shipment_no in ( select distinct(shipment_no) from order_details where order_id =:param ) ";
        }
        try {
            Integer count = jdbcTemplate.queryForObject(QueryConstants.SUSPENDED_ORDER_COUNT + where,
                    new Object[]{param}, Integer.class);
            return null == count ? 0 : count;

        } catch (Exception e) {
            throw new TripApplicationException("Exception occurred while getting Suspended orders for Shipment" + shipmentNo, e);
        }
    }
}
