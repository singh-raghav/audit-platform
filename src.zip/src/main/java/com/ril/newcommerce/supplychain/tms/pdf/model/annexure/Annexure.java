package com.ril.newcommerce.supplychain.tms.pdf.model.annexure;

import java.util.List;

public class Annexure {
    private String tripNumber;
    private String fcName;
    private String vehicleNumber;
    private String totalInvoiceLoaded;
    private String tripDate;
    private String hubName;
    private String driverName;
    private String totalHULoaded;
    private List<InvoiceDetails> invoiceDetails;

    public String getTripNumber() {
        return tripNumber;
    }

    public void setTripNumber(String tripNumber) {
        this.tripNumber = tripNumber;
    }

    public String getFcName() {
        return fcName;
    }

    public void setFcName(String fcName) {
        this.fcName = fcName;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getTotalInvoiceLoaded() {
        return totalInvoiceLoaded;
    }

    public void setTotalInvoiceLoaded(String totalInvoiceLoaded) {
        this.totalInvoiceLoaded = totalInvoiceLoaded;
    }

    public String getTripDate() {
        return tripDate;
    }

    public void setTripDate(String tripDate) {
        this.tripDate = tripDate;
    }

    public String getHubName() {
        return hubName;
    }

    public void setHubName(String hubName) {
        this.hubName = hubName;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getTotalHULoaded() {
        return totalHULoaded;
    }

    public void setTotalHULoaded(String totalHULoaded) {
        this.totalHULoaded = totalHULoaded;
    }

    public List<InvoiceDetails> getInvoiceDetails() {
        return invoiceDetails;
    }

    public void setInvoiceDetails(List<InvoiceDetails> invoiceDetails) {
        this.invoiceDetails = invoiceDetails;
    }
}
