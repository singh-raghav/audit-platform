package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"ReturnOrder"
})*/
public class ReturnOrders {

	@JsonProperty("ReturnOrder")
	private List<ReturnOrder> returnOrder = null;

	@JsonProperty("ReturnOrder")
	public List<ReturnOrder> getReturnOrder() {
		return returnOrder;
	}

	@JsonProperty("ReturnOrder")
	public void setReturnOrder(List<ReturnOrder> returnOrder) {
		this.returnOrder = returnOrder;
	}

}
