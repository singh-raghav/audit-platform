package com.ril.newcommerce.supplychain.tms.exception;

/**
 * 
 * @author jeevi.natarajan
 *
 */
public class StateMachineProcessingException extends RuntimeException{

	private static final long serialVersionUID = -7947853318272388858L;

	public StateMachineProcessingException(String message) {
		super(message);
	}
	
	
	public StateMachineProcessingException(String message,Throwable th) {
		super(message,th);
	}
	
	public StateMachineProcessingException(Throwable th) {
		super(th);
	}
}
