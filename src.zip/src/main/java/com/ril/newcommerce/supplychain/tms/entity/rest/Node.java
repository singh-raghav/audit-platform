package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

public class Node {

	private String nodeId;
	private String nodeType;
	private String name;
	private String clusterId;
	private boolean active;
	private String description;
	private Address address;
	private String regionCode;
	private String longitude;
	private String latitude;
	private List<String> servesPinCodes;
	private List<Node> childNodes;
	private String coHostId;
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getNodeType() {
		return nodeType;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClusterId() {
		return clusterId;
	}
	public void setClusterId(String clusterId) {
		this.clusterId = clusterId;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getRegionCode() {
		return regionCode;
	}
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public List<String> getServesPinCodes() {
		return servesPinCodes;
	}
	public void setServesPinCodes(List<String> servesPinCodes) {
		this.servesPinCodes = servesPinCodes;
	}
	public List<Node> getChildNodes() {
		return childNodes;
	}
	public void setChildNodes(List<Node> childNodes) {
		this.childNodes = childNodes;
	}
	public String getCoHostId() {
		return coHostId;
	}
	public void setCoHostId(String coHostId) {
		this.coHostId = coHostId;
	}
	
	
}

