package com.ril.newcommerce.supplychain.tms.constants;

/**
B1.Divya
*/

public class Constants {

	private Constants() {}


	public static final String INVOICE_NOT_AVAILABLE =  "Invoice not available";
	public static final String SHIPMENT_STATUS_INACTIVE = "Inactive";
	public static final String ORDER_DETAILS_DATE_FORMAT="yyyy-MM-dd hh:mm:ss";
	public static final String EXTERNAL_SYSTEMS_DATE_FORMAT="yyyy-MM-dd'T'HH:mm:ss";
	public static final String PUBLISH_DATE_FORMAT="yyyy-MM-dd'T'HH:mm:ssXX";
	public static final Integer EXPLICIT_CLIENT_ACKNOWLEDGE= 23;
	public static final String DATE_FORMAT="dd-MM-yy";
	public static final String SHORT_CASH_REASON="SHORT_CASH_REASON";
	public static final String DATE_FORMAT_dd_MM_yyyy = "dd/MM/yyyy";
	public static final String DATE_FORMAT_DD_MM_YYYY = "dd-MM-yyyy";
	public static final int FETCH_SIZE=200;
	public static final int ONE=1;
	public static final String TOTE="Tote";
	public static final String BAG="Bag";
	public static final String HU="Hu";
	public static final String MISSING="Missing";
	public static final String DAMAGED="Damaged";
	public static final String TOTE_PRESENT="Tote_Present";
	public static final String TOTE_MISSED="Tote_Missed";
	public static final String BAG_PRESENT="Bag_Present";
	public static final String BAG_MISSED="Bag_Missed";
	public static final String HU_PRESENT="Hu_Present";
	public static final String HU_MISSED="Hu_Missed";
	public static final String SEAL="SEAL";
	public static final String EWAYBILL="EWAYBILL";
	public static final String FLOWNAME="FlowName";
	public static final String RETRY_COUNT = "RetryCount";
	public static final String TRIPID="tripId";
	public static final String STATUS="status";
	public static final String INTERVAL="interval";
	public static final String UNIT="unit";
	public static final String FETCH_SIZE_JOB="fetchSize";
	public static final String REFERENCEID="referenceId";
	public static final String INBOUND="inBound";
	public static final String INCLUDE="include";
	public static final String FC_TRIP_TYPE = "FC-HUB";
	public static final String SPLIT="SPLIT";
	public static final String MERGE="MERGE";
	public static final String SHUTTLE="SHUTTLE";
	public static final String MANUAL_TRIP="MANUAL_TRIP";
	public static final String RETURN_TO_SAP="RETURN_TO_SAP";
	public static final String ORDER_STATUS_UPDATE ="OrderStatusUpdate" ;

	public static final String JMSTEMPLATE="jmsTemplate";
	public static final String JMSTEMPLATE_PUBLISH="jmsTemplatePublish";
	public static final String JMSTEMPLATE_WITH_DELAY="jmsTemplateWithDelay";

	//Qualifiers
	public static final String START_ACTION="startAction";
	public static final String END_ACTION="endAction";
	public static final String SHUTTLE_TRIP="Shuttle Trip";
	public static final String ASSIGN_ACTION="assignAction";
	public static final String UNASSIGN_ACTION="UnassignAction";
	public static final String LOADING_START_ACTION="loadinStartAction";
	public static final String LOADING_COMPLETE_ACTION="loadingCompleteAction";
	public static final String FLUID_LOADING_COMPLETE_TRIP_ACTION ="fluidLoadingCompleteTripAction";
	public static final String TRIP_SETTLE_ACTION = "tripSettleAction";
	public static final String CANCEL_TRIP_ACTION = "cancelTripAction";
	public static final String TRIP_EVENT_PROCESSOR="tripEventProcessor";
	public static final String DO_NOTHING_PROCESSOR="doNothingProcessor";
	public static final String TRIP_STATE_MACHINE_PROCESSOR ="tripStateMachineProcessor";
	public static final String ORDER_STATE_MACHINE_PROCESSOR ="orderStateMachineProcessor";
	public static final String UPDATE_ONLY_PROCESSOR="updateOnlyProcessor";
	public static final String REASSIGN_PROCESSOR="reAssignProcessor";
	public static final String SPLIT_PROCESSOR="splitProcessor";
	public static final String MERGE_PROCESSOR="mergeProcessor";
	public static final String MANUAL_TRIP_PROCESSOR="manualTripProcessor";
	public static final String FLUID_MANUAL_TRIP_PROCESSOR="fluidManualTripProcessor";
	public static final String UNLOADING_COMPLETE_PROCESSOR="unloadingCompleteProcessor";
	public static final String POST_LOADING_COMPLETE="postLoadingComplete";
	public static final String POST_FLUID_LOADING_COMPLETE="postFluidLoadingComplete";
	public static final String PUBLISH_TO_GRAB="publishToGrab";
	public static final String WAYPOINT_UPDATES="wayPointUpdatesProcessor";
	public static final String CANCEL_ORDER_PROCESSOR ="cancelOrderProcessor";
	public static final String CANCEL_RETURN_ORDER_PROCESSOR ="cancelReturnOrderProcessor";
	public static final String DELAYED_SHIPMENT_PROCESSOR ="delayedShipmentProcessor";
	public static final String ORDER_STATUS_UPDATE_PROCESSOR ="orderStatusUpdateProcessor" ;
	public static final String CHECK_IN_PROCESSOR="checkInProcessor";
	public static final String CHECK_OUT_PROCESSOR="checkOutProcessor";
	public static final String REPORT_RECONCILE_PROCESSOR="reportReconcileProcessor";
	public static final String DO_NOTHING_POSTPROCESSOR="doNothingPostProcessor";
	public static final String ASSIGN_TRIP_POST_PROCESSOR="assignTripPostProcessor";
	public static final String UNASSIGN_TRIP_POST_PROCESSOR="unAssignTripPostProcessor";
	public static final String DO_NOTHING_PREPROCESSOR="doNothingPreProcessor";
	public static final String VALIDATION_PRE_PROCESSOR="validationPreProcessor";
	public static final String POST_SPILT_PROCESSOR="postSplitProcessor";
	public static final String POST_MERGE_PROCESSOR="postMergeProcessor";
	public static final String SHUTTLE_TRIP_PROCESSOR="shuttleTripProcessor";
	public static final String PACK_FEED_PROCESSOR="packFeedProcessor";
	public static final String FLUID_LOADING_PROCESSOR="fluidLoadingProcessor";
	public static final String RETURN_INVOICE_DETAILS = "returnInvoiceDetails";
	public static final String START_KM_VALIDATOR="stKmValidator";
	public static final String END_KM_VALIDATOR="endKmValidator";
	public static final String WAYPOINT_VALIDATOR="wayPointValidator";
	public static final String VEHICLE_VALIDATOR="vehicleValidator";
	public static final String DRIVER_VALIDATOR="driverValidator";
	public static final String EWAYBILL_VALIDATOR="ewayBillValidator";
	public static final String MODIFY_TRIP_VALIDATOR="modifyTripValidator";
	public static final String INITIAL_AMT_VALIDATOR="intialAmtValidator";
	public static final String SEAL_VALIDATOR="sealValidator";
	public static final String LABEL_VALIDATOR="labelValidator";
	public static final String FC_UNLOADING_VALIDATOR="fcUnloadValidator";
	public static final String RECONCILE_ARTICLES_VALIDATOR="reconcileArticlesValidator";
	public static final String LABEL_STAGING_PROCESSOR = "labelStagingProcessor";

	public static final String ORDER_INVOICE_DETAILS_PROCESSOR="orderInvoiceDetailsProcessor";
	public static final String RETURN_ITEM_TO_SAP="returnItemsToSap";
	public static final String TRIP_SETTLE_UPDATE_PROCESSOR="tripSettleUpdateProcessor";

	public static final String ORDER_DETAILS_UPDATE="orderDetailsUpdate";
	public static final String RETURN_SHUTTLE_TRIP_PROCESSOR_RETURN="returnShuttleTripProcessor";

	//actions
	public static final String EVENT="event";
	public static final String TRIP="trip";
	public static final String EXCEPTION="exception";
	public static final String RESERVE="RESERVE";
	public static final String UNASSIGN="UNASSIGN";
	public static final String ASSIGN="ASSIGN";
	public static final String USER_ID="userId";
	public static final String NODE_ID="nodeId";
	public static final String NODE_TYPE="nodeType";
	public static final String ORDER_IDS="orderIds";
	public static final String ORDER_ID="orderId";
	public static final String SHIPMENT_NO="shipmentNo";
	public static final String ORDER_STATE="orderState";
	public static final String INTITIAL_AMOUNT="INITIAL_AMOUNT";
	public static final String VENDOR_ID="VENDOR_ID";
	public static final String VENDOR_NAME="VENDOR_NAME";

	public static final String TOLL = "TOLL";
	public static final String HANDLING = "HANDLING";
	public static final String OTHER = "OTHER";
	public static final String CASH_TO_BE_COLLECTED = "CASH_TO_BE_COLLECTED";
	public static final String CASH_COLLECTED = "CASH_COLLECTED";

	public static final String ACTION="Modify";
	public static final String ENTERPRISE_CODE="RIL";
	public static final String FLOW_NAME="FlowName";
	public static final String SOURCE_SYSTEM="SourceSystem";
	public static final String BUSINESS_KEY_ONE="BusinessKey1";
	public static final String BUSINESS_VALUE_ONE="BusinessValue1";
	public static final String TRIP_NUMBER="TripNumber";
	public static final String TRIP_TYPE="TripType";
	public static final String FLUID_OR_NON_FLUID="FluidOrNonFluid";
	public static final String FLUID="Fluid";
	public static final String NON_FLUID="NonFluid";
	public static final String VEHICLE_NUMBER="vehicleNumber";
	public static final String VEHICLE="Vehicle";
	public static final String TRIP_APP="TripApp";
	public static final String INDICATOR_Y = "Y";
	public static final String VECHICLE_NO="assigned_vehicle";
	public static final String INTEGER_UTIL="IntegerUtil";
	public static final String STRING_UTIL="StringUtil";

	public static final String END_FC_TRIP="END_FC_TRIP";
	public static final String END_HUB_TRIP="END_HUB_TRIP";
	public static final String ASSIGN_FC_TRIP="ASSIGN_FC_TRIP";
	public static final String ASSIGN_HUB_TRIP="ASSIGN_HUB_TRIP";
	public static final String REASSIGN_FC_TRIP="REASSIGN_FC_TRIP";
	public static final String REASSIGN_HUB_TRIP="REASSIGN_HUB_TRIP";
	public static final String FORMAT_FOR_CREATE_TRIP_ID="ddMMyyyy";
	public static final String TRIP_ID_PREFIX="T";
	public static final String TRIP_ID_PREFIX_SHUTTLE="S";

	public static final String YES="Y";
	public static final String NO="N";
	public static final String TRUE="true";
	public static final String FALSE="false";

	public static final String BAG_REGULAR = "Bag - Regular";
	public static final String TOTE_REGULAR = "Tote - Regular";

	public static final String COMMA=",";

	public static final long MAX_CHALLAN_ID= 9999999999l;


	public static final String CLIENTID="clientId";
	public static final String SERVICENAME="serviceName";
	public static final String APIKEY="apiKey";

	public static final String AUTHORIZATION="Authorization";
	public static final String PUBLICKEY ="X-Public";
	public static final String HASHKEY ="X-Hash";
	public static final String BASIC="Basic";

	public static final String ORDER_DELIVERED = "1400.9";
	public static final String DSR_RETURNED = "1400.1";
	public static final String FC_DELAYED = "1100.70.06.10.1";
	public static final String RESCHEDULED = "1400.04";
	public static final String SHIPMENT_SHIPPED = "1400";
	public static final String UNDELIVERED = "Undelivered";

	public static final String FC ="FC";
	public static final String HUB ="HUB";
	public static final String SDP = "SDP";
	public static final String DASH="-";
	public static final String CUSTOMER="CUSTOMER";
	public static final String PRIMARY_TRANSPORTATION_TYPE = "PRI";
	public static final String SECONDARY_TRANSPORTATION_TYPE="SEC";
	public static final String PRIMARY_DELIVERY_TYPE="PGRO";
	public static final String SECONDARY_DELIVERY_TYPE="SGRO";
	public static final String DEDICATED_MOD="D1";
	public static final String MARKET_MOD="M1";
	public static final String DEDICATED = "DEDICATED";
	public static final String MARKET = "MARKET";
	public static final String NOT_APPLICABLE="N/A";

	public static final String TRIP_STATE_MACHINE_CONFIGURATION = "tripSMConfiguration";
	public static final String ORDER_STATE_MACHINE_CONFIGURATION = "orderSMConfiguration";
	public static final String SHUTTLE_TRIP_STATE_MACHINE_CONFIGURATION = "shuttleTripConfiguration";

	//EwayBill
	public static final String TRANSPORTERID="24AAACF5232A1ZF";
	public static final String TRANSPORTERNAME="QWIK Supply Chain P.Ltd";
	public static final String TRANSMODE="1";

	public static final String QUESTION_MARK="?";
	public static final String AMPHASENT="&";
	public static final String EQUALS="=";
	public static final String INCLUDERECON="includeRecon";

	public static final String ENTRYTYPE_B2B_KIRANA = "B2B-Kirana";
	public static final String ERROR="ERROR";
	public static final String SUCCESS="SUCCESS";
	public static final String DELIVERY_CHALLAN_PREFIX="DELIVERY_CHALLAN_";
	public static final String DELIVERY_CHALLAN="DELIVERY_CHALLAN";
	public static final String SLASH="/";

	public static final String SALT = "TripApp";
	public static final String NA = "NA";
	public static final String EMPTY_STRING = " ";
	public static final String PENDING="Pending";
	public static final String COMPLETE="Complete";
	public static final String NEW_LINE = " \n ";


	public static final String UNREGISTERED_PERSON="URP";
	public static final String SRC_NODE_ID="srcNodeId";

	public static final String TRIP_BAD_MESSAGE="Trip Bad Message";
	public static final String BUSINESS_KEY_TWO="BusinessKey2";
	public static final String BUSINESS_VALUE_TWO="BusinessValue2";
	public static final String BUSINESS_KEY_THREE="BusinessKey3";
	public static final String BUSINESS_VALUE_THREE="BusinessValue3";

	public static final String APPLICATION_JSON_TYPE="application/json";

	public static class PDF{
		public static final String PDF_FOLDER="out";
		public static final String MANIFEST_PDF_PREFIX ="Manifest_" ;
		public static final String ANNEXURE_PDF_PREFIX="Annexure_" ;
		public static final String DAY_LEVEL_ACK="Ack_" ;
		public static final String CONSIGNMENT_ORDER_DOWNLOAD = "consignment_order_";
		public static final String PDF_EXT=".pdf";
		public static final String OCTET_STREAM="application/octet-stream";
		public static final String MSG_OBJECT_CREATION_FAILED="Exception while creating Object";

	}
	public static class ORDER_PROCESSOR{

		public static final String SHIPPED_PRE_PROCESSOR = "shippedPreProcessor";
		public static final String INVOICED_PRE_PROCESSOR = "invoicedPreProcessor";
		public static final String DELIVERED_PRE_PROCESSOR = "deliveredPreProcessor";
		public static final String CANCELLED_PRE_PROCESSOR = "FCDelayedAndCancelldPreProcessor";
		public static final String DO_NOTHING_PRE_PROCESSOR = "defaultPreProcessor";
		public static final String DEFAULT_POST_PROCESSOR = "defaultPostProcessor";
	}
	public static class WAYPOINT_DB_STATUS{
		public static final String FULL_DSR = "Full Dsr";
		public static final String DELIVERED = "Delivered";
		public static final String RESCHEDULED = "Rescheduled";
		public static final String PICKED = "PickedUp";
		public static final String PARTIALLY_DELIVERED = "Partially Delivered";
	}

	// Grab Constants
	public static final String AMOUNTCOLLECTED="AmountCollected";
	public static final String ORDER_RETURN = "Return";
	public static final String RETURN_INVOICE = "Return_Invoice";
	public static final String FWD_ORDER_ID = "FWD_ORDER_ID";

	//Notification
	public static final String OUT_OF_ORDER_MESSAGE="TRIP_APP --- OUT_OF_ORDER_MESSAGE";
	public static final String ATS_KAFKA_UNREACHABLE="TRIP_APP--- KAKFA_REST_PROXY_UNREACHABLE";

	public static final String SETTLE_FC_TRIP = "SETTLE_FC_TRIP";
	public static final String SETTLE_HUB_TRIP = "SETTLE_HUB_TRIP";
	public static final String SETTLE_HUB_FC_TRIP = "SETTLE_HUB_FC_TRIP";
	public static final String AMOUNT_COLLECTED_VALIDATOR = "amountCollectedValidator";
	public static final String RRL_SITE_MAPPING_VALIDATOR = "rrlSiteMappingValidator";

	public static final String TOGSTN_B2BGSTNO = "B2BGSTNO";

	public static final String HYPEN="-";
	public static final String SETTLEMENT="SETTLEMENT";


	public static final String MOP_COD = "COD";
	public static final String MOP_PREPAID = "Prepaid";
	public static final String MOP_PREPAID_AND_COD = "Prepaid / COD";

	//Audit Constants
	public static final String EVENT_SOURCE="eventSource";
	public static final String BUSINESS_OPERATION="businessOperation";
	public static final String TRACKING_ID="trackingId";

	// Trip Unassignment
	public static final String UNASSIGNMENT_INITIATED="UNASSIGNMENT_INITIATED";
	public static final String ACTIVITY_MODIFIEDBY="CRON_JOB";
	public static final String UNASSIGNMENT_FAILED ="UNASSIGNMENT_FAILED";
	public static final String CANCEL_UNASSIGNMENT="CANCEL_UNASSIGNMENT";
	public static final String UNASSIGNMENT_FLOW="UNASSIGNMENT_FLOW";
	public static final String UNASSIGNED="UNASSIGNED";
	public static final String START_UNASSIGNMENT="START_UNASSIGNMENT";
	public static final String LOADER_UNASSIGNMENT="UnassignVehicle";
	public static final double DEFAULT_INITIAL_AMT=0.0;

	public static final String TRIP_CANCELLATION_CRON_JOB="TripCancelJob";

	//filter
	public static final String PAGE_SIZE="pageSize";
	public static final String PAGE_INDEX ="pageIndex";
	public static final String FROM_DATE="fromDate";
	public static final String TO_DATE="toDate";
	public static final String STATISTICS="statistics";
	public static final String FILTER_IDS="filterIds";
	public static final String MOVEMENT_TYPE="movementType";
	public static final String DUMMY_VEHICLE = "DUMMY_VEHICLE";
	public static final String DUMMY_VENDOR = "0010145849";
	public static final String DUMMY_VEHICLE_TYPE = "118";

}
