package com.ril.newcommerce.supplychain.tms.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ril.newcommerce.supplychain.tms.enums.AccountStatus;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;
import com.ril.newcommerce.supplychain.tms.enums.UserRoles;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@Getter
@Setter
@Builder
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
@Table(name = "USER_DETAILS", indexes =  @Index( name = "USER_DETAILS_I1", columnList = "USER_NAME", unique = true ))
public class UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_GENERATOR")
    @GenericGenerator(name = "ID_GENERATOR", strategy = "com.ril.newcommerce.supplychain.tms.entity.config.KeyGenerator")
    @Column(name = "ID")
    private String id;

    @Column(name = "HAWKEYE_USER_ID", length = 36, nullable = false)
    private String hawkeyeUserId;

    @Column(name = "USER_NAME", length = 50, nullable = false)
    private String userName;

    @Column(name = "FIRST_NAME", length = 50, nullable = false)
    private String firstName;

    @Column(name = "LAST_NAME", length = 50, nullable = false)
    private String lastName;

    @Column(name = "ROLE", length = 50, nullable = false)
    @Enumerated(EnumType.STRING)
    private UserRoles role;

    @Column(name = "MOBILE_NO", length = 50, nullable = false)
    private String mobileNo;

    @Column(name = "ACCOUNT_STATUS")
    @Enumerated(EnumType.STRING)
    private AccountStatus accountStatus;

    @Column(name = "ADDRESS", length = 500)
    private String address;

    @Column(name = "EMAIL_ID", length = 50, nullable = false)
    private String emailId;

    @Column(name = "ALT_CONTACT_PERSON", length = 50)
    private String altContactPerson;

    @Column(name = "ALT_CONTACT_NO", length = 50)
    private String altContactNo;

    @Column(name = "NODE_ID", length = 50)
    private String nodeId;

    @Column(name = "CLUSTER_ID", length = 50)
    private String clusterId;

    @Column(name = "NODE_TYPE", length = 50)
    @Enumerated(EnumType.STRING)
    private NodeType nodeType;

    @Column(name = "UPDATED_BY", length =50)
    private String updatedBy;

    @Column(name = "UPDATED_AT")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updatedAt;

    @Column(name = "LAST_LOGGED_IN")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastLoggedIn;

    @Column(name = "INVALID_ATTEMPTS", length =2)
    private Integer invalidAttempts;

    @Column(name = "STATE", length = 50)
    private String state;

    @Column(name = "PINCODE",length = 6)
    private Integer pincode;

}
