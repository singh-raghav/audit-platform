package com.ril.newcommerce.supplychain.tms.entity;

import javax.xml.bind.annotation.*;

@XmlRootElement(name = "OrderInvoice")
@XmlAccessorType(XmlAccessType.FIELD)
public class InvoicePdfDetailRequestBody {
    @XmlElement(name = "Order", required = true)
    private InvoicePdfDetailRequestBody.Order order;

    public InvoicePdfDetailRequestBody.Order getOrder() {
        return order;
    }

    public void setOrder(InvoicePdfDetailRequestBody.Order order) {
        this.order = order;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    public static class Order{
        @XmlAttribute(name = "OrderNo")
        private String orderNo;

        @XmlAttribute(name = "ShipmentNo")
        private String shipmentNo;

        public String getOrderNo() {
            return orderNo;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public String getShipmentNo() {
            return shipmentNo;
        }

        public void setShipmentNo(String shipmentNo) {
            this.shipmentNo = shipmentNo;
        }
    }
}
