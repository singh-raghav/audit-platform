/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.OrderDetailsDAO;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.EwayBillStatus;
import com.ril.newcommerce.supplychain.tms.enums.OrderClassification;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.event.processor.TripEventProcessor;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate;
import com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill.Trip.TripOrders;
import com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill.Trip.TripOrders.TripOrder;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate.Labels.Label;
import com.ril.newcommerce.supplychain.tms.tibco.ewaybill.entity.Trip.Shipments;
import com.ril.newcommerce.supplychain.tms.tibco.ewaybill.entity.Trip.Shipments.Shipment;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * @author Raghav1.Singh
 *
 */

public class PostLoadingCompleteChange implements Processor {

	private static final Logger log = LoggerFactory.getLogger(PostLoadingCompleteChange.class);
	
	@Autowired
	private OrderDetailsDAO orderDetails;
	
	@Autowired 
	private JAXBContextConfig jAXBContextConfig;

	@Autowired
	private TripService tripService;

	@Autowired
	private JMSPublisher jmsPublisher;

	@Value("${trip.publish.queue}")
	private String topicName;
	
	@Value("${tripapp.queue}")
	private String queueName;
	
	@Autowired
	private OrderDetailsDAO orderDetailsDAO;
	
	@Autowired
	TripOrdersService tripOrdersSrvice;
	
	@Autowired
	@Qualifier(Constants.TRIP_EVENT_PROCESSOR)
	private TripEventProcessor eventProcessor;
	
	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {
		// TODO 
		StringReader reader = new StringReader(((TextMessage) message).getText());
		TripStatusUpdate tripStatus = (TripStatusUpdate) jAXBContextConfig.getJaxbContextInstance(TripStatusUpdate.class).createUnmarshaller().unmarshal(reader);
		log.info("Post Load complete  feed :{} ", message);
		
		String tripId=tripStatus.getTripNo();
		String nodeId=tripStatus.getNodeId();
		
		Trip trip = tripService.getTrip(tripStatus.getTripNo());
		if (!TripState.LOADING_COMPLETED.getValue().equals(trip.getStatus())) {
			log.info("Sent to retry queue status of trip {} is not load complete ", trip.getTripId());
			throw new TripApplicationException("Trip status is not load complete " + trip.getTripId());
		}
		
		List<Consignment> consignments = orderDetailsDAO.getTripOrderDetails(tripId,nodeId,null,null,null);
        List<Consignment> returnConsignmnet = new ArrayList<>();
		
		if (isReturnOrderTrip(trip, returnConsignmnet,consignments))
		{
			log.info("return trip {} ", trip.getTripId());
			processRetunOrderTrip(trip,returnConsignmnet);
		} else {
			updateNextNodeId(tripStatus, trip,consignments);
			jmsPublisher.publishMessage(topicName, createFeedForEwayBill(trip), FlowName.EWAYBILLREQUEST.getValue(),
					Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
							tripStatus.getTripNo()),com.ril.newcommerce.supplychain.tms.tibco.ewaybill.entity.Trip.class);			
		}
		
		jmsPublisher.publishMessage(topicName, tripStatus, FlowName.LOADINGCOMPLETE.getValue(),
				Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
						tripStatus.getTripNo()),TripStatusUpdate.class);

		log.info("Loading complete feed published to Loader app and to ewaybill");

	}
	
	private void updateNextNodeId(TripStatusUpdate tripStatus, Trip trip,List<Consignment> consignments) {
		Map<String, String> result = consignments.stream()
				.collect(Collectors.toMap(Consignment::getShipmentNo, Consignment::getNextNodeId));

		for (Label label : tripStatus.getLabels().getLabel()) {
			String nodeId = result.get(label.getShipmentNo());
			label.setDestinationNodeId(nodeId);
		}
	}

	
	private void processRetunOrderTrip(Trip trip,List<Consignment> returnConsignmnet )
	{
		TripAdditionalDetail additionalDetails = new TripAdditionalDetail(trip.getTripId(),
				trip.getSourceNode(), Constants.EWAYBILL, EwayBillStatus.SUCCESS.value());
		tripService.updateTripAdditionalDetails(additionalDetails);
		
		jmsPublisher.publishMessage(topicName, getEwayBillForDelivery(trip, returnConsignmnet),
				FlowName.EWAYBILLPUBLISH.getValue(), Utility.getMap(Constants.BUSINESS_KEY_ONE,
						Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE, trip.getTripId()),EwayBill.class);
		
	}
	
	private boolean isReturnOrderTrip(Trip trip,List<Consignment> returnOrder,List<Consignment> consignments) throws InterruptedException, ExecutionException
	{

		List<String> fwdOrderIds = consignments.stream().filter(
				consignment -> OrderClassification.Forward.getValue().equals(consignment.getOrderClassification()) && OrderStatus.ACTIVE.getValue().equals(consignment.getShipmentStatus()) )
				.map(mapper -> mapper.getOrderId()).collect(Collectors.toList());

		returnOrder.addAll(consignments.stream().filter(
				consignment -> OrderClassification.Return.getValue().equals(consignment.getOrderClassification()) && OrderStatus.ACTIVE.getValue().equals(consignment.getShipmentStatus()))
				.collect(Collectors.toList()));
		if (CollectionUtils.isEmpty(fwdOrderIds))
			return true;
		else
			return false;
	}
	
	public EwayBill getEwayBillForDelivery(Trip tripObj,List<Consignment> returnConsignmnet)
	{
		EwayBill ewayMessage=new EwayBill();
		com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill.Trip trip=new com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill.Trip();
		TripOrders tripOrders=new TripOrders();
		List<TripOrder> tripOrderList=new ArrayList<>();
		trip.setTripNo(tripObj.getTripId());
		trip.setTripType(tripObj.getTripType());
		trip.setVehicleNO(tripObj.getAssignedVehicle());
		trip.setDeliveryPartner(tripObj.getAssignedDpId());
		
		for(Consignment consignment:returnConsignmnet)
		{
			TripOrder tripOrder=new TripOrder();
			tripOrder.setOrderNo(consignment.getOrderId());
			tripOrder.setShipmentNo(consignment.getShipmentNo());
			tripOrder.setStatus(EwayBillStatus.NOT_REQUIRED.value());
			tripOrderList.add(tripOrder);
		}
		tripOrders.setTripOrder(tripOrderList);
		trip.setTripOrders(tripOrders);
		ewayMessage.setTrip(trip);
		
		return ewayMessage;
		
	}
	
	private com.ril.newcommerce.supplychain.tms.tibco.ewaybill.entity.Trip createFeedForEwayBill(Trip tripObj) {
		com.ril.newcommerce.supplychain.tms.tibco.ewaybill.entity.Trip trip = new com.ril.newcommerce.supplychain.tms.tibco.ewaybill.entity.Trip();

		List<String> status = new ArrayList<String>();
		status.add(OrderStatus.ACTIVE.getValue());
		List<Consignment> consignments = orderDetails.getTripOrderDetails(tripObj.getTripId(), tripObj.getSourceNode(),
				status, null, OrderClassification.Forward.getValue());

		trip.setTripNo(tripObj.getTripId());
		trip.setNodeId(tripObj.getSourceNode());
		trip.setTripType(tripObj.getTripType());
		trip.setTransporterId(Constants.TRANSPORTERID);
		trip.setTransporterName(Constants.TRANSPORTERNAME);
		trip.setTransMode(Constants.TRANSMODE);
		trip.setTransDocDate(new Date().toString());
		trip.setVehicleNo(tripObj.getAssignedVehicle());

		List<Shipment> shipmentList = new ArrayList<Shipment>();
		Shipments shipments = new Shipments();

		for (Consignment consignment : consignments) {
				Shipment shipment = new Shipment();
				shipment.setOrderNumber(consignment.getOrderId());
				shipment.setShipmentNumber(consignment.getShipmentNo());
				shipmentList.add(shipment);
		}
		shipments.setShipment(shipmentList);
		trip.setShipments(shipments);

		return trip;
	}

}
