package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.WayPointUpdatesService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import static com.ril.newcommerce.supplychain.tms.enums.OrderState.*;

@Qualifier(Constants.ORDER_PROCESSOR.DELIVERED_PRE_PROCESSOR)
@Service
public class OrderStatusDeliveredPreProcessor implements OrderStatusUpdatePreProcessor {

    @Autowired
    private WayPointUpdatesService wayPointUpdatesService;

    @Override
    public boolean validateUpdate(OrderStatusFeed.Order order) {
        if (!isWayPointUpdated(order.getOrderId(), order.getStateTo())) {
            throw new TripApplicationException("Order status update to SHIPPED failed as FC trip not yet started. Order Id : " + order.getOrderId() + "Shipment No : " + order.getShipmentNo());
        }
        return false;
    }

    private boolean isWayPointUpdated(String orderId, OrderState stateTo) {
        String wayPointUpdate = wayPointUpdatesService.getLastUpdate(orderId);
        if (!StringUtils.isBlank(wayPointUpdate) &&
                orderStateEnumForWayPointStatus(wayPointUpdate).getValue().equalsIgnoreCase((stateTo.getValue()))) {
            return true;
        }
        return false;
    }

    private OrderState orderStateEnumForWayPointStatus(String wayPointUpdate) {
        OrderState orderState = null;
        switch (wayPointUpdate) {
            case Constants.WAYPOINT_DB_STATUS.FULL_DSR:
                orderState = FULL_DSR;
                break;
            case Constants.WAYPOINT_DB_STATUS.DELIVERED:
                orderState = DELIVERED;
                break;
            case Constants.WAYPOINT_DB_STATUS.RESCHEDULED:
                orderState = RESCHEDULED;
                break;
            case Constants.WAYPOINT_DB_STATUS.PICKED:
                orderState = PICKED;
                break;
            case Constants.WAYPOINT_DB_STATUS.PARTIALLY_DELIVERED:
                orderState = PARTIALLY_DELIVERED;
                break;
            default:
                throw new TripApplicationException("Unhandled waypoint status: " + wayPointUpdate);
        }
        return orderState;
    }

}
