package com.ril.newcommerce.supplychain.tms.enums;

import java.util.HashMap;
import java.util.Map;

/**
B1.Divya
*/

public enum TripState {

	INPROGRESS("INPROGRESS",1),
	CREATED("CREATED",2),
	ASSIGNED("ASSIGNED",3),
	LOADING_INPROGRESS("LOADING_INPROGRESS",4),
	LOADING_COMPLETED("LOADING_COMPLETED",5),
	CANCELLED("CANCELLED",6),
	INTRANSIT("INTRANSIT",7),
	SETTLEMENT_PENDING("SETTLEMENT_PENDING",8),
	SETTLED("SETTLED",9);
	
	private String value;
	private int order;

	public String getValue() {
		return this.value;
	}
	
	public int getOrder() {
		return this.order;
	}

	private TripState(String value,int order) {
		this.value = value;
		this.order = order;
	}
	
	private static final Map<String, TripState> lookup = new HashMap<>();
	
	static {
		for (TripState reasonCode : TripState.values())
			lookup.put(reasonCode.getValue(), reasonCode);
	}

	public static TripState get(String value) {
		return lookup.get(value);
	}
	
}
