package com.ril.newcommerce.supplychain.tms.addverb.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

public class ReturnedProductDetails {

	private String productID;
	private String orderID;
	private String returnType;
	private double quantityReturned;
	private Double price;
	private Double amount;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer good;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer damaged;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer shortaged;

	@JsonIgnore
	private String fcId;
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	public double getQuantityReturned() {
		return quantityReturned;
	}
	public void setQuantityReturned(double quantityReturned) {
		this.quantityReturned = quantityReturned;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Integer getGood() {
		return good;
	}
	public void setGood(Integer good) {
		this.good = good;
	}
	public Integer getDamaged() {
		return damaged;
	}
	public void setDamaged(Integer damaged) {
		this.damaged = damaged;
	}
	public Integer getShortaged() {
		return shortaged;
	}
	public void setShortaged(Integer shortaged) {
		this.shortaged = shortaged;
	}
	public String getFcId() {
		return fcId;
	}
	public void setFcId(String fcId) {
		this.fcId = fcId;
	}

}
