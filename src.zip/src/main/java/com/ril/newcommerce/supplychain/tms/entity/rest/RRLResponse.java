/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

/**
 * @author Raghav1.Singh
 *
 */
public class RRLResponse {
	
	private List<NodeRRLMappings> nodeRRLMappings;
	private String status;
	private String message;
	private List<Object> errors;
	
	public List<NodeRRLMappings> getNodeRRLMappings() {
		return nodeRRLMappings;
	}
	public void setNodeRRLMappings(List<NodeRRLMappings> nodeRRLMappings) {
		this.nodeRRLMappings = nodeRRLMappings;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<Object> getErrors() {
		return errors;
	}
	public void setErrors(List<Object> errors) {
		this.errors = errors;
	}

}
