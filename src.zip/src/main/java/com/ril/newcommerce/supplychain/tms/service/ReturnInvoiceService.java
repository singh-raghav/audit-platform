package com.ril.newcommerce.supplychain.tms.service;

import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.tibco.invoice.entity.InvoiceDetail;

@Service
public interface ReturnInvoiceService {

	void persistReturnItems(InvoiceDetail invoiceDetails) throws Exception;

}
