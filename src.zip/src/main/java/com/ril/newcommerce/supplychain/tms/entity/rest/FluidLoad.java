package com.ril.newcommerce.supplychain.tms.entity.rest;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * 
 * @author Asha1.Rani
 *
 */

@JsonDeserialize
@JsonSerialize
@Data
public class FluidLoad {
	@JsonProperty("NodeId")
	private String nodeId;
	@JsonProperty("Flag")
	private String flag;
}
