package com.ril.newcommerce.supplychain.tms.exception;

/**
B1.Divya
*/

public class EntityNotModifiedException extends RuntimeException {

	private static final long serialVersionUID = 3567580813746463072L;

	public EntityNotModifiedException(String message) {
		super(message);
	}
	
	
	public EntityNotModifiedException(String message,Throwable th) {
		super(message,th);
	}
	
	public EntityNotModifiedException(Throwable th) {
		super(th);
	}
}
