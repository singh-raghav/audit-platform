package com.ril.newcommerce.supplychain.tms.entity;

public class ItemDetails {
	
	private String itemId;
	private String orderId;
	private String returnOrderId;
	private Double quantity;
	private Double receivedQuantity;
	private String itemName;
	private String primeLineNo;
	private Double unitPrice;
	private String uom;
	private String hsnCode;
	private String returnType;
	private String scrNodeId;
	
	public String getReturnType() {
		return returnType;
	}
	
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	
	public String getScrNodeId() {
		return scrNodeId;
	}
	
	public void setScrNodeId(String scrNodeId) {
		this.scrNodeId = scrNodeId;
	}
	
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getReturnOrderId() {
		return returnOrderId;
	}
	public void setReturnOrderId(String returnOrderId) {
		this.returnOrderId = returnOrderId;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public Double getReceivedQuantity() {
		return receivedQuantity;
	}
	public void setReceivedQuantity(Double receivedQuantity) {
		this.receivedQuantity = receivedQuantity;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getPrimeLineNo() {
		return primeLineNo;
	}
	public void setPrimeLineNo(String primeLineNo) {
		this.primeLineNo = primeLineNo;
	}
	public Double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public String getHsnCode() {
		return hsnCode;
	}
	public void setHsnCode(String hsnCode) {
		this.hsnCode = hsnCode;
	}
}
