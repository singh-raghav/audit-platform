package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.Date;


public class Vehicle {

	private String vehicleNo;
	private String vehicleType;
	private String vehicleTypeId;
	private String fleetType;
	private String vendorId;
	private String vendorName;
	private int vendorMobile;
	private String vendorAddress;
	private String vehicleActive;
	private Double averageSpeed;
	private Date validFrom;
	private Date validTo;	
	private String availableForPlan;
	private String status;
	private String vrnId;
	private Date vrnIn;
	private String rateCardId;
	
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getVehicleTypeId() {
		return vehicleTypeId;
	}
	public void setVehicleTypeId(String vehicleTypeId) {
		this.vehicleTypeId = vehicleTypeId;
	}
	public String getFleetType() {
		return fleetType;
	}
	public void setFleetType(String fleetType) {
		this.fleetType = fleetType;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public int getVendorMobile() {
		return vendorMobile;
	}
	public void setVendorMobile(int vendorMobile) {
		this.vendorMobile = vendorMobile;
	}
	public String getVendorAddress() {
		return vendorAddress;
	}
	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}
	public String getVehicleActive() {
		return vehicleActive;
	}
	public void setVehicleActive(String vehicleActive) {
		this.vehicleActive = vehicleActive;
	}
	public Double getAverageSpeed() {
		return averageSpeed;
	}
	public void setAverageSpeed(Double averageSpeed) {
		this.averageSpeed = averageSpeed;
	}
	public Date getValidFrom() {
		return validFrom;
	}
	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}
	public Date getValidTo() {
		return validTo;
	}
	public void setValidTo(Date validTo) {
		this.validTo = validTo;
	}
	public String getAvailableForPlan() {
		return availableForPlan;
	}
	public void setAvailableForPlan(String availableForPlan) {
		this.availableForPlan = availableForPlan;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVrnId() {
		return vrnId;
	}
	public void setVrnId(String vrnId) {
		this.vrnId = vrnId;
	}
	public Date getVrnIn() {
		return vrnIn;
	}
	public void setVrnIn(Date vrnIn) {
		this.vrnIn = vrnIn;
	}
	public String getRateCardId() {
		return rateCardId;
	}
	public void setRateCardId(String rateCardId) {
		this.rateCardId = rateCardId;
	}
	
	@Override
	public String toString() {
		return "Vehicle [vehicleNo=" + vehicleNo + ", vehicleType=" + vehicleType + ", vehicleTypeId=" + vehicleTypeId
				+ ", fleetType=" + fleetType + ", vendorId=" + vendorId + ", vendorName=" + vendorName
				+ ", vendorMobile=" + vendorMobile + ", vendorAddress=" + vendorAddress + ", vehicleActive="
				+ vehicleActive + ", averageSpeed=" + averageSpeed + ", validFrom=" + validFrom + ", validTo=" + validTo
				+ ", availableForPlan=" + availableForPlan + ", status=" + status + ", vrnId=" + vrnId + ", vrnIn="
				+ vrnIn + ", rateCardId=" + rateCardId + "]";
	}
}
