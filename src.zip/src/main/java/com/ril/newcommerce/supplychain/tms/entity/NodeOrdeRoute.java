package com.ril.newcommerce.supplychain.tms.entity;

import java.sql.Timestamp;

/**
B1.Divya
*/

public class NodeOrdeRoute
{
	private String nodeId;
	private String orderId;
	private String previousRouteId;
	private String nextRouteId;
	private String createdBy;
	private Timestamp createdTime;
	private String flowName;
	private String modifiedBy;
	private Timestamp modifiedTime;
	
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getPreviousRouteId() {
		return previousRouteId;
	}
	public void setPreviousRouteId(String previousRouteId) {
		this.previousRouteId = previousRouteId;
	}
	public String getNextRouteId() {
		return nextRouteId;
	}
	public void setNextRouteId(String nextRouteId) {
		this.nextRouteId = nextRouteId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Timestamp modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	
	
}
