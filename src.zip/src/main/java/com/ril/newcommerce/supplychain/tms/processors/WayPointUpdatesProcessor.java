package com.ril.newcommerce.supplychain.tms.processors;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.WayPointUpdates;
import com.ril.newcommerce.supplychain.tms.enums.OrderClassification;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.service.WayPointUpdatesService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import com.ril.newcommerce.supplychain.tms.tibco.waypoint.entity.Waypoint;
import com.ril.newcommerce.supplychain.tms.tibco.waypoint.entity.Waypoint.Shipments.Shipment;
import com.ril.newcommerce.supplychain.tms.tibco.waypoint.entity.Waypoint.Shipments.Shipment.ShipmentLines.ShipmentLine;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.UnmarshalException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Service
@Qualifier(Constants.WAYPOINT_UPDATES)
public class WayPointUpdatesProcessor  implements Processor {

	private static final Logger log = LoggerFactory.getLogger(WayPointUpdatesProcessor.class);

	@Autowired
	private TripService tripService;

	@Autowired
	private WayPointUpdatesService wayPointUpdateService;

	@Autowired
	private JAXBContextConfig jAXBContextConfig;

	@Autowired
	TripOrdersService tripOrdersSrvice;

	@Value("${tripapp.queue}")
    private String tripAppQueue;

    @Autowired
    private JMSPublisher publisher;
	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {

		try {
			StringReader reader = new StringReader(((TextMessage) message).getText());
			Waypoint wayPointUpdate = (Waypoint) jAXBContextConfig.getJaxbContextInstance(Waypoint.class)
					.createUnmarshaller().unmarshal(reader);
			log.info("Delivery update feed :{} ", message);

			Trip trip = tripService.getTrip(wayPointUpdate.getTripId());

			List<String> shipmentNos = new ArrayList<>();

			List<WayPointUpdates> wayPointUpdates = getWayPointUpdates(wayPointUpdate, trip, flowName, shipmentNos);

			wayPointUpdateService.insertToWayPointUpdate(wayPointUpdates);

			if (!CollectionUtils.isEmpty(shipmentNos)) {
				tripOrdersSrvice.updateShipmentStatus(OrderStatus.RESCHEDULED.getValue(), shipmentNos, trip.getTripId(),
						flowName, flowName, trip.getSourceNode(), null);
			}

			publishOrderStatusFeed(wayPointUpdates);

		} catch (UnmarshalException par) {
			throw new ParsingException("Parsing error while parsing trip status feed", par);
		}
	}
    private void publishOrderStatusFeed(List<WayPointUpdates> wayPointUpdate) {

        OrderStatusFeed orderStatusFeed = createOrderStatusFeed(wayPointUpdate);
        publisher.inputToQueue(tripAppQueue, orderStatusFeed, FlowName.ORDER_STATUS_UPDATE.getValue(), null, OrderStatusFeed.class);
    }

    private OrderStatusFeed createOrderStatusFeed(List<WayPointUpdates> wayPointUpdates) {

		OrderStatusFeed orderStatusFeed = new OrderStatusFeed();
		for (WayPointUpdates wayPointUpdate : wayPointUpdates) {
			OrderState stateTo = getStateTo(wayPointUpdate);
			if (null != stateTo) {
				OrderStatusFeed.Order order = new OrderStatusFeed.Order();
				order.setOrderId(wayPointUpdate.getOrderId());
				order.setStateTo(stateTo);
				order.setFlowName(Constants.WAYPOINT_UPDATES);
				orderStatusFeed.getOrder().add(order);
			}
		}
        return orderStatusFeed;
    }

	private OrderState getStateTo(WayPointUpdates wayPointUpdates) {
		OrderState orderState = null;
		String status = wayPointUpdates.getStatus();
		if (status.equals(OrderStatus.ORDER_DELIVERED.getValue()) ){
			orderState = OrderState.DELIVERED;
		}else if (status.equals(OrderStatus.FULL_DSR.getValue())  ){
			orderState = OrderState.FULL_DSR;
		}else if (status.equals(OrderStatus.PARTIALLY_DELIVERED.getValue()) ){
			orderState = OrderState.PARTIALLY_DELIVERED;
		}else if(status.equals(OrderStatus.PICKEDUP.getValue())){
			orderState = OrderState.PICKED;
		}else if (status.equals(OrderStatus.RESCHEDULED.getValue())){
			orderState = OrderState.RESCHEDULED;
		}
		return orderState;
	}

	private List<WayPointUpdates> getWayPointUpdates(Waypoint wayPointUpdate, Trip trip, String flowName,
			List<String> shipmentNos) {
		List<WayPointUpdates> wayPointUpdates = new ArrayList<>();

		for (Shipment shipments : wayPointUpdate.getShipments().getShipment()) {
			WayPointUpdates update = new WayPointUpdates();
			update.setTripId(wayPointUpdate.getTripId());
			update.setWayPointId(wayPointUpdate.getWaypointId());
			update.setNodeId(trip.getSourceNode());
			update.setOrderId(shipments.getOrderNo());

			if (OrderClassification.Forward.getValue().equals(shipments.getOrderClassification().value())
					&& !Constants.YES.equals(shipments.getRescheduled().value())) {
				List<ShipmentLine> rejected = shipments.getShipmentLines().getShipmentLine().stream()
						.filter(mapper -> mapper.getRejectedQty() > 0).collect(Collectors.toList());
				List<ShipmentLine> accepted = shipments.getShipmentLines().getShipmentLine().stream()
						.filter(mapper -> mapper.getAcceptedQty() > 0).collect(Collectors.toList());
				Character shouldReconcile = CollectionUtils.isEmpty(rejected) ? 'N' : 'Y';
				update.setShouldReconcile(shouldReconcile);
				update.setOrderClassification(OrderClassification.Forward.getValue());

				if(CollectionUtils.isEmpty(rejected)) {
                    update.setStatus(OrderStatus.ORDER_DELIVERED.getValue());
                    updateAmountDetails(shipments, update);
                }

				else if(!CollectionUtils.isEmpty(accepted) && !CollectionUtils.isEmpty(rejected)) {
                    update.setStatus(OrderStatus.PARTIALLY_DELIVERED.getValue());
                    updateAmountDetails(shipments, update);
                }
				
				else if(!CollectionUtils.isEmpty(rejected) && CollectionUtils.isEmpty(accepted))
					update.setStatus(OrderStatus.FULL_DSR.getValue());
			}

			else if (OrderClassification.Return.getValue().equals(shipments.getOrderClassification().value())
					&& !Constants.YES.equals(shipments.getRescheduled().value())) {
				List<ShipmentLine> accepted = shipments.getShipmentLines().getShipmentLine().stream()
						.filter(mapper -> mapper.getAcceptedQty() > 0).collect(Collectors.toList());
				Character shouldReconcile = CollectionUtils.isEmpty(accepted) ? 'N' : 'Y';
				update.setShouldReconcile(shouldReconcile);
				update.setOrderClassification(OrderClassification.Return.getValue());

				if(CollectionUtils.isEmpty(accepted))
					update.setStatus(OrderStatus.REJECTED.getValue());

				else
					update.setStatus(OrderStatus.PICKEDUP.getValue());
			} else if (Constants.YES.equals(shipments.getRescheduled().value())) {
				Character shouldReconcile = Constants.NO.charAt(0);
				update.setShouldReconcile(shouldReconcile);
				update.setOrderClassification(shipments.getOrderClassification().value());
				update.setStatus(OrderStatus.RESCHEDULED.getValue());
				shipmentNos.add(shipments.getShipmentNo());
			}

			update.setCreatedBy(flowName);
			update.setFlowName(flowName);

			wayPointUpdates.add(update);
		}
		return wayPointUpdates;

	}

	private void updateAmountDetails(Shipment shipments, WayPointUpdates update) {

		try {
			BigDecimal roundOffAmount = new BigDecimal("0.00");
			BigDecimal amountPaid = new BigDecimal("0.00");
			for (Shipment.Payments.Payment payment : shipments.getPayments().getPayment()) {
				if ((null != payment)) {

					if (null != payment.getRoundOffAmount()) {
						roundOffAmount = roundOffAmount.add(payment.getRoundOffAmount());
					}
					if (null != payment.getAmountPaid()) {
						amountPaid = amountPaid.add(payment.getAmountPaid());
					}
				}
			}
			update.setAmountPaid(amountPaid.doubleValue());
			update.setRoundOffAmount(roundOffAmount.doubleValue());
		} catch (NullPointerException e) {
			//This can happen if the order is prepaid forward order
			log.info("Payments missing for order number {}", shipments.getOrderNo());
		}
	}

}
