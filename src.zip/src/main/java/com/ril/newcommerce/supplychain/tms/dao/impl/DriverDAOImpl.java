package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.DriversDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.DriversMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripMapper;
import com.ril.newcommerce.supplychain.tms.entity.rest.Drivers;

@Repository
public class DriverDAOImpl implements DriversDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<Drivers> getAvailableDrivers(String nodeId) {		
		List<Drivers> drivers = null;
		String query = QueryConstants.GET_AVAILABLE_DRIVERS;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeId", nodeId);
		try {
			drivers = namedParameterJdbcTemplate.query(query, parameters,new DriversMapper());
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return drivers;
	}

}
