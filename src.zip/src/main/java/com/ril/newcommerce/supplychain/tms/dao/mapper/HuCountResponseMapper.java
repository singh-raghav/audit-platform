package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.response.HuCountResponse;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HuCountResponseMapper implements ResultSetExtractor<List<HuCountResponse>> {
    @Override
    public List<HuCountResponse> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<HuCountResponse> orderCountResponses = new ArrayList<>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            HuCountResponse orderCountResponse = new HuCountResponse();
            orderCountResponse.setSdpId(rs.getString("SDP_ID"));
            orderCountResponse.setHuCount(rs.getInt("HU_COUNT"));
            orderCountResponse.setHuMissing(rs.getInt("MISSED_COUNT"));
            orderCountResponse.setOrderId(rs.getString("ORDER_ID"));
            orderCountResponses.add(orderCountResponse);
        }
        return orderCountResponses;
    }
}
