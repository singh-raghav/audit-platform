package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Invoice;

/**
B1.Divya
*/

public class InvoiceMapper implements ResultSetExtractor<List<Invoice>> {

	@Override
	public List<Invoice> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<Invoice> invoiceList = new ArrayList<Invoice>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			Invoice invoice=new Invoice();
			invoice.setInvoiceNo(rs.getString("INVOICE_NO"));
			invoice.setInvoiceAmount(rs.getDouble("INVOICE_VALUE"));
			invoice.setInvoiceDate(rs.getDate("INVOICED_DATE"));
			invoice.setOrderNo(rs.getString("ORDER_NO"));
			invoice.setShipmentNo(rs.getString("SHIPMENT_NO"));
			invoice.setEwayBillNo(rs.getString("EWB_NO"));
			invoice.setEwayBillStatus(rs.getString("EWB_STATUS"));
			invoice.setAmountToBeCollected(rs.getDouble("AMOUNT_TO_BE_COLLECTED"));
			invoiceList.add(invoice);
		}
		return invoiceList;
	}

}
