package com.ril.newcommerce.supplychain.tms.entity;

import java.util.List;

/**
B1.Divya
*/

public class LoadCompleteReconcilation 
{
	private String tripId;
	private List<Consignment> splitShipments;
	private List<TripConsignmentInfo> mergeShipments;
	private List<Trip> reconcileShipments;
	private List<Consignment> suspendedOrders;
	private boolean isShuttle;
	
	public boolean isShuttle() {
		return isShuttle;
	}
	public void setShuttle(boolean isShuttle) {
		this.isShuttle = isShuttle;
	}
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public List<Consignment> getSplitShipments() {
		return splitShipments;
	}
	public void setSplitShipments(List<Consignment> splitShipments) {
		this.splitShipments = splitShipments;
	}
	public List<TripConsignmentInfo> getMergeShipments() {
		return mergeShipments;
	}
	public void setMergeShipments(List<TripConsignmentInfo> mergeShipments) {
		this.mergeShipments = mergeShipments;
	}
	public List<Trip> getReconcileShipments() {
		return reconcileShipments;
	}
	public void setReconcileShipments(List<Trip> reconcileShipments) {
		this.reconcileShipments = reconcileShipments;
	}
	public List<Consignment> getSuspendedOrders() {
		return suspendedOrders;
	}
	public void setSuspendedOrders(List<Consignment> suspendedOrders) {
		this.suspendedOrders = suspendedOrders;
	}
	
}
