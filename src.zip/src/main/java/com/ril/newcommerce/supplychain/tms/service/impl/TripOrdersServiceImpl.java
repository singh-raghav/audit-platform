package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.dao.TripOrdersDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripSequenceDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.dao.impl.TripOrdersDAOImpl;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;


@Service
public class TripOrdersServiceImpl implements TripOrdersService {

	private static final Logger log = LoggerFactory.getLogger(TripOrdersDAOImpl.class);
	
	@Autowired
	TripOrdersDAO tripOrdersDAO;
	
	@Autowired
	TripsDAO tripDAO;
	
	@Autowired
	TripSequenceDAO tripSequenceDAO;
	
	@Override
	public void insertToTripConsignment(Trip trip) {
		try {
			tripOrdersDAO.insertToTripConsignment(trip);
		} 
		catch (Exception e) {
			log.error(
					"Got Exception while inserting trip consignments in trip_consignment table in insertToTripConsignment of TripOrdersServiceImpl",
					e);
			throw new DataProcessingException(
					"Got Exception while inserting trip consignments in trip_consignment table in insertToTripConsignment of TripOrdersServiceImpl",
					e);
		}

	}

	@Override
	public int updateShipmentStatus(String status, List<String> shipmentnos, String tripId, String modifiedBy,
			String flowName, String nodeId,String statusClause) throws Exception {
		int result = 0;

		try {
			result = tripOrdersDAO.updateShipmentStatus(status, shipmentnos, tripId, modifiedBy, flowName, nodeId,statusClause);
		} catch (Exception e) {

			throw new TripApplicationException("Exception occured on status of trip consignment in  TripOrdersServiceImpl", e);
		}

		return result;
	}
	
	@Override
	public List<TripConsignmentInfo> getTripConsignmentInfo(List<String> tripIds, List<String> nodeIds,List<String> status,String externalRefId,List<String> shipmentNos,List<String> orderIds) 
	{
		List<TripConsignmentInfo> tripConsignment =new ArrayList<>();
		try {
			tripConsignment = tripOrdersDAO.getTripConsignmentInfo(tripIds, nodeIds,status, externalRefId,shipmentNos,orderIds);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on status of trip consignment in  TripOrdersServiceImpl", e);
		}

		return tripConsignment;
	}

	@Override
	public void deleteTripConsignment(List<String> shipmentNos, String nodeId, String status) 
	{
		if (!CollectionUtils.isEmpty(shipmentNos)) {
			try {
				tripOrdersDAO.deleteTripConsignment(shipmentNos, nodeId, status);
			} catch (Exception e) {
				log.error("Exception occurred while deleteing trip order association for no. of shipments :{} ",
						shipmentNos.size(),e);
				throw new TripApplicationException(
						"Exception occured on status of trip consignment in  TripOrdersServiceImpl", e);
			}
			log.info("Trip consignment association successfully deleted ");
		}
	}

	@Override
	public void updateShipmentStatus(String status, List<String> orderIds, String modifiedBy, String flowName) {
		try {
			tripOrdersDAO.updateShipmentStatus(status, orderIds, modifiedBy, flowName);
		} catch (Exception e) {
			log.error("Exception occured in updateShipmentStatus in TripOrdersServiceImpl", e);
			throw new TripApplicationException(
					"Exception occured in updateShipmentStatus in TripOrdersServiceImpl ", e);
		}
		
	}

	@Override
	public List<TripConsignmentInfo> getTripConsignmentInfo(String tripId, List<String> status) {
		List<TripConsignmentInfo> tripConsignment =new ArrayList<>();
		try {
			tripConsignment = tripOrdersDAO.getTripConsignmentInfo(tripId,status);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured getTripConsignmentInfo by trip id  TripOrdersServiceImpl", e);
		}

		return tripConsignment;
	}

	@Override
	public int updateShipments(List<String> shipmentnos, String tripId, String nodeId) throws Exception {
		int result = 0;

		try {
			result = tripOrdersDAO.updateShipments(shipmentnos, tripId,nodeId);
		} catch (Exception e) {

			throw new TripApplicationException("Exception occured on status of trip consignment in  TripOrdersServiceImpl", e);
		}

		return result;
	}
	
	@Override
	public void mergeTripConsignment(List<Consignment> consignments, String tripId, String createdBy, String flowName,
			String nodeId, boolean flag) {
		
		List<String> tripIds = new ArrayList<>();
		tripIds.add(tripId);
		Map<String, List<Hub>> tripSequence = tripSequenceDAO.getTripSequence(tripIds, null);
		
		consignments.forEach(c -> c.setOrderStatus(OrderStatus.ACTIVE.getValue()));
		consignments.forEach(c -> c.setCreatedBy(createdBy));
		consignments.forEach(c -> c.setFlowName(flowName));
		Set<String> nextDestinationIds = consignments.stream().map(mapper -> mapper.getNextNodeId())
				.collect(Collectors.toSet());
		Set<String> nodeIdsNotLinked = new HashSet<>(nextDestinationIds);
		List<Hub> newNodes = new ArrayList<>();
		List<Hub> hubs = new ArrayList<Hub>();
		int sequence=0;

		if(!MapUtils.isEmpty(tripSequence))
		{
			hubs = tripSequence.get(tripId);
			Set<String> nodeIdsLinked = hubs.stream().map(m -> m.getNodeId()).collect(Collectors.toSet());
			nodeIdsNotLinked.removeAll(nodeIdsLinked);
			
			Hub hubObj = Collections.max(hubs, Comparator.comparing(s -> s.getSequence()));
			 sequence = hubObj.getSequence();
		}

		Trip trip = new Trip();
		trip.setTripId(tripId);
		trip.setConsignment(consignments);
		if (!CollectionUtils.isEmpty(nodeIdsNotLinked)) {
			for (String id : nodeIdsNotLinked) {
				Hub obj = new Hub();
				obj.setNodeId(id);
				obj.setSequence(sequence + 1);
				newNodes.add(obj);
				sequence++;
			}

		}
		trip.setHub(newNodes);
		List<String> shipmentNos=consignments.stream().map(mapper->mapper.getShipmentNo()).collect(Collectors.toList());
		if(flag) {
			deleteTripConsignment(shipmentNos, nodeId, OrderStatus.INPROGRESS.getValue());			
		}	
		insertToTripConsignment(trip);
		tripSequenceDAO.insertToTripSequence(trip);

		
	}

	@Override
	public boolean isShipmentSuspended(String shipment, String orderId) {

		return tripOrdersDAO.getSuspendedConsignmentsCount(shipment, orderId) > 0;
	}
}
