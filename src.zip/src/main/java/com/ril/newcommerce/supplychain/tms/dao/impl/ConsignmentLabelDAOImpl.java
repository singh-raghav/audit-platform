package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ril.newcommerce.supplychain.tms.dao.mapper.ConsignmentLabelMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.HuCountResponseMapper;
import com.ril.newcommerce.supplychain.tms.response.HuCountResponse;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.ConsignmentLabelDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.enums.ConsignmentLabelStatus;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate.Labels.Label;

/**
B1.Divya
*/
@Repository
public class ConsignmentLabelDAOImpl implements ConsignmentLabelDAO{
	
	private static final Logger log = LoggerFactory.getLogger(ConsignmentLabelDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int saveShipmentLabel(Set<ConsignmentLabel> consignmentLabels) {
		log.info("Insert label feed");

		int[] result = null;
		int[] count = null;
		if (!consignmentLabels.isEmpty()) {
			try {
				List<Object[]> inputList = new ArrayList<Object[]>();
				for (ConsignmentLabel label : consignmentLabels) {
					Object[] tmp = { label.getLabelId(), label.getParentLabelId(), label.getLabelType(),
							label.getShipmentNo(), ConsignmentLabelStatus.CREATED.value(), new Timestamp(System.currentTimeMillis()) };
					inputList.add(tmp);
				}
				result = jdbcTemplate.batchUpdate(QueryConstants.INSERT_INTO_CONSIGNMENT_LABEL, inputList);
				count = Arrays.stream(result).filter(s -> s > 0).toArray();
			}

			catch (Exception e) {
				throw new DataProcessingException("Got Exception in ConsignmentLabelDAOImpl saveShipmentLabel",e);
				//logger.error("Exception: saveShipmentLabel method of ShipmentLabelDAOImpl ::: ", e);

			}
		}
		return count.length;
	}

	@Override
	public int updateStatusOfShipmentLabel(Map<String, Map<String, List<String>>> labelWithStatus,String modifiedBy) {

		//logger.info("Inside updateStatusOfShipmentLabel_V2 of ShipmentLabelDAOImpl ");
		int count = 0;
		int result = 0;
		for (Map.Entry<String, Map<String, List<String>>> entry : labelWithStatus.entrySet()) {
			if (!entry.getValue().isEmpty()) {
				for (Map.Entry<String, List<String>> shipmentWithLabel : entry.getValue().entrySet()) {
					if (null != shipmentWithLabel.getValue() || !shipmentWithLabel.getValue().isEmpty()) {
						NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
								jdbcTemplate.getDataSource());
						MapSqlParameterSource parameters = new MapSqlParameterSource();
						parameters.addValue("status", entry.getKey());
						parameters.addValue("labelIds", shipmentWithLabel.getValue());
						parameters.addValue("shipmentNo", shipmentWithLabel.getKey());
						parameters.addValue("modifiedBy", modifiedBy);
						//logger.info("updateStatusOfShipmentLabel_V2 menthod Labels ids " + shipmentWithLabel.getValue()
							//	+ " status to be updated to " + entry.getKey());
						String query = QueryConstants.UPDATE_STATUS_OF_SHIPMENT_LABEL;
						try {
							count = namedParameterJdbcTemplate.update(query, parameters);
							result = result + count;
						} catch (Exception e) {
							
							e.printStackTrace();
						}
					}
				}
			}
		}
		//logger.info(" end of updateStatusOfShipmentLabel_V2 of ShipmentLabelDAOImpl..");
		return result;
	}
	
	@Override
	public void updateStatusOfShipmentLabel(List<Label> labels,String modifiedBy) {
		try{
		 jdbcTemplate.batchUpdate(
				QueryConstants.UPDATE_STATUS_OF_SHIPMENT_LABEL,
				new BatchPreparedStatementSetter() {

            	@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
            		 ps.setString(1, labels.get(i).getMissingStatus());
                     ps.setString(2, modifiedBy);
                    ps.setString(3, labels.get(i).getLabelID());
                    ps.setString(4, labels.get(i).getShipmentNo());
                }

                public int getBatchSize() {
                    return labels.size();
                }

            });
		}
		catch (Exception e) {
			log.error("Exception occured during updating label status {}", e);
			throw new TripApplicationException("Exception occured during updating label status ", e);
		}
		
	}

	public int updateStatusOfShipmentLabel(String shipmentNo, String status, String modifiedBy, List<String> labelIds) {

		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		String query = QueryConstants.UPDATE_LABEL_STATUS;
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("status", status);
		parameters.addValue("labelIds", labelIds);
		parameters.addValue("shipmentNo", shipmentNo);
		parameters.addValue("modifiedBy", modifiedBy);
		try {
			return namedParameterJdbcTemplate.update(query, parameters);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred while updating label status for Shipment" + shipmentNo, e);
		}
	}

	@Override
	public Integer getLabelsCountForShipment(String shipmentNo) {

		if (StringUtils.isBlank(shipmentNo) ) {
			return null;
		}
		try {
			return jdbcTemplate.queryForObject(QueryConstants.STAGING_PENDING_LABEL_COUNT_FOR_SHIPMENT ,
					new Object[]{shipmentNo}, Integer.class);

		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred while getting unstaged label count for Shipment" + shipmentNo, e);
		}
	}

	@Override
	public Map<String, Map<String, List<ConsignmentLabel>>> getTripConsignmentLabel(List<String> tripIds,
			List<String> sourceNode) {
		log.info("Start of the method to fetch consignment details for trips in getTripConsignmentLabel of TripsDAOImpl");
		Map<String, Map<String, List<ConsignmentLabel>>> queryResults = null;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("tripIds", tripIds);
		parameters.addValue("sourceNode", sourceNode);
		String query = QueryConstants.GET_TRIP_CONSIGNMENT_LABEL;
		try {
			queryResults = namedParameterJdbcTemplate.query(query, parameters, new TripConsignmentLabel());
		} catch (Exception e) {
			log.error("Exception occured while fetching trip consignment deatils in getTripConsignmentLabel of TripsDAOImpl ", e);
			throw new TripApplicationException("Exception occured on getTripConsignmentLabel ", e);
		}
		return queryResults;
	}

	@Override
	public List<ConsignmentLabel> getConsignmentLabel(String shipmentNo) {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String query = QueryConstants.GET_CONSIGNMENT_LABEL;
		try {
			parameters.addValue("shipmentNo", shipmentNo);
			return new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource())
					.query(query, parameters, new ConsignmentLabelMapper());
		} catch (Exception e) {
			log.error("Exception occurred while fetching consignment_label details for shipmentNo {}, exception {}  ", shipmentNo, e);
			throw new TripApplicationException("Exception occurred while fetching consignment_label details for shipmentNo:" + shipmentNo, e);
		}
	}

    @Override
    public List<HuCountResponse> getHUCountForSDP(List<String> nodeIds, String fromDate, String toDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> sdpIds) {

		StringBuilder query = new StringBuilder( QueryConstants.HU_COUNT_FOR_SDP);
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeIds", nodeIds);

		if (!StringUtils.isBlank(fromDate) && !StringUtils.isBlank(toDate)) {
			parameters.addValue("fromDate", fromDate);
			parameters.addValue("toDate", toDate);
			query.append(" AND od.created_time BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
					+ "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ");
		}


		if (!CollectionUtils.isEmpty(sdpIds)) {
			query.append(" AND oi.node_id in (:selectedHubs) ");
			parameters.addValue("selectedHubs", sdpIds);
		}

		if (!StringUtils.isBlank(orderId)) {
			orderId = "%" + orderId + "%";
			query.append(" AND od.ORDER_ID LIKE :orderId ");
			parameters.addValue("orderId", orderId);
		}

		if (!CollectionUtils.isEmpty(orderStatus)) {
			query.append(" AND od.order_status in (:orderStatus) ");
			parameters.addValue("orderStatus", orderStatus);
		}

		if (!StringUtils.isEmpty(pinCode)) {
			query.append(" AND  od.pincode in (:pinCode) ");
			parameters.addValue("pinCode", pinCode);
		}

		if (!StringUtils.isEmpty(mId)) {
			String mid = "%" + mId + "%";
			query.append(" AND  cd.id  LIKE :mId ");
			parameters.addValue("mId", mid);
		}
		query.append(" group by oi.node_id, od.order_id ");

		List<HuCountResponse> huCountResponses;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			huCountResponses = namedParameterJdbcTemplate.query(query.toString(), parameters, new HuCountResponseMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred while executing getHUCountForSDP ", e);
		}
		log.info("HU_COUNT_FOR_SDP query has been executed successfully, fetched Rows: {} ", huCountResponses.size());
		return huCountResponses;
    }


}
