package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.WayPointUpdates;
import com.ril.newcommerce.supplychain.tms.entity.rest.ReturnItemCheck;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;

/**
B1.Divya
*/

@Service
public interface ReconcileService
{
	public ReturnItemCheck checkReturnItemMisMatchForHubTrip(String tripId);
	public List<Trip> getTripDetails(String tripId, String includeRecon, String nodeId, List<ReconcileArticle> returnItems, List<WayPointUpdates> waypointUpdates) throws Exception;
}
