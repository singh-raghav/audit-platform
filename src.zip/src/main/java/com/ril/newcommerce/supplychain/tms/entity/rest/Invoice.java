package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.Date;
import java.util.Set;

import lombok.Data;

/**
B1.Divya
*/

@Data
public class Invoice {
	
	private String invoiceNo;
	private String orderNo;
	private String shipmentNo;
	private double invoiceAmount;
	private Date invoiceDate;
	private String ewayBillNo;
	private String ewayBillStatus;
	private String customerName;
	private Set<String> huIds;
	private Set<String> bagIds;
	private Set<String> toteIds;
	

}
