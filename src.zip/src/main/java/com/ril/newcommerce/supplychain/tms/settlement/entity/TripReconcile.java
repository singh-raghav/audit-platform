package com.ril.newcommerce.supplychain.tms.settlement.entity;

import java.util.List;

public class TripReconcile {

	private String tripId;
	private String nodeType;
	private String driverName;
	private String vehicleNumber;
	private List<String> hub;
	private Integer assignedTasks;
	private Integer unassignedTasks;
	private Integer deliveredTasks;
	private Double plannedKm;
	private Double startKm;
	private Double endKm;
	private Double travelledKm;
	private MonetarySettlement monetarySettlement;
	private AdditionalCharges additionalCharges;
	private List<ReturnedAsset> returnedAssets;
	private List<ReconcileArticle> reconcileArticles;

	public String getTripId() {
		return tripId;
	}

	public void setTripId(String tripId) {
		this.tripId = tripId;
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public List<String> getHub() {
		return hub;
	}

	public void setHub(List<String> hub) {
		this.hub = hub;
	}

	public Integer getAssignedTasks() {
		return assignedTasks;
	}

	public void setAssignedTasks(Integer assignedTasks) {
		this.assignedTasks = assignedTasks;
	}

	public Integer getUnassignedTasks() {
		return unassignedTasks;
	}

	public void setUnassignedTasks(Integer unassignedTasks) {
		this.unassignedTasks = unassignedTasks;
	}

	public Integer getDeliveredTasks() {
		return deliveredTasks;
	}

	public void setDeliveredTasks(Integer deliveredTasks) {
		this.deliveredTasks = deliveredTasks;
	}

	public Double getPlannedKm() {
		return plannedKm;
	}

	public void setPlannedKm(Double plannedKm) {
		this.plannedKm = plannedKm;
	}

	public Double getStartKm() {
		return startKm;
	}

	public void setStartKm(Double startKm) {
		this.startKm = startKm;
	}

	public Double getEndKm() {
		return endKm;
	}

	public void setEndKm(Double endKm) {
		this.endKm = endKm;
	}

	public MonetarySettlement getMonetarySettlement() {
		return monetarySettlement;
	}

	public void setMonetarySettlement(MonetarySettlement monetarySettlement) {
		this.monetarySettlement = monetarySettlement;
	}

	public AdditionalCharges getAdditionalCharges() {
		return additionalCharges;
	}

	public void setAdditionalCharges(AdditionalCharges additionalCharges) {
		this.additionalCharges = additionalCharges;
	}

	public List<ReturnedAsset> getReturnedAssets() {
		return returnedAssets;
	}

	public void setReturnedAssets(List<ReturnedAsset> returnedAssets) {
		this.returnedAssets = returnedAssets;
	}

	public List<ReconcileArticle> getReconcileArticles() {
		return reconcileArticles;
	}

	public void setReconcileArticles(List<ReconcileArticle> reconcileArticles) {
		this.reconcileArticles = reconcileArticles;
	}

	public Double getTravelledKm() {
		return travelledKm;
	}

	public void setTravelledKm(Double travelledKm) {
		this.travelledKm = travelledKm;
	}

	@Override
	public String toString() {
		return "TripReconcile [tripId=" + tripId + ", nodeType=" + nodeType + ", driverName=" + driverName
				+ ", vehicleNumber=" + vehicleNumber + ", hub=" + hub + ", assignedTasks=" + assignedTasks
				+ ", unassignedTasks=" + unassignedTasks + ", deliveredTasks=" + deliveredTasks + ", plannedKm="
				+ plannedKm + ", startKm=" + startKm + ", endKm=" + endKm + ", travelledKm=" + travelledKm
				+ ", monetarySettlement=" + monetarySettlement + ", additionalCharges=" + additionalCharges
				+ ", returnedAssets=" + returnedAssets + ", reconcileArticles=" + reconcileArticles + "]";
	}



}