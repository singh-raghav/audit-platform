package com.ril.newcommerce.supplychain.tms.listeners;

import java.util.HashMap;
import java.util.Map;

/**
 * B1.Divya
 */

public enum FlowName {

	PUBLISHTRIP("PublishTrip"),
	FLUIDLOADING_PUBLISHTRIP("publishFluidTripProcessor"),
	CREATE_FLUIDLOADING_SECONDARYTRIP("createFluidLoadingSecondaryTrip"),
	ORDERDETAILS("Shipment"), 
	TRIPFEED("TripFeed"),
	CONNECTIONTRIPFEED("ConnectionTripFeed"),
	PUBLISHCONNECTIONTRIP("PublishConnectionTrip"),
	ORDERINVOICEDETAILS("InvoiceDetail"),
	ADDLABEL("LabelFeed"),
	PACKFEED("PackFeed"),
	LABELSTATUS("LABEL_STATUS"),
	EWAYBILLRESPONSE("EwayBillResponse"),
	EWAYBILLPUBLISH("EwayBillPublish"),
	EWAYBILLREQUEST("EwayBillRequest"),
	LOADINGSTART("LoadingStart"),
	LOADINGCOMPLETE("LoadingComplete"),
	POSTLOADINGCOMPLETE("PostLoadingComplete"),
	POSTFLUIDLOADINGCOMPLETE("PostFluidLoadingComplete"),
	UNLOADINGSTART("UnloadingStart"),
	UNLOADINGCOMPLETE("UnloadingComplete"),
	SPLIT("Split"),
	MERGE("Merge"),
	SETTLE("Settle"),
	PUBLISHTOGRAB("PublishToGrab"),
	WAYPOINTUPDATES("WaypointDeliverySummary"),
	CANCELLEDSTATUS("CancelledStatus"),
	RETURN_CANCELLEDSTATUS("ReturnCancelledStatus"),
	RETURNINVOICE("ReturnInvoice"),
	FCDELAYED("FCDelayStatus"),
	RETURNITEMSAP("ReturnItemSap"),
	MANUALTRIP("ManualTrip"),
	ORDER_STATUS_UPDATE("OrderStatusUpdate"),
	ORDER_STATUS_CREATED("OrderCreated"),
	ORDER_STATUS_CANCELLED("OrderCancelled"),
	ORDER_STATUS_FC_DELAYED("OrderFcDelayed"),
	ORDER_STATUS_SHIPPED("OrderShipped"),
	ORDER_STATUS_DELIVERED("OrderDelivered"),
	ORDER_STATUS_RETURNED("OrderReturned"),
	ORDER_STATUS_PARTIALLY_DELIVERED("OrderPartiallyDelivered"),
	CREATESHUTTLETRIP("CreateShuttleTrip"),
	TRIPSETTLEUPDATE("TripSettleUpdate"),
	SETTLEMENTUPDATE("SettlementUpdate"),
	FLUIDLOADING("FluidLoading"),
	STAGING_FEED("StagingFeed");

	private static final Map<String, FlowName> map = new HashMap<>();

	private String value;

	private FlowName(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

	static {
		for (FlowName flowName : FlowName.values())
			map.put(flowName.getValue(), flowName);
	}

	public static FlowName get(String value) {
		return map.get(value);
	}

}
