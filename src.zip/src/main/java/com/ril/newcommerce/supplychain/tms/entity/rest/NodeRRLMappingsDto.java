/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.entity.rest;

import lombok.Data;

/**
 * @author Raghav1.Singh
 *
 */
@Data
public class NodeRRLMappingsDto {
	
	private String nodeId;
	private String rrlId;
	private String siteName;
	private String siteAddress;

}
