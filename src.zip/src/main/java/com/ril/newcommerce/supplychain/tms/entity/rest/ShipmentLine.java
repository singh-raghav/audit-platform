package com.ril.newcommerce.supplychain.tms.entity.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"ItemID",
"PrimeLineNo"
})*/
public class ShipmentLine {

	@JsonProperty("ItemID")
	private String itemID;
	@JsonProperty("PrimeLineNo")
	private String primeLineNo;

	@JsonProperty("ItemID")
	public String getItemID() {
		return itemID;
	}

	@JsonProperty("ItemID")
	public void setItemID(String itemID) {
		this.itemID = itemID;
	}

	@JsonProperty("PrimeLineNo")
	public String getPrimeLineNo() {
		return primeLineNo;
	}

	@JsonProperty("PrimeLineNo")
	public void setPrimeLineNo(String primeLineNo) {
		this.primeLineNo = primeLineNo;
	}

}