package com.ril.newcommerce.supplychain.tms.service.impl;

import com.google.common.collect.Lists;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.OrderDetailsDAO;
import com.ril.newcommerce.supplychain.tms.dao.OrderInvoiceDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.*;
import com.ril.newcommerce.supplychain.tms.enums.OrderClassification;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.NetworkCommunicationException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.response.*;
import com.ril.newcommerce.supplychain.tms.service.ConsignmentLabelService;
import com.ril.newcommerce.supplychain.tms.service.ConsignmentOrderPdfGenerationService;
import com.ril.newcommerce.supplychain.tms.service.OrderDetailsService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import com.ril.newcommerce.supplychain.tms.util.OrderDetailsUtil;
import com.ril.newcommerce.supplychain.tms.util.RestClient;
import com.ril.newcommerce.supplychain.tms.util.Utility;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

/**
 * B1.Divya
 */

@Component
@Service
public class OrderDetailsServiceImpl implements OrderDetailsService {
	
	private static final Logger log = LoggerFactory.getLogger(TripServiceImpl.class);

	@Autowired
	private OrderDetailsDAO orderDetailsDAO;
		
	@Autowired
	private TripsDAO tripsDAO;
	
	@Autowired
	private OrderInvoiceDAO orderInvoiceDAO;
	
	@Value("${thread.future.timeout}")
	private int timeOut;
	
	@Autowired
	private TripExecutor tripExecutor;

	@Autowired
	private ConsignmentLabelService consignmentLabelService;

	@Autowired
	private RestClient restClient;

	@Autowired
	private JAXBContextConfig jAXBContextConfig;

	@Value("${oms.rfgetinvoicepdf.url}")
	private String rfGetInvoicePdfURL;

	@Value("${oms.rfgetinvoicepdf.userName}")
	private String omsUserName;

	@Value("${oms.rfgetinvoicepdf.password}")
	private String omsPassword;

	@Autowired
	private TripService tripService;

	@Autowired
	private ConsignmentOrderPdfGenerationService consignmentOrderPdfGenerationService;

	@Override
	public boolean addOrderDetails(List<OrderDetails> orderDetails) {
		
		boolean isDuplicate = false;		
		try {			    
				orderDetailsDAO.insertOrderDetails(orderDetails);
				log.info("Added order details");
			}
		catch(DuplicateKeyException ex) {
			
			isDuplicate = true;
			
			String orderId = orderDetails.get(0).getOrderId();
			String shipmentNo = orderDetails.get(0).getShipmentNo();
			Timestamp slotStartTime = orderDetails.get(0).getSlotStartTime();
			Timestamp slotEndTime = orderDetails.get(0).getSlotEndTime();
			
			log.warn("Entry already exists for unique key OrderId {} and shipmentNo {}", orderId, shipmentNo);
			
			List<String> orderIds = new ArrayList<String>();
			List<String> shipmentNos = new ArrayList<String>();
			orderIds.add(orderId);
			shipmentNos.add(shipmentNo);
			
			List<OrderDetails> existingOrderDetails = new ArrayList<OrderDetails>();
			existingOrderDetails = getOrderDetails(orderIds, shipmentNos);
			log.info("Select query for getting order details executed..");
			
			Timestamp existingSlotStartTime = null;
			Timestamp existingSlotEndTime = null;
			for (OrderDetails orderDetails2 : existingOrderDetails) {				
			    existingSlotStartTime = orderDetails2.getSlotStartTime();
				existingSlotEndTime = orderDetails2.getSlotEndTime();
			}
			//throwing validation exception if the slot timings are same
			if(slotStartTime.compareTo(existingSlotStartTime)==0 && slotEndTime.compareTo(existingSlotEndTime)==0) {
				throw new ValidationException("The slot timings are already correct for order:"+orderId+
						"and shipmentNo:"+shipmentNo);
			}else {
				//updating slot timings 
				updateOrderDetails(slotStartTime, slotEndTime, orderId, shipmentNo);
				log.info("Updated slot timinngs for orderId {} and shipmentNo {}",orderId,shipmentNo);
			}	
			
		}
		catch(Exception e) {
			log.error("Error occured in inserting order details ",e);
			throw new DataProcessingException("Got Exception in OrderDetailsServiceImpl addOrderDetails",e);
		}
		
		return isDuplicate;
	}
	
	@Override
	public void updateOrderDetails(Timestamp slotStartTime, Timestamp slotEndTime, String orderId, String shipmentNo) {
		
		orderDetailsDAO.updateOrderDetails(slotStartTime, slotEndTime, orderId, shipmentNo);
		log.info("Updated order details slot timings..");
		
	}
	
	@Override
	public List<Consignment> getTripOrderDetails(String tripId, String nodeId, List<String> status, List<String> shipmentNos,String orderclassification)
	{
		try
		{
			return orderDetailsDAO.getTripOrderDetails(tripId,nodeId,status,shipmentNos,orderclassification);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on getOrderDetails of OrderDetailsServiceImplImpl", e);
		}
		
	}

	@Override
	public List<Consignment> getTripOrderAndAdditionalDetails(String tripId, String nodeId, List<String> status, List<String> shipmentNos,String orderclassification) throws InterruptedException, ExecutionException, TimeoutException {
		Collection<Future<?>> futures = new LinkedList<Future<?>>();
		
			Future<List<Invoice>> invoiceList = tripExecutor.getTripExecutor().submit(() -> orderInvoiceDAO.getInvoicesForTrip(tripId, status));
			Future<List<Consignment>> consignmnets=tripExecutor.getTripExecutor().submit(() -> orderDetailsDAO.getTripOrderDetails(tripId,nodeId,status,shipmentNos,orderclassification));
			Future<Map<String, Map<String, List<ConsignmentLabel>>>> labels=tripExecutor.getTripExecutor().submit(() ->consignmentLabelService.getTripConsignmentLabel(tripId, nodeId));
		futures.add(invoiceList);
		futures.add(consignmnets);
		futures.add(labels);
		
		for (Future<?> future : futures) {
			future.get(timeOut,TimeUnit.SECONDS);
		}

		Map<String, List<ConsignmentLabel>> shipmentLabels=null;
		if(null!=labels.get() && null!=labels.get().get(tripId))
			shipmentLabels=labels.get().get(tripId);

		for(Consignment consignmnet:consignmnets.get())
		{
			if (null != invoiceList.get() && !invoiceList.get().isEmpty()) {
				Invoice invoice = invoiceList.get().stream()
						.filter(p -> consignmnet.getOrderId().equals(p.getOrderNo())).findAny().orElse(null);
				if (null != invoice)
					consignmnet.setInvoice(invoice);
			}
			if(!MapUtils.isEmpty(shipmentLabels))
			{
				consignmnet.setLabel(shipmentLabels.get(consignmnet.getShipmentNo()));
			}
		}
		return consignmnets.get();
	}

	@Override
	public boolean isAllReturnOrders(String tripId, String nodeId) throws InterruptedException, ExecutionException, TimeoutException  {
		List<String> status = new ArrayList<String>();
		status.add(OrderStatus.ACTIVE.getValue());

		List<Consignment> consignments = getTripOrderAndAdditionalDetails(tripId,nodeId, status, null,null);

		List<String> fwdOrderIds = consignments.stream()
				.filter(consignment->OrderClassification.Forward.getValue().equals(consignment.getOrderClassification()))
				.map(mapper -> mapper.getOrderId())
				.collect(Collectors.toList());
		if(CollectionUtils.isEmpty(fwdOrderIds))
			return true;
		else
			return false;

	}

	@Override
	public void updateOrderDetails(List<Consignment> consignment) {

		List<String> whereList = consignment.stream().map(Consignment::getOrderId).collect(Collectors.toList());
		Map<String, Object> whereMap = new HashMap<>();
		whereMap.put("ORDER_ID", whereList);

		Map<String, String> setMap = new HashMap<>();
		setMap.put("ORDER_STATUS", OrderState.SHIPPED.getValue());

		orderDetailsDAO.updateOrderDetails(setMap, whereMap);
	}

	@Override
	public void updateOrderDetails(String orderId, OrderState orderState) {
		Map<String, String> setMap = new HashMap<>();
		setMap.put("ORDER_STATUS", orderState.getValue());

		Map<String, Object> whereMap = new HashMap<>();
		whereMap.put("ORDER_ID", orderId);
		orderDetailsDAO.updateOrderDetails(setMap, whereMap);
	}

	@Override
	public List<OrderDetails> getOrderDetails(List<String> orderId, List<String> shipmentNo) {
		try {
			return orderDetailsDAO.getOrderDetails(orderId, shipmentNo);
		} catch (Exception e) {
			log.error("Exception occurred in getOrderDetails in orderdetailsserviceImpl", e);
			throw new TripApplicationException(
					"Exception occurred in getOrderDetails in orderdetailsserviceImpl ", e);
		}

	}

	
	@Override
	public void updateOrderstatus(List<String> orderIds, String status, String flowName, String modifiedBy) {
		try {
			orderDetailsDAO.updateOrderStatus(orderIds, status, flowName, modifiedBy);
		} catch (Exception e) {
			log.error("Exception occured in updateOrderstatus in orderdetailsserviceImpl", e);
			throw new TripApplicationException(
					"Exception occured in updateOrderstatus in orderdetailsserviceImpl ", e);
		}
	}

	private void validateInput(Object... inputs) {
		for (Object input : inputs) {
			Objects.requireNonNull(input,  " (nodeName | pageSize | pageIndex) can't be null");
		}
	}

	public void addCustomerDetails(List<OrderDetails> orderDetails) {
		try {
			orderDetailsDAO.insertCustomerDetails(orderDetails);
			log.info("Added customer details");
		}
		catch (Exception e) {
			log.error("Error occured in inserting customer details ",e);
			throw new DataProcessingException("Got Exception in OrderDetailsServiceImpl addCustomerDetails",e);
		}
	}
	
	@Override
	public OrderListResponse getOrders(List<String> nodeName, Integer pageSize, Integer pageIndex, String fromDate, String toDate, String orderId, List<String> orderStatuses, List<String> orderTypes, List<String> movementTypes, List<String> destHubs) throws InterruptedException, ExecutionException {

		log.info("Inside getOrders of OrderDetailsServiceImpl, given nodes are  :{}", nodeName);

		try {

			validateInput(nodeName, pageSize, pageIndex);
			toDate = DateUtility.getToDate(toDate);
			fromDate = DateUtility.getFromDate(fromDate);

			return orderDetailsDAO.getOrders(nodeName,  pageSize, pageIndex, fromDate, toDate, orderId, orderStatuses, orderTypes, movementTypes, destHubs);

		} catch (Exception e) {
			log.error("Exception occurred while providing Order Details", e);
			throw new TripApplicationException("Exception occurred in getOrders of OrderDetailsServiceImpl ", e);
		}
	}

    @Override
    public OrderListResponseFluidLoading tripOrderViewFluidLoading(List<String> nodeIds, Integer pageSize, Integer pageIndex, String fromDate, String toDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs) {
        if (!CollectionUtils.isEmpty(nodeIds)) {

            if ((null != toDate) && (null != fromDate)) {
                toDate = DateUtility.getToDate(toDate);
                fromDate = DateUtility.getFromDate(fromDate);
            }

            return orderDetailsDAO.tripOrderViewFluidLoading(nodeIds, pageSize, pageIndex, fromDate,
                    toDate, orderId, orderStatus, mId, pinCode, destHubs);
        }
        throw new DataProcessingException("NodeId information is missing in the request");
    }

    @Override
    public OrderListResponseFluidLoading consignmentViewFluidLoading(List<String> nodeIds, Integer pageSize, Integer pageIndex, String fromDate, String toDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs) {
        if (!CollectionUtils.isEmpty(nodeIds)) {

            if ((null != toDate) && (null != fromDate)) {
                toDate = DateUtility.getToDate(toDate);
                fromDate = DateUtility.getFromDate(fromDate);
            }

            return orderDetailsDAO.consignmentViewFluidLoading(nodeIds, pageSize, pageIndex, fromDate,
                    toDate, orderId, orderStatus, mId, pinCode, destHubs);
        }
        throw new DataProcessingException("NodeId information is missing in the request");
    }

    @Override
	public List<OrderDetails> getOrderDetails(String tripId) {
		if (!StringUtils.isBlank(tripId)) {
			return orderDetailsDAO.getOrderDetails(tripId);
		}
		return new ArrayList<>();
	}

	@Override
	public OrderDetails getOrderDetail(String orderId) {
		List<OrderDetails> orderDetails = getOrderDetails(Lists.newArrayList(orderId), new ArrayList<>());
		if (!CollectionUtils.isEmpty(orderDetails)) {
			return orderDetails.get(0);
		}
		throw new TripApplicationException("No record found for order " + orderId);
	}

	@Override
	public InvoicePdfDetail getInvoiceDetail(String orderId, String shipmentNo) throws JAXBException,
			NetworkCommunicationException, RestClientException {
		Map<String, String> headers = generateOMSRestCallHeaders();
		InvoicePdfDetailRequestBody invoicePdfDetailRequestBody = getInvoicePdfDetailRequestBody(orderId, shipmentNo);
		StringWriter sw = marshalInvoicePdfDetailRequestBody(invoicePdfDetailRequestBody);
		String response = restClient.post(rfGetInvoicePdfURL, headers, null, sw.toString());
		return unmarshalInvoicePdfDetailRequestBody(response);
	}

	@Override
	public List<SDPSummaryResponse> getSDPSummary(List<String> nodeIds, List<String> sdpIds, String startDate, String endDate) throws Exception {

		if (CollectionUtils.isEmpty(sdpIds)) {
			return new ArrayList<>();
		}

		Collection<Future<?>> futures = new LinkedList<>();
		Future<List<TripCountResponse>> tripCountResponses = tripExecutor.getTripExecutor().submit(() -> tripService.getTripCount(nodeIds, sdpIds, startDate, endDate));
		Future<List<OrderCountResponse>> orderCountResponses = tripExecutor.getTripExecutor().submit(() -> orderDetailsDAO.orderCountForSDP(nodeIds, sdpIds, startDate, endDate));
		Future<List<HuCountResponse>> huCountResponses = tripExecutor.getTripExecutor().submit(() -> consignmentLabelService.huCountForSDP(nodeIds, startDate, endDate, null, null, null, null, sdpIds));
		futures.add(tripCountResponses);
		futures.add(orderCountResponses);
		futures.add(huCountResponses);

		for (Future<?> future : futures) {
			future.get(timeOut, TimeUnit.SECONDS);
		}
		return OrderDetailsUtil.createSummaryResponse(tripCountResponses.get(), orderCountResponses.get(), huCountResponses.get());

	}

    private InvoicePdfDetailRequestBody getInvoicePdfDetailRequestBody(String orderId, String shipmentNo){
		InvoicePdfDetailRequestBody.Order order = new InvoicePdfDetailRequestBody.Order();
		order.setOrderNo(orderId);
		order.setShipmentNo(shipmentNo);
		InvoicePdfDetailRequestBody invoicePdfDetailRequestBody = new InvoicePdfDetailRequestBody();
		invoicePdfDetailRequestBody.setOrder(order);
		return invoicePdfDetailRequestBody;
	}
	private Map<String, String> generateOMSRestCallHeaders() {
		String base64Creds = Utility.getBase64EncodedString(omsUserName + ":" + omsPassword);
		Map<String, String> headers = new HashMap<>();
		headers.put(Constants.AUTHORIZATION, "Basic " + base64Creds);
		headers.put("CONTENT_TYPE", MediaType.APPLICATION_XML_VALUE);
		headers.put("Accept", MediaType.APPLICATION_XML_VALUE);
		return headers;
	}

	private StringWriter marshalInvoicePdfDetailRequestBody(InvoicePdfDetailRequestBody invoicePdfDetailRequestBody)
				throws JAXBException {
		StringWriter sw = new StringWriter();
		JAXBContext jaxbContext = jAXBContextConfig.getJaxbContextInstance(InvoicePdfDetailRequestBody.class);
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.marshal(invoicePdfDetailRequestBody, sw);
		return sw;
	}

	private InvoicePdfDetail unmarshalInvoicePdfDetailRequestBody(String response) throws JAXBException {
		StringReader reader = new StringReader(response);
		JAXBContext jaxbContext = jAXBContextConfig.getJaxbContextInstance(InvoicePdfDetail.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		InvoicePdfDetail invoicePdfDetail = (InvoicePdfDetail) unmarshaller.unmarshal(reader);
		return invoicePdfDetail;
	}

	public ResponseEntity getConsignmentOrderPdf(OrderListResponseFluidLoading orderListResponse){
		return consignmentOrderPdfGenerationService.createPdf(orderListResponse);
	}

	@Override
	public List<Consignment> getUnplannedOrderList(String nodeId) {
		List<Consignment> consignments = orderDetailsDAO.getUnplannedCustomerReturnOrder(nodeId);
		List<Consignment> resheduledConsignments = orderDetailsDAO.getUnplannedRescheduledOrders(nodeId);
		if(!resheduledConsignments.isEmpty())
			consignments.addAll(resheduledConsignments);
		return consignments;
	}

	@Override
	public String getOrderIdForShipment(String shipmentNo) {

		log.info("Fetching order id for shipment no : {}", shipmentNo);
		String orderId = orderDetailsDAO.getOrderIdForShipment(shipmentNo);
		if (StringUtils.isBlank(orderId)) {
			throw new TripApplicationException("Order doesn't exist for shipment no " + shipmentNo);
		}
		return orderId;
	}
}
