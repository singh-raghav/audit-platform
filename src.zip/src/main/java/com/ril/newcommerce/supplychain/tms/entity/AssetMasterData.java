package com.ril.newcommerce.supplychain.tms.entity;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssetMasterData {
	
	private String assetId;
	private String assetName;
	private String hsnCode;
	private double price;
	private String uom;
	private Double quantity;
	
	public Double getQuantity() {
		return quantity;
	}
	
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	
	public String getAssetId() {
		return assetId;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getHsnCode() {
		return hsnCode;
	}
	public void setHsnCode(String hsnCode) {
		this.hsnCode = hsnCode;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}

}
