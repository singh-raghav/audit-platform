package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"Load"
})*/
public class HubTripDetails {

	@JsonProperty("Load")
	private List<Load> load = null;

	@JsonProperty("Load")
	public List<Load> getLoad() {
		return load;
	}

	@JsonProperty("Load")
	public void setLoad(List<Load> load) {
		this.load = load;
	}

}