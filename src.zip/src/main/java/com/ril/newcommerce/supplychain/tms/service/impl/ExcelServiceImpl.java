package com.ril.newcommerce.supplychain.tms.service.impl;

import com.google.common.collect.Lists;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.ExcelCreationException;
import com.ril.newcommerce.supplychain.tms.response.OrderExcelViewResponse;
import com.ril.newcommerce.supplychain.tms.service.ExcelService;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

@Service
public class ExcelServiceImpl implements ExcelService {

    @Autowired
    private WayPointUpdatesServiceImpl wayPointUpdatesService;

    @Override
    public ResponseEntity<InputStreamSource> createExcel(String tripId) {
        List<OrderExcelViewResponse> excelViewResponses = wayPointUpdatesService.getOrderViewExcel(tripId);

        if(CollectionUtils.isEmpty( excelViewResponses)){
            throw new DataProcessingException("No record found!");
        }

        List<String> header = Lists.newArrayList(
                "Date",
                "Trip ID",
                "MID",
                "Merchant Name",
                "Order ID",
                "Order Classification",
                "Order type",
                "Order status",
                "Expected cash",
                "Cash Collected ",
                "Vehicle Number",
                "Rider Name"
        );
        List<List<String>> rows = createRowsForOrderView(excelViewResponses);
        return createExcel(header, rows, tripId);
    }

    private List<List<String>> createRowsForOrderView(List<OrderExcelViewResponse> excelViewResponses) {

        List<List<String>> rows = new ArrayList<>();
        for (OrderExcelViewResponse excelViewResponse : excelViewResponses) {
            rows.add(Lists.newArrayList(
                    excelViewResponse.getDate(),
                    excelViewResponse.getTripId(),
                    excelViewResponse.getMid(),
                    excelViewResponse.getMerchantName(),
                    excelViewResponse.getOrderId(),
                    excelViewResponse.getClassification(),
                    excelViewResponse.getMop(),
                    excelViewResponse.getOrderStatus(),
                    String.valueOf(
                            new BigDecimal(excelViewResponse.getAmountPaid() + Math.abs(excelViewResponse.getRoundOffAmount()))
                                    .setScale(2, RoundingMode.HALF_UP)),
                    String.valueOf(excelViewResponse.getAmountPaid()),
                    excelViewResponse.getVehicleNumber(),
                    excelViewResponse.getRiderName()
                    ));
        }
        return rows;
    }


    public ResponseEntity<InputStreamSource> createExcel(List<String> header, List<List<String>> rows, String sheetName) {
        SXSSFWorkbook wb = new SXSSFWorkbook(rows.size() + 1);
        Sheet sh = wb.createSheet(sheetName);
        createHeader(sh, header);
        createRows(sh, rows);
        String destFileName = sheetName.concat(".xlsx");

        File outDir = new File(new File("."), Constants.PDF.PDF_FOLDER);
        outDir.mkdirs();
        try (OutputStream fileStream = new java.io.FileOutputStream(new File(outDir, destFileName));
             OutputStream bufferedOutputStream = new java.io.BufferedOutputStream(fileStream)) {
            wb.write(bufferedOutputStream);
            wb.dispose();
            return ResponseEntityFactory.getPDFResponseSuccess(destFileName);
        } catch (Exception e) {
            throw new ExcelCreationException("Excel generation failed!", e);
        }

    }

    private void createHeader(Sheet sh, List<String> header) {
        Row row = sh.createRow(0);
        for (int cellnum = 0; cellnum < header.size(); cellnum++) {

            Cell cell = row.createCell(cellnum);
            cell.setCellValue(header.get(cellnum));
        }
    }

    private void createRows(Sheet sh, List<List<String>> rowData) {
        int rownum = 1;
        for (List<String> rowDatum : rowData) {
            Row row = sh.createRow(rownum++);
            for (int cellnum = 0; cellnum < rowDatum.size(); cellnum++) {

                Cell cell = row.createCell(cellnum);
                cell.setCellValue(rowDatum.get(cellnum));
            }
        }
    }
}
