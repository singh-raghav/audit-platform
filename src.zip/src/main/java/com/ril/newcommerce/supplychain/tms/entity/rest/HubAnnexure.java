package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

import lombok.Data;

/**
B1.Divya
*/
@Data
public class HubAnnexure {
	private String hubId;
	private String hubName;
	private int totalInvoiceOrders;
	private int totalInvoiceHUs;
	private List<Invoice> invoices;

	public String getHubId() {
		return hubId;
	}
	public void setHubId(String hubId) {
		this.hubId = hubId;
	}
	public String getHubName() {
		return hubName;
	}
	public void setHubName(String hubName) {
		this.hubName = hubName;
	}
	public int getTotalInvoiceOrders() {
		return totalInvoiceOrders;
	}
	public void setTotalInvoiceOrders(int totalInvoiceOrders) {
		this.totalInvoiceOrders = totalInvoiceOrders;
	}
	public int getTotalInvoiceHUs() {
		return totalInvoiceHUs;
	}
	public void setTotalInvoiceHUs(int totalInvoiceHUs) {
		this.totalInvoiceHUs = totalInvoiceHUs;
	}
	public List<Invoice> getInvoices() {
		return invoices;
	}
	public void setInvoices(List<Invoice> invoices) {
		this.invoices = invoices;
	}
}
