package com.ril.newcommerce.supplychain.tms.service.challan;

import org.xml.sax.InputSource;

import com.ril.newcommerce.supplychain.tms.entity.ArticleInfo;
import com.ril.newcommerce.supplychain.tms.entity.DeliveryChallan;

public class ChallanInputSource extends InputSource {
    private DeliveryChallan deliveryChallan;
    private ArticleInfo articleInfo;

    public ChallanInputSource(DeliveryChallan deliveryChallan) {
        this.deliveryChallan = deliveryChallan;
    }

    public ChallanInputSource(DeliveryChallan deliveryChallan , ArticleInfo articleInfo) {
        this.deliveryChallan = deliveryChallan;
        this.articleInfo = articleInfo;
    } 
    
    public ArticleInfo getArticleInfo() {
		return articleInfo;
	}
    
    public void setArticleInfo(ArticleInfo articleInfo) {
		this.articleInfo = articleInfo;
	}
    
    public DeliveryChallan getDeliveryChallan() {
        return deliveryChallan;
    }

    public void setDeliveryChallan(DeliveryChallan deliveryChallan) {
        this.deliveryChallan = deliveryChallan;
    }
}
