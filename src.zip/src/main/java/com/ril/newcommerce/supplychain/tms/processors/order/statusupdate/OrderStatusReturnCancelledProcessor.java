package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.processors.Processor;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import com.ril.newcommerce.supplychain.tms.tibco.entity.ReturnOrderStatuses;
import com.ril.newcommerce.supplychain.tms.util.OrderStatusFeedFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.jms.Message;
import javax.jms.TextMessage;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Qualifier(Constants.CANCEL_RETURN_ORDER_PROCESSOR)
@Slf4j
@Service
public class OrderStatusReturnCancelledProcessor implements Processor {

    @Autowired
    private JAXBContextConfig jAXBContextConfig;

    @Autowired
    private TripOrdersService tripOrderService;

    @Value("${tripapp.queue}")
    private String queueName;

    @Autowired
    private JMSPublisher jmsPublisher;

    @Override
    public void processMessage(Message message, String flowName) throws Exception {
        StringReader reader = new StringReader(((TextMessage) message).getText());
        ReturnOrderStatuses returnOrderStatuses = (ReturnOrderStatuses) jAXBContextConfig.getJaxbContextInstance(ReturnOrderStatuses.class)
                .createUnmarshaller().unmarshal(reader);
        List<String> orders = returnOrderStatuses.getReturnOrderStatus().stream().map(ReturnOrderStatuses.ReturnOrderStatus::getReturnOrderNo).collect(Collectors.toList());

        log.debug("Cancel return order request for order: {}", orders);
        tripOrderService.updateShipmentStatus(OrderStatus.SUSPEND.getValue(), orders, flowName, flowName);

        publishOrderStatusFeed(orders, OrderState.CANCELLED);
    }

    private void publishOrderStatusFeed(List<String> orderIds, OrderState orderState) {

        log.info("Publishing order status update feed for return order {}, state {} ", orderIds, orderState.getValue());
        List<OrderDetails> orderDetails = new ArrayList<>();
        for (String orderId : orderIds) {
            OrderDetails orderDetail = new OrderDetails();
            orderDetail.setOrderId(orderId);
            orderDetails.add(orderDetail);
        }

        jmsPublisher.inputToQueue(queueName, OrderStatusFeedFactory.getInstance(orderDetails, orderState, Constants.CANCEL_RETURN_ORDER_PROCESSOR), FlowName.ORDER_STATUS_UPDATE.getValue(), null, OrderStatusFeed.class);
    }
}
