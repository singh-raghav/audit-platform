package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Qualifier(Constants.ORDER_PROCESSOR.SHIPPED_PRE_PROCESSOR)
@Service
public class OrderStatusShippedPreProcessor implements OrderStatusUpdatePreProcessor {

    @Autowired
    private TripService tripService;

    @Override
    public boolean validateUpdate(OrderStatusFeed.Order order) {
       boolean  validatedForBatch = false;
        if (!isTripStarted(order.getShipmentNo())) {
            throw new TripApplicationException("Order status update to SHIPPED failed as trip not yet started. Order Id : " + order.getOrderId() + "Shipment No : " + order.getShipmentNo());
        }
        return  validatedForBatch = true;
    }

    private boolean isTripStarted(String shipmentNo) {
        return tripService.isTripStared(shipmentNo);
    }
}
