package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.Invoice;
import com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill.Trip.TripOrders.TripOrder;
import com.ril.newcommerce.supplychain.tms.tibco.invoice.entity.InvoiceDetail;

/**
B1.Divya
*/

public interface OrderInvoiceDAO {
	
	int insertOrderInvoiceDetails(Invoice invoice);
	
	List<Invoice> getInvoicesForTrip(String tripId,List<String> status);
	
	int updateEwayBillStatus(List<TripOrder> tripOrders);

	public boolean isEwayBillGenerated(String tripId);

	List<Invoice> findOrderInvoiceByTripId(String tripId);

	List<Invoice> findOrderInvoiceByShipmentNo(String shipmentNo);

	int insertConsignmentInvoiceDetails(InvoiceDetail invoiceDetails);

	int getInvoiceCount(String OrderId);
}
