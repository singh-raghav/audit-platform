/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.entity;

import java.sql.Timestamp;
import java.util.List;

import com.ril.newcommerce.supplychain.tms.enums.MovementType;

/**
 * @author Raghav1.Singh
 *
 */

public class ConnectionTrip {
	
	private String tripId;
	private String tripType;
	private String sourceNodeId;
	private Timestamp tripCreationTime;
	private String status;
	private String createdBy;
	private String flowname;
	private int version;
	private MovementType movementType;
	private int sequence;
	private String externalRefId;
	private List<String> connections;
	
	public List<String> getConnections() {
		return connections;
	}
	public void setConnections(List<String> connections) {
		this.connections = connections;
	}
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public String getTripType() {
		return tripType;
	}
	public void setTripType(String tripType) {
		this.tripType = tripType;
	}
	public String getSourceNodeId() {
		return sourceNodeId;
	}
	public void setSourceNodeId(String sourceNodeId) {
		this.sourceNodeId = sourceNodeId;
	}
	public Timestamp getTripCreationTime() {
		return tripCreationTime;
	}
	public void setTripCreationTime(Timestamp tripCreationTime) {
		this.tripCreationTime = tripCreationTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getFlowname() {
		return flowname;
	}
	public void setFlowname(String flowname) {
		this.flowname = flowname;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public MovementType getMovementType() {
		return movementType;
	}
	public void setMovementType(MovementType movementType) {
		this.movementType = movementType;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public String getExternalRefId() {
		return externalRefId;
	}
	public void setExternalRefId(String externalRefId) {
		this.externalRefId = externalRefId;
	}

}
