package com.ril.newcommerce.supplychain.tms.entity;

import com.ril.newcommerce.supplychain.tms.tibco.waypoint.entity.Waypoint;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Invoice")
public class InvoicePdfDetail {
    @XmlAttribute(name = "EncodedPdfUrl")
    private String encodedPdfUrl;
    @XmlAttribute(name = "OrderNo")
    private String orderNo;
    @XmlAttribute(name = "ShipmentNo")
    private String shipmentNo;


    public String getEncodedPdfUrl() {
        return encodedPdfUrl;
    }

    public void setEncodedPdfUrl(String encodedPdfUrl) {
        this.encodedPdfUrl = encodedPdfUrl;
    }


    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }


    public String getShipmentNo() {
        return shipmentNo;
    }

    public void setShipmentNo(String shipmentNo) {
        this.shipmentNo = shipmentNo;
    }
}
