/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.entity;

/**
 * @author Raghav1.Singh
 *
 */
public class TripSettleDetails {
	
	private String orderId;
	private String shipmentNo;
	private double amountPaid;
	private double roundOffAmount;
	private double shortAmount;
	
	public double getShortAmount() {
		return shortAmount;
	}
	public void setShortAmount(double shortAmount) {
		this.shortAmount = shortAmount;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getShipmentNo() {
		return shipmentNo;
	}
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}
	public double getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}
	public double getRoundOffAmount() {
		return roundOffAmount;
	}
	public void setRoundOffAmount(double roundOffAmount) {
		this.roundOffAmount = roundOffAmount;
	}

}
