package com.ril.newcommerce.supplychain.tms.listeners;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.springframework.stereotype.Service;

/**
B1.Divya
*/

@Service
public class JAXBContextConfig 
{

	private Map<Class<?>, JAXBContext> contextMap = new ConcurrentHashMap<>();

	public JAXBContext getJaxbContextInstance(Class<?> cls) throws JAXBException 
	{		
		if(contextMap.get(cls) == null) {
			contextMap.put(cls, JAXBContext.newInstance(cls));
		}
		
		return contextMap.get(cls);
	}
}
