package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.response.OrderViewResponseForFluidLoading;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderViewResponseForFluidLoadingMapper implements ResultSetExtractor<List<OrderViewResponseForFluidLoading>> {
    @Override
    public List<OrderViewResponseForFluidLoading> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<OrderViewResponseForFluidLoading> orderDetailsList = new ArrayList<>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            OrderViewResponseForFluidLoading order = new OrderViewResponseForFluidLoading();
            order.setOrderId(rs.getString("ORDER_ID"));
            order.setOrderPlacedDate(rs.getTimestamp("ORDER_DATE"));
            order.setDeliveryPromisedDate(rs.getTimestamp("SLOT_START_TIME"));
            order.setOrderType(new StringBuilder(rs.getString("ORDER_TYPE")).append(" - ").append(rs.getString("ORDER_CLASSIFICATION")).toString());
            order.setCustomerPincode(rs.getString("PINCODE"));
            order.setCustomerAddress(rs.getString("ADDRESS"));
            order.setOrderStatus(rs.getString("ORDER_STATUS"));
            order.setMid(rs.getString("MID"));
            order.setCustomerName(rs.getString("NAME"));
            order.setDeliveryZoneId(rs.getString("DELIVERY_ZONE_ID"));
            order.setDestination(rs.getString("HUBID"));
            orderDetailsList.add(order);
        }
        return orderDetailsList;
    }
}
