package com.ril.newcommerce.supplychain.tms.configurations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.stereotype.Component;

import com.ril.vms.deadpool.securitycore.JwtConfigurer;
import com.ril.vms.deadpool.securitycore.JwtTokenProvider;

@Configuration
@Component
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true, prePostEnabled = true)
public class SecurityConfigAdapter extends WebSecurityConfigurerAdapter {

    private final JwtTokenProvider jwtTokenProvider;
    private final Http401UnauthorizedEntryPoint http401UnauthorizedEntryPoint;

    @Autowired
    public SecurityConfigAdapter(JwtTokenProvider jwtTokenProvider,Http401UnauthorizedEntryPoint http401UnauthorizedEntryPoint) {
        this.jwtTokenProvider = jwtTokenProvider;
        this.http401UnauthorizedEntryPoint = http401UnauthorizedEntryPoint;
    }


    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return authenticationManager();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.httpBasic().disable()
                .csrf().disable()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                .antMatchers(HttpMethod.OPTIONS).permitAll()
                .antMatchers(new String[]{"/version",
                        "/trip-mgmt/v1/login",
                        "/trip-mgmt/v1/trips/vehiclestatus",
                        "/trip-mgmt/v1/trips/asset/**",
                        "/trip-mgmt/error",
                        "/v2/api-docs",
                        "/configuration/ui",
                        "/swagger-resources/**",
                        "/configuration/security",
                        "/swagger-ui.html",
                        "/webjars/**"}).permitAll()
                .anyRequest().authenticated()
                .and()
                .apply(new JwtConfigurer(this.jwtTokenProvider))
                .and()
                .exceptionHandling().authenticationEntryPoint(this.http401UnauthorizedEntryPoint);

    }

    public void configure(WebSecurity web) {
        web.ignoring().antMatchers(HttpMethod.OPTIONS, new String[] { "/**" }).antMatchers(
        		new String[] {
                        "/trip-mgmt/v1/login",
                        "/trip-mgmt/v1/trips/asset/**",
                        "/trip-mgmt/error",
                        "/v2/api-docs",
                        "/configuration/ui",
                        "/swagger-resources/**",
                        "/configuration/security",
                        "/swagger-ui.html",
                        "/webjars/**"});
    }
}

