package com.ril.newcommerce.supplychain.tms.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public enum ReturnItemQuality {
	GOOD(1), BAD(2) , UGLY(3) , DAMAGED(4) , LOST(5) ;
	
	private int order;
	
	private ReturnItemQuality(int order) {
		this.order = order;
	}
	
	public int getOrder() {
		return order;
	}
	
	private static Map<Integer,ReturnItemQuality> map = new HashMap<>();
	
	private static Map<String,ReturnItemQuality> name = new HashMap<>();
	
	static {
		for(ReturnItemQuality quality :  ReturnItemQuality.values()) {
			map.put(quality.order,quality);
			name.put(quality.name(),quality);
		}
	}
	
	public static ReturnItemQuality getQualityByOrder(int order) {
		return map.get(order);
	}
	
	public static ReturnItemQuality getQualityByName(String value) {
		return name.get(value);
	}
	
}
