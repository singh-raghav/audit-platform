package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class AssetTypeMasterDataMapper implements ResultSetExtractor<Map<String , ChallanArticle>> {

	@Override
	public Map<String , ChallanArticle> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String , ChallanArticle>  articlesMap = new HashMap<>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			ChallanArticle article = new ChallanArticle();
			article.setArticleCode(rs.getString("ASSET_ID"));
			article.setArticleDesc(rs.getString("ASSET_DESC"));
			article.setHsnCode(rs.getString("HSNCODE"));
			article.setUOM(rs.getString("UOM"));
			article.setRate(rs.getDouble("PRICE"));
			article.setArticleType(ArticleType.ASSET.name());
			
			articlesMap.put(article.getArticleCode(), article);
		
		}
		return articlesMap;
	}

}
