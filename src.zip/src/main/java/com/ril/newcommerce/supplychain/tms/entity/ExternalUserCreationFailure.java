package com.ril.newcommerce.supplychain.tms.entity;

import com.ril.newcommerce.supplychain.tms.enums.ExternalSystem;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.sql.Clob;
import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@Getter
@Setter
@Builder
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@ToString
@Table(name = "EXTERNAL_USER_CREATION_FAILURE")
public class ExternalUserCreationFailure {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_GENERATOR")
    @GenericGenerator(name = "ID_GENERATOR", strategy = "com.ril.newcommerce.supplychain.tms.entity.config.KeyGenerator")
    @Column(name = "ID")
    private String id;

    @Column(name = "EXTERNAL_SYSTEM", length = 50, nullable = false)
    @Enumerated(EnumType.STRING)
    private ExternalSystem system;

    @Column(name = "USER_NAME", length = 50, nullable = false)
    private String userName;

    @Column(name = "REQUEST")
    @Lob
    private String request;

    @Column(name = "ERROR")
    @Lob
    private String error;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @Column(name = "CREATED_BY", length =50)
    private String createdBy;

}
