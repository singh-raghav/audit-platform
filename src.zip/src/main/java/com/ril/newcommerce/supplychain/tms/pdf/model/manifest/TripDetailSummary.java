package com.ril.newcommerce.supplychain.tms.pdf.model.manifest;

import java.util.List;

public class TripDetailSummary {
    private List<TripDetails> tripDetails;
    private String returnSealNumber;
    private String totalLoadedOrders;
    private String totalRollcagesAndPallets;
    private String totalLoadedTotes;

    public List<TripDetails> getTripDetails() {
        return tripDetails;
    }

    public void setTripDetails(List<TripDetails> tripDetails) {
        this.tripDetails = tripDetails;
    }

    public String getReturnSealNumber() {
        return returnSealNumber;
    }

    public void setReturnSealNumber(String returnSealNumber) {
        this.returnSealNumber = returnSealNumber;
    }

    public String getTotalLoadedOrders() {
        return totalLoadedOrders;
    }

    public void setTotalLoadedOrders(String totalLoadedOrders) {
        this.totalLoadedOrders = totalLoadedOrders;
    }

    public String getTotalRollcagesAndPallets() {
        return totalRollcagesAndPallets;
    }

    public void setTotalRollcagesAndPallets(String totalRollcagesAndPallets) {
        this.totalRollcagesAndPallets = totalRollcagesAndPallets;
    }

    public String getTotalLoadedTotes() {
        return totalLoadedTotes;
    }

    public void setTotalLoadedTotes(String totalLoadedTotes) {
        this.totalLoadedTotes = totalLoadedTotes;
    }
}
