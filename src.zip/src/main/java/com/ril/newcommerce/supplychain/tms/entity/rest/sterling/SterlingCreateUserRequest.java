package com.ril.newcommerce.supplychain.tms.entity.rest.sterling;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SterlingCreateUserRequest implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;
    @JsonProperty("User")
    private User User;
}
