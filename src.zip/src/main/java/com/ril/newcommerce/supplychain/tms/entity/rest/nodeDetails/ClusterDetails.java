package com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ClusterDetails implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;

    private String clusterId;
    private String name;
    private boolean isActive;
    private String externalcommunicationemail;
    private String phone;
    private int dcleadtime;
    private String createdTime;
    private String createdBy;
    private String lastUpdatedTime;
    List<NodeDetails> childNodes;
}
