package com.ril.newcommerce.supplychain.tms.entity.rest;
import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"PaidByEzetap",
"PaidByCash",
"PaidByMealCard",
"PaidBySodexo",
"PaidByCard",
"ExtnBaseTripID",
"AmountCollected"
})*/
public class Extn {

	@JsonProperty("PaidByEzetap")
	private String paidByEzetap;
	@JsonProperty("PaidByCash")
	private String paidByCash;
	@JsonProperty("PaidByMealCard")
	private String paidByMealCard;
	@JsonProperty("PaidBySodexo")
	private String paidBySodexo;
	@JsonProperty("PaidByCard")
	private String paidByCard;
	@JsonProperty("ExtnBaseTripID")
	private String extnBaseTripID;
	@JsonProperty("AmountCollected")
	private String amountCollected;

	@JsonProperty("PaidByEzetap")
	public String getPaidByEzetap() {
		return paidByEzetap;
	}

	@JsonProperty("PaidByEzetap")
	public void setPaidByEzetap(String paidByEzetap) {
		this.paidByEzetap = paidByEzetap;
	}

	@JsonProperty("PaidByCash")
	public String getPaidByCash() {
		return paidByCash;
	}

	@JsonProperty("PaidByCash")
	public void setPaidByCash(String paidByCash) {
		this.paidByCash = paidByCash;
	}

	@JsonProperty("PaidByMealCard")
	public String getPaidByMealCard() {
		return paidByMealCard;
	}

	@JsonProperty("PaidByMealCard")
	public void setPaidByMealCard(String paidByMealCard) {
		this.paidByMealCard = paidByMealCard;
	}

	@JsonProperty("PaidBySodexo")
	public String getPaidBySodexo() {
		return paidBySodexo;
	}

	@JsonProperty("PaidBySodexo")
	public void setPaidBySodexo(String paidBySodexo) {
		this.paidBySodexo = paidBySodexo;
	}

	@JsonProperty("PaidByCard")
	public String getPaidByCard() {
		return paidByCard;
	}

	@JsonProperty("PaidByCard")
	public void setPaidByCard(String paidByCard) {
		this.paidByCard = paidByCard;
	}

	@JsonProperty("ExtnBaseTripID")
	public String getExtnBaseTripID() {
		return extnBaseTripID;
	}

	@JsonProperty("ExtnBaseTripID")
	public void setExtnBaseTripID(String extnBaseTripID) {
		this.extnBaseTripID = extnBaseTripID;
	}

	@JsonProperty("AmountCollected")
	public String getAmountCollected() {
		return amountCollected;
	}

	@JsonProperty("AmountCollected")
	public void setAmountCollected(String amountCollected) {
		this.amountCollected = amountCollected;
	}

}