package com.ril.newcommerce.supplychain.tms.entity;

import java.util.Set;


import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

public class LinkDetails {

	private String rel;
	private String href;
	private HttpMethod action;
	private Set<MediaType> types;
	public String getRel() {
		return rel;
	}
	public void setRel(String rel) {
		this.rel = rel;
	}
	public String getHref() {
		return href;
	}
	public void setHref(String href) {
		this.href = href;
	}
	public HttpMethod getAction() {
		return action;
	}
	public void setAction(HttpMethod action) {
		this.action = action;
	}
	public Set<MediaType> getTypes() {
		return types;
	}
	public void setTypes(Set<MediaType> types) {
		this.types = types;
	}
	
	
}
