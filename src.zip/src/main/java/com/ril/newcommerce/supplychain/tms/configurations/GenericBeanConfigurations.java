package com.ril.newcommerce.supplychain.tms.configurations;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.util.GenericUtils;

@Configuration
public class GenericBeanConfigurations {
	
	@Bean
	@Qualifier(Constants.INTEGER_UTIL)
	public GenericUtils<Integer> getIntegerUtilty(){
		return  new GenericUtils<Integer>();
	}
	
	@Bean
	@Qualifier(Constants.STRING_UTIL)
	public GenericUtils<String> getStringUtilty(){
		return  new GenericUtils<String>();
	}
	
	

}
