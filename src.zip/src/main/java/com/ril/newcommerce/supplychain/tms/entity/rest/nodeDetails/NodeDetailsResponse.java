package com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NodeDetailsResponse implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;

    private int statusCode;
    private List<NodeDetails> nodeDetails;
    private List<ClusterDetails> clusterDetails;

}
