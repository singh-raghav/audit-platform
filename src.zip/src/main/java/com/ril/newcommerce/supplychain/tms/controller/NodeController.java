package com.ril.newcommerce.supplychain.tms.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.AssetMasterData;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.service.ChallanService;
import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
@RestController
@RequestMapping
public class NodeController {

	private static final Logger log = LoggerFactory.getLogger(NodeController.class);

	@Autowired
	private ChallanService deliveryChallanService;
		
	@GetMapping(value = "/trip-mgmt/v1/nodes/{nodeId}/assets", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getAssets(@RequestHeader(value = Constants.NODE_ID, required = true) String nodeId) {
		log.info("Get available assets at node : {}", nodeId);
		try {
			List<AssetMasterData>  assets = deliveryChallanService.getAvailableAssets();
			return Utility.getSuccessMsg(assets);
		} catch (Exception e) {
			log.error("Exception Occured on fetching the assettypes from ATS   "+ e);
			return Utility.getfailureMsg("Unable to fetch available assetTypes");
		}
	}
	
	@GetMapping(value = "/trip-mgmt/v1/nodes/{nodeId}/returnorders", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getReturnOrders(@RequestHeader(value = Constants.NODE_ID, required = true) String nodeId , 
			@RequestParam(value = Constants.SRC_NODE_ID, required = true) String srcNodeId) {
		log.info("Get available return orders at node : {}", nodeId);
		try {
			Set<String> returnOrderIds = deliveryChallanService.getAvailableOrders(nodeId,srcNodeId);
			return Utility.getSuccessMsg(returnOrderIds);
		} catch (Exception e) {
			log.error("Exception Occured on fetching return orders for node   "+ e);
			return Utility.getfailureMsg("Unable to fetch return orders for node " + nodeId );
		}
	}
	
	@GetMapping(value = "/trip-mgmt/v1/nodes/{nodeId}/returnitems", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getReturnItems(@RequestHeader(value = Constants.NODE_ID, required = true) String nodeId , 
			@RequestParam(value = Constants.ORDER_IDS, required = true) String returnOrderIds) {
		log.info("Get available return items  at node : {} and orderIds :{} ", nodeId , returnOrderIds);
		try {
			
			if(StringUtils.isBlank(returnOrderIds))
				Utility.getfailureMsg("Request param orderIds is Mandatory!");
			
			List<String> returnOrders = Arrays.asList(returnOrderIds.split(","));
			List<String> availableReturnOrders = deliveryChallanService.getAvailableOrdersByOrderId(returnOrders);
			
			if(availableReturnOrders==null || availableReturnOrders.size()<returnOrders.size()) {
				returnOrders.removeAll(availableReturnOrders);
				return Utility.getfailureMsg("Delivery challan already generated for " + returnOrders + " orders. Please reselect from available Return Orders!" , HttpStatus.BAD_REQUEST);
			}
			
			List<ReturnItem> returnItems = deliveryChallanService.getAvailableReturnItems(returnOrders);
			
			return Utility.getSuccessMsg(returnItems);
			
		} catch (Exception e) {
			log.error("Exception Occured on fetching the return items  "+ e);
			return Utility.getfailureMsg("Unable to fetch available return items");
		}
	}

}
