package com.ril.newcommerce.supplychain.tms.exception;

/**
B1.Divya
*/

public class DataProcessingException extends RuntimeException {

	private static final long serialVersionUID = -2538286562491861181L;

	public DataProcessingException(String message) {
		super(message);
	}
	
	
	public DataProcessingException(String message,Throwable th) {
		super(message,th);
	}
	
	public DataProcessingException(Throwable th) {
		super(th);
	}
}
