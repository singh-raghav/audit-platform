package com.ril.newcommerce.supplychain.tms.entity.rest.userdetails;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.ril.newcommerce.supplychain.tms.enums.AccountStatus;
import lombok.*;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDetailResponse implements Serializable {

	private static final long serialVersionUID = -422876268445093219L;

	private String username;
	private String firstName;
	private String lastName;
	private String userRole;
	private String displayName;
	private AccountStatus accountStatus;
	List<Cluster> clusters;

}
