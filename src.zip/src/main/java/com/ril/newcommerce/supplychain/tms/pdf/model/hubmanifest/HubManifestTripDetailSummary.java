package com.ril.newcommerce.supplychain.tms.pdf.model.hubmanifest;

import java.util.ArrayList;
import java.util.List;

public class HubManifestTripDetailSummary {

    private String totalTotesPresent;
    private String totalTotesMissing;
    private String totalBillCollected;
    private String totalPrepaidCollected;
    private String totalBalance;
    private List<HubManifestTripDetails> hubManifestTripDetails;

    public String getTotalTotesPresent() {
        return totalTotesPresent;
    }

    public void setTotalTotesPresent(String totalTotesPresent) {
        this.totalTotesPresent = totalTotesPresent;
    }

    public String getTotalTotesMissing() {
        return totalTotesMissing;
    }

    public void setTotalTotesMissing(String totalTotesMissing) {
        this.totalTotesMissing = totalTotesMissing;
    }

    public String getTotalBillCollected() {
        return totalBillCollected;
    }

    public void setTotalBillCollected(String totalBillCollected) {
        this.totalBillCollected = totalBillCollected;
    }

    public String getTotalPrepaidCollected() {
        return totalPrepaidCollected;
    }

    public void setTotalPrepaidCollected(String totalPrepaidCollected) {
        this.totalPrepaidCollected = totalPrepaidCollected;
    }

    public String getTotalBalance() {
        return totalBalance;
    }

    public void setTotalBalance(String totalBalance) {
        this.totalBalance = totalBalance;
    }

    public List<HubManifestTripDetails> getHubManifestTripDetails() {
        return null == hubManifestTripDetails ? new ArrayList<>() : hubManifestTripDetails;
    }

    public void setHubManifestTripDetails(List<HubManifestTripDetails> hubManifestTripDetails) {
        this.hubManifestTripDetails = hubManifestTripDetails;
    }
}
