package com.ril.newcommerce.supplychain.tms.externalApis;

import com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails.NodeDetailsResponse;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;


@FeignClient(name = "nodeDetailService", url = "${nodeDetailService.endpoint}")
public interface NodeDetailsFeign {

    @GetMapping("/node-services/v1/nodes/types/{nodeType}?active=true")
    NodeDetailsResponse getNodeListAgainstNodeType(@RequestHeader("ClientId") String clientId, @RequestHeader("ApiKey") String apiKey,
                                                   @PathVariable("nodeType") NodeType nodeType);

    @GetMapping("/node-services/v1/nodes/{nodeId}?hierarchy=true&level={level}")
    NodeDetailsResponse getNodeDetailsWithHierarchyWithLevels(@RequestHeader("ClientId") String clientId, @RequestHeader("ApiKey") String apiKey,
                                     @PathVariable("nodeId") String nodeId,  @PathVariable("level") String level);

    @GetMapping("/node-services/v1/nodes/{nodeId}?hierarchy=true")
    NodeDetailsResponse getNodeDetailsWithHierarchy(@RequestHeader("ClientId") String clientId, @RequestHeader("ApiKey") String apiKey,
                                     @PathVariable("nodeId") String nodeId);

    @GetMapping("/node-services/v1/nodes/clusters/{clusterId}?hierarchy=true")
    NodeDetailsResponse getClusterDetailsWithHierarchy(@RequestHeader("ClientId") String clientId, @RequestHeader("ApiKey") String apiKey,
                                                    @PathVariable("clusterId") String clusterId);
    
    @GetMapping("/node-services/v1/nodes/{nodeId}")
    NodeDetailsResponse getNodeDetails(@RequestHeader("ClientId") String clientId, @RequestHeader("ApiKey") String apiKey,
                                     @PathVariable("nodeId") String nodeId);

    @GetMapping("/node-services/v1/nodes/clusters/{clusterId}")
    NodeDetailsResponse getClusterDetails(@RequestHeader("ClientId") String clientId, @RequestHeader("ApiKey") String apiKey,
                                                    @PathVariable("clusterId") String clusterId);
}
