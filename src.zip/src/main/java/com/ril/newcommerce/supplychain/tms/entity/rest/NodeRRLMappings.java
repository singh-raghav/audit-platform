package com.ril.newcommerce.supplychain.tms.entity.rest;

import lombok.Data;

@Data
public class NodeRRLMappings {
    private String nodeId;
    private String rrlId;
    private String siteName;
    private String siteAddress;
}
