package com.ril.newcommerce.supplychain.tms.exception;

/**
 * 
 * @author jeevi.natarajan
 *
 */
public class EventOutOfOrderException extends RuntimeException {
	
	private static final long serialVersionUID = 5712831892128322576L;

	public EventOutOfOrderException(String message) {
		super(message);
	}
	
	public EventOutOfOrderException(String message,Throwable th) {
		super(message,th);
	}
	
	public EventOutOfOrderException(Throwable th) {
		super(th);
	}
}
