package com.ril.newcommerce.supplychain.tms.service;

import com.ril.newcommerce.supplychain.tms.response.TripAmountResponse;
import org.springframework.http.ResponseEntity;

public interface DayLevelAckGenerationService {

    ResponseEntity createPdf(TripAmountResponse annexure, String nodeId);

}
