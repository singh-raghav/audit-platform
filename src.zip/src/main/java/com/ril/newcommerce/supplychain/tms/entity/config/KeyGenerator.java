package com.ril.newcommerce.supplychain.tms.entity.config;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class KeyGenerator implements IdentifierGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(KeyGenerator.class);

    @Override
    public Serializable generate(SharedSessionContractImplementor session, Object arg1) throws HibernateException {

        Serializable result = null;
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        LocalDateTime localDateTime = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
        String formatDateTime = localDateTime.format(format);

        connection = session.connection();
        try {
            statement = connection.createStatement();
            try {
                resultSet = statement.executeQuery("select TRIP_ID_SEQUENCE.nextval from dual");
                if(resultSet.next()) {
                    String nextValue = resultSet.getString(1);
                    result = formatDateTime + nextValue;
                    return result;
                }
            } catch(Exception ex) {
                LOGGER.error("ERROR -- ",ex);
            }
        } catch (SQLException e) {
            LOGGER.error("ERROR -- ",e);
        }
        return null;
    }

}
