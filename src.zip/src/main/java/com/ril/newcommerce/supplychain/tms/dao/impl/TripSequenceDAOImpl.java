package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.TripSequenceDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripHubMapper;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;

/**
B1.Divya
*/

@Repository
public class TripSequenceDAOImpl implements TripSequenceDAO 
{
	private static final Logger log = LoggerFactory.getLogger(TripSequenceDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public void insertToTripSequence(Trip trip) {
		try {
			if (null != trip.getHub() && !trip.getHub().isEmpty()) {
				List<Object[]> inputList = new ArrayList<>();
				for (Hub hub : trip.getHub()) {
					Object[] tmp = { trip.getTripId(), hub.getNodeId(), hub.getSequence(), hub.getPlannedArrivalTime(),
							hub.getPlannedDispatchTime(), trip.getCreatedBy(),trip.getCreatedBy(), trip.getFlowName(),
							new Timestamp(System.currentTimeMillis()),new Timestamp(System.currentTimeMillis()) };
					inputList.add(tmp);
				}
				jdbcTemplate.batchUpdate(QueryConstants.INSERT_TO_TRIP_SEQUENCE, inputList);
				log.info("Trip sequence details  successfully inserted  in trip_sequence table",trip.getTripId());
			}

		} catch (Exception e) {
			log.error("Exception occured during inserting data in trip sequence", e);
			throw new DataProcessingException("Exception occured during inserting data in trip sequence", e);
		}

	}
	
	@Override
	public Map<String, List<com.ril.newcommerce.supplychain.tms.entity.Hub>> getTripSequence(List<String> tripIds,List<String> nodeIds) {
		log.info("Getting hub details for tripIds in getHubs()");
		Map<String, List<com.ril.newcommerce.supplychain.tms.entity.Hub>> queryResult = null;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		StringBuilder queryBuilder=new StringBuilder();
		queryBuilder.append(QueryConstants.GET_HUB_SEQUENCE);
		parameters.addValue("tripIds", tripIds);

		if(!CollectionUtils.isEmpty(nodeIds))
		{
			queryBuilder.append(" AND NODE_ID IN (:nodeIds)");
			parameters.addValue("nodeIds", nodeIds);
		}
		try {
			queryResult = namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new TripHubMapper());
		} catch (Exception e) {
			log.error("Exception occured while fetching hub details in getHubs of TripsDAOImpl ", e);
			throw new TripApplicationException("Exception occured on getHubs of TripsDAOImpl ", e);
		}
		return queryResult;
	}
	@Override
	public void deassociateTripSequence(String tripId,List<String> nodeIds) {

		log.info("Deleting trip sequence : tripId -  {} , nodeid -{}  " , tripId, nodeIds );

		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripId", tripId);
			parameters.addValue("nodeIds", nodeIds);
			namedParameterJdbcTemplate.update(QueryConstants.DELETE_TRIP_SEQUENCE, parameters);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured during deleting trip sequence ", e);
		}
	}
}
