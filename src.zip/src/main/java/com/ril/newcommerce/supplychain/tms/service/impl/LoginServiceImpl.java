package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.entity.UserDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.LoginRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.LoginResponse;
import com.ril.newcommerce.supplychain.tms.entity.rest.hawkeye.HawkeyeLoginInput;
import com.ril.newcommerce.supplychain.tms.entity.rest.hawkeye.HawkeyeLoginOutput;
import com.ril.newcommerce.supplychain.tms.enums.AccountStatus;
import com.ril.newcommerce.supplychain.tms.service.HawkEyeService;
import com.ril.newcommerce.supplychain.tms.service.LoginService;
import com.ril.newcommerce.supplychain.tms.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class LoginServiceImpl implements LoginService {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoginServiceImpl.class);

    @Autowired
    private HawkEyeService hawkEyeService;

    @Autowired
    private UserService userService;

    @Value("${hawkeye.client}")
    private String hawkeyeClient;

    @Value("${invalidLogin.allowedAttemptCount}")
    private Integer invalidAttemptsAllowed;

    public LoginResponse login(LoginRequest loginRequest){

        HawkeyeLoginOutput hawkeyeLoginOutput = null;

        try {
            UserDetails userDetails = userService.findUserByUserName(loginRequest.getUsername());
            if(userDetails==null){
                LOGGER.info("{} not found in system",loginRequest.getUsername());
                return LoginResponse.builder()
                        .errorMessage("Invalid User")
                        .build();
            }
            else if(!userDetails.getAccountStatus().equals(AccountStatus.ACTIVE)){
                LOGGER.info("{} account is {} in system",loginRequest.getUsername(), userDetails.getAccountStatus().toString());
                return LoginResponse.builder()
                        .errorMessage("User Account is "+userDetails.getAccountStatus().toString())
                        .build();
            }
            else{
                HawkeyeLoginInput hawkeyeLoginInput = HawkeyeLoginInput.builder()
                        .password(loginRequest.getSecret())
                        .username(loginRequest.getUsername())
                        .clientName(hawkeyeClient)
                        .build();
                try {
                    hawkeyeLoginOutput = hawkEyeService.authenticate(hawkeyeLoginInput);
                }catch(Exception ex){
                    if (ex.getMessage().contains("401")) {
                        // authentication failure - will increase invalid
                        int completedAttempts = userDetails.getInvalidAttempts();
                        int currentAttempt = 1;
                        int totalAttempts = completedAttempts + currentAttempt;
                        userDetails.setInvalidAttempts(totalAttempts);
                        if (totalAttempts >= invalidAttemptsAllowed) {
                            userDetails.setAccountStatus(AccountStatus.LOCKED);
                            userDetails.setInvalidAttempts(0);
                            userService.saveUser(userDetails);
                            return LoginResponse.builder()
                                    .errorMessage("User Account is " + userDetails.getAccountStatus().toString())
                                    .build();
                        } else {
                            userService.saveUser(userDetails);

                            int invalidAttemptsLeft = (invalidAttemptsLeft = invalidAttemptsAllowed - totalAttempts) < 0 ? 0 : invalidAttemptsLeft;
                            return LoginResponse.builder()
                                    .errorMessage("Authentication Failure")
                                    .invalidAttemptLeft(invalidAttemptsLeft)
                                    .build();
                        }
                    }
                    return LoginResponse.builder()
                            .errorMessage(ex.getMessage())
                            .build();
                }

                if(hawkeyeLoginOutput.getSuccess().equals("true")){

                    userDetails.setLastLoggedIn(LocalDateTime.now());
                    userDetails.setInvalidAttempts(0);

                    userService.saveUser(userDetails);

                    LocalDateTime expiryTime = hawkEyeService.getExpiryTime(hawkeyeLoginOutput);
                    return LoginResponse.builder()
                            .accessToken(hawkeyeLoginOutput.getResult().getAccessToken())
                            .expiresAt(expiryTime)
                            .build();
                }
            }
        }
        catch (Exception ex){
            LOGGER.error("ERROR -- ",ex);
            return LoginResponse.builder()
                    .errorMessage(ex.getMessage())
                    .build();
        }
        return LoginResponse.builder()
                .errorMessage("some error occurred")
                .build();

    }
}
