package com.ril.newcommerce.supplychain.tms.entity;

public class TripIdDetails 
{
	private int sequence;
	private String tripDate;
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public String getTripDate() {
		return tripDate;
	}
	public void setTripDate(String tripDate) {
		this.tripDate = tripDate;
	}
	
}
