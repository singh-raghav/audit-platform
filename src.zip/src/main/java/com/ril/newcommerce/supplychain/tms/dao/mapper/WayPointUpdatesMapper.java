package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.WayPointUpdates;

public class WayPointUpdatesMapper implements ResultSetExtractor<List<WayPointUpdates>> {

	@Override
	public List<WayPointUpdates> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<WayPointUpdates> wayPoints =new ArrayList<>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) 
		{
			WayPointUpdates wayPoint =new WayPointUpdates();
			wayPoint.setTripId(rs.getString("TRIP_ID"));
			wayPoint.setWayPointId(rs.getString("WAY_POINT_ID"));
			wayPoint.setNodeId(rs.getString("NODE_ID"));
			wayPoint.setOrderId(rs.getString("FWD_ORDER_ID"));
			wayPoint.setOrderClassification(rs.getString("ORDER_CLASSIFICATION"));
			wayPoint.setShouldReconcile(rs.getString("SHOULD_RECONCILE").charAt(0));
			wayPoint.setStatus(rs.getString("STATUS"));
			wayPoint.setAmountPaid(rs.getDouble("AMOUNT_PAID"));
			wayPoint.setRoundOffAmount(rs.getDouble("ROUND_OFF_AMOUNT"));
			wayPoints.add(wayPoint);
			
		}
		return wayPoints;
	}
}
