package com.ril.newcommerce.supplychain.tms.entity;

import lombok.Data;

/**
B1.Divya
*/


public class TripConsignmentCount {
	
	private int missedTote;
	private int presentTote;
	private int missedBag;
	private int presentBag;
	private int missedHu;
	private int presentHu;
	private int missedOrderCount;
	private int plannedOrderCount; 
	private int invoicedOrderCount;
	
	public int getMissedTote() {
		return missedTote;
	}
	public void setMissedTote(int missedTote) {
		this.missedTote = missedTote;
	}
	public int getPresentTote() {
		return presentTote;
	}
	public void setPresentTote(int presentTote) {
		this.presentTote = presentTote;
	}
	public int getMissedBag() {
		return missedBag;
	}
	public void setMissedBag(int missedBag) {
		this.missedBag = missedBag;
	}
	public int getPresentBag() {
		return presentBag;
	}
	public void setPresentBag(int presentBag) {
		this.presentBag = presentBag;
	}
	public int getMissedHu() {
		return missedHu;
	}
	public void setMissedHu(int missedHu) {
		this.missedHu = missedHu;
	}
	public int getPresentHu() {
		return presentHu;
	}
	public void setPresentHu(int presentHu) {
		this.presentHu = presentHu;
	}
	public int getMissedOrderCount() {
		return missedOrderCount;
	}
	public void setMissedOrderCount(int missedOrderCount) {
		this.missedOrderCount = missedOrderCount;
	}
	public int getPlannedOrderCount() {
		return plannedOrderCount;
	}
	public void setPlannedOrderCount(int plannedOrderCount) {
		this.plannedOrderCount = plannedOrderCount;
	}
	public int getInvoicedOrderCount() {
		return invoicedOrderCount;
	}
	public void setInvoicedOrderCount(int invoicedOrderCount) {
		this.invoicedOrderCount = invoicedOrderCount;
	}
	
	

}
