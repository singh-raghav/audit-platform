package com.ril.newcommerce.supplychain.tms.event.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;

/**
 * 
 * @author jeevi.natarajan
 *
 */
@Component
public class PostProcessorFactory {
	
	@Autowired
	@Qualifier(Constants.ASSIGN_TRIP_POST_PROCESSOR)
	private IPostProcessor assignTripPostProcessor;
	
	@Autowired
	@Qualifier(Constants.DO_NOTHING_POSTPROCESSOR)
	private IPostProcessor doNothingPostProcessor;
	
	public IPostProcessor getPostProcessor(TripEvent event) {
		
		switch (event) {

			case ASSIGN:
			case REASSIGN:
				return assignTripPostProcessor;
		
			default:
				return doNothingPostProcessor;

		}
		
		
	}
	
}
