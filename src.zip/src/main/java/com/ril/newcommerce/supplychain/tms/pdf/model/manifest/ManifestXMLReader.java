package com.ril.newcommerce.supplychain.tms.pdf.model.manifest;

import java.io.IOException;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ril.newcommerce.supplychain.tms.entity.FCManifest;
import com.ril.newcommerce.supplychain.tms.entity.HubDetail;
import com.ril.newcommerce.supplychain.tms.pdf.tools.AbstractObjectReader;

public class ManifestXMLReader extends AbstractObjectReader {
    public void parse(InputSource input) throws IOException, SAXException {
        if (input instanceof ManifestInputSource) {
            parse(((ManifestInputSource) input).getManifest());
        } else {
            throw new SAXException("Unsupported InputSource specified. "
                    + "Must be a ManifestInputSource");
        }
    }

    private void parse(FCManifest manifest) throws SAXException {
        if (manifest == null) {
            return;
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        //Start the document
        handler.startDocument();

        //Generate SAX events for the ProjectTeam
        generateFor(manifest);

        //End the document
        handler.endDocument();
    }

    private void generateFor(FCManifest manifest) throws SAXException {
        if (manifest == null) {
            throw new NullPointerException("Parameter manifest must not be null");
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        handler.startElement("manifest");
        handler.element("driverNameAndMobile", manifest.getDriverName() + " /" + manifest.getDriverMobileNumber());
        handler.element("endKm", String.valueOf(manifest.getEndKm()));
        handler.element("mode", manifest.getMode());
        handler.element("startKm", String.valueOf(manifest.getStartKm()));
        handler.element("totalOrders", String.valueOf(manifest.getTotalOrders()));
        handler.element("totalHU", String.valueOf(manifest.getTotalHUs()));
        handler.element("tripLocationCode", manifest.getFcName());
        handler.element("tripNumber", manifest.getTripId());
        handler.element("truckOperator", manifest.getTruckOperator());
        handler.element("vehicle", manifest.getVechicleNumber());
        handler.element("vehicleType", manifest.getVehicleType());

        

        for (HubDetail hubDetail : manifest.getHubDetails()) {
            generateFor(hubDetail);
        }

        handler.endElement("manifest");
    }

    private void generateFor(HubDetail tripDetails) throws SAXException {
        handler.startElement("tripDetails");
        handler.element("arrivalTime", "");
        handler.element("departureTime", "");
        handler.element("hubAddress", StringUtils.join(Arrays.stream(StringUtils.split(tripDetails.getHubAdderss(), ",")).filter(s -> !StringUtils.isBlank(s)).collect(Collectors.toList()), ", "));
        handler.element("hubSequence", String.valueOf(tripDetails.getSequence()));
        handler.element("loadedOrder", String.valueOf(tripDetails.getLoadedOrders().size()));
        handler.element("LoadedHU", String.valueOf(tripDetails.getLoadedHUs().size()));
        handler.element("remarks", "");
        handler.element("seal", tripDetails.getSeals());
        handler.endElement("tripDetails");
    }
}
