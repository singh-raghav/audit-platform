package com.ril.newcommerce.supplychain.tms.event.processor;

import com.ril.newcommerce.supplychain.tms.enums.OrderState;

public interface BasicSMOrderUpdateProcessor {
    void processOrder(String orderId, OrderState orderState, String flowName);
}
