package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.entity.NodeOrdeRoute;
import com.ril.newcommerce.supplychain.tms.entity.rest.Drivers;

/**
B1.Divya
*/

public class NodeOrdeRouteMapper implements ResultSetExtractor<List<NodeOrdeRoute>>  {

	@Override
	public List<NodeOrdeRoute> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<NodeOrdeRoute> orderRoutes = new ArrayList<NodeOrdeRoute>();
		while (rs.next()) {
			NodeOrdeRoute orderRoute=new NodeOrdeRoute();
			orderRoute.setNodeId(rs.getString("NODE_ID"));
			orderRoute.setOrderId(rs.getString("ORDER_ID"));
			orderRoute.setPreviousRouteId(rs.getString("PRE_ROUTE_ID"));
			orderRoute.setNextRouteId(rs.getString("NEXT_ROUTE_ID"));
			orderRoutes.add(orderRoute);
		}
		return orderRoutes;
	}

}
