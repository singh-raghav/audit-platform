package com.ril.newcommerce.supplychain.tms.listeners;

import javax.jms.JMSException;
import javax.jms.Message;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.notification.NotificationEngine;
import com.ril.newcommerce.supplychain.tms.processors.Processor;
import com.ril.newcommerce.supplychain.tms.processors.ProcessorFactory;


@Service
public class JMSListener {

	private static final Logger log = LoggerFactory.getLogger(JMSListener.class);

	@Autowired
	@Qualifier("jmsTemplate")
	JmsTemplate jmsTemplate;

	@Autowired
	ProcessorFactory processorFactory;

	@Value("${tripapp.backout.maxRetryCount}")
	private int maxRetryCount;

	@Value("${tripapp.bad.queue}")
	private String badQueue;

	@Value("${tripapp.backout.queue}")
	private String backoutQueue;
	
	@Autowired
	private NotificationEngine notificationEngine;

	@JmsListener(destination = "${tripapp.queue}" ,concurrency= "${trip.listeners.concurrency}")
	@Transactional(rollbackFor = Exception.class)
	public void onMessage(Message message,@Header(required = false, value = Constants.RETRY_COUNT) Integer retryCount)  throws ParsingException,Exception {
		String messageFlowName =message.getStringProperty(Constants.FLOWNAME);
		try {
				FlowName name = validateFlowName(message);

				Processor processor = processorFactory.getProcessor(name);
				processor.processMessage(message, name.getValue());
			
		} catch (ParsingException e) { 
			log.error("Exception occured on parsing message : {} ", message, e);
			notificationEngine.triggerAlert(Constants.TRIP_BAD_MESSAGE,
					StringEscapeUtils.escapeXml11(message.toString()), messageFlowName + Constants.TRIP);
			sendMessage(badQueue, message);
			throw new ParsingException("Exception occured in listner ",e);
			}
		catch(ValidationException valiEx)
		{
			 
			log.error("Validation Exception occured : {} ", message, valiEx);
			notificationEngine.triggerAlert(Constants.TRIP_BAD_MESSAGE,
					StringEscapeUtils.escapeXml11(message.toString()), messageFlowName + Constants.TRIP);
			sendMessage(badQueue, message);
			throw new ValidationException("Validation Exception occured in listner ",valiEx);
		}
		catch (Exception ex) { 
			log.error("Exception occured on processing message : {}", message, ex);
			int retry = (retryCount == null) ? 0 : retryCount;
			String queue=backoutQueue;
			if(retry >= maxRetryCount)
			{
				queue=badQueue;
				notificationEngine.triggerAlert(Constants.TRIP_BAD_MESSAGE,
						StringEscapeUtils.escapeXml11(message.toString()), messageFlowName + Constants.TRIP);
			}
			sendMessage(queue, message);
			throw new Exception("Exception occured in listner ",ex);}
		sendAck(message);
	}
	private FlowName validateFlowName(Message message) throws JMSException,ParsingException
	{
		String flowName = message.getStringProperty(Constants.FLOWNAME);
		FlowName name = null;
		if (!StringUtils.isBlank(flowName)) {
			name = FlowName.get(flowName);
		} else {
			throw new ParsingException("FlowName not present " + message.getJMSMessageID());
		}
		if (null != name) {
			return name;
		} else {
			throw new ParsingException("FlowName not present in TripApp" + message.getJMSMessageID());
		}
	}

	private void sendMessage(String queueName, Message message) {
		jmsTemplate.convertAndSend(queueName, message);
		sendAck(message);
		log.debug("Succesfully pushed message to {}", queueName);
	}

	private void sendAck(Message message) {
		try {
			message.acknowledge();
		} catch (JMSException e) {
			log.error("Error in sending Acknowledgement", e.getMessage());
		}
	}

}
