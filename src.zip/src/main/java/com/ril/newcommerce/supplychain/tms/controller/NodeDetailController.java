package com.ril.newcommerce.supplychain.tms.controller;

import com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails.NodeDetailsResponse;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;
import com.ril.newcommerce.supplychain.tms.service.NodeDetailApiService;
import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/trip-mgmt/v1/nodedetail")
public class NodeDetailController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private NodeDetailApiService nodeDetailApiService;

    @GetMapping(value = "/node/{nodeid}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseMessage> getNodeDetails(@PathVariable("nodeid")  String nodeid, @RequestParam("nodetype") NodeType nodetype,@RequestParam("hierarchy") boolean hierarchy) {

        long startTime = System.currentTimeMillis();

        ResponseEntity<ResponseMessage> responseEntity = null;

        try {
            NodeDetailsResponse nodeDetailsResponse = nodeDetailApiService.getNodeDetails(nodeid, nodetype,hierarchy);

            if (nodeDetailsResponse.getStatusCode()!=HttpStatus.OK.value()) {
                responseEntity = Utility.getfailureMsg("Node not found", HttpStatus.NO_CONTENT);
            } else {
                responseEntity = Utility.getSuccessMsg(nodeDetailsResponse);
            }
        }catch(Exception ex){
            LOGGER.error("ERROR_IN_getNodeDetails -- ",ex);
            responseEntity = Utility.getfailureMsg(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }

        LOGGER.info("getNodeDetails_time -- [{}]ms", (System.currentTimeMillis() - startTime));
        return responseEntity;

    }

    @GetMapping(value = "/nodes", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseMessage> getNodeList(@RequestParam("nodetype") NodeType nodetype) {

        long startTime = System.currentTimeMillis();

        ResponseEntity<ResponseMessage> responseEntity = null;

        try {
            NodeDetailsResponse nodeDetailsResponse = nodeDetailApiService.getNodeList(nodetype);

            if (nodeDetailsResponse.getStatusCode()!=HttpStatus.OK.value()) {
                responseEntity = Utility.getfailureMsg("Node not found", HttpStatus.NO_CONTENT);
            } else {
                responseEntity = Utility.getSuccessMsg(nodeDetailsResponse);
            }
        }catch(Exception ex){
            LOGGER.error("ERROR_IN_getNodeList -- ",ex);
            responseEntity = Utility.getfailureMsg(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }

        LOGGER.info("getNodeList_time -- [{}]ms", (System.currentTimeMillis() - startTime));
        return responseEntity;

    }
}
