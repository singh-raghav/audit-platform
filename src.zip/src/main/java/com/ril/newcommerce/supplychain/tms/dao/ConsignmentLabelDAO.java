package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.response.HuCountResponse;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate.Labels.Label;

/**
B1.Divya
*/

public interface ConsignmentLabelDAO {
	public int saveShipmentLabel(Set<ConsignmentLabel> consignmentLabels);
	
	public int updateStatusOfShipmentLabel(Map<String, Map<String, List<String>>> labelWithStatus,String modifiedBy);
	
	public void updateStatusOfShipmentLabel(List<Label> labels,String modifiedBy);

	public int updateStatusOfShipmentLabel(String shipmentNo, String status, String modifiedBy, List<String> labelIds);

	public Integer getLabelsCountForShipment(String shipmentNo);
	
	public Map<String, Map<String, List<ConsignmentLabel>>> getTripConsignmentLabel(List<String> tripIds, List<String> sourceNode);

	List<ConsignmentLabel> getConsignmentLabel(String shipmentNo);

    List<HuCountResponse> getHUCountForSDP(List<String> nodeIds, String startDate, String endDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> sdpIds);
}

