package com.ril.newcommerce.supplychain.tms.controller;


import com.ril.newcommerce.supplychain.tms.exception.ExcelCreationException;
import com.ril.newcommerce.supplychain.tms.service.ExcelService;
import com.ril.newcommerce.supplychain.tms.service.PdfDeletionService;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.MSG_OBJECT_CREATION_FAILED;


@RestController
@RequestMapping(value = "/trip-mgmt/v1/trips/order-view/{tripId}")
public class ExcelController {

    private static final Logger log = LoggerFactory.getLogger(ExcelController.class);

    @Autowired
    private ExcelService excelService;

    @Autowired
    private PdfDeletionService pdfDeletionService;


    @GetMapping(produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity createExcel(@PathVariable(value = "tripId", required = true) String tripId) {
        log.info("Start creating order view for trip : {}", tripId);
        String errorMessage;
        try {
            return excelService.createExcel(tripId);

        } catch (ExcelCreationException e) {
            errorMessage = e.getMessage();
            log.error("Excel file creation failed! {}", e);
        } catch (Exception e) {
            errorMessage = MSG_OBJECT_CREATION_FAILED;
            log.error("OrderExcelViewResponse object creation failed! {}", e);

        } finally {
            pdfDeletionService.deletePDf();
        }
        return ResponseEntityFactory.textResponse(errorMessage);
    }
}
