package com.ril.newcommerce.supplychain.tms.entity;

import java.sql.Timestamp;
import java.util.Date;

/**
B1.Divya
*/
public class Invoice {
	
	private String invoiceNo;
	private String orderNo;
	private String shipmentNo;
	private double invoiceAmount;
	private double amountToBeCollected;
	private Date invoiceDate;
	private String ewayBillNo;
	private String ewayBillStatus;
	private String createdBy;
	private Timestamp createdTs;
	private String modifiedBy;
	private Timestamp modifiedTs;
	private String flowName;
	private String mop;

	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getShipmentNo() {
		return shipmentNo;
	}
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}
	public double getInvoiceAmount() {
		return invoiceAmount;
	}
	public void setInvoiceAmount(double invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getEwayBillNo() {
		return ewayBillNo;
	}
	public void setEwayBillNo(String ewayBillNo) {
		this.ewayBillNo = ewayBillNo;
	}
	public String getEwayBillStatus() {
		return ewayBillStatus;
	}
	public void setEwayBillStatus(String ewayBillStatus) {
		this.ewayBillStatus = ewayBillStatus;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedTs() {
		return createdTs;
	}
	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Timestamp getModifiedTs() {
		return modifiedTs;
	}
	public void setModifiedTs(Timestamp modifiedTs) {
		this.modifiedTs = modifiedTs;
	}
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}
	public double getAmountToBeCollected() {
		return amountToBeCollected;
	}
	public void setAmountToBeCollected(double amountToBeCollected) {
		this.amountToBeCollected = amountToBeCollected;
	}

	public String getMop() {
		return mop;
	}

	public void setMop(String mop) {
		this.mop = mop;
	}
}
