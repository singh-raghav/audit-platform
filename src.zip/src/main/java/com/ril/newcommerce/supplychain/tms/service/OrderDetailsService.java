package com.ril.newcommerce.supplychain.tms.service;

import java.sql.Timestamp;

import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.InvoicePdfDetail;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.exception.NetworkCommunicationException;
import com.ril.newcommerce.supplychain.tms.response.OrderListResponse;
import com.ril.newcommerce.supplychain.tms.response.OrderListResponseFluidLoading;
import com.ril.newcommerce.supplychain.tms.response.SDPSummaryResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import javax.xml.bind.JAXBException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

/**
B1.Divya
*/

@Service
public interface OrderDetailsService {
	
	boolean addOrderDetails(List<OrderDetails> orderDetails); 
	
	void updateOrderDetails(Timestamp slotStartTime, Timestamp slotEndTime, String orderId, String shipmentNo);

	public List<Consignment> getTripOrderAndAdditionalDetails(String tripId, String nodeId, List<String> status, List<String> shipmentNos,String orderclassification) throws InterruptedException, ExecutionException,TimeoutException;
	
	public List<Consignment> getTripOrderDetails(String tripId, String nodeId, List<String> status, List<String> shipmentNos,String orderclassification) ;
	
	public List<OrderDetails> getOrderDetails(List<String> orderId, List<String> shipmentNo);
	
	public void updateOrderstatus(List<String> orderIds, String status,String flowName,String modifiedBy);

	public boolean isAllReturnOrders(String tripId, String nodeId) throws InterruptedException, ExecutionException,TimeoutException;

	public void addCustomerDetails(List<OrderDetails> orderDetails);

	void updateOrderDetails(List<Consignment> consignment);

	void updateOrderDetails(String orderId, OrderState orderState);

	 OrderListResponse getOrders(List<String> nodeName, Integer startIndex, Integer endIndex, String fromDate, String toDate, String orderId, List<String> orderStatuses, List<String> orderTypes, List<String> movementTypes, List<String> destHubs) throws InterruptedException, ExecutionException;

	OrderListResponseFluidLoading tripOrderViewFluidLoading(List<String> nodeIds, Integer pageSize, Integer pageIndex, String fromDate,
														   String toDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs);

	OrderListResponseFluidLoading consignmentViewFluidLoading(List<String> nodeIds, Integer pageSize, Integer pageIndex, String fromDate,
														   String toDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs);

	public List<OrderDetails> getOrderDetails(String tripId);

	OrderDetails getOrderDetail(String orderId);

	InvoicePdfDetail getInvoiceDetail(String orderId, String shipmentId) throws JAXBException,
			NetworkCommunicationException, RestClientException;

    List<SDPSummaryResponse> getSDPSummary(List<String> nodeIds, List<String> sdpIds, String startDate, String endDate) throws Exception;

	public ResponseEntity getConsignmentOrderPdf(OrderListResponseFluidLoading orderListResponse);

	List<Consignment> getUnplannedOrderList(String nodeId);

	String getOrderIdForShipment(String shipmentNo);
}
