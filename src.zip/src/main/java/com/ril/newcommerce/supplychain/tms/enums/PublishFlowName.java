package com.ril.newcommerce.supplychain.tms.enums;

/**
 * 
 * @author jeevi.natarajan
 * 
 * 
 * DO i need this enum ??? why did i create???
 *
 */
public enum PublishFlowName {

	START_TRIP("StartTrip"), END_TRIP("EndTrip") , ASSIGN_TRIP("AssignTrip"), SETTLE_TRIP("SettleTrip") , VEHICLE_STATE("VehicleState");
	
	private String value;
	
	private PublishFlowName(String value) {
		this.value= value;
	}
	
	public String getValue() {
		return this.value;
	}
}
