package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.entity.BusinessDetail;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class StateWiseBusinessMapper implements RowMapper<BusinessDetail> {

	@Override
	public BusinessDetail mapRow(ResultSet rs, int arg1) throws SQLException {
		
		BusinessDetail businessDetails = new BusinessDetail();
		businessDetails.setAddress(rs.getString("ADDRESS"));
		businessDetails.setGstin(rs.getString("GSTIN"));
		businessDetails.setId(rs.getString("ID"));
		businessDetails.setName(rs.getString("NAME"));
		businessDetails.setCode(rs.getString("CODE"));
		
		return businessDetails;
		
	}

}
