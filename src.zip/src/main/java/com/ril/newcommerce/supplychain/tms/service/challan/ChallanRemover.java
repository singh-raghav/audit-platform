package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.rest.Asset;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.enums.AssetFlowName;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.event.processor.TripEventProcessor;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.util.AssetEventPublisher;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */

@Service
@Transactional(rollbackFor = Exception.class)
public class ChallanRemover {
	
	private static final Logger log = LoggerFactory.getLogger(ChallanRemover.class);
	
	@Autowired
	private TripService tripService;
	
	@Autowired
	private InboundDAO inboundDAO;
	
	@Autowired
	private AssetEventPublisher assetEventPublisher;
	
	@Autowired
	@Qualifier(Constants.TRIP_EVENT_PROCESSOR)
	private TripEventProcessor eventProcessor;
	
	public void deleteDeliveryChallan(String challanId ,String hubId, String userId) {
		
		//1. Fetch all the challan articles..
		List<ChallanArticle> challanArticles = inboundDAO.getChallanArticles(challanId);
		
		List<String> returnOrderIds = challanArticles.stream()													
				.map(article -> article.getReturnOrderId())
				.collect(Collectors.toList());
		
		log.info("Return Order ids : {} ", returnOrderIds);

		//Do not delete the CR orders.. 
		List<String> crOrderIds = challanArticles.stream()
														.filter(article -> OrderStatus.CR_RETURNED.getValue().equals(article.getReturnType()))
														.map(article-> article.getReturnOrderId())
														.collect(Collectors.toList());
		log.info("No of CR orders : {}" , crOrderIds);
		
		if(CollectionUtils.isNotEmpty(crOrderIds)) //update trip id to null.
			inboundDAO.updateChallantripId(crOrderIds, Constants.NOT_APPLICABLE);
			
		
		List<String> returnOrderIdsToBeDeleted = new ArrayList<>();
		returnOrderIdsToBeDeleted.addAll(returnOrderIds);
		
		returnOrderIdsToBeDeleted.removeAll(crOrderIds);
					
		log.info("Return Order Ids to be deleted : {} " , returnOrderIdsToBeDeleted);
		//Fetching trip details for trip
		Trip trip = tripService.getTrip(challanArticles.get(0).getTripId());
		//2. Delete all challan articles.
		if(CollectionUtils.isNotEmpty(returnOrderIdsToBeDeleted))
			inboundDAO.deleteChallanArticle(returnOrderIdsToBeDeleted);
		
		//3. Reset the challanId back to null
		
		inboundDAO.updateChallanIdByOrderIds(returnOrderIds, null);
		
		//4. Send the negated event to ATS
		List<ChallanArticle> assets = challanArticles.stream()
													.filter(article -> ArticleType.ASSET.name().equals(article.getArticleType()))
													.collect(Collectors.toList());
		
		if(CollectionUtils.isNotEmpty(assets)) { //Send Information to ATS...
		
			List<Asset> assetsToBeSent  = new ArrayList<>();
			assets.forEach(selectedAsset->{
				
				Asset asset = new Asset();
				asset.setAssetType(selectedAsset.getArticleCode());
				asset.setCount(-1*selectedAsset.getQuantity().intValue());
				assetsToBeSent.add(asset);
			});	
			if(MovementType.FTL.equals(trip.getMovementType()))
			{
			assetEventPublisher.sendAssetInfoToATS(assetsToBeSent,hubId,trip.getSourceNode(), trip.getTripId(), UUID.randomUUID().toString(), AssetFlowName.OUT);
			}
			else
			{
				assetEventPublisher.sendAssetInfoToATS(assetsToBeSent,hubId,hubId, trip.getTripId(), UUID.randomUUID().toString(), AssetFlowName.OUT);
			}
		}
		
		if(trip.getMovementType().name().equalsIgnoreCase(MovementType.SHUTTLE.getValue())) {
			List<String> challanIds = inboundDAO.getChallanIds(trip.getTripId(),hubId);
			if(CollectionUtils.isEmpty(challanIds)) {
				TripEventInput eventInput = new TripEventInput();
				eventInput.setTripId(trip.getTripId());
				eventInput.setFlowName(TripEvent.CANCEL.name()); 
				eventInput.setNodeId(hubId);
				eventInput.setModifiedBy(userId);
				eventInput.setAction(TripEvent.CANCEL);
				eventProcessor.processEvent(eventInput);
			}					
		}
		
	}

}
