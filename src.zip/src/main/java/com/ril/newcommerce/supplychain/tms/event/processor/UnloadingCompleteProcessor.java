package com.ril.newcommerce.supplychain.tms.event.processor;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.SetUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.addverb.entity.Challan;
import com.ril.newcommerce.supplychain.tms.addverb.entity.ReturnDetails;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.processors.PublishReturnItems;
import com.ril.newcommerce.supplychain.tms.service.ConsignmentLabelService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate.Labels.Label;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
B1.Divya
*/

@Component
@Qualifier(Constants.UNLOADING_COMPLETE_PROCESSOR)
public class UnloadingCompleteProcessor implements IUpdateOnlyProcessor {

	private static final Logger log = LoggerFactory.getLogger(UnloadingCompleteProcessor.class);
	
	@Autowired
	private TripsDAO tripDao;

	@Autowired
	private ConsignmentLabelService consignmentLabelService;
	
	@Value("${trip.status.queue}")
	private String topicName;

	@Autowired
	private JMSPublisher jmsPublisher;
	
	@Autowired
	private TripService tripService;
	
	@Value("${tripapp.queue}")
	private String queueName;
	
	
	@Override
	public void processEvent(TripEventInput event, Trip trip)  {
		
		log.info("Unloading complete received for trip {}",trip.getTripId());
		
		List<TripStatusUpdate.Labels.Label> labelFromLoader=event.getTripStatusUpdate().getLabels().getLabel();
		
		validateLabelInfo(trip, labelFromLoader,event.getTripStatusUpdate().getNodeId());
		
		// update label status
		List<Label> labelStatusInfo = consignmentLabelService.getStatusOfLabels(labelFromLoader);
					
		consignmentLabelService.updateStatusOfLabels(labelStatusInfo, event.getFlowName());
		
		//update dispatch time , this might move if we make check-out mandatory
		Timestamp arrivalTime=DateUtility.convertStringToTimeStamp(event.getTripStatusUpdate().getEventTimeStamp(),
				Constants.EXTERNAL_SYSTEMS_DATE_FORMAT);
		tripDao.updateActualDispatch(event.getTripId(), event.getNodeId(), arrivalTime, event.getFlowName());
		
		log.info("Actual dispatch time dispatched of tripId {}",trip.getTripId());
		//publishing return orders to SAP
			Challan challanInfo=getChallanInfo(trip,event.getTripStatusUpdate().getNodeId());
		
		//publish message to OMS
		jmsPublisher.publishMessage(topicName, event.getTripStatusUpdate(), FlowName.UNLOADINGCOMPLETE.getValue(),
				Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
						event.getTripId()),TripStatusUpdate.class);
		
		jmsPublisher.inputToQueue(queueName, challanInfo, FlowName.RETURNITEMSAP.getValue(),
				Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
						challanInfo.getId()),Challan.class);
		
		
	}
	
	

	private Challan getChallanInfo(Trip trip, String nodeId) {
		Challan challan=new Challan();
		challan.setId(trip.getTripId());
		challan.setHubId(nodeId);
		challan.setDestinationNodeId(trip.getSourceNode());
		return challan;
	}



	private void validateLabelInfo(Trip trip,List<TripStatusUpdate.Labels.Label> labelFromLoader,String destId)
	{
		Map<String, Map<String, List<ConsignmentLabel>>> labelInfo=consignmentLabelService.getTripConsignmentLabel(trip.getTripId(),trip.getSourceNode());
		
		Map<String, List<ConsignmentLabel>> labelPresent=labelInfo.get(trip.getTripId());
		
		
			for(Iterator<Map.Entry<String,  List<ConsignmentLabel>>> it = labelPresent.entrySet().iterator(); it.hasNext(); ) {
			    Map.Entry<String, List<ConsignmentLabel>> entry = it.next();
			    
			    if(entry.getValue()!=null && entry.getValue().size()>0) {
			    	ConsignmentLabel value = entry.getValue().get(0);
			    	if(!value.getNodeId().equals(destId))
			    		it.remove();
			    }
			    
			 }		
	
		Map<String, List<Label>> labelLoader = labelFromLoader.stream().collect(Collectors
				.groupingBy(Label::getShipmentNo, HashMap::new, Collectors.toCollection(ArrayList::new)));
		
		Set<String> presentShipments = labelPresent.keySet().stream().collect(Collectors.toSet());

		Set<String> shipmentFromLoader = labelLoader.keySet().stream().collect(Collectors.toSet());
		
		if (SetUtils.isEqualSet(presentShipments, shipmentFromLoader)) {
		for(Entry<String, List<ConsignmentLabel>> entry: labelPresent.entrySet())
		{
			Set<String> labelIdsPresent =entry.getValue().stream().filter(label-> destId.equals(label.getNodeId())).map(mapper->mapper.getLabelId()).collect(Collectors.toSet());
			Set<String> labelIdsFromLoader=null;
			if(null!=labelLoader.get(entry.getKey()))
				 labelIdsFromLoader=labelLoader.get(entry.getKey()).stream().map(mapper->mapper.getLabelID()).collect(Collectors.toSet());
			else
				throw new ValidationException("Shipment number labels not present in loader feed "+entry.getKey());
			
			if(SetUtils.isEqualSet(labelIdsPresent, labelIdsFromLoader))
						continue;
			else
				throw new ValidationException("Labels doesn't match in loader and TripApp");
		}
		}
		
		log.info("Validation passed for unloadingcomplete for tripId {}",trip.getTripId());
		
	}

}
