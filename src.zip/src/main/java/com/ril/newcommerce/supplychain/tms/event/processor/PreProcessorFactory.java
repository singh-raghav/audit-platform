package com.ril.newcommerce.supplychain.tms.event.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;

@Component
public class PreProcessorFactory {
	
	@Autowired
	@Qualifier(Constants.VALIDATION_PRE_PROCESSOR)
	private IPreProcessor validationPreProcessor;
	
	@Autowired
	@Qualifier(Constants.DO_NOTHING_PREPROCESSOR)
	private IPreProcessor doNothingPreProcessor;
	
	
	public IPreProcessor getPreProcessor(TripEvent event) {
		
		switch (event) {
		
		case CHECK_IN :
		case CHECK_OUT:
		case START_LOADING:
		case UNLOADING_START:
//		case SETTLE:
		case REPORTRECONCILE:
		case COMPLETE_LOADING:
		case UNLOADING_COMPLETE:
			return doNothingPreProcessor;
			
		default:
			return validationPreProcessor;
			
			
		}
	}

}
