package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.UnmarshalException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.AdhocTripRequest;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.NodeOrdeRoute;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripIdDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.Node;
import com.ril.newcommerce.supplychain.tms.enums.EwayBillStatus;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.AdhocTripRequestService;
import com.ril.newcommerce.supplychain.tms.service.NodeOrderRouteService;
import com.ril.newcommerce.supplychain.tms.service.NodeService;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.service.impl.CreateTrip;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.tibco.entity.RouteResponse;
import com.ril.newcommerce.supplychain.tms.tibco.entity.RouteResponse.Route.Orders.Order;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * B1.Divya
 */
@Service
@Qualifier("tripDetails")
public class TripProcessor implements Processor  {

	private static final Logger log = LoggerFactory.getLogger(TripProcessor.class);

	@Autowired 
	private JAXBContextConfig jAXBContextConfig;

	@Autowired
	private NodeService nodeService;

	@Autowired
	private TripService tripService;
	
	
	@Value("${tripapp.queue}")
	private String queueName;
	
	@Autowired
	private JMSPublisher jmsPublisher;
	
	@Autowired
	private AdhocTripRequestService adhocTripRequestService;
	
	@Autowired
	private NodeOrderRouteService nodeOrderRouteservice;
	
	@Autowired
	private TripOrdersService tripOrderService;
	
	@Autowired
	private CreateTrip createTrip;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception{

		TextMessage textMessage = (TextMessage) message;
		long start = System.currentTimeMillis();
		long end;
		String routeId = "";
		try {
			StringReader reader = new StringReader(((TextMessage) message).getText());
			RouteResponse routeResponse = (RouteResponse) jAXBContextConfig.getJaxbContextInstance(RouteResponse.class).createUnmarshaller().unmarshal(reader);
			routeId = routeResponse.getRoute().getRouteId();

			log.debug("Trip Feed from Noah :{}", textMessage.getText());
			Trip trip=processTripData(routeResponse, flowName);
			log.info("Trip feed successfully consumed and saved in Trip {}", trip.getTripId());
			TripPublish tripPublishMeaage=Utility.createMessageToPublishTrip(trip.getTripId(),Constants.ONE,trip.isAdhocTrip());
			publishTripMessage(tripPublishMeaage);
			log.info("Trip sent successfully to get published {}", tripPublishMeaage.getTrip().getId());
			end = System.currentTimeMillis();
			log.info("Execution time for trip: {}, startTIme: {}, endTime: {} EXTime: {} milliseconds", routeResponse.getRoute().getRouteId(), start, end, end - start);
		}
		catch(UnmarshalException par)
		{
			throw new ParsingException("Parsing error while parsing tripfeed",par);
		}
		catch(ValidationException valiEx)
		{
			throw new ValidationException(valiEx);
		}
		catch (Exception e) {
			log.error("Error while processing trip ", e);
			end = System.currentTimeMillis();
			log.info("Execution Failed for routeId: {}, startTIme: {}, endTime: {} EXTime: {} milliseconds", routeId , start, end, end - start);
			throw new Exception("Exception occurred while processing tripfeed",e);

		}
	}


	private Trip processTripData(RouteResponse routeResponse, String flowName) throws Exception {

		Trip trip = new Trip();
		TripAdditionalDetail additionalDetails=null;
		
		setTripProperties(trip,routeResponse,flowName);
		
		//to get trip type
		List<String> nodeIds=new ArrayList<>();
		nodeIds.add(trip.getSourceNode());
		nodeIds.add(routeResponse.getRoute().getOrders().getOrder().get(0).getDestinationId());
		String tripType=getTripAndMovementType(nodeIds,trip,routeResponse);
		trip.setTripType(tripType);
		
		Set<String> prevRouteIds = new HashSet<>();
		Set<String> nextRouteIds = new HashSet<>();
		List<String> adhocTripOrders=new ArrayList<>();
		List<String> adhocTripShipments=new ArrayList<>();
		List<NodeOrdeRoute> nodeOrders =new ArrayList<>();
		int sequence=0;
		 TripIdDetails tripIdDetails=null;
		
		setTripConsignment(trip, routeResponse, prevRouteIds,nextRouteIds,adhocTripOrders,adhocTripShipments,nodeOrders,flowName);
		
		HashMap<String, Object> filter = new HashMap<>();
		filter.put(Constants.FLOWNAME, flowName);
		List<String> refIds=new ArrayList<>();
		refIds.add(routeResponse.getRoute().getRouteId());
		filter.put(Constants.REFERENCEID, refIds);

		List<Trip> existingTrip = tripService.getTrips(filter);
		if(!existingTrip.isEmpty())
		{
			throw new ValidationException("trip already present with reference id "+routeResponse.getRoute().getRouteId());
		}
		else
		{
			tripIdDetails=getTripDate(routeResponse.getRoute().getPlannedStart(), routeResponse.getStartNodeId(),trip.getMovementType().getValue());
			additionalDetails = gettripAdditionalDetails(trip);
		}
		processAdhocTripRequest(adhocTripOrders,adhocTripShipments,routeResponse,trip);

		createTrip(trip,additionalDetails,nextRouteIds,prevRouteIds,nodeOrders,tripIdDetails);
		
		return trip;
	}

	private void processAdhocTripRequest(List<String> adhocTripOrders,List<String> adhocTripShipments,RouteResponse routeResponse,Trip trip) {
		if(!CollectionUtils.isEmpty(adhocTripOrders))
		{
			List<AdhocTripRequest> adhocTripRequest = adhocTripRequestService.getAdhoctripRequest(adhocTripOrders,
					routeResponse.getStartNodeId(), Constants.PENDING);
			List<String> pendingOrderIds = adhocTripRequest.stream().map(mapper -> mapper.getOrderId())
					.collect(Collectors.toList());

			if (!CollectionUtils.isEmpty(adhocTripRequest)) {
				if (pendingOrderIds.containsAll(adhocTripOrders)) {
					trip.setAdhocTrip(true);
					log.info("Manual trip with ref id {}", routeResponse.getRoute().getRouteId());

					Map<String, List<String>> tripIdWithOrderIds = adhocTripRequest.stream()
							.collect(Collectors.groupingBy(AdhocTripRequest::getTripId, HashMap::new,
									Collectors.mapping(AdhocTripRequest::getOrderId, Collectors.toList())));

					Map<String, List<String>> externalRefIdWithOrderIds = getExternalRefIdwithOrders(
							tripIdWithOrderIds);

					nodeOrderRouteservice.updateNextRouteId(externalRefIdWithOrderIds,
							routeResponse.getRoute().getRouteId());
					nodeOrderRouteservice.updatePreviousRouteId(externalRefIdWithOrderIds,
							routeResponse.getRoute().getRouteId());

					adhocTripRequestService.updateAdhocTripStatus(adhocTripOrders, routeResponse.getStartNodeId(),
							Constants.COMPLETE);

					List<NodeOrdeRoute> orderRoute = nodeOrderRouteservice
							.getRouteIdsByNodeAndOrder(routeResponse.getStartNodeId(), adhocTripOrders);

					Set<String> nextRouteIds = orderRoute.stream().map(mapper -> mapper.getNextRouteId())
							.collect(Collectors.toSet());
					Set<String> prevRouteIds = orderRoute.stream().map(mapper -> mapper.getPreviousRouteId())
							.collect(Collectors.toSet());

					if (!CollectionUtils.isEmpty(nextRouteIds) && !nextRouteIds.contains(null))
						tripService.insertToTripHierarchy(routeResponse.getRoute().getRouteId(), nextRouteIds,
								routeResponse.getSourceSystemId());

					if (!CollectionUtils.isEmpty(prevRouteIds) && !prevRouteIds.contains(null))
						tripService.insertToTripHierarchy(prevRouteIds, routeResponse.getRoute().getRouteId(),
								routeResponse.getSourceSystemId());

					tripOrderService.deleteTripConsignment(adhocTripShipments, routeResponse.getStartNodeId(),
							OrderStatus.INREQUEST.getValue());

				}

				else {
					log.info("orders not valid to create manual trip ", adhocTripOrders);
					throw new ValidationException("orders not valid to create manual trip with routeId "
							+ routeResponse.getRoute().getRouteId());
				}
			}
		}
		
	}


	private Map<String, List<String>> getExternalRefIdwithOrders(Map<String, List<String>> tripIdWithOrderIds) 
	{
		Map<String, List<String>> externalRefIdWithOrderIds=new HashMap<>();
		List<String> tripIds=tripIdWithOrderIds.keySet().stream().collect(Collectors.toList());
		List<Trip> tripList=tripService.getTripDetails(tripIds);
		
		for(Entry<String, List<String>> entry: tripIdWithOrderIds.entrySet())
		{
			Trip  tripObj=tripList.stream().filter(f->f.getTripId().equals(entry.getKey())).findAny().orElse(null);
			externalRefIdWithOrderIds.put(tripObj.getExternalReferenceId(), entry.getValue());
		}
		return externalRefIdWithOrderIds;
	}


	private void setTripProperties(Trip trip,RouteResponse routeResponse, String flowName) {
		trip.setExternalReferenceId(routeResponse.getRoute().getRouteId());
		trip.setPlannedStartTime(DateUtility.convertStringToTimeStamp(routeResponse.getRoute().getPlannedStart(),
				Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
		trip.setPlannedEndTime(DateUtility.convertStringToTimeStamp(routeResponse.getRoute().getPlannedEnd(),
				Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
		trip.setVehicleModel(routeResponse.getRoute().getVehicleModel());
		trip.setFleetType(routeResponse.getRoute().getVehicleType());
		trip.setSuggestedVehicleNo(routeResponse.getRoute().getVehicleId());
		trip.setSourceNode(routeResponse.getStartNodeId());
		trip.setStatus(TripState.CREATED.getValue());
		trip.setPlannedKm(routeResponse.getRoute().getPlannedDistanceInKM());
		trip.setLongitude(routeResponse.getStartNodeLongitude());
		trip.setLatitude(routeResponse.getStartNodeLatitude());
		trip.setFlowName(flowName);
		trip.setCreatedBy(routeResponse.getSourceSystemId());
		
	}



	private TripIdDetails getTripDate( String date, String nodeId,String movementType)
{
		String plannedStart = DateUtility.convertStringToFormattedDate(date, Constants.EXTERNAL_SYSTEMS_DATE_FORMAT,
				Constants.DATE_FORMAT);
		int sequence = tripService.getTripCountByGivenDate(plannedStart, nodeId,movementType);
		String tripDate = DateUtility.convertStringToFormattedDate(date, Constants.EXTERNAL_SYSTEMS_DATE_FORMAT,
				Constants.FORMAT_FOR_CREATE_TRIP_ID);
		
		TripIdDetails deatils=new TripIdDetails();
		deatils.setSequence(sequence);
		deatils.setTripDate(tripDate);
		return deatils;
	}
	
	private String getTripAndMovementType(List<String> nodeIds,Trip trip,RouteResponse routeResponse)
	{
		StringBuilder nodeType=new StringBuilder();
		Map<String, Node> nodeTypes=nodeService.getNodesByID(nodeIds);
		if(!MapUtils.isEmpty(nodeTypes))
		{
			if(null!=nodeTypes.get(trip.getSourceNode()))
				nodeType.append(nodeTypes.get(trip.getSourceNode()).getNodeType().toUpperCase());
			nodeType.append(Constants.DASH);
			if(null!=nodeTypes.get(routeResponse.getRoute().getOrders().getOrder().get(0).getDestinationId()))
			{
				String type=nodeTypes.get(routeResponse.getRoute().getOrders().getOrder().get(0).getDestinationId()).getNodeType().toUpperCase();
				type=NodeType.get(type);
				nodeType.append(type);
				
				Node node= nodeTypes.get(routeResponse.getRoute().getOrders().getOrder().get(0).getDestinationId());
				if(null!=node.getCoHostId() && !node.getCoHostId().equals(routeResponse.getRoute().getOrders().getOrder().get(0).getDestinationId()))
					trip.setMovementType(MovementType.SHUTTLE);
				else
					trip.setMovementType(MovementType.FTL);
			}
			else
			{
				log.error("Node id not present in node details {}",routeResponse.getRoute().getOrders().getOrder().get(0).getDestinationId());
				throw new ValidationException("Node not present in node details service "+nodeIds);
			}
		}
		return nodeType.toString();
	}

	private void setTripConsignment(Trip trip, RouteResponse routeResponse, Set<String> prevRouteIds,
			Set<String> nextRouteIds, List<String> adhocTripOrders, List<String> adhocTripShipments,
			List<NodeOrdeRoute> nodeOrders, String flowName) {
		List<Consignment> consignmnets = new ArrayList<>();
		Map<Integer, Hub> hubSequence = new HashMap<Integer, Hub>();
		for (Order order : routeResponse.getRoute().getOrders().getOrder()) {
			Consignment consignment = new Consignment();
			consignment.setOrderId(order.getOrderId());
			consignment.setShipmentNo(order.getShipmentId());
			consignment.setNextNodeId(order.getDestinationId());
			consignment.setLatitude(order.getDestinationLatitude());
			consignment.setLongitute(order.getDestinationLongitude());
			consignment.setSlotStart(DateUtility.convertStringToTimeStamp(order.getSlotStart(),
						Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
			consignment.setSlotEnd(DateUtility.convertStringToTimeStamp(order.getSlotEnd(),
					Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
			consignment.setShipmentStatus(OrderStatus.ACTIVE.getValue());
			consignment.setCreatedBy(routeResponse.getSourceSystemId());
			consignment.setModifiedBy(routeResponse.getSourceSystemId());
			consignment.setFlowName(flowName);
			consignment.setDeliveryZoneId(order.getDeliveryZoneId());
			if (null == hubSequence.get(Integer.valueOf(order.getSequence()))) {
				Hub hub = new Hub();
				hub.setNodeId(order.getDestinationId());
				hub.setSequence(Integer.valueOf(order.getSequence()));
				hub.setPlannedArrivalTime(DateUtility.convertStringToTimeStamp(order.getEstimatedArrivalTime(),
						Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
				hub.setPlannedDispatchTime(DateUtility.convertStringToTimeStamp(order.getEstimatedDepartureTime(),
						Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
				hubSequence.put(Integer.valueOf(order.getSequence()), hub);
			}
			consignmnets.add(consignment);
			
			if (!StringUtils.isBlank(order.getNextRouteId()))
				nextRouteIds.add(order.getNextRouteId());
			
			if (!StringUtils.isBlank(order.getPrevRouteId()))
				prevRouteIds.add(order.getPrevRouteId());

			if(StringUtils.isBlank(order.getNextRouteId()) && StringUtils.isBlank(order.getPrevRouteId())){
				adhocTripOrders.add(order.getOrderId());
				adhocTripShipments.add(order.getShipmentId());
			}
			if(!StringUtils.isBlank(order.getNextRouteId()) || !StringUtils.isBlank(order.getPrevRouteId()))
				nodeOrders.add(createNodeOrder(order,trip.getSourceNode()));
		}
		trip.setConsignment(consignmnets);
		List<Hub> hubs = new ArrayList<>(hubSequence.values());
		trip.setHub(hubs);
		log.debug("Consignment info set for trip with ref id {}",routeResponse.getRoute().getRouteId());

	}
	
	private  NodeOrdeRoute createNodeOrder(Order order, String sourceNode)
	{
		NodeOrdeRoute node=new NodeOrdeRoute();
		node.setNodeId(sourceNode);
		node.setOrderId(order.getOrderId());
		node.setPreviousRouteId(order.getPrevRouteId());
		node.setNextRouteId(order.getNextRouteId());
		return node;
	}


	private TripAdditionalDetail gettripAdditionalDetails(Trip trip)
	{
		TripAdditionalDetail additionalDetails = new TripAdditionalDetail();
		 additionalDetails.setNodeId(trip.getSourceNode());
		 additionalDetails.setKey(Constants.EWAYBILL);
		 additionalDetails.setValue(EwayBillStatus.PENDING.value());
		 return additionalDetails;
	}

	/*void createTrip(Trip trip, 
			TripAdditionalDetail additionalDetails,Set<String> nextTripIds,Set<String> prevtripIds,List<NodeOrdeRoute> nodeOrders,TripIdDetails tripIdDetails) {
		log.info("started the process to create trip ");

		tripService.createtrip(trip,tripIdDetails);
		
		if (null != additionalDetails)
		{
			additionalDetails.setTripId(trip.getTripId());
			tripService.insertTripAdditionalDetails(additionalDetails);
		}
		
		if(!CollectionUtils.isEmpty(nextTripIds))
			tripService.insertToTripHierarchy(trip.getExternalReferenceId(), nextTripIds,trip.getCreatedBy());
		
		if(!CollectionUtils.isEmpty(prevtripIds))
			tripService.insertToTripHierarchy(prevtripIds, trip.getExternalReferenceId(),trip.getCreatedBy());
		
		nodeOrderRouteservice.createNodeOrderRoute(nodeOrders);
		
	}*/
	
	private void publishTripMessage(TripPublish tripPublishRequest) throws Exception
	{
		jmsPublisher.inputToQueue(queueName, tripPublishRequest, FlowName.PUBLISHTRIP.getValue(),
				Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
						tripPublishRequest.getTrip().getId()),TripPublish.class);	
	}
	void createTrip(Trip trip, 
			TripAdditionalDetail additionalDetails,Set<String> nextTripIds,Set<String> prevtripIds,List<NodeOrdeRoute> nodeOrders,TripIdDetails tripIdDetails)
	{
		
		createTrip.createtrip( trip, 
				 additionalDetails, nextTripIds,prevtripIds, nodeOrders, tripIdDetails);
	}
}
