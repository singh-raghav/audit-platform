package com.ril.newcommerce.supplychain.tms.pdf.model.daylevelack;

import com.ril.newcommerce.supplychain.tms.pdf.tools.AbstractObjectReader;
import com.ril.newcommerce.supplychain.tms.response.TripAmountResponse;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class DayLevelAckXMLReader extends AbstractObjectReader {
    public void parse(InputSource input) throws  SAXException {
        String nodeId = ((DayLevelAckInputSource) input).getNodeId();
        if (input instanceof DayLevelAckInputSource) {
            parse(((DayLevelAckInputSource) input).getTripAmountResponse(), nodeId);
        } else {
            throw new SAXException("Unsupported InputSource specified. "
                    + "Must be a DayLevelAckInputSource");
        }
    }

    private void parse(TripAmountResponse tripAmountResponse, String nodeId) throws SAXException {
        if (tripAmountResponse == null) {
            return;
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        //Start the document
        handler.startDocument();

        //Generate SAX events for the ProjectTeam
        generateFor(tripAmountResponse, nodeId);

        //End the document
        handler.endDocument();
    }

    private void generateFor(TripAmountResponse amountResponse, String nodeId) throws SAXException {
        if (amountResponse == null) {
            throw new NullPointerException("Parameter amountResponse must not be null");
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        handler.startElement("dayLevelAck");
        handler.element("sdpId", nodeId);
        handler.element("storeName", amountResponse.getStoreName());
        handler.element("sdpMgrName", amountResponse.getsDPManagerName());
        handler.element("storeAddress", amountResponse.getStoreAddress());
        handler.element("rRLId", amountResponse.getrRLId());
        handler.element("date", amountResponse.getDate());
        handler.element("totalCollected",  String.valueOf(amountResponse.getCashToBeCollected()));
        handler.element("netCashToBeDeposited",String.valueOf(amountResponse.getCashCollected()));
        handler.element("missingCash", new BigDecimal(amountResponse.getCashToBeCollected() - amountResponse.getCashCollected())
                .setScale(2, RoundingMode.HALF_UP).toString());
        handler.endElement("dayLevelAck");
    }
}
