package com.ril.newcommerce.supplychain.tms.entity.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Status", "ShipmentLines", "Extn", "ReturnOrders" })*/
public class Shipment {

	@JsonProperty("Status")
	private String status;
	@JsonProperty("OrderNo")
	private String orderNo;
	@JsonProperty("ShipmentLines")
	private ShipmentLines shipmentLines;
	@JsonProperty("Extn")
	private Extn extn;
	@JsonProperty("ReturnOrders")
	private ReturnOrders returnOrders;

	@JsonProperty("Status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("Status")
	public void setStatus(String status) {
		this.status = status;
	}
	
	@JsonProperty("OrderNo")
	public String getOrderNo() {
		return orderNo;
	}

	@JsonProperty("OrderNo")
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	@JsonProperty("ShipmentLines")
	public ShipmentLines getShipmentLines() {
		return shipmentLines;
	}

	@JsonProperty("ShipmentLines")
	public void setShipmentLines(ShipmentLines shipmentLines) {
		this.shipmentLines = shipmentLines;
	}

	@JsonProperty("Extn")
	public Extn getExtn() {
		return extn;
	}

	@JsonProperty("Extn")
	public void setExtn(Extn extn) {
		this.extn = extn;
	}

	@JsonProperty("ReturnOrders")
	public ReturnOrders getReturnOrders() {
		return returnOrders;
	}

	@JsonProperty("ReturnOrders")
	public void setReturnOrders(ReturnOrders returnOrders) {
		this.returnOrders = returnOrders;
	}

}