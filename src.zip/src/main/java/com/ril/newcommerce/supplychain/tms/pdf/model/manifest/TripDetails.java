package com.ril.newcommerce.supplychain.tms.pdf.model.manifest;

public class TripDetails {
    private String hubSequence;
    private String hubCode;
    private String secTripLoadingSequence;
    private String secTrip;
    private String loadedOrder;
    private String rollcagePallets;
    private String LoadedTotes;
    private String seal;
    private String arrivalTime;
    private String departureTime;
    private String remarks;

    public String getHubSequence() {
        return hubSequence;
    }

    public void setHubSequence(String hubSequence) {
        this.hubSequence = hubSequence;
    }

    public String getHubCode() {
        return hubCode;
    }

    public void setHubCode(String hubCode) {
        this.hubCode = hubCode;
    }

    public String getSecTripLoadingSequence() {
        return secTripLoadingSequence;
    }

    public void setSecTripLoadingSequence(String secTripLoadingSequence) {
        this.secTripLoadingSequence = secTripLoadingSequence;
    }

    public String getSecTrip() {
        return secTrip;
    }

    public void setSecTrip(String secTrip) {
        this.secTrip = secTrip;
    }

    public String getLoadedOrder() {
        return loadedOrder;
    }

    public void setLoadedOrder(String loadedOrder) {
        this.loadedOrder = loadedOrder;
    }

    public String getRollcagePallets() {
        return rollcagePallets;
    }

    public void setRollcagePallets(String rollcagePallets) {
        this.rollcagePallets = rollcagePallets;
    }

    public String getLoadedTotes() {
        return LoadedTotes;
    }

    public void setLoadedTotes(String loadedTotes) {
        LoadedTotes = loadedTotes;
    }

    public String getSeal() {
        return seal;
    }

    public void setSeal(String seal) {
        this.seal = seal;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
