package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ValidationException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.dao.OrderDetailsDAO;
import com.ril.newcommerce.supplychain.tms.entity.BusinessDetail;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.entity.Party;
import com.ril.newcommerce.supplychain.tms.entity.rest.Node;
import com.ril.newcommerce.supplychain.tms.exception.NetworkCommunicationException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.NodeService;
import com.ril.newcommerce.supplychain.tms.util.DeliveryChallanConfig;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */

@Service
public class NodeAddressAccumulator {
	
	private static final Logger log = LoggerFactory.getLogger(NodeAddressAccumulator.class);

	@Autowired
	private DeliveryChallanConfig dcConfig;
	
	@Autowired
	private NodeService nodeService;
	
	@Autowired
	private InboundDAO inboundDAO;
	
	@Autowired
	private OrderDetailsDAO orderDAO;
	
	/**
	 * In Ideal case we must be getting all address from Node Service.
	 * Since Node- service don't have Kirana addresses we are depending on the order_details table to fetch it.
	 * This method takes care of both... 
	 * 
	 * @param nodeIds
	 * @param pdrOrderIds
	 */
	public Map<String, Party> getAddress(Set<String> nodeIds , List<String> pdrOrderIds) { 
		
		//2.Get the node details from node service..
		Map<String, Node> nodeDetails = getNodeDetails(nodeIds);
		
		List<String> regionCodes = nodeDetails.values().stream().map(node->node.getRegionCode()).collect(Collectors.toList());
		
		//3. Fetch the state related details.
		Map<String, BusinessDetail> businessDetails = inboundDAO.getBusinessDetailsBystateCode(regionCodes);
		
		Map<String, Party> partyInformationByNode = new HashMap<>();
		
		nodeIds.forEach(node -> {
			Node nodeDetail = nodeDetails.get(node);
			partyInformationByNode.put(node, getPartyInformation(businessDetails.get(nodeDetail.getRegionCode()), nodeDetail));
		});
		
		//Fetch the information for kirana if any.
		if(CollectionUtils.isNotEmpty(pdrOrderIds)) {
			
			Map<String,OrderDetails> customerInfo = orderDAO.getCustomerInfo(pdrOrderIds);
			
			pdrOrderIds.forEach(orderId->{
				partyInformationByNode.put(orderId,getPartyInformation(customerInfo.get(orderId)));
			});
		}
		
		log.info("Party Informtion by Node : {} " , partyInformationByNode);
		
		return partyInformationByNode;
		
	}
	
	private Map<String, Node> getNodeDetails(Set<String> nodeIds) {
		//2.Get the node details from node service..
		Map<String, Node> nodes = null;
		try {
			List<String> nodeList = new ArrayList<>();
			nodeList.addAll(nodeIds);
			nodes = nodeService.getNodesByID(nodeList);
			if(MapUtils.isEmpty(nodes))
				throw new ValidationException("Unable to fetch Node details from Node service..");
		}
		catch (ValidationException e) {
			throw e;
		}
		catch (NetworkCommunicationException e) {
			//TODO raise alert saying that Node service is down...
			throw new TripApplicationException("Node service is down.. Aborting the challan creation.."); 	
		}
		
		return nodes;
	}
	
	private Party getPartyInformation(BusinessDetail node, Node nodeDetails) {
		
		Party party = new Party();
		if(StringUtils.isBlank(nodeDetails.getName()))
			party.setAddress(nodeDetails.getAddress().toString());
		else
			party.setAddress(nodeDetails.getName() +","+ nodeDetails.getAddress().toString());
		party.setGstin(node.getGstin());
		party.setTruckOperator(dcConfig.getTruckOperator());
		party.setStateCode(node.getId());
		party.setModeOfTransport(dcConfig.getModeOfTransport());
		
		return party;		
	}
	
	private Party getPartyInformation(OrderDetails customerInfo) {
		
		Party party = new Party();
		if(StringUtils.isBlank(customerInfo.getCustomerName()))
			party.setAddress(customerInfo.getCustomerAddress() +" , "+ customerInfo.getCustomerState() +" , " + customerInfo.getCustomerPincode());
		else
			party.setAddress(customerInfo.getCustomerName() + " , " + customerInfo.getCustomerAddress() +" , "+ customerInfo.getCustomerState() +" , " + customerInfo.getCustomerPincode());
		
		party.setGstin(customerInfo.getCustomerGstn());
		party.setTruckOperator(dcConfig.getTruckOperator());
		party.setStateCode(dcConfig.getStateCode().get(customerInfo.getCustomerStateCode())==null?customerInfo.getCustomerStateCode():dcConfig.getStateCode().get(customerInfo.getCustomerStateCode()));
		party.setModeOfTransport(dcConfig.getModeOfTransport());
		
		return party;		
	}
	
	
	

}
