package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class AtsPayload {

	private String nodeId;
	private String tripId;
	private String tripStartNodeId;
	private long eventCreationTime;
	private String eventSource;
	private String flowType;
	private List<Asset> assets;	
	private String eventId;
	
	public AtsPayload(String nodeId, String tripId, String tripStartNodeId,
			String flowType, String eventId,List<Asset> assets) {
		super();
		this.eventId=eventId;
		this.nodeId = nodeId;
		this.tripId = tripId;
		this.tripStartNodeId = tripStartNodeId;
		this.eventCreationTime = System.currentTimeMillis();
		this.eventSource = "TRIP";
		this.flowType = flowType;
		this.assets = assets;
	}
	
	public String getEventId(){
		return eventId;
	}
	
	public void setEventId(String eventId){
		this.eventId = eventId;
	}
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public String getTripStartNodeId() {
		return tripStartNodeId;
	}
	public void setTripStartNodeId(String tripStartNodeId) {
		this.tripStartNodeId = tripStartNodeId;
	}
	public long getEventCreationTime() {
		return eventCreationTime;
	}
	public void setEventCreationTime(long eventCreationTime) {
		this.eventCreationTime = eventCreationTime;
	}
	public String getEventSource() {
		return eventSource;
	}
	public void setEventSource(String eventSource) {
		this.eventSource = eventSource;
	}
	public String getFlowType() {
		return flowType;
	}
	public void setFlowType(String flowType) {
		this.flowType = flowType;
	}
	public List<Asset> getAssets() {
		return assets;
	}
	public void setAssets(List<Asset> assets) {
		this.assets = assets;
	}
}
