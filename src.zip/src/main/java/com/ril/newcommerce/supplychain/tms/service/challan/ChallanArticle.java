package com.ril.newcommerce.supplychain.tms.service.challan;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.ril.newcommerce.supplychain.tms.enums.ReturnItemQuality;

@JsonInclude(value = Include.NON_NULL)
public class ChallanArticle {
	


	private String challanId;
	private String tripId;
	private String returnOrderId;
	private String articleCode;
	private String articleDesc;
	private String hsnCode;
	private Double quantity;
	private Double recievedQuantity;
	private String UOM;
	private Double rate;
	private Double baseValue;
	private String articleType;
	private String createdBy;
	private String nodeId;
	private String returnType;
	private String orderSrcNodeId;
	private ReturnItemQuality quality;
	private String fwdOrderId;
	
	public ChallanArticle() {}
	
	public ChallanArticle(String challanId, String tripId, String returnOrderId, String articleCode,
			String articleType , double quanity, ReturnItemQuality quality, String createdBy) {
		super();
		this.challanId = challanId;
		this.tripId = tripId;
		this.returnOrderId = returnOrderId;
		this.articleCode = articleCode;
		this.articleType = articleType;
		this.quantity = quanity;
		this.createdBy = createdBy;
		this.quality = quality;
	}
	
	public ChallanArticle(String challanId, String tripId, String articleCode, String articleDesc,
			String hsnCode, double quanity, String uOM, double rate) {
		super();
		this.challanId = challanId;
		this.tripId = tripId;
		this.articleCode = articleCode;
		this.articleDesc = articleDesc;
		this.hsnCode = hsnCode;
		this.quantity = quanity;
		this.UOM = uOM;
		this.rate = rate;
	}

	/**
	 * Copy Constructor.
	 *
	 */
	public ChallanArticle(ChallanArticle article) {
		super();
		this.challanId = article.challanId;
		this.tripId = article.tripId;
		this.returnOrderId = article.returnOrderId;
		this.articleCode = article.articleCode;
		this.articleDesc = article.articleDesc;
		this.hsnCode = article.hsnCode;
		this.quantity = article.quantity;
		this.recievedQuantity = article.recievedQuantity;
		this.UOM = article.UOM;
		this.rate = article.rate;
		this.baseValue = article.baseValue;
		this.articleType = article.articleType;
		this.createdBy = article.createdBy;
		this.nodeId = article.nodeId;
		this.returnType = article.returnType;
		this.orderSrcNodeId = article.orderSrcNodeId;
		this.quality = article.quality;
	}
	
	public String getOrderSrcNodeId() {
		return orderSrcNodeId;
	}
	
	public void setOrderSrcNodeId(String orderSrcNodeId) {
		this.orderSrcNodeId = orderSrcNodeId;
	}
	
	public String getReturnType() {
		return returnType;
	}
	
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	
	public String getChallanId() {
		return challanId;
	}

	public void setChallanId(String challanId) {
		this.challanId = challanId;
	}

	public String getTripId() {
		return tripId;
	}

	public void setTripId(String tripId) {
		this.tripId = tripId;
	}

	public String getReturnOrderId() {
		return returnOrderId;
	}

	public void setReturnOrderId(String returnOrderId) {
		this.returnOrderId = returnOrderId;
	}

	public String getArticleCode() {
		return articleCode;
	}

	public void setArticleCode(String articleCode) {
		this.articleCode = articleCode;
	}

	public String getArticleDesc() {
		return articleDesc;
	}

	public void setArticleDesc(String articleDesc) {
		this.articleDesc = articleDesc;
	}

	public String getHsnCode() {
		return hsnCode;
	}

	public void setHsnCode(String hsnCode) {
		this.hsnCode = hsnCode;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Double getRecievedQuantity() {
		return recievedQuantity;
	}

	public void setRecievedQuantity(Double recievedQuantity) {
		this.recievedQuantity = recievedQuantity;
	}

	public String getUOM() {
		return UOM;
	}

	public void setUOM(String uOM) {
		UOM = uOM;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	public Double getBaseValue() {
		return baseValue;
	}

	public void setBaseValue(Double baseValue) {
		this.baseValue = baseValue;
	}

	public String getArticleType() {
		return articleType;
	}

	public void setArticleType(String articleType) {
		this.articleType = articleType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getNodeId() {
		return nodeId;
	}
	
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

	public ReturnItemQuality getQuality() {
		return quality;
	}
	
	public void setQuality(ReturnItemQuality quality) {
		this.quality = quality;
	}
	
	public String getFwdOrderId() {
		return fwdOrderId;
	}

	public void setFwdOrderId(String fwdOrderId) {
		this.fwdOrderId = fwdOrderId;
	}

	@Override
	public String toString() {
		String q = this.quality==null?"":this.quality.name();
		return "ChallanArticle [challanId=" + challanId + ", tripId=" + tripId + ", returnOrderId=" + returnOrderId
				+ ", articleCode=" + articleCode + ", nodeId=" + nodeId + ",quality=" + q + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((articleCode == null) ? 0 : articleCode.hashCode());
		result = prime * result + ((quality == null) ? 0 : quality.hashCode());
		result = prime * result + ((returnOrderId == null) ? 0 : returnOrderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChallanArticle other = (ChallanArticle) obj;
		if (articleCode == null) {
			if (other.articleCode != null)
				return false;
		} else if (!articleCode.equals(other.articleCode))
			return false;
		if (quality != other.quality)
			return false;
		if (returnOrderId == null) {
			if (other.returnOrderId != null)
				return false;
		} else if (!returnOrderId.equals(other.returnOrderId))
			return false;
		return true;
	}

}
