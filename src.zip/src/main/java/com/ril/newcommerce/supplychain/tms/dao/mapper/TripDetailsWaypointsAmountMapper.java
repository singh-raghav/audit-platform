package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TripDetailsWaypointsAmountMapper implements ResultSetExtractor<List<Trip>> {

	@Override
	public List<Trip> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<Trip> trips=new ArrayList<Trip>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			Trip trip=new Trip();
			trip.setTripId(rs.getString("TRIP_ID"));
			trip.setTripType(rs.getString("TYPE"));
			trip.setSourceNode(rs.getString("SOURCE_NODE"));
			trip.setPlannedStartTime(rs.getTimestamp("PLANNED_START"));
			trip.setPlannedEndTime(rs.getTimestamp("PLANNED_END"));
			trip.setActualStartTime(rs.getTimestamp("ACTUAL_START"));
			trip.setActualEndTime(rs.getTimestamp("ACTUAL_END"));
			trip.setStatus(rs.getString("STATUS"));
			trip.setAssignedVehicle(rs.getString("ASSIGNED_VEHICLE"));
			trip.setAssignedDpId(rs.getString("DP_ID"));
			trip.setAssignedDp(rs.getString("DP_NAME"));
			trip.setCreatedTime(rs.getTimestamp("CREATED_TS"));
			trip.setFleetType(rs.getString("FLEET_TYPE"));
			trip.setVehicleModel(rs.getString("SUGGESTED_VEHICLE_TYPE"));
			trip.setSuggestedVehicleNo(rs.getString("SUGGESTED_VEHICLE_NO"));
			trip.setVrnId(rs.getString("VRN_ID"));
			trip.setStartKm(rs.getDouble("START_KM"));
			trip.setEndKm(rs.getDouble("END_KM"));
			trip.setPlannedKm(rs.getDouble("PLANNED_KM"));  //TODO check with Divya.
			trip.setVersion(rs.getInt("VERSION"));
			trip.setExternalReferenceId(rs.getString("EXTERNAL_REF_ID"));
			trip.setCreatedBy(rs.getString("CREATED_BY"));
			trip.setMovementType(Enum.valueOf(MovementType.class, rs.getString("MOVEMENT_TYPE")));
			trip.setCashCollected(rs.getDouble("AMOUNT_PAID_SUM"));
			trip.setCashToBeCollected(rs.getDouble("AMOUNT_PAID_SUM")  + rs.getDouble("ROUND_OFF_AMOUNT_SUM"));
			trips.add(trip);
	} 
		return trips;
	}

}
