/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.ConnectionTrip;
import com.ril.newcommerce.supplychain.tms.entity.rest.Connection;
import com.ril.newcommerce.supplychain.tms.service.ConnectionTripService;
import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * @author Raghav1.Singh
 *
 */

@RestController
@RequestMapping(value = "/trip-mgmt/v2/connectiontrips")
public class ConnectionTripController {
	
	private static final Logger logger = LoggerFactory.getLogger(ConnectionTripController.class);
	
	@Autowired
	private ConnectionTripService connectionTripService;
	
	@PostMapping(produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> createTrip(@RequestBody Connection connections,
			                                          @RequestHeader(value = Constants.NODE_ID,required = true) String nodeId,
			                                          HttpServletRequest request){
		
		try {
			
			List<String> connectionList = new ArrayList<>();
			connectionList = connections.getConnections();
			ConnectionTrip connectionTrip = connectionTripService.createConnection(connectionList, nodeId);
			return Utility.getSuccessMessage("TripId created successfully", connectionTrip.getTripId());
			
		} catch (Exception e) {
			
			return Utility.getfailureMsg(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
		
	}
	
	@PatchMapping(value="/{tripId}", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ResponseMessage> updateTrip(@RequestBody Connection connections,
			                                          @RequestHeader(value = Constants.NODE_ID,required = true) String nodeId,
			                                          @PathVariable(value="tripId", required=true) String tripId, 
			                                          HttpServletRequest request){
		
		try {
			
			List<String> connectionList = new ArrayList<>();
			connectionList = connections.getConnections();
			connectionTripService.addConnection(connectionList, nodeId, tripId);
			return Utility.getSuccessMsg("TripId updated successfully");
			
		} catch (Exception e) {
			
			return Utility.getfailureMsg(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	

}
