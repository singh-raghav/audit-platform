package com.ril.newcommerce.supplychain.tms.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author jeevi.natarajan
 *
 */
public enum TripType {
	
	FC_HUB("FC-HUB") ,
	HUB_CUSTOMER("HUB-CUSTOMER"),
	HUB_FC("HUB-FC");
	
	private String value;

	public String getValue() {
		return this.value;
	}

	private TripType(String value) {
		this.value = value;
	}
	
	private static final Map<String, TripType> lookup = new HashMap<>();
	
	static {
		for (TripType reasonCode : TripType.values())
			lookup.put(reasonCode.getValue(), reasonCode);
	}

	public static TripType get(String value) {
		return lookup.get(value);
	}
	
}
