package com.ril.newcommerce.supplychain.tms.pdf.builder;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.exception.PdfCreationException;
import com.ril.newcommerce.supplychain.tms.pdf.model.hubmanifest.HubManifest;
import com.ril.newcommerce.supplychain.tms.service.ManifestGenerationService;
import com.ril.newcommerce.supplychain.tms.service.OrderDetailsService;
import com.ril.newcommerce.supplychain.tms.service.TripService;

@Service
public class HubManifestBuilder  {
    @Autowired
    private TripService tripService;

    @Autowired
    private OrderDetailsService orderService;
    
    @Autowired
    private ManifestGenerationService manifestGenerationService;

    private static final Logger log = LoggerFactory.getLogger(HubManifestBuilder.class);
    public HubManifest build(@RequestParam(value = "storeID") String storeId,
                             @RequestParam(value = "tripID") String tripId) throws Exception {

        log.info("Controller: getTripSheetDetails method starts...");
        log.info("Store ID in getTripSheetDetails :: {}", storeId);
        log.info("Trip ID in getTripSheetDetails ::: {}",  tripId);
        String errorMessage;
        try {
            if ((storeId != null && !storeId.isEmpty()) && (tripId != null && !tripId.isEmpty())) {
                String storeIdTrip = StringUtils.substringBefore(tripId, "_");
                if (storeId.equals(storeIdTrip)) {
                    return manifestGenerationService.getHubManifestDetails(storeId, tripId);
                } else {
                    errorMessage = "Invalid User! You can not print trip sheet for different store";
                }
            } else {
                errorMessage = "Invalid Request!";
            }

        } catch (Exception e) {
           errorMessage = "Exception: Controller: Caught Exception in getTripSheetDetails method: "+e;
        }
        log.error(errorMessage);
        throw new Exception(errorMessage);
    }
}
