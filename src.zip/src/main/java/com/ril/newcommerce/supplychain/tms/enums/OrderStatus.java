package com.ril.newcommerce.supplychain.tms.enums;

import java.util.HashMap;
import java.util.Map;

/**
B1.Divya
*/

public enum OrderStatus {
	
	ACTIVE("Active"),
	AWAITING_RECONCILIATION("Reconcile"),
	REPLANNED("Replanned"),
	INACTIVE("InActive"),
	INREQUEST("InRequest"),
	INPROGRESS("InProgress"),
	CANCELLED("Cancelled"),
	SUSPEND("Suspend"),
	ORDER_DELIVERED("Delivered"),
	PARTIALLY_DELIVERED("Partially Delivered"),
	FULL_DSR("Full Dsr"),
	DSR_RETURNED("DSR"),
	FC_DELAYED("Fc Delayed"),
	RESCHEDULED("Rescheduled"),
	PICKEDUP("PickedUp"),
	SHIPMENT_SHIPPED("Out For Delivery"),
	CR_RETURNED("CR"),
	REJECTED("Rejected");
	
private String value;
	
	private OrderStatus(String value){
		this.value=value;
	}
	
	public String getValue(){
		return this.value;
	}
	
	private static final Map<String, OrderStatus> lookup = new HashMap<>();
	
	static {
		for (OrderStatus type : OrderStatus.values())
			lookup.put(type.getValue(), type);
	}
	
	public static OrderStatus get(String value) {
		return lookup.get(value);
	}


}

