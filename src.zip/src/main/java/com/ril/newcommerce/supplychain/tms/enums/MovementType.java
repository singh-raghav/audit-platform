package com.ril.newcommerce.supplychain.tms.enums;

public enum MovementType 
{
	FTL("FTL"),
	SHUTTLE("SHUTTLE");
	
	private String value;
	
	private MovementType(String value){
		this.value=value;
	}
	
	public String getValue(){
		return this.value;
	}

}
