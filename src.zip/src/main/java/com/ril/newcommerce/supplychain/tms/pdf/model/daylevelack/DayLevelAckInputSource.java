package com.ril.newcommerce.supplychain.tms.pdf.model.daylevelack;

import com.ril.newcommerce.supplychain.tms.response.TripAmountResponse;
import org.xml.sax.InputSource;

public class DayLevelAckInputSource extends InputSource {

    private String nodeId;
    private TripAmountResponse tripAmountResponse;


    public DayLevelAckInputSource(TripAmountResponse tripAmountResponse, String nodeId) {
        this.tripAmountResponse = tripAmountResponse;
        this.nodeId = nodeId;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public TripAmountResponse getTripAmountResponse() {
        return tripAmountResponse;
    }

    public void setTripAmountResponse(TripAmountResponse tripAmountResponse) {
        this.tripAmountResponse = tripAmountResponse;
    }
}
