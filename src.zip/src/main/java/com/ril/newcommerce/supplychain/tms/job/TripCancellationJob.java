package com.ril.newcommerce.supplychain.tms.job;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.TripService;

/**
 * B1.Divya
 */
@Component
public class TripCancellationJob {

	private static final Logger logger = LoggerFactory.getLogger(TripCancellationJob.class);

	@Autowired
	private TripService tripService;

	@Value("${trip.cancel.awaiting.time}")
	private int awaitTime;

	@Value("${trip.cancel.fetchSize}")
	private int fetchSize;

	@Value("${trip.cancel.awaiting.unit}")
	private String awaitUnit;

	@Scheduled(fixedDelayString = "${trip.cancel.cron.delay.ms}")
	@Transactional(rollbackFor = Exception.class)
	public void handleFailedTripUnassignment() {
		logger.info("Trip cancellation Cron running.... {} ", LocalTime.now());
		try {

			List<String> tripStatus=new ArrayList<>();
			tripStatus.add(TripState.CREATED.getValue());
			tripStatus.add(TripState.ASSIGNED.getValue());
			
			List<String> shipmentstatus=new ArrayList<>();
			shipmentstatus.add(OrderStatus.ACTIVE.getValue());
			shipmentstatus.add(OrderStatus.RESCHEDULED.getValue());
			shipmentstatus.add(OrderStatus.AWAITING_RECONCILIATION.getValue());
			shipmentstatus.add(OrderStatus.INPROGRESS.getValue());
			shipmentstatus.add(OrderStatus.INREQUEST.getValue());
			
			List<Trip> trips = tripService.getTripsTobeCancelled(tripStatus, shipmentstatus, awaitUnit, fetchSize, awaitTime);

			for (Trip trip : trips) {
				try {
					tripService.moveTripToCancelledState(trip, Constants.TRIP_CANCELLATION_CRON_JOB);
				} catch (Exception e) {
					logger.error("exception occured for cancelling trip {} ", trip.getTripId());
				}
			}

		} catch (Exception e) {
			logger.error("Error in cancelling trip ::", e);
			throw new TripApplicationException(e);
		}
	}
}
