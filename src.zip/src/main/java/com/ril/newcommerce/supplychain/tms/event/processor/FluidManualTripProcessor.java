package com.ril.newcommerce.supplychain.tms.event.processor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.bouncycastle.eac.EACException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.AdhocTripRequest;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;
import com.ril.newcommerce.supplychain.tms.enums.EwayBillStatus;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.InvalidActionException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.service.AdhocTripRequestService;
import com.ril.newcommerce.supplychain.tms.service.KafkaRestProxyService;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest.Trips;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest.Trips.Trip.Orders;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest.Trips.Trip.Orders.Order;
import com.ril.newcommerce.supplychain.tms.util.Utility;


/**
 B1.Divya
 */

@Component
@Qualifier(Constants.FLUID_MANUAL_TRIP_PROCESSOR)
public class FluidManualTripProcessor implements IUpdateOnlyProcessor{

    private static final Logger log = LoggerFactory.getLogger(ManualTripProcessor.class);

    @Autowired
    TripOrdersService tripOrderService;

    @Autowired
    TripService tripService;

    @Autowired
    AdhocTripRequestService adhocTripRequestService;

    @Autowired
    private JMSPublisher jmsPublisher;

    @Value("${trip.status.queue}")
    private String queueName;

    @Autowired
    private KafkaRestProxyService commonAuditEventPublisher;

    @Override
    public void processEvent(TripEventInput event, Trip trip)
    {
        if(CollectionUtils.isEmpty(event.getConsignments()))
        {
            throw new ValidationException("Orders cannot be empty");
        }
        else
        {
            try{

                List<String> shipmentNos = event.getConsignments().stream().map(mapper -> mapper.getShipmentNo())
                        .collect(Collectors.toList());

                int count = tripOrderService.updateShipmentStatus(OrderStatus.INREQUEST.getValue(), shipmentNos, null,
                        event.getModifiedBy(), event.getFlowName(), event.getNodeId(), OrderStatus.ACTIVE.getValue());

//                if (count == shipmentNos.size())
//                {
                    log.info("Request for manual trip for number of shipments {}",shipmentNos.size());
                    List<String> nodeIds = new ArrayList<>();
                    nodeIds.add(event.getNodeId());
                    List<String> status = new ArrayList<>();
                    status.add(OrderStatus.INREQUEST.getValue());

                    List<TripConsignmentInfo> tripConsignmentInfo = tripOrderService.getTripConsignmentInfo(null,
                            nodeIds, status, null, shipmentNos,null);

                    List<AdhocTripRequest> adhocTripRequests = new ArrayList<>();

                    TripRequest tripRequest = createRequestFortrip(tripConsignmentInfo, event.getNodeId(),
                            adhocTripRequests);

                    adhocTripRequests.forEach(c -> c.setStatus(Constants.PENDING));
                    adhocTripRequests.forEach(c -> c.setCreatedBy(event.getFlowName()));
                    adhocTripRequests.forEach(c -> c.setFlowName(event.getFlowName()));

                    adhocTripRequestService.insertToAdhocTripRequest(adhocTripRequests);

                    sendtoAudit(tripRequest,event.getNodeId());

                    jmsPublisher.publishMessage(queueName, tripRequest, FlowName.MANUALTRIP.getValue(),
                            Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER,
                                    Constants.BUSINESS_VALUE_ONE, tripConsignmentInfo.get(0).getTripId()),TripRequest.class);

                    log.info("Request sent for manual trip for number of shipments {}",shipmentNos.size());
//
//                }
//                else
//                {
//                    throw new InvalidActionException("These shipments cannot be modified right now");
//                }
            }
            catch(Exception e)
            {
                log.error("exception occured during processign shipments for manual trip ",e.getMessage());
                throw new TripApplicationException(e.getMessage());
            }
        }

    }

    private TripRequest createRequest(Map<String, List<Order>> tripWithOrders,String node,List<AdhocTripRequest> adhocTripRequests)
    {
        TripRequest request =new TripRequest();
        if (!MapUtils.isEmpty(tripWithOrders))
        {
            Trips trips=new Trips();
            List<com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest.Trips.Trip> listOfTrip=new ArrayList<>();
            for (Entry<String, List<Order>> entry : tripWithOrders.entrySet())
            {
                com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest.Trips.Trip trip=new com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest.Trips.Trip();
                trip.setId(entry.getKey());
                trip.setNodeId(node);

                Orders orders=new Orders();
                orders.setOrder(entry.getValue());
                trip.setOrders(orders);
                listOfTrip.add(trip);

                List<AdhocTripRequest> adhocRequest=createAdhocRequest(entry,node);
                adhocTripRequests.addAll(adhocRequest);
            }
            trips.setTrip(listOfTrip);
            request.setTrips(trips);
        }
        return request;

    }

    private List<AdhocTripRequest> createAdhocRequest(Entry<String, List<Order>> entry,String node)
    {
        List<AdhocTripRequest> adhocRequest =new ArrayList<>();
        for( Order order :entry.getValue())
        {
            AdhocTripRequest request = new AdhocTripRequest();

            request.setTripId(entry.getKey());
            request.setNodeId(node);
            request.setOrderId(order.getOrderId());
            adhocRequest.add(request);
        }
        log.info("Adhoc trip request inserted, no. of rows {}",adhocRequest.size());
        return adhocRequest;
    }

    private TripRequest createRequestFortrip(List<TripConsignmentInfo> tripConsignmentInfo, String nodeId, List<AdhocTripRequest> adhocTripRequests)
    {
        Map<String, List<Order>> tripWithOrders = new HashMap<>();
        for(TripConsignmentInfo info: tripConsignmentInfo)
        {
            if(null!= tripWithOrders.get(info.getTripId()))
            {
                List<Order> order=tripWithOrders.get(info.getTripId());
                Order o=new Order();
                o.setOrderId(info.getOrderId());
                o.setShipmentId(info.getShipmentNo());
                order.add(o);
            }
            else
            {
                List<Order> order =new ArrayList<>();
                Order o=new Order();
                o.setOrderId(info.getOrderId());
                o.setShipmentId(info.getShipmentNo());
                order.add(o);
                tripWithOrders.put(info.getTripId(), order);
            }
        }
        return createRequest(tripWithOrders,nodeId,  adhocTripRequests);
    }
    private void sendtoAudit(TripRequest tripRequest, String nodeId)  {
        try{
            ObjectMapper objectMapper = new ObjectMapper();
            String request = objectMapper.writeValueAsString(tripRequest);
            commonAuditEventPublisher.publishToCommonAuditPlatform(Constants.TRIP_APP, nodeId, Constants.MANUAL_TRIP, System.currentTimeMillis(), request);
        }
        catch(Exception ex)
        {
            log.error(ex.getMessage());
        }

    }
}
