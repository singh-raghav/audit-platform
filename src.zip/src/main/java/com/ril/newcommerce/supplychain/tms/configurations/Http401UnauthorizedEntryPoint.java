package com.ril.newcommerce.supplychain.tms.configurations;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class Http401UnauthorizedEntryPoint implements AuthenticationEntryPoint {

    private final String unAuthorizedErrorMessage;

    @Autowired
    public Http401UnauthorizedEntryPoint(ObjectMapper objectMapper) throws JsonProcessingException {
        this.unAuthorizedErrorMessage = objectMapper.writeValueAsString(new UnAuthorizedErrorObject());
    }

    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException {
        response.setContentType("application/json");
        response.setStatus(401);
        response.getOutputStream().println("{\n" +
                "    \"status\": \"FAILURE\",\n" +
                "    \"message\": \"authToken expired/Invalid authToken\",\n" +
                "    \"statusCode\": -1,\n" +
                "    \"errors\": [\n" +
                "        {\n" +
                "            \"errorCode\": null,\n" +
                "            \"errorMessage\": \"authToken expired/Invalid authToken\"\n" +
                "        }\n" +
                "    ]\n" +
                "}");
        response.flushBuffer();
    }
}
