package com.ril.newcommerce.supplychain.tms.exception;

/**
 * @author jeevi.natarajan
 *
 */
public class RequestTimedOutException  extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2697629287814003919L;

	public RequestTimedOutException(String message) {
		super(message);
	}
	
	public RequestTimedOutException(String message,Throwable th) {
		super(message,th);
	}
	
	public RequestTimedOutException(Throwable th) {
		super(th);
	}
}

