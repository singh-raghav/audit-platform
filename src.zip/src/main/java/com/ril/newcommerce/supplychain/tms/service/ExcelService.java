package com.ril.newcommerce.supplychain.tms.service;

import org.springframework.core.io.InputStreamSource;
import org.springframework.http.ResponseEntity;

public interface ExcelService {
    ResponseEntity<InputStreamSource> createExcel(String tripId);
}
