package com.ril.newcommerce.supplychain.tms.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ril.newcommerce.supplychain.tms.constants.Constants;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping(value = "/check")

public class ThreadTestController {
		
		@GetMapping
		public void create(@RequestHeader(value = Constants.NODE_ID,required = true) String nodeId){
			
			int value=0 ;
			synchronized (nodeId) {
				value++;
				System.out.println("Hey I am " + Thread.currentThread().getName() +
						" and i updated the value to " + value);
			}
			
			
	    }

	

}
