package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDetailsMapperForAll implements ResultSetExtractor<List<OrderDetails>> {

    @Override
    public List<OrderDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<OrderDetails> orderDetailsList = new ArrayList<OrderDetails>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            OrderDetails order = new OrderDetails();
            order.setCustomerName(rs.getString("CUSTOMER_NAME"));
            orderDetailsList.add(order);
        }
        return orderDetailsList;
    }
}
