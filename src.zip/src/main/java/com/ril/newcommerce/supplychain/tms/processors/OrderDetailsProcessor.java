package com.ril.newcommerce.supplychain.tms.processors;

import com.ril.newcommerce.supplychain.tms.constants.Constants;

import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.enums.OrderClassification;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.OrderDetailsService;
import com.ril.newcommerce.supplychain.tms.service.OrderIntermediariesService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Order;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Order.ShipAddresses.ShipAdress;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Order.Shipments.Shipment;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Order.Shipments.Shipment.ShipmentLines.ShipmentLine;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.UnmarshalException;
import java.io.StringReader;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * B1.Divya
 */

@Service
@Qualifier("orderDetailsProcessor")
public class OrderDetailsProcessor implements Processor {
	
	private static final Logger log = LoggerFactory.getLogger(OrderDetailsProcessor.class);

	@Autowired
	private JAXBContextConfig jAXBContextConfig;

	@Autowired
	private OrderDetailsService orderDetailsService;
	
	@Autowired
	private InboundDAO inboundDao;


	@Autowired
	private OrderIntermediariesService orderIntermediariesService;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {
		boolean isDuplicate = false;
		try {
			long start = System.currentTimeMillis();
			StringReader reader = new StringReader(((TextMessage) message).getText());
			Order order = (Order) jAXBContextConfig.getJaxbContextInstance(Order.class).createUnmarshaller().unmarshal(reader);
			log.info("Order details received for order {}",order.getOrderNumber());
			List<OrderDetails> orderDetails = createOrders(order, flowName);
			log.info("Adding order details ",orderDetails.size());
			isDuplicate = orderDetailsService.addOrderDetails(orderDetails);
			if(!isDuplicate) {
				orderDetailsService.addCustomerDetails(orderDetails);

			    List<Shipment.Intermediaries> intermediaries = order.getShipments().getShipment().stream().map(Shipment::getIntermediaries).collect(Collectors.toList());
			    orderIntermediariesService.insertRow(intermediaries, order.getOrderNumber());

			    if(OrderClassification.Return.getValue().equals(order.getOrderClassification())) {
				    log.info("Adding Return itmes details");
				    inboundDao.addReturnItems(getReturnItems(order),flowName);
			    }
			}
			log.info("Execution time for OrderNumber {} is {} milliseconds", order.getOrderNumber(), System.currentTimeMillis() - start);
			long end = System.currentTimeMillis();
			log.info("Execution time for OrderNumber: {}, startTIme: {}, endTime: {} EXTime: {} milliseconds",order.getOrderNumber(), start, end, end - start);
			}catch (UnmarshalException par) {
			throw new ParsingException("Parsing error while parsing order details", par);
		} catch (Exception e) {
			log.error("Error while processing order details ", e);
			throw new Exception("Exception occurred while parsing order details", e);
		}

	}
	
	
	private List<OrderDetails> createOrders(Order order,String flowName){  //OrderDetails per shipment.
		
		List<OrderDetails> ordersDetails=new ArrayList<>();
		List<Shipment> shipments= order.getShipments().getShipment();
		
		if(order.getB2BCustomerInfo()==null)
			throw new ParsingException("B2B customer Info is null");
			
		String customerId = String.valueOf(order.getB2BCustomerInfo().getCustomerId());
		String stateCode = order.getB2BCustomerInfo().getStateCode();
		String gstn = order.getB2BCustomerInfo().getGstn()==null?Constants.UNREGISTERED_PERSON:order.getB2BCustomerInfo().getGstn();
		
		List<ShipAdress> shipAddress=order.getShipAddresses().getShipAdress();
		Map<String, ShipAdress> address = shipAddress.stream().collect(Collectors.toMap(ShipAdress::getId, item -> item,(x1, x2) -> x2));
		
		for(Shipment shipment:shipments){
			
			OrderDetails orderDetail=new OrderDetails();
			orderDetail.setOrderId(order.getOrderNumber());
			orderDetail.setOrderType(order.getOrderType());
			orderDetail.setOrderClassification(order.getOrderClassification());
			orderDetail.setSourceNode(shipment.getShipNode());
			orderDetail.setOrderDate(DateUtility.convertStringToTimeStamp(order.getOrderDate(),
						Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
			orderDetail.setSellerOrgCode(order.getSellerOrganizationCode());
			orderDetail.setShipmentNo(shipment.getShipmentNo());
			orderDetail.setSlotStartTime(DateUtility.convertStringToTimeStamp(shipment.getSlot().getStartTime(),
						Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
			orderDetail.setSlotEndTime(DateUtility.convertStringToTimeStamp(shipment.getSlot().getEndTime(),
						Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
			orderDetail.setOrderStatus(OrderStatus.ACTIVE.getValue());
			orderDetail.setDeliveryZoneId(shipment.getDeliveryZoneId());
			
			ShipAdress add=address.get(shipment.getShipAddressRef());
			orderDetail.setCustomerId(customerId);
			orderDetail.setCity(order.getB2BCustomerInfo().getCity());
			orderDetail.setCustomerGstn(gstn);
			orderDetail.setCustomerStateCode(stateCode);
			orderDetail.setCustomerName(add.getFirstName() +" "+add.getLastName());
			orderDetail.setCustomerAddress(add.getAddress());
			orderDetail.setCustomerState(add.getState());
			orderDetail.setCustomerPincode(add.getZipCode());
			orderDetail.setCreatedTime(new Timestamp(System.currentTimeMillis()));
			orderDetail.setCreatedBy(flowName);
			orderDetail.setFlowName(flowName);
			orderDetail.setPhoneNumber(order.getB2BCustomerInfo().getPrimaryPhone());

			ordersDetails.add(orderDetail);
			
		}
		return ordersDetails;
	}
	
	private List<ReturnItem> getReturnItems(Order order){  //OrderDetails per shipment.
		
		List<ReturnItem> returnItems =new ArrayList<>();
		List<Shipment> shipments= order.getShipments().getShipment();
		String orderId = order.getOrderNumber();
		
		for(Shipment shipment:shipments){
			for(ShipmentLine shipmentLine : shipment.getShipmentLines().getShipmentLine()) {
				
				ReturnItem item = new ReturnItem();
			
				item.setHsnCode(shipmentLine.getTaxProductCode());
				item.setPrimeLineNo(shipmentLine.getPrimeLineNo());
				item.setUnitPrice(Double.valueOf(shipmentLine.getUnitPrice()));
				item.setOrderedQuantity(shipmentLine.getActualQuantity().doubleValue());
				item.setReturnOrderId(orderId);
				item.setFwdOrderId(orderId);//For PDR.
				item.setItemId(shipmentLine.getItemID());
				item.setItemName(shipmentLine.getItemDesc());
				item.setUom(shipmentLine.getPrimaryInformation().getUnitWeightUOM());
				item.setReturnType(OrderStatus.CR_RETURNED.getValue());
				item.setOrderedQuantity(shipmentLine.getActualQuantity().doubleValue());
				item.setInvoicedQuanity(0.0);
				item.setRecievedQuantity(0.0);
				
				
				
				returnItems.add(item);
			}
		}
		
		return returnItems;
	}

}
