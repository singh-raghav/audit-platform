package com.ril.newcommerce.supplychain.tms.pdf.model.annexure;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.pdf.tools.AbstractObjectReader;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.List;

public class AnnexureXMLReader extends AbstractObjectReader {
    public void parse(InputSource input) throws IOException, SAXException {
        if (input instanceof AnnexureInputSource) {
            parse(((AnnexureInputSource) input).getAnnexure());
        } else {
            throw new SAXException("Unsupported InputSource specified. "
                    + "Must be a AnnexureInputSource");
        }
    }

    private void parse(Annexure annexure) throws SAXException {
        if (annexure == null) {
            return;
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        //Start the document
        handler.startDocument();

        //Generate SAX events for the ProjectTeam
        generateFor(annexure);

        //End the document
        handler.endDocument();
    }

    private void generateFor(Annexure annexure) throws SAXException {
        if (annexure == null) {
            throw new NullPointerException("Parameter annexure must not be null");
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        handler.startElement("annexure");
        handler.element("driverName", annexure.getDriverName());
        handler.element("fcName", annexure.getFcName());
        handler.element("hubName", annexure.getHubName());
        handler.element("totalHULoaded", annexure.getTotalHULoaded());
        handler.element("totalInvoiceLoaded", annexure.getTotalInvoiceLoaded());
        handler.element("tripDate", annexure.getTripDate());
        handler.element("tripNumber", annexure.getTripNumber());
        handler.element("vehicleNumber", annexure.getVehicleNumber());

        List<InvoiceDetails> invoiceDetails = annexure.getInvoiceDetails();
        for (InvoiceDetails invoiceDetail : invoiceDetails) {
            generateFor(invoiceDetail);
        }
        handler.endElement("annexure");
    }

    private void generateFor(InvoiceDetails invoiceDetails) throws SAXException {

        handler.startElement("invoiceDetails");
        handler.element("invoiceValue", invoiceDetails.getInvoiceValue());
        handler.element("cnNumber", invoiceDetails.getCnNumber());
        handler.element("countOfBags", invoiceDetails.getCountOfBags());
        handler.element("countOfTotes", invoiceDetails.getCountOfTotes());
        handler.element("customerName", invoiceDetails.getCustomerName());
        handler.element("eWayBillNum", getValue(invoiceDetails.geteWayBillNum()));
        handler.element("invoiceDate", invoiceDetails.getInvoiceDate());
        handler.element("invoiceNum", invoiceDetails.getInvoiceNum());
        handler.element("orderNum", invoiceDetails.getOrderNum());
        handler.endElement("invoiceDetails");
    }

    private String getValue(String value) {
        return null == value ? Constants.NA : value;
    }
}
