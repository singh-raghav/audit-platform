package com.ril.newcommerce.supplychain.tms.entity.rest.sterling;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class User implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;
    @JsonProperty("Role")
    private String Role;
    @JsonProperty("Localecode")
    private String Localecode;
    @JsonProperty("Loginid")
    private String Loginid;
    @JsonProperty("OrganizationKey")
    private String OrganizationKey;
    @JsonProperty("NodeType")
    private String NodeType;
    @JsonProperty("Password")
    private String Password;
    @JsonProperty("Activateflag")
    private String Activateflag;
    @JsonProperty("Username")
    private String Username;
    @JsonProperty("DataSecurityGroupId")
    private String DataSecurityGroupId;
    @JsonProperty("Action")
    private String Action;
    @JsonProperty("ContactPersonInfo")
    private ContactPersonInfo ContactPersonInfo;
    @JsonProperty("UserGroupLists")
    private UserGroupLists UserGroupLists;


}
