package com.ril.newcommerce.supplychain.tms.repository;

import com.ril.newcommerce.supplychain.tms.entity.UserDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserDetailsRepository extends JpaRepository<UserDetails, String> {

    UserDetails findByUserName(String userName);
    List<UserDetails> findAllByUserNameOrEmailId(String username, String emailId);

}
