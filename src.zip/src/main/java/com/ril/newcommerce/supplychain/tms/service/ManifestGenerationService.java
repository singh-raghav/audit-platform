package com.ril.newcommerce.supplychain.tms.service;

import org.springframework.http.ResponseEntity;

import com.ril.newcommerce.supplychain.tms.pdf.model.hubmanifest.HubManifest;

/**
 * @author Jeevi.Natarajan
 */
public interface ManifestGenerationService {

    ResponseEntity getManifest(String tripId, String nodeId);

	HubManifest getHubManifestDetails(String storeId, String tripId) throws Exception;
}
