package com.ril.newcommerce.supplychain.tms.entity.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"ItemID",
"ItemDesc",
"ItemShortDesc"
})*/
public class Item {

	@JsonProperty("ItemID")
	private String itemID;
	@JsonProperty("ItemDesc")
	private String itemDesc;
	@JsonProperty("ItemShortDesc")
	private String itemShortDesc;
	@JsonProperty("UnitOfMeasure")
	private String unitOfMeasure;
	@JsonProperty("TaxProductCode")
	private String taxProductCode;

	@JsonProperty("ItemID")
	public String getItemID() {
		return itemID;
	}

	@JsonProperty("ItemID")
	public void setItemID(String itemID) {
		this.itemID = itemID;
	}

	@JsonProperty("ItemDesc")
	public String getItemDesc() {
		return itemDesc;
	}

	@JsonProperty("ItemDesc")
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	@JsonProperty("ItemShortDesc")
	public String getItemShortDesc() {
		return itemShortDesc;
	}

	@JsonProperty("ItemShortDesc")
	public void setItemShortDesc(String itemShortDesc) {
		this.itemShortDesc = itemShortDesc;
	}

	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}

	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public String getTaxProductCode() {
		return taxProductCode;
	}

	public void setTaxProductCode(String taxProductCode) {
		this.taxProductCode = taxProductCode;
	}

}