package com.ril.newcommerce.supplychain.tms.exception;

/**
B1.Divya
*/

public class EventAlreadyProcessedException extends RuntimeException {

	private static final long serialVersionUID = -7654959429431861835L;

	public EventAlreadyProcessedException(String message) {
		super(message);
	}
	
	public EventAlreadyProcessedException(String message,Throwable th) {
		super(message,th);
	}
	
	public EventAlreadyProcessedException(Throwable th) {
		super(th);
	}
}
