package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.ril.newcommerce.supplychain.tms.entity.TripActivityDetails;

public interface TripActivityDAO {
    public List<TripActivityDetails> getTripOnActivityStatus(String status, int fetchSize, int thresholdTime) throws Exception;

    public void batchUpdateTripActivityStatus(@NotNull List<TripActivityDetails> tripActivities);
    
    public void insertTripActivity(TripActivityDetails tripActivity);
    
    public TripActivityDetails getTripActivity(String tripId) ;
    
    public void updateTripActivityStatus(TripActivityDetails tripActivity,String oldStatus);

}
