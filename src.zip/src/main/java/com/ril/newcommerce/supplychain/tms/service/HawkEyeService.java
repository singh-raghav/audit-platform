package com.ril.newcommerce.supplychain.tms.service;

import com.ril.newcommerce.supplychain.tms.entity.rest.hawkeye.*;

import java.time.LocalDateTime;

public interface HawkEyeService {

    HawkeyeLoginOutput authenticate(HawkeyeLoginInput hawkeyeLoginInput);

    HawkeyeCreateUserOutput createUser(HawkeyeCreateUserInput hawkeyeCreateUserInput);

    LocalDateTime getExpiryTime(HawkeyeLoginOutput hawkeyeLoginOutput);

    String resetPasswordForOthers(HawkeyeResetPasswordInput hawkeyeResetPasswordInput);

    String changePassword(String token, HawkeyeChangePasswordInput hawkeyeChangePasswordInput);

}
