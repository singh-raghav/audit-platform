package com.ril.newcommerce.supplychain.tms.exception;

/**
 * 
 * @author jeevi.natarajan
 *
 */
public class ActionExecutionException extends RuntimeException {
	
	private static final long serialVersionUID = -6807898014258786139L;

	public ActionExecutionException(String message) {
		super(message);
	}
	
	public ActionExecutionException(String message,Throwable th) {
		super(message,th);
	}
	
	public ActionExecutionException(Throwable th) {
		super(th);
	}
}