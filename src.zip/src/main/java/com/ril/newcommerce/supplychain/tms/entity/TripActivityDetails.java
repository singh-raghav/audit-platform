package com.ril.newcommerce.supplychain.tms.entity;

public class TripActivityDetails {

    // SELECT TRIP_ID, STATUS FROM
    private String tripId;
    private String Status;
    private String assignedVehicle;
    private String vehiclePartner;

    public String getTripId() {
        return tripId;
    }

    public String getStatus() {
        return Status;
    }

    public String getAssignedVehicle() {
        return assignedVehicle;
    }

    public String getVehiclePartner() {
        return vehiclePartner;
    }

    public void setTripId(String tripId) {
        this.tripId = tripId;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public void setAssignedVehicle(String assignedVehicle) {
        this.assignedVehicle = assignedVehicle;
    }

    public void setVehiclePartner(String vehiclePartner) {
        this.vehiclePartner = vehiclePartner;
    }
}
