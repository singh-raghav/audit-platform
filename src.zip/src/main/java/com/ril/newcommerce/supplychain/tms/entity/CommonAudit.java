package com.ril.newcommerce.supplychain.tms.entity;

import java.util.List;

/**
B1.Divya
*/

public class CommonAudit {
	private List<Audit> audit;

	public List<Audit> getAudit() {
		return audit;
	}

	public void setAudit(List<Audit> audit) {
		this.audit = audit;
	}

}
