package com.ril.newcommerce.supplychain.tms.entity;

/**
B1.Divya
*/

public class ConsignmentLabel {
	
	private String labelId;
	private String parentLabelId;
	private String labelType;
	private String status;
	private String shipmentNo;
	private String nodeId;
	
	public String getNodeId() {
		return nodeId;
	}
	
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public String getLabelId() {
		return labelId;
	}
	public void setLabelId(String labelId) {
		this.labelId = labelId;
	}
	public String getParentLabelId() {
		return parentLabelId;
	}
	public void setParentLabelId(String parentLabelId) {
		this.parentLabelId = parentLabelId;
	}
	public String getLabelType() {
		return labelType;
	}
	public void setLabelType(String labelType) {
		this.labelType = labelType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getShipmentNo() {
		return shipmentNo;
	}
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((labelId == null) ? 0 : labelId.hashCode());
		result = prime * result + ((shipmentNo == null) ? 0 : shipmentNo.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConsignmentLabel other = (ConsignmentLabel) obj;
		if (labelId == null) {
			if (other.labelId != null)
				return false;
		} else if (!labelId.equals(other.labelId))
			return false;
		if (shipmentNo == null) {
			if (other.shipmentNo != null)
				return false;
		} else if (!shipmentNo.equals(other.shipmentNo))
			return false;
		return true;
	}
	

	
}
