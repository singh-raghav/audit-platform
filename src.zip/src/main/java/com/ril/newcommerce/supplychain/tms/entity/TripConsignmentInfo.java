package com.ril.newcommerce.supplychain.tms.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
B1.Divya
*/

public class TripConsignmentInfo
{

	private String tripId;
	private String status;
	private String tripSourceNode;
	private String shipmentNo;
	private String orderId;
	private String orderStatus;
	private String nextNodeId;
	private int version;
	private Timestamp slotStart;
	private Timestamp slotEnd;
	private BigDecimal latitude;
	private BigDecimal longitute;
	private int sequenceNo;
	private Timestamp plannedArrival;
	private Timestamp planneddispatch;
	private String orderClassification;
	private Invoice invoice;
	private String deliveryZoneId;
	
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public String getShipmentNo() {
		return shipmentNo;
	}
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getNextNodeId() {
		return nextNodeId;
	}
	public void setNextNodeId(String nextNodeId) {
		this.nextNodeId = nextNodeId;
	}
	public Timestamp getSlotStart() {
		return slotStart;
	}
	public void setSlotStart(Timestamp slotStart) {
		this.slotStart = slotStart;
	}
	public Timestamp getSlotEnd() {
		return slotEnd;
	}
	public void setSlotEnd(Timestamp slotEnd) {
		this.slotEnd = slotEnd;
	}
	public BigDecimal getLatitude() {
		return latitude;
	}
	public void setLatitude(BigDecimal latitude) {
		this.latitude = latitude;
	}
	public BigDecimal getLongitute() {
		return longitute;
	}
	public void setLongitute(BigDecimal longitute) {
		this.longitute = longitute;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
	
	public int getSequenceNo() {
		return sequenceNo;
	}
	public void setSequenceNo(int sequenceNo) {
		this.sequenceNo = sequenceNo;
	}
	public Timestamp getPlannedArrival() {
		return plannedArrival;
	}
	public void setPlannedArrival(Timestamp plannedArrival) {
		this.plannedArrival = plannedArrival;
	}
	public Timestamp getPlanneddispatch() {
		return planneddispatch;
	}
	public void setPlanneddispatch(Timestamp planneddispatch) {
		this.planneddispatch = planneddispatch;
	}
	public String getOrderClassification() {
		return orderClassification;
	}
	public void setOrderClassification(String orderClassification) {
		this.orderClassification = orderClassification;
	}
	public Invoice getInvoice() {
		return invoice;
	}
	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}

	public String getTripSourceNode() {
		return tripSourceNode;
	}
	public void setTripSourceNode(String tripSourceNode) {
		this.tripSourceNode = tripSourceNode;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getDeliveryZoneId() {
		return deliveryZoneId;
	}
	public void setDeliveryZoneId(String deliveryZoneId) {
		this.deliveryZoneId = deliveryZoneId;
	}
	
	
}
