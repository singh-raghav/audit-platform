package com.ril.newcommerce.supplychain.tms.pdf.model.annexure;

import org.xml.sax.InputSource;

public class AnnexureInputSource extends InputSource {
    private Annexure annexure;

    public Annexure getAnnexure() {
        return annexure;
    }

    public void setAnnexure(Annexure annexure) {
        this.annexure = annexure;
    }

    public AnnexureInputSource(Annexure annexure) {
        this.annexure = annexure;
    }
}
