package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

public interface OrderStatusUpdatePostProcessor {

    void publishToAudit(String id, String orderId, String toState);
}
