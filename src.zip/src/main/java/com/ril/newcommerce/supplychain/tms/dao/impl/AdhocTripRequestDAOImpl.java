package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.AdhocTripRequestDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.AdhocTripRequestMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.entity.AdhocTripRequest;
import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;

@Repository
public class AdhocTripRequestDAOImpl implements AdhocTripRequestDAO
{
private static final Logger log = LoggerFactory.getLogger(AdhocTripRequestDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void insertToAdhocTripRequest(List<AdhocTripRequest> tripRequest) {
		
		
	log.debug("Inserting in to adhoc request table ");
	
		try{

		jdbcTemplate.batchUpdate(
				QueryConstants.INSERT_TO_ADHOC_TRIP_REQUEST,
				new BatchPreparedStatementSetter() {
					
					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1,tripRequest.get(i).getNodeId());
						ps.setString(2,tripRequest.get(i).getOrderId());
						ps.setString(3,tripRequest.get(i).getTripId());
						ps.setString(4,tripRequest.get(i).getStatus());
						ps.setString(5,tripRequest.get(i).getFlowName());
						ps.setString(6,tripRequest.get(i).getCreatedBy());
						ps.setTimestamp(7,new Timestamp(System.currentTimeMillis()));
					}
					
					@Override
					public int getBatchSize() {
						return tripRequest.size();
					}
				});
	
		} catch (Exception e) {
			throw new DataProcessingException("Exception occured while inserting adhoc request",e);
		}
	}

	@Override
	public List<AdhocTripRequest> getAdhoctripRequest(List<String> orders, String nodeId,String status) {
		List<AdhocTripRequest> adhochTripRequest= new ArrayList<AdhocTripRequest>();
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("orderIds", orders);
		parameters.addValue("nodeId", nodeId);
		parameters.addValue("status", status);
		String query = QueryConstants.GET_ADHOC_TRIP_REQUEST;
		try {
			adhochTripRequest = namedParameterJdbcTemplate.query(query, parameters, new AdhocTripRequestMapper());
		} catch (Exception e) {
			log.error("Exception occured while fetching adhoc trip requests ", e);
			throw new TripApplicationException("Exception occured while fetching adhoc trip requests ", e);
		}
		return adhochTripRequest;
	}

	@Override
	public void updateAdhocTripStatus(List<String> orders, String node, String status) {
		
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("status", status);
		parameters.addValue("orderIds", orders);
		parameters.addValue("nodeId", node);
		String query = QueryConstants.ADHOC_TRIP_REQUEST_STATUS_UPDATE;
		try {
			namedParameterJdbcTemplate.update(query, parameters);
		} catch (Exception e) {
			log.error("Exception occured while updating status of adhoc trip request ", e);
			throw new TripApplicationException("Exception occured while updating status of adhoc trip request ", e);
		}
	}

}
