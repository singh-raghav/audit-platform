package com.ril.newcommerce.supplychain.tms.externalApis;

import com.ril.newcommerce.supplychain.tms.entity.rest.hawkeye.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "hawkeyeService", url = "${hawkeye.endpoint}")
public interface HawkeyeFeign {

    @PostMapping("/v1/login")
    HawkeyeLoginOutput login(@RequestBody HawkeyeLoginInput hawkEyeLoginInput);

    @PostMapping("/v1/users")
    HawkeyeCreateUserOutput createUser(@RequestHeader("Authorization") String token, @RequestBody HawkeyeCreateUserInput hawkeyeCreateUserInput);

    @PostMapping("/v1/password/initiate-reset")
    void initiateResetForOthers(@RequestBody HawkeyeResetPasswordInput hawkeyeResetPasswordInput);

    @PostMapping("/v1/password/change-password")
    void changePassword(@RequestHeader("Authorization") String token, @RequestBody HawkeyeChangePasswordInput hawkeyeChangePasswordInput);

}
