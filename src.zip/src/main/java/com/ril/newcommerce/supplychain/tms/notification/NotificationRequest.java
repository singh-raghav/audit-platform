package com.ril.newcommerce.supplychain.tms.notification;

public class NotificationRequest {
	private String appName;
	private Header header;
	private String appKey;
	private String enterpriseId;
	private Body body;

	@Override
	public String toString() {
		return "[appName = " + appName + ", header = " + header
				+ ", appKey = " + appKey + ", enterpriseId =" + enterpriseId
				+ ", body = " + body + "]";
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public Body getBody() {
		return body;
	}

	public void setBody(Body body) {
		this.body = body;
	}

}
