package com.ril.newcommerce.supplychain.tms.entity.rest.userdetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.ril.newcommerce.supplychain.tms.entity.UserDetails;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserListResponse implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;
    int userCount;
    List<UserDetails> userList;
}
