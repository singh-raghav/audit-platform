package com.ril.newcommerce.supplychain.tms.entity.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"OrderNo",
"OrderType",
"OrderLines",
"OriginalTotalAmount"
})*/
public class ReturnOrder {

	@JsonProperty("OrderNo")
	private String orderNo;
	@JsonProperty("OrderType")
	private String orderType;
	@JsonProperty("OrderLines")
	private OrderLines orderLines;
	@JsonProperty("OriginalTotalAmount")
	private String originalTotalAmount;

	@JsonProperty("OrderNo")
	public String getOrderNo() {
		return orderNo;
	}

	@JsonProperty("OrderNo")
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	@JsonProperty("OrderType")
	public String getOrderType() {
		return orderType;
	}

	@JsonProperty("OrderType")
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	@JsonProperty("OrderLines")
	public OrderLines getOrderLines() {
		return orderLines;
	}

	@JsonProperty("OrderLines")
	public void setOrderLines(OrderLines orderLines) {
		this.orderLines = orderLines;
	}

	@JsonProperty("OriginalTotalAmount")
	public String getOriginalTotalAmount() {
		return originalTotalAmount;
	}

	@JsonProperty("OriginalTotalAmount")
	public void setOriginalTotalAmount(String originalTotalAmount) {
		this.originalTotalAmount = originalTotalAmount;
	}

}
