package com.ril.newcommerce.supplychain.tms.service;

import com.ril.newcommerce.supplychain.tms.entity.*;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.response.TripAmountResponse;
import com.ril.newcommerce.supplychain.tms.response.TripCountResponse;
import com.ril.newcommerce.supplychain.tms.response.TripLazyLoadResponse;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.util.DestinationNodesDeliveryZoneIds;
import org.json.JSONException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;


@Service
public interface TripService {
	
	public Trip getTrip(String tripId);
	
	public Trips getTrips(List<String> nodeName,Map<String,Object> filters) throws InterruptedException, ExecutionException;
	
	public void setTripStatictisc(List<Trip> tripList,List<String> nodeIds) throws InterruptedException, ExecutionException, TimeoutException;
	
	public List<VehicleStatus> getVehicleStatus(List<String> vehicleIds);
	
	public int getTripCountByGivenDate(String date,String nodeId,String movementType);
	
	public void createtrip(Trip trip,TripIdDetails tripIdDetails);
	
	public List<Trip> getTrips(HashMap<String, Object> filter) throws Exception;
	
	public void insertTripOrderAndSequenceDetails(Trip trip);
	
	public void insertToTripHierarchy(String tripId, Set<String> associatedTripIds,String system);
	
	public void insertToTripHierarchy(Set<String> prevTripIds,String tripId,String system);
	
	public void deassociateTripHierarchy(Map<String,String> tripIds);
	
	public void mergeOrdersInTrip(List<Consignment> consignments,Map<String, List<Hub>> tripSequence, String tripId,String createdBy,String flowName,String nodeId);
	
	List<Trip> getTripDetails(String tripId, String includeRecon, String nodeId, List<ReconcileArticle> returnItems) throws Exception;
	
	public void updateTripAdditionalDetails(TripAdditionalDetail additionalDetails);
	
	public void insertTripAdditionalDetails(TripAdditionalDetail additionalDetails);
	
	public void retryEwaybillGeneration(String tripId, String nodeType) throws InterruptedException, JSONException;
	 
	 public void updateTripVersion(String tripId,String flowname,String modifedBy);
	 
	 public List<Trip> getTripDetails(List<String> tripIds);
	 
	 public Map<String, List<String>> getNumberChildTrips(List<String> tripIds);

	boolean isTripStared(String shipmentNo);

	List<TripLazyLoadResponse> getTripForOrder(String shipmentNo, String nodeId);
	
	public boolean istripCancelled(List<Consignment> actaulConsignments,Trip trip,String modifiedBy,TripEvent event);
	
	public void moveTripToCancelledState(Trip trip,String modifiedby);
	
	public String getVendorId(String tripId);

	public String getVendorName(String tripId);
	
	public List<Trip> getTripsTobeCancelled(List<String> tripStatus,List<String> shipmentstatus,String unit,int fetchSize,int interval);

	List<TripAmountResponse> getTripAmount(String startDate, String endDate, String nodeId) throws ParseException;

    ResponseEntity getDayLevelAck(String fromDate, String toDate, String nodeId, String token) throws ParseException;

	List<TripCountResponse> getTripCount(List<String> nodeIds, List<String> sdpIds, String startDate, String endDate);

	Map<String, DestinationNodesDeliveryZoneIds> getDeliveryZonesAndDestinationNodesForTrips(List<String> nodeIds, Map<String, Object> filters);
}
