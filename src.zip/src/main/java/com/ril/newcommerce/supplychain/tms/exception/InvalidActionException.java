package com.ril.newcommerce.supplychain.tms.exception;

/**
 * 
 * @author jeevi.natarajan
 *
 */
public class InvalidActionException extends RuntimeException {
	
	private static final long serialVersionUID = -9121504258067570073L;

	public InvalidActionException(String message) {
		super(message);
	}
	
	public InvalidActionException(String message,Throwable th) {
		super(message,th);
	}
	
	public InvalidActionException(Throwable th) {
		super(th);
	}
}
