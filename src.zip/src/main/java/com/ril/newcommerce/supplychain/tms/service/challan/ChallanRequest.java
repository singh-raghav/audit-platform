package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.AssetMasterData;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class ChallanRequest {

	private String nodeId;
	private String tripId;
	private List<AssetMasterData> assets;
	private List<ReturnItem> returnItems;
	private String userId;
	private List<String> orderIds;
	
	public List<String> getOrderIds() {
		return orderIds;
	}
	
	public void setOrderIds(List<String> orderIds) {
		this.orderIds = orderIds;
	}
	
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getNodeId() {
		return nodeId;
	}
	
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	
	public String getTripId() {
		return tripId;
	}
	
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	
	public List<AssetMasterData> getAssets() {
		return assets;
	}
	
	public void setAssets(List<AssetMasterData> assets) {
		this.assets = assets;
	}
	
	public List<ReturnItem> getReturnItems() {
		return returnItems;
	}
	
	public void setReturnItems(List<ReturnItem> returnItems) {
		this.returnItems = returnItems;
	}
}
