package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.HubDetail;
import com.ril.newcommerce.supplychain.tms.entity.ManifestOrderDetails;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public interface ManifestDAO {
	
	public List<HubDetail> getHubWiseLoadedHUCount(String tripId);

	public List<ManifestOrderDetails> getManifestOrders(String tripID, List<String> status);

}
