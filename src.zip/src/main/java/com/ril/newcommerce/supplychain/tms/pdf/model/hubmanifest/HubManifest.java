package com.ril.newcommerce.supplychain.tms.pdf.model.hubmanifest;

public class HubManifest {
    private String tripId;
    private String tripDate;
    private String vehicleNo;
    private String deliveryPartner;
    private String totalNoOfOrders;
    private String totalNoOfTotes;
    private String initialAmountGivenTo;
    private String result;
    private String isTripDataAvailable;
    private HubManifestTripDetailSummary hubManifestTripDetailSummary;

    public String getTripId() {
        return tripId;
    }

    public void setTripId(String tripId) {
        this.tripId = tripId;
    }

    public String getTripDate() {
        return tripDate;
    }

    public void setTripDate(String tripDate) {
        this.tripDate = tripDate;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getDeliveryPartner() {
        return deliveryPartner;
    }

    public void setDeliveryPartner(String deliveryPartner) {
        this.deliveryPartner = deliveryPartner;
    }

    public String getTotalNoOfOrders() {
        return totalNoOfOrders;
    }

    public void setTotalNoOfOrders(String totalNoOfOrders) {
        this.totalNoOfOrders = totalNoOfOrders;
    }

    public String getTotalNoOfTotes() {
        return totalNoOfTotes;
    }

    public void setTotalNoOfTotes(String totalNoOfTotes) {
        this.totalNoOfTotes = totalNoOfTotes;
    }

    public String getInitialAmountGivenTo() {
        return initialAmountGivenTo;
    }

    public void setInitialAmountGivenTo(String initialAmountGivenTo) {
        this.initialAmountGivenTo = initialAmountGivenTo;
    }

    public HubManifestTripDetailSummary getHubManifestTripDetailSummary() {
        return hubManifestTripDetailSummary;
    }

    public void setHubManifestTripDetailSummary(HubManifestTripDetailSummary hubManifestTripDetailSummary) {
        this.hubManifestTripDetailSummary = hubManifestTripDetailSummary;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getIsTripDataAvailable() {
        return isTripDataAvailable;
    }

    public void setIsTripDataAvailable(String isTripDataAvailable) {
        this.isTripDataAvailable = isTripDataAvailable;
    }
}
