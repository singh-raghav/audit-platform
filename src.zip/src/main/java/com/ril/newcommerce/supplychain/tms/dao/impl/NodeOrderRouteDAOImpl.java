package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.sql.Array;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.NodeOrderRouteDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.NodeOrdeRouteMapper;
import com.ril.newcommerce.supplychain.tms.entity.NodeOrdeRoute;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge.Trips.Trip.Orders;

@Repository
public class NodeOrderRouteDAOImpl implements NodeOrderRouteDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<NodeOrdeRoute> getRouteIdsByNodeAndOrder(String nodeId, List<String> orderIds) {
		List<NodeOrdeRoute> nodeOrderRoute=new ArrayList<>();
		String query = QueryConstants.GET_NODE_ORDER_ROUTE;
		
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeId", nodeId);
		parameters.addValue("orderIds", orderIds);
		try {
			nodeOrderRoute = namedParameterJdbcTemplate.query(query,parameters, new NodeOrdeRouteMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured while getting node order route info..", e);
		}
		return nodeOrderRoute;
	}

	@Override
	public void updateCurrentRouteId(String nodeId, String routeId, List<String> orderIds) {
		String query = QueryConstants.UPDATE_CURRENT_ROUTE_ID;

		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeId", nodeId);
		parameters.addValue("orderIds", orderIds);
		parameters.addValue("routId", routeId);
		try {
			namedParameterJdbcTemplate.update(query, parameters);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured while getting node order route info..", e);
		}

	}

	@Override
	public void updatePreviousRouteId(String routeId, String preRoutId, List<String> orderIds) {
		String query = QueryConstants.UPDATE_PRE_ROUTE_ID;

		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("orderIds", orderIds);
		parameters.addValue("routeId", routeId);
		parameters.addValue("preRouteId", preRoutId);
		try {
			namedParameterJdbcTemplate.update(query, parameters);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured while updating prev route id", e);
		}

	}
	
	@Override
	public void updatePreviousRouteId(Map<String, List<String>> tripWithOrders,String newExternalRouteId) {
		
	
		String query = QueryConstants.UPDATE_PRE_ROUTE_ID;

		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		
		try {
		for(Entry<String, List<String>> entry:tripWithOrders.entrySet())
		{
			MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("routeId", newExternalRouteId);
		parameters.addValue("orderIds", entry.getValue());
		parameters.addValue("preRouteId", entry.getKey());
		namedParameterJdbcTemplate.update(query, parameters);
		}
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured while updating provious route id", e);
		}
		
	}
	
	@Override
	public void updateNextRouteId(Map<String, List<String>> tripWithOrders, String newExternalRouteId) {

		String query = QueryConstants.UPDATE_NEXT_ROUTE_ID;

		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		
		try {
			for (Entry<String, List<String>> entry : tripWithOrders.entrySet()) {
				MapSqlParameterSource parameters = new MapSqlParameterSource();
				parameters.addValue("routeId", newExternalRouteId);
				parameters.addValue("orderIds", entry.getValue());
				parameters.addValue("nextRouteId", entry.getKey());
				namedParameterJdbcTemplate.update(query, parameters);
			}
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured while updating next route id", e);
		}

	}

	@Override
	public void updateNextRouteId(String routeId, String nextRoutId, List<String> orderIds) {
		String query = QueryConstants.UPDATE_NEXT_ROUTE_ID;

		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("orderIds", orderIds);
		parameters.addValue("routeId", routeId);
		parameters.addValue("nextRouteId", nextRoutId);
		try {
			namedParameterJdbcTemplate.update(query, parameters);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured while updating next route id", e);
		}

	}

	@Override
	public void insertNodeOrderRoute(List<NodeOrdeRoute> nodeOrders) {
		
		try {
			jdbcTemplate.batchUpdate(
					QueryConstants.INSERT_TO_NODE_ORDER_ROUTE,
					new BatchPreparedStatementSetter() {
						
						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {
							ps.setString(1,nodeOrders.get(i).getNodeId());
							ps.setString(2,nodeOrders.get(i).getOrderId());
							ps.setString(3,nodeOrders.get(i).getPreviousRouteId());
							ps.setString(4,nodeOrders.get(i).getNextRouteId());
						}
						
						@Override
						public int getBatchSize() {
							return nodeOrders.size();
						}
					});
					
		}
		catch (Exception e) {
			throw new TripApplicationException("Exception occured on inserting the trip additional details ", e);
		}
		
	}

}
