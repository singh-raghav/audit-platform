package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.ConsignmentLabelService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.RFPrintBill1808;
import com.ril.newcommerce.supplychain.tms.tibco.entity.RFPrintBill1808.Shipment.Labels;
import com.ril.newcommerce.supplychain.tms.tibco.entity.RFPrintBill1808.Shipment.Labels.Label;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipment;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipment.Containers.Container;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipment.Extn.ExtnLabelInfoList.ExtnLabelInfo;

/**
B1.Divya
*/

@Service
@Qualifier(Constants.PACK_FEED_PROCESSOR)
public class PackFeedProcessor implements Processor {

	private static final Logger log = LoggerFactory.getLogger(PackFeedProcessor.class);

	@Autowired 
	private JAXBContextConfig jAXBContextConfig;
	
	@Autowired
	private ConsignmentLabelService consignmentLabelService;
	
	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception
	{
		StringReader reader = new StringReader(((TextMessage) message).getText());
		RFPrintBill1808 shipment =  (RFPrintBill1808) jAXBContextConfig.getJaxbContextInstance(RFPrintBill1808.class).createUnmarshaller().unmarshal(reader);
		
		log.debug("packfeed label messages : {}", message);
		Set<ConsignmentLabel> labels = getShipmentLableFromShipment(shipment);
		log.info("Addlabel received for {} ",shipment.getShipment().getShipmentNo());
		consignmentLabelService.saveShipmentLabel(labels);

		
	}
	
	private Set<ConsignmentLabel> getShipmentLableFromShipment(RFPrintBill1808 shipment) {
		Set<ConsignmentLabel> consignmentLabels = new HashSet<>();
		if (shipment != null && shipment.getShipment() != null && shipment.getShipment().getLabels() != null
				&& !CollectionUtils.isEmpty(shipment.getShipment().getLabels().getLabel()))
		{
			
			for (Label label : shipment.getShipment().getLabels().getLabel()) {

				
				ConsignmentLabel consignmentLabel = new ConsignmentLabel();
				consignmentLabel.setLabelId(label.getLabelID());
				consignmentLabel.setShipmentNo(shipment.getShipment().getShipmentNo());
				consignmentLabel.setLabelType(label.getLabelType());
				consignmentLabel.setParentLabelId(label.getParentID());
				consignmentLabels.add(consignmentLabel);

			}

		}
		log.info("packeed processed  :{}",consignmentLabels.size());
		return consignmentLabels;
	}

}
