package com.ril.newcommerce.supplychain.tms.notification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotificationEngine {
	
	private static final Logger log = LoggerFactory.getLogger(NotificationEngine.class);
	
	@Autowired
	private EmailNotificationService emailNotificationService;
	
	
	public void triggerAlert(String eventType, String eventDetails, String subject){
		try {
			emailNotificationService.postNotificationEmail(eventType,eventDetails, subject);
		} catch (Exception ex) {
			log.error("Exception in proccessing notification method ",ex);
			//throw new TripApplicationException("Unable to trigger notification! " + ex);
		}
	}
}
