package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;

public class ReturnArticlesMapper implements ResultSetExtractor<List<ReconcileArticle>> {

	@Override
	public List<ReconcileArticle> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<ReconcileArticle> returnArticles=new ArrayList<ReconcileArticle>();
		int count = 1;
		while (rs.next()) {
			ReconcileArticle reconcileArticle = new ReconcileArticle();
			reconcileArticle.setFwdOrderId(rs.getString("FORWARD_ORDER_ID"));
			reconcileArticle.setOrderId(rs.getString("RETURN_ORDER_ID"));
			reconcileArticle.setPrimeLineNo(rs.getString("PRIME_LINE_NO"));
			reconcileArticle.setSerialNo(count);
			reconcileArticle.setArticleName(rs.getString("ITEM_NAME"));
			reconcileArticle.setArticleId(rs.getString("ITEM_ID"));
			reconcileArticle.setHsnCode(rs.getString("HSN_CODE"));
			reconcileArticle.setQuantity(rs.getDouble("INVOICED_QTY"));
			reconcileArticle.setPricePerItem(rs.getDouble("UNIT_PRICE"));
			reconcileArticle.setUom(rs.getString("UOM"));
			reconcileArticle.setStatus(Constants.UNDELIVERED);
			reconcileArticle.setReturnType(rs.getString("RETURN_TYPE"));
			returnArticles.add(reconcileArticle);
			count++;
		} 
		return returnArticles;
	}
}


