package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.service.UpdatedOrderUtilService;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class UpdatedOrderUtilServiceImpl implements UpdatedOrderUtilService {
    private Map<String, String> orderStateMap = new ConcurrentHashMap<>();

    @Override
    public void update(String orderId, String fromState) {
        orderStateMap.put(orderId, fromState);
    }

    @Override
    public String remove(String orderId) {
        return orderStateMap.remove(orderId);
    }

    @Override
    public void delete(String orderId) {
        orderStateMap.remove(orderId);
    }
}
