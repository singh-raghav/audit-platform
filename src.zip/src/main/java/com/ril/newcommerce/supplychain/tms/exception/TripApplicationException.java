package com.ril.newcommerce.supplychain.tms.exception;

/**
B1.Divya
*/

public class TripApplicationException extends RuntimeException  {

	
	private static final long serialVersionUID = 6951241033796890299L;

	public TripApplicationException(String message) {
		super(message);
	}
	
	
	public TripApplicationException(String message,Throwable th) {
		super(message,th);
	}
	
	public TripApplicationException(Throwable th) {
		super(th);
	}
}
