package com.ril.newcommerce.supplychain.tms.event.processor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.tibco.grab.entity.DiscrepancyType;
import com.ril.newcommerce.supplychain.tms.tibco.grab.entity.Status;
import com.ril.newcommerce.supplychain.tms.tibco.grab.entity.TripSettlement;
import com.ril.newcommerce.supplychain.tms.tibco.grab.entity.TripSettlement.Discrepancies;
import com.ril.newcommerce.supplychain.tms.tibco.grab.entity.TripSettlement.Discrepancies.Discrepancy;
import com.ril.newcommerce.supplychain.tms.tibco.grab.entity.TripSettlement.Discrepancies.Discrepancy.DiscrepancyDetails;
import com.ril.newcommerce.supplychain.tms.tibco.grab.entity.TripSettlement.Discrepancies.Discrepancy.DiscrepancyDetails.DiscrepancyDetail;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
B1.Divya
*/

@Component
@Qualifier(Constants.REPORT_RECONCILE_PROCESSOR)
public class ReportReconcileProcessor implements IUpdateOnlyProcessor {
	
	@Autowired
	private JMSPublisher jmsPublisher;
	
	@Value("${tripapp.queue}")
	private String queueName;

	@Override
	public void processEvent(TripEventInput event, Trip trip)
	{
		try {
			TripSettlement settlemnetInfo = postToGrab(event);

			jmsPublisher.inputToQueue(queueName, settlemnetInfo, FlowName.PUBLISHTOGRAB.getValue(),
					Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
							event.getTripId()),TripSettlement.class);
		} catch (Exception e) {
			throw new TripApplicationException(e);
		}

	}
	private TripSettlement postToGrab(TripEventInput event)
	{
		TripSettlement tripSettlementToGrab = new TripSettlement();

		tripSettlementToGrab.setTripId(event.getTripId());
		tripSettlementToGrab.setStatus(Status.FAILURE);
		
		Discrepancies discrepancies =new Discrepancies();
		Discrepancy discrepancy =new Discrepancy();
		DiscrepancyDetails discrepancyDetails =new DiscrepancyDetails();
		DiscrepancyDetail discrepancyDetail =new DiscrepancyDetail();
		
		discrepancyDetail.setId(Constants.AMOUNTCOLLECTED);
		if(null !=event.getCashCollected())
			discrepancyDetail.setActualValue(BigDecimal.valueOf(event.getCashCollected()));
		else
			discrepancyDetail.setActualValue(BigDecimal.valueOf(0.0));
		if(null !=event.getCashToBeCollected())
			discrepancyDetail.setExpectedValue(BigDecimal.valueOf(event.getCashToBeCollected()));
		else
			discrepancyDetail.setExpectedValue(BigDecimal.valueOf(0.0));
		
		List<DiscrepancyDetail> discrepancyDetailList =new ArrayList<>();
		discrepancyDetailList.add(discrepancyDetail);
		
		discrepancyDetails.setDiscrepancyDetail(discrepancyDetailList);
		
		discrepancy.setDiscrepancyDetails(discrepancyDetails);
		discrepancy.setType(DiscrepancyType.AMOUNT);
		
		List<Discrepancy> discrepancyList= new ArrayList<>();
		
		discrepancyList.add(discrepancy);
		
		discrepancies.setDiscrepancy(discrepancyList);
		
		tripSettlementToGrab.setDiscrepancies(discrepancies);
		
		
		return tripSettlementToGrab;
	}
}
