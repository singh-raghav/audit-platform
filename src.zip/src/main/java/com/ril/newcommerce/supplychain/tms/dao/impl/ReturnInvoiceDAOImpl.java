package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.ReturnInvoiceDAO;
import com.ril.newcommerce.supplychain.tms.entity.ItemDetails;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;

@Repository
public class ReturnInvoiceDAOImpl implements ReturnInvoiceDAO{
	
	private static final Logger log = LoggerFactory.getLogger(ReturnInvoiceDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void saveReturnItems(List<ItemDetails> items) {
		try {
			if(null!=items) {
				List<Object[]> inputList = new ArrayList<>();
				for(ItemDetails item:items) {
					Object[] tmp = { item.getOrderId(), item.getReturnOrderId(), item.getPrimeLineNo(), item.getItemId(), item.getItemName(), item.getQuantity(), item.getHsnCode(), item.getUnitPrice(), item.getUom(), item.getReturnType(), Constants.RETURN_INVOICE, Constants.RETURN_INVOICE};
					inputList.add(tmp);
				}
				jdbcTemplate.batchUpdate(QueryConstants.INSERT_RETURN_ITEM_V2, inputList);
			}
		} catch(Exception ex) {
			log.error("Exception occured during inserting data for return_items ", ex);
			throw new DataProcessingException("Exception occured during inserting data into return_items ", ex);
		}
	}

	@Override
	public void updateReturnItemsOnInvoice(List<ItemDetails> items) {
		try {
			if(null!=items) {
				List<Object[]> inputList = new ArrayList<>();
				for(ItemDetails item:items) {
					Object[] tmp = { item.getQuantity(), item.getReturnOrderId(), item.getItemId(), item.getPrimeLineNo()};
					inputList.add(tmp);
				}
				jdbcTemplate.batchUpdate(QueryConstants.UPDATE_INVOICED_QTY_RETURN_ITEM, inputList);
			}
		} catch(Exception ex) {
			log.error("Exception occured during updating received quantity for return_items ", ex);
			throw new DataProcessingException("Exception occured during updating received quantity for return_items ", ex);
		}
		
	}

}
