package com.ril.newcommerce.supplychain.tms.entity.rest.commonAuditPlatform;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommonAuditPlatformInput implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;

    String eventSource;
    String trackingId;
    String businessOperation;
    long eventCreationTime;
    String event;
}
