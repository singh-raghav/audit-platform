package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;
import java.util.Map;

import com.ril.newcommerce.supplychain.tms.entity.rest.Node;

/**
B1.Divya
*/

public interface NodeService {
	
	public Node getNodeDetailsByNodeId(String nodeId);
	
	public List<Node> getNodes(List<String> nodeIds);
	
	public Map<String ,Node> getNodesByID(List<String> nodeIds);//<NodeId , Node>
	
}
