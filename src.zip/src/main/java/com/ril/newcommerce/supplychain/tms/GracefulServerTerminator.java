package com.ril.newcommerce.supplychain.tms;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.catalina.connector.Connector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;

import com.ril.newcommerce.supplychain.tms.service.challan.ChallanExecutorService;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanPdfExecutorService;
import com.ril.newcommerce.supplychain.tms.service.impl.TripExecutor;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.UnAssignmentExecutorService;

public class GracefulServerTerminator implements TomcatConnectorCustomizer, ApplicationListener<ContextClosedEvent> {
	
    private static final Logger log = LoggerFactory.getLogger(GracefulServerTerminator.class);
    
    private volatile Connector connector;
    
    @Autowired
    private ChallanExecutorService challanExecutorService;
    
    @Autowired
    private ChallanPdfExecutorService challanPdfExecutorService;
    
    @Autowired
    private UnAssignmentExecutorService unassignmentExecutor;
    
    @Autowired
    private TripExecutor tripExecutor;
    
    @Value("${server.graceful-shutdown-wait-timeout-ms:30000}")
	private long timeout;
    
    @Override
    public void customize(Connector connector) {
        this.connector = connector;
    }
    
    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
    	
    	log.info("Shutting down Challan Executor service.....");
    	challanExecutorService.shutdownChallanExecutor();
    	log.info("Sucessfully shutdown challan executor service.....");

    	log.info("Shutting down Challan Pdf Executor service.....");
    	challanPdfExecutorService.shutdownPdfChallanExecutor();
    	log.info("Sucessfully shutdown challan pdf executor service.....");
    	
    	log.info("Shutting down unassignment executor service.....");
    	unassignmentExecutor.shutdownUnAssignmentExecutor();
    	log.info("Sucessfully shutdown unassignment executor service.....");
    	
    	
    	tripExecutor.shutdownExecutor();
    	
    	log.info("Tomcat shutting down, allowing {} millis for threadpool to shutdown gracefully", timeout);
    	
        this.connector.pause();
        
        Executor executor = this.connector.getProtocolHandler().getExecutor();
        
        if (executor instanceof ThreadPoolExecutor) {
        	
            try {
            	
                ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) executor;
                threadPoolExecutor.shutdown();
                
                if (!threadPoolExecutor.awaitTermination(timeout, TimeUnit.SECONDS)) {
                	
                	log.warn("Tomcat thread pool did not shut down gracefully within {} milli-seconds. "
                			+ "Proceeding with forceful shutdown", timeout);
                }
  
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
