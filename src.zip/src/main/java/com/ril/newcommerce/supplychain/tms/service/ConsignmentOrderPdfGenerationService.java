package com.ril.newcommerce.supplychain.tms.service;

import com.ril.newcommerce.supplychain.tms.response.OrderListResponseFluidLoading;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface ConsignmentOrderPdfGenerationService {
    ResponseEntity createPdf(OrderListResponseFluidLoading orderListResponse);
}
