package com.ril.newcommerce.supplychain.tms.entity.rest;

public class ErrorMessage {
	
    private String userMessage;    

	private String internalMessage;
	
	private int code;
	
	private String moreInfo;
	
	public String getUserMessage() {
		return userMessage;
	}

	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}

	public String getInternalMessage() {
		return internalMessage;
	}

	public void setInternalMessage(String internalMessage) {
		this.internalMessage = internalMessage;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMoreInfo() {
		return moreInfo;
	}

	public void setMoreInfo(String moreInfo) {
		this.moreInfo = moreInfo;
	}

	@Override
	public String toString() {
		return "ErrorMessage [userMessage=" + userMessage + ", internalMessage=" + internalMessage + ", code=" + code
				+ ", moreInfo=" + moreInfo + "]";
	}

}
