package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.enums.ReturnItemQuality;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */

@Service
public class PickupChallanGenerator {
	
	private static final Logger log = LoggerFactory.getLogger(PickupChallanGenerator.class);
	
	
	@Autowired
	private InboundDAO inboundDAO;
	
	@Autowired
	private ChallanCreator challanCreator;
	
	@Autowired
	private ChallanRetriver challanRetriver;
	
	public ResponseEntity<InputStreamSource> getAllPickupChallanByTrip(String tripId,String userId,String nodeId) {
		
		//Get all PRD orders for a trip.
		Map<String,String> pdrIdsAndSrcNode = inboundDAO.getPDRIdAndSourceNode(tripId);
		
		if(MapUtils.isEmpty(pdrIdsAndSrcNode))
			ResponseEntityFactory.getPDFResponseFailure("No PDR orders!");
		
		//Fetch all the return_items table.
		List<String> pdrIds = pdrIdsAndSrcNode.entrySet().stream().map(entry-> entry.getKey()).collect(Collectors.toList());
		List<ReturnItem> returnItems = inboundDAO.getReturnItems(pdrIds);
		
		log.info("Return items for pickup challan in trip  :  {} - {} " ,  returnItems , tripId );
		
		if(CollectionUtils.isEmpty(returnItems))
			return ResponseEntityFactory.getPDFResponseFailure("No Return Items!");
		
		 	// Assuming, pickup-challan is created for all or None doesnt work, incase of Return reschedule.. So everytime user clicks on the generate pickup challan button. 
																							//We keeps calling create.. thinking tat there could be some reschedule order. 
		
			Map<String,List<ChallanArticle>> orderChallanArticlesMap = new HashMap<>();
			
			returnItems.forEach(item -> {
			
				ChallanArticle article = new ChallanArticle(null, tripId,
						item.getReturnOrderId(), item.getItemId() , ArticleType.RETURN_ITEM.name() ,item.getOrderedQuantity(),ReturnItemQuality.GOOD ,userId);
				
				orderChallanArticlesMap.putIfAbsent(item.getReturnOrderId(), new ArrayList<>());
				orderChallanArticlesMap.get(item.getReturnOrderId()).add(article);
			});
			
			challanCreator.createPickupChallan(nodeId, orderChallanArticlesMap);
			
		//Now pickup challan is created.. just render it.
		return challanRetriver.getAllChallansByTrip(tripId, nodeId);
	
	}

}
