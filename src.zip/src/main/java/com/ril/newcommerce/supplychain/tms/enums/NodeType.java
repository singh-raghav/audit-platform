package com.ril.newcommerce.supplychain.tms.enums;

import java.util.HashMap;
import java.util.Map;

public enum NodeType {
    FC,
    HUB,
    STORE,
    CLUSTER;
    
private static final Map<String, String> nodeType = new HashMap<>();
	
	static {
		nodeType.put("HUB", "HUB");
		nodeType.put("STORE", "CUSTOMER");
		nodeType.put("CUSTOMER", "CUSTOMER");
	}
	
	public static String get(String value) {
		return nodeType.get(value);
	}
}
