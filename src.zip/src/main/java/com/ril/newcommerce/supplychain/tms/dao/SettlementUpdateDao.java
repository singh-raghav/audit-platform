/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.TripAdditionalDetails;
import com.ril.newcommerce.supplychain.tms.entity.TripSettleDetails;

/**
 * @author Raghav1.Singh
 *
 */
public interface SettlementUpdateDao {
	
	public List<TripSettleDetails> getOrderDetails(String tripId);
	
	public List<TripAdditionalDetails> getTripDetails(String tripId);

}
