package com.ril.newcommerce.supplychain.tms.controller;


import javax.websocket.server.PathParam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.exception.PdfCreationException;
import com.ril.newcommerce.supplychain.tms.service.ManifestGenerationService;
import com.ril.newcommerce.supplychain.tms.service.PdfDeletionService;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.MSG_OBJECT_CREATION_FAILED;

/**
 *
 * @author Jeevi.Natarajan
 *
 */
@RestController
@RequestMapping(value = "/trip-mgmt/v1/trips/{tripId}/manifest")
public class ManifestController {

	private static final Logger log = LoggerFactory.getLogger(ManifestController.class);

	@Autowired
	private ManifestGenerationService mainfestGenerationService;

	@Autowired
	private PdfDeletionService pdfDeletionService;


	@GetMapping(produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity getManifest(@PathVariable(value = "tripId", required = true) String tripId,
                                             @PathParam(value = Constants.NODE_ID) String nodeId) {
		log.info("Generate FC Manifest for  : {}", tripId);
		String  errorMessage;
		try {
			return mainfestGenerationService.getManifest(tripId, nodeId);
			
		} catch ( PdfCreationException e) {
			errorMessage = e.getMessage();
			log.error("Manifest pdf creation failed! {}", e);
		} catch (Exception e) {
			errorMessage = MSG_OBJECT_CREATION_FAILED;
			log.error("Manifest object creation failed! {}", e);

		} finally {
			pdfDeletionService.deletePDf();
		}
		return ResponseEntityFactory.getPDFResponseFailure(errorMessage);
	}
}
