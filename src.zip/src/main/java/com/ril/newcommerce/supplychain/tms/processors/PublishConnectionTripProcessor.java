/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.ConnectionTripDAO;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripIdDetails;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.connection.entity.ConnectionTrip;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * @author Raghav1.Singh
 *
 */

@Service
@Qualifier("publishConnectionTripProcessor")
public class PublishConnectionTripProcessor implements Processor {
	
	private static final Logger log = LoggerFactory.getLogger(PublishConnectionTripProcessor.class);
	
	@Autowired 
	private JAXBContextConfig jAXBContextConfig;
	
	@Autowired
	private TripService tripService;
	
	@Autowired
	private ConnectionTripDAO connectionTripDAO;
	
	@Value("${trip.status.queue}")
	private String queueName;

	@Autowired
	private JMSPublisher jmsPublisher;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {
		
		try {
			
			StringReader reader = new StringReader(((TextMessage) message).getText());
			
			TripPublish tripPublishRequest = (TripPublish) jAXBContextConfig.getJaxbContextInstance(TripPublish.class)
					.createUnmarshaller().unmarshal(reader);
			
			String tripId = tripPublishRequest.getTrip().getId();
			int version = tripPublishRequest.getTrip().getVersion();
			boolean isAdhocTrip=tripPublishRequest.getTrip().isIsAdhocTrip();
			
			if (StringUtils.isBlank(tripId)) {
				throw new ParsingException("TripId cannot be null for creating tripFeed");
			}
			
			Trip trip = tripService.getTrip(tripId); 
			
			validate(trip, version, tripId);
			
			List<String> connections = connectionTripDAO.getConnections(tripId);
			
            ConnectionTrip response = setConnectionTripData(trip,connections);
			
			jmsPublisher.publishMessage(queueName, response,
					FlowName.CONNECTIONTRIPFEED.getValue(), Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER,
							Constants.BUSINESS_VALUE_ONE, tripId,Constants.BUSINESS_KEY_TWO, Constants.MOVEMENT_TYPE , 
							Constants.BUSINESS_VALUE_TWO, trip.getMovementType().toString()),
					        ConnectionTrip.class);
			
			log.info("Published ConnectionTripFeed response :{}", tripId);
			
		}
		catch(ParsingException par){
			
			throw new ParsingException("Parsing error while parsing publish trip message",par);
		}		
		catch (Exception e) {
			
			log.error("Error while processing trip ", e);
			throw new TripApplicationException("Exception occurred while creating  Connectiontripfeed", e);
		}						

	}
	
	private void validate(Trip trip,int version,String tripId){
		
		if(null!=trip)
		{
			 if (trip.getVersion() > version) {
				throw new ValidationException("version received  is lesser than in original state for tripId"
						+ trip.getTripId() + "version present " + trip.getVersion() + " and received " + version);
			}
			else if(trip.getVersion() < version)
			{
				log.info("Sent to retry queue to publish trip trip version {} and received {} ",trip.getVersion(),version);
				throw new TripApplicationException("Trip version in db is " +trip.getVersion() +" and received is "+version);
			}
		}
		else
		{
			log.info("Trip doesn't exist in DB, sent to retry queue {} ",tripId);
			throw new TripApplicationException("Trip doesn't exist in DB, sent to retry queue "+tripId);	
		}
		
	}
	
    private ConnectionTrip setConnectionTripData(Trip trip, List<String> connectionList) {
		
		ConnectionTrip connectionTrip = new ConnectionTrip();		
		
		connectionTrip.setSourceSystemId(Constants.TRIP_APP);
		connectionTrip.setLoadingType("FluidLoading");
		connectionTrip.setMovementType(trip.getMovementType().getValue());
		connectionTrip.setVersion(trip.getVersion());
		connectionTrip.setStartNodeId(trip.getSourceNode());
		connectionTrip.setTripId(trip.getTripId());
		connectionTrip.setTripStatus(trip.getStatus());
		connectionTrip.setPlannedStart(DateUtility.convertTimeStampToString(trip.getPlannedStartTime(),
				Constants.PUBLISH_DATE_FORMAT));
		
		List<ConnectionTrip.Connections.Connection> connection = new ArrayList<ConnectionTrip.Connections.Connection>();
		
		if(connectionList!=null) {			
			for (String s: connectionList) {
				ConnectionTrip.Connections.Connection obj = new ConnectionTrip.Connections.Connection();
				obj.setDestinationId(s);
				connection.add(obj);
			}			
		}			
		
		ConnectionTrip.Connections connections = new ConnectionTrip.Connections();
		
		connections.setConnections(connection);
		
		connectionTrip.setConnections(connections);		
		
		return connectionTrip;
	}

}
