package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;

public class ReturnItemsByOrderMapper implements RowMapper<ReturnItem> {

	@Override
	public ReturnItem mapRow(ResultSet rs, int arg1) throws SQLException {
		
		ReturnItem  returnItem = new ReturnItem();
		
		returnItem.setChallanId(rs.getString("CHALLAN_ID"));
		returnItem.setReturnOrderId(rs.getString("RETURN_ORDER_ID"));
		returnItem.setFwdOrderId(rs.getString("FORWARD_ORDER_ID"));
		returnItem.setItemId(rs.getString("ITEM_ID"));
		returnItem.setPrimeLineNo(rs.getString("PRIME_LINE_NO"));
		returnItem.setItemName(rs.getString("ITEM_NAME"));
		returnItem.setOrderedQuantity(rs.getDouble("ORDERED_QTY"));
		returnItem.setHsnCode(rs.getString("HSN_CODE"));
		returnItem.setUnitPrice(rs.getDouble("UNIT_PRICE"));
		returnItem.setUom(rs.getString("UOM"));
		returnItem.setRecievedQuantity(rs.getDouble("RECEIVED_QTY"));
		returnItem.setInvoicedQuanity(rs.getDouble("INVOICED_QTY"));
		returnItem.setReturnType(rs.getString("RETURN_TYPE"));
		
		return returnItem;

	}

}
