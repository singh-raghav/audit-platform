package com.ril.newcommerce.supplychain.tms.enums;

public enum AccountStatus {
    ACTIVE,
    LOCKED,
    DELETED
}
