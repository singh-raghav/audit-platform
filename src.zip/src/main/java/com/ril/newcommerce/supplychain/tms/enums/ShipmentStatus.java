package com.ril.newcommerce.supplychain.tms.enums;

/**
 * B1.Divya
 */

public enum ShipmentStatus {

	AVAILABLE("Available"), NOTAVAILABLE("NotAvaiable");

	private String value;

	private ShipmentStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

}
