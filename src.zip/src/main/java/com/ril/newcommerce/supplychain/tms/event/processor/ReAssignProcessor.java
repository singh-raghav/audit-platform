package com.ril.newcommerce.supplychain.tms.event.processor;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.AssignTripAction;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */

@Component
@Qualifier(Constants.REASSIGN_PROCESSOR)
@Transactional(rollbackFor = Exception.class)
public class ReAssignProcessor  implements IUpdateOnlyProcessor {
	
	private static final Logger log = LoggerFactory.getLogger(ReAssignProcessor.class);
	
	@Autowired
	private AssignTripAction assignAction;
	
	@Override
	public void processEvent(TripEventInput event , Trip trip) { 
		
		log.info("Logging the event : {} " ,trip.getTripId()); 
		assignAction.doExecute(trip, event); //Call the assign trip.. It will not affect the state-machine.
		
		log.info("Reassign Success for trip : {} " , trip.getTripId());
		
	}

}
