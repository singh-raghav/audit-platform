package com.ril.newcommerce.supplychain.tms.dao;

import java.io.IOException;

import org.json.JSONException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ril.newcommerce.supplychain.tms.entity.ATSResponse;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.rest.HubTripDetails;
import com.ril.newcommerce.supplychain.tms.settlement.entity.TripReconcile;

public interface TripReconcileDAO {

	ATSResponse getAssetForReconcile(String tripId);
}
