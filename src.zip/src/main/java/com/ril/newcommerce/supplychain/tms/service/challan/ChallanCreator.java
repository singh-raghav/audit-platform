package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.entity.AssetMasterData;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.rest.Asset;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.enums.AssetFlowName;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.service.NodeService;
import com.ril.newcommerce.supplychain.tms.service.TripSequenceService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.util.AssetEventPublisher;
import com.ril.newcommerce.supplychain.tms.util.GenericUtils;

/**
 * Takes care of Delivery/pickup challan Creation.
 * @author Jeevi.Natarajan
 *
 */

@Service
@Transactional(rollbackFor = Exception.class)
public class ChallanCreator {
	
	private static final Logger log = LoggerFactory.getLogger(ChallanCreator.class);

	@Autowired
	private NodeService nodeService;
	
	@Autowired
	private InboundDAO inboundDAO;
	
	@Autowired
	private AssetEventPublisher assetEventPublisher;

	@Value("${ats.assettypes.url}")
	private String assetTypesUrl;

	@Value("${pdf.deliveryChallan}")
	private String deliveryChallanXsl;
	
	@Autowired
	@Qualifier(Constants.STRING_UTIL)
	private GenericUtils<String> util;
	
    @Value("${pdf.deliveryChallan}")
    private String challanTemplatePath;
    
    @Autowired
	private TripService tripService;
    
    @Autowired
	private TripSequenceService tripSequenceService;
  
    @Autowired
	private ChallanExecutorService challanExecutorService;
	
	public void createDeliveryChallan(ChallanRequest request) {
		
		if(request==null)
			throw new ValidationException("Request can't be null!");
		
		log.info("Return Items : {}" , request.getReturnItems());
			
		Map<String,List<ChallanArticle>> orderChallanArticlesMap = null; //This has orderId , deliveryChallan Article.
				
		List<ReturnItem>  inputReturnItems= request.getReturnItems();
		List<AssetMasterData> assets = request.getAssets();
		List<ReturnItem> returnItems = null;
		if(CollectionUtils.isNotEmpty(inputReturnItems)) {
			log.info("ReturnItems - orderids : {} " , request.getOrderIds());
			// Fetch the returnItems details from ReturnItems table - Required for order , item mapping.
			returnItems = inboundDAO.getItemAccumulatedByOrderId(request.getOrderIds()); 
			log.info("ReturnItems from DB : {} " , returnItems);
		}
		orderChallanArticlesMap = ChallanUtils.getChallanArticles(inputReturnItems,returnItems,assets,request.getTripId(),request.getUserId());
		
		triggerChallanCreation(request.getNodeId(), orderChallanArticlesMap, false);
		
		// Send event to ATS.
		if(CollectionUtils.isNotEmpty(assets)) { //Send Information to ATS...
		
			List<Asset> assetsToBeSent  = new ArrayList<>();
			assets.stream().filter(asset-> (asset.getQuantity()!=null && asset.getQuantity()>0)).forEach(selectedAsset->{
				
				Asset asset = new Asset();
				asset.setAssetType(selectedAsset.getAssetName());
				asset.setCount(selectedAsset.getQuantity().intValue());
				assetsToBeSent.add(asset);
			});
			
			if(CollectionUtils.isNotEmpty(assetsToBeSent)) {
				sendAssetToATS(request,assetsToBeSent);
					
			}
		}
	
	}
	
	private void sendAssetToATS(ChallanRequest request, List<Asset> assetsToBeSent) 
	{
		Trip trip = tripService.getTrip(request.getTripId());
		if(MovementType.FTL.equals(trip.getMovementType()))
		{
			assetEventPublisher.sendAssetInfoToATS(assetsToBeSent, request.getNodeId(), trip.getSourceNode(),
					request.getTripId(), UUID.randomUUID().toString(), AssetFlowName.OUT);
		}
		else
		{
			Map<String,List<Hub>> map = tripSequenceService.getTripSequence(request.getTripId());

			List<Hub> hub = null;
			if(!map.isEmpty()) {
				hub = map.get(request.getTripId());
			}
			else{
				throw new TripApplicationException("Tripsequence for tripId="+request.getTripId()+ " is empty.");
			}

			String nodeId;
			if(hub != null && hub.size() > 0){
				nodeId = hub.get(0).getNodeId();
			}
			else{
				throw new TripApplicationException("Hub list is empty for tripId="+request.getTripId());
			}
			
			assetEventPublisher.sendAssetInfoToATS(assetsToBeSent,request.getNodeId(),nodeId, request.getTripId(), UUID.randomUUID().toString(), AssetFlowName.OUT);
		}
			
	
		
	}

	public void createPickupChallan(String nodeId , Map<String,List<ChallanArticle>> orderChallanArticlesMap) { 
	
		triggerChallanCreation(nodeId, orderChallanArticlesMap, true);
	}
	
	
	private void triggerChallanCreation(String nodeId , Map<String,List<ChallanArticle>> orderChallanArticlesMap,boolean isPickup) {
		//Trigger challan creation threads
		Set<Callable<String>> tasks = new HashSet<>();
		for(Entry<String, List<ChallanArticle>> entry  : orderChallanArticlesMap.entrySet()) {
			String returnOrderId = ArticleType.ASSET.name().equals(entry.getKey())?null:entry.getKey();
					
			log.info("REturnOrderId - articles : {} - {}" ,  returnOrderId , entry.getValue());
			ChallanCreatorThread challanGenerator = new ChallanCreatorThread(nodeService, inboundDAO, returnOrderId, entry.getValue(),
							nodeId,isPickup);
			tasks.add(challanGenerator);
		}
				
		try {
			List<Future<String>> futures = challanExecutorService.getChallanExecutor().invokeAll(tasks);
			for(Future<String> future : futures){
				String res = future.get();
				if(StringUtils.isNotBlank(res))
					throw  new TripApplicationException("Unable to create Challan. Please Try Again!");
			}
		} catch (InterruptedException  | ExecutionException e ) {
			throw new ValidationException("Unable to create Delivery challan");
		}
	}
	
}
