package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.entity.Invoice;
import com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill.Trip.TripOrders.TripOrder;



@Service
public interface OrderInvoiceService {
	
	void addOrderInvoiceDetails(Invoice invoice);
	List<Invoice> getAllInvoiceForTrip(String tripId,List<String> status);
	void updateEwayBillStatusForOrders(List<TripOrder> tripOrders);

	boolean isOrderInvoiced(String OrderId);
}
