package com.ril.newcommerce.supplychain.tms.dao.impl;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.WayPointUpdatesDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.OrderExcelViewResponseMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.WayPointUpdatesMapper;
import com.ril.newcommerce.supplychain.tms.entity.WayPointUpdates;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.response.OrderExcelViewResponse;
import com.ril.newcommerce.supplychain.tms.service.impl.WayPointUpdatesServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

@Repository
public class WayPointUpdatesDAOImpl implements WayPointUpdatesDAO {
	
	private static final Logger log = LoggerFactory.getLogger(WayPointUpdatesServiceImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void insertToWayPointUpdate(List<WayPointUpdates> wayPointUpdates) {
		try {
			jdbcTemplate.batchUpdate(QueryConstants.INSERT_TO_WAYPOINT_UPDATE, new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, wayPointUpdates.get(i).getTripId());
					ps.setString(2, wayPointUpdates.get(i).getWayPointId());
					ps.setString(3, wayPointUpdates.get(i).getNodeId());
					ps.setString(4, wayPointUpdates.get(i).getOrderId());
					ps.setString(5, wayPointUpdates.get(i).getOrderClassification());
					ps.setString(6, wayPointUpdates.get(i).getStatus());
					ps.setString(7, String.valueOf(wayPointUpdates.get(i).getShouldReconcile()));
					ps.setString(8, wayPointUpdates.get(i).getCreatedBy());
					ps.setTimestamp(9, new Timestamp(System.currentTimeMillis()));
					ps.setString(10, wayPointUpdates.get(i).getFlowName());
					setVal(ps, wayPointUpdates.get(i).getAmountPaid(), 11);
					setVal(ps, wayPointUpdates.get(i).getRoundOffAmount(), 12);
				}

				private void setVal(PreparedStatement ps, Double doubleVal, int index) throws SQLException {
					if ((null == doubleVal)) {
						ps.setDouble(index, 0);
					} else {
						ps.setDouble(index, doubleVal);
					}
				}

				@Override
				public int getBatchSize() {
					return wayPointUpdates.size();
				}
			});

		} catch (Exception e) {
			throw new DataProcessingException("Got Exception while inserting trip details in trip table", e);
		}
		log.info("Waypoint updates successfully consumed");
	}

	@Override
	public List<WayPointUpdates> getWayPointUpdates(String tripId) 
	{
		List<WayPointUpdates> wayPoinUpdates=null;
		try {
			 wayPoinUpdates = jdbcTemplate.query(QueryConstants.GET_WAY_POINT_UPDATES,
					new Object[] { tripId }, new WayPointUpdatesMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception ocurred getting waypoint details ", e);
		}
		return wayPoinUpdates;
	}

	@Override
	public List<OrderExcelViewResponse> getOrderViewExcel(String tripId) {
		List<OrderExcelViewResponse> viewResponses;
		try {
			viewResponses = jdbcTemplate.query(QueryConstants.GET_WAYPOINT_TRIP_ORDER_CUSTOMER_INVOICE,
					new Object[]{tripId}, new OrderExcelViewResponseMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred getting order excel view response. ", e);
		}
		return viewResponses;
	}

    @Override
    public String getLastUpdate(String orderId) {
        try {
            return jdbcTemplate.queryForObject(QueryConstants.GET_LAST_WAY_POINT_UPDATE_FOR_ORDER,
                    new Object[]{orderId}, String.class);
        } catch (Exception e) {
            throw new TripApplicationException("Exception occurred while getting waypoint details for orderId" + orderId, e);
        }
    }

}
