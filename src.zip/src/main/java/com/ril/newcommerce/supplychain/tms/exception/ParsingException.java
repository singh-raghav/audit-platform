package com.ril.newcommerce.supplychain.tms.exception;

/**
 * 
 * 
 * @author jeevi.natarajan
 *
 */
public class ParsingException extends RuntimeException {

	private static final long serialVersionUID = 8421036679298041548L;

	public ParsingException(String message) {
		super(message);
	}
	
	public ParsingException(String message,Throwable th) {
		super(message,th);
	}
	
	public ParsingException(Throwable th) {
		super(th);
	}

}
