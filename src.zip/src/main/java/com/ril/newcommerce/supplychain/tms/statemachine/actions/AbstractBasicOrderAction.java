package com.ril.newcommerce.supplychain.tms.statemachine.actions;

import com.google.common.collect.Lists;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.OrderEvent;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.exception.ActionExecutionException;
import org.springframework.statemachine.StateContext;
import org.springframework.statemachine.action.Action;

import java.util.List;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.FLOWNAME;
import static com.ril.newcommerce.supplychain.tms.constants.Constants.ORDER_ID;

public abstract class AbstractBasicOrderAction implements Action<OrderState, OrderEvent> {

    @Override
    public void execute(StateContext<OrderState, OrderEvent> context) {

        try {

            String orderId = (String) context.getExtendedState().getVariables().get(ORDER_ID);

            String state = ((OrderState) context.getExtendedState().getVariables().get(Constants.ORDER_STATE)).getValue();
            String flowName = (String) context.getExtendedState().getVariables().get(FLOWNAME);

            doExecute(Lists.newArrayList(orderId), state, flowName, flowName);

        } catch (ActionExecutionException e) {
            context.getStateMachine().setStateMachineError(e);
        } catch (Exception e) {
            context.getStateMachine().setStateMachineError(new ActionExecutionException(e.getMessage()));
        }
    }

    public abstract void doExecute(List<String> orderId, String orderState, String flowName, String modifiedBy) throws ActionExecutionException;

}
