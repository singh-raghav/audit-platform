package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.TripOrdersDAO;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.NodeOrdeRoute;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.NodeOrderRouteService;
import com.ril.newcommerce.supplychain.tms.service.OrderDetailsService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Split;

/**
B1.Divya
*/
@Service
@Qualifier(Constants.POST_SPILT_PROCESSOR)
public class PostSplitProcessor implements Processor  {
	
	private static final Logger log = LoggerFactory.getLogger(PostSplitProcessor.class);
	
	@Autowired 
	private JAXBContextConfig jAXBContextConfig;
	
	@Autowired
	private OrderDetailsService orderDetailsService;
	
	@Autowired
	private NodeOrderRouteService nodeOrderRouteservice;
	
	@Autowired
	private TripOrdersDAO tripOrderDAO;
	
	@Autowired
	private TripService tripService;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception 
	{
		log.info("post split feed :{} ",message);
		
		StringReader reader = new StringReader(((TextMessage) message).getText());
		Split splitDetails = (Split) jAXBContextConfig.getJaxbContextInstance(Split.class).createUnmarshaller().unmarshal(reader);
		String tripId= splitDetails.getTrip().getId();
		String nodeId=splitDetails.getTrip().getNodeId();
		int version=splitDetails.getTrip().getVersion();
		
		log.info("Post split processor called for {}",tripId );
		
		Trip trip=tripService.getTrip(tripId);
		
		validate( trip, version);
		
		
		List<String> orderIdsToSplit = splitDetails.getTrip().getOrders().getOrder().stream()
				.map(mapper -> mapper.getOrderId()).collect(Collectors.toList());
		
		List<String> status=new ArrayList<>();
		status.add(OrderStatus.ACTIVE.getValue());
		status.add(OrderStatus.INACTIVE.getValue());
		
		List<Consignment> consignment = orderDetailsService.getTripOrderAndAdditionalDetails(tripId,
				nodeId, status, null,null);
		
		List<String> orderIdsOfTrip=consignment.stream().filter(f->f.getShipmentStatus().equals(OrderStatus.ACTIVE.getValue())).map(mapper->mapper.getOrderId()).collect(Collectors.toList());
			
		Map<String,String> deassociateHierarchy=getTripstoDeassociateHierarchy(orderIdsToSplit, trip.getExternalReferenceId(), nodeId, orderIdsOfTrip);
		
		
		if(!MapUtils.isEmpty(deassociateHierarchy))
			tripService.deassociateTripHierarchy(deassociateHierarchy);
		
		log.info("post split processor executed successfully {} ",trip.getTripId());
		
	}
	
	
	private String getTrips(List<String> orderIdsToSplit,List<String> orderIdsOfTrip,String routeId)
	{
		List<String> orderCopy=new ArrayList<>(orderIdsOfTrip);
		List<String> status=new ArrayList<>();
		status.add(OrderStatus.ACTIVE.getValue());
		List<TripConsignmentInfo> tripConsignmentInfo=tripOrderDAO.getTripConsignmentInfo(null, null,status, routeId,null,null);
		List<String> tripOrderIds=tripConsignmentInfo.stream().map(mapper->mapper.getOrderId()).collect(Collectors.toList());
		orderCopy.removeAll(orderIdsToSplit);
		tripOrderIds.removeAll(orderIdsToSplit);
		orderCopy.retainAll(tripOrderIds);
		if(CollectionUtils.isEmpty(orderCopy))
		{
			return routeId;
		}
		
		return null;
	}
	
	private Map<String,String> getTripstoDeassociateHierarchy(List<String> orderIdsToSplit,String tripId,String nodeId,List<String> orderIdsOfTrip)
	{
		List<NodeOrdeRoute> ordeRoute = nodeOrderRouteservice.getRouteIdsByNodeAndOrder(nodeId, orderIdsToSplit);
		Map<String, String> deassociateHierarchy = new HashMap<>();

		Set<String> nextRouteIds = ordeRoute.stream().map(m -> m.getNextRouteId()).filter(mapper -> null != mapper)
				.collect(Collectors.toSet());
		Set<String> prevRouteIds = ordeRoute.stream().map(m -> m.getPreviousRouteId()).filter(mapper -> null != mapper)
				.collect(Collectors.toSet());
		
		for (String nexRouteId : nextRouteIds) {
			String id = getTrips(orderIdsToSplit, orderIdsOfTrip, nexRouteId);
			if (!StringUtils.isEmpty(id))
				deassociateHierarchy.put(tripId, id);
		}
		for (String prevRouteId : prevRouteIds) {
			String id = getTrips(orderIdsToSplit, orderIdsOfTrip, prevRouteId);
			if (!StringUtils.isEmpty(id))
				deassociateHierarchy.put(id, tripId);
		}
		return deassociateHierarchy;
	}
	
	private void validate(Trip trip, int version) {
		 if(trip.getVersion() < version)
		{
			log.info("Post split processor Sent to retry queue to publish trip trip version {} and received {} ",trip.getVersion(),version);
			throw new TripApplicationException("Trip version in db is " +trip.getVersion() +" and received is "+version);
		}
	}


}
