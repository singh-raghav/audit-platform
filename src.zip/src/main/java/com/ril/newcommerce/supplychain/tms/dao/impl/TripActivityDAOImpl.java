package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.TripActivityDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripActivityMapper;
import com.ril.newcommerce.supplychain.tms.entity.TripActivityDetails;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;

@Repository
public class TripActivityDAOImpl implements TripActivityDAO {

    private static final Logger log = LoggerFactory.getLogger(TripActivityDAOImpl.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<TripActivityDetails> getTripOnActivityStatus(String status, int fetchSize, int reservedThreshold) throws Exception {
        List<TripActivityDetails> tripActivityDetails = new ArrayList<>();

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append(QueryConstants.GET_UNASSIGNMENT_INITIATED_TRIPS);
        NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
                jdbcTemplate.getDataSource());
        MapSqlParameterSource parameters = new MapSqlParameterSource();

        parameters.addValue("status", Constants.UNASSIGNMENT_INITIATED);
        parameters.addValue("reservedThreshold",reservedThreshold);
        parameters.addValue("rowNum", fetchSize);

        try {
            tripActivityDetails = namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new TripActivityMapper());
        } catch(Exception e) {
            throw new TripApplicationException("Exception on getTripOnActivityStatus ", e);
        }
        return tripActivityDetails;
    }

    @Override
    public TripActivityDetails getTripActivity(String tripId)  {
        
        try {
            List<TripActivityDetails> activities =   jdbcTemplate.query(QueryConstants.GET_TRIP_ACTIVITY, new Object[] { tripId , Constants.UNASSIGNED },  new TripActivityMapper());
            if(CollectionUtils.isNotEmpty(activities))
            	return activities.get(0);
        } catch(Exception e) {
            throw new TripApplicationException("Exception on getTripOnActivityStatus ", e);
        }
        return null;
    }

    
    @Override
    public void batchUpdateTripActivityStatus(@NotNull List<TripActivityDetails> tripActivities) {

        if (!CollectionUtils.isEmpty(tripActivities)) {
            int[] result = null;
            int[] count = null;
            try {
                List<Object[]> inputList = new ArrayList<Object[]>();
                for(TripActivityDetails activity : tripActivities) {
                	
                    Object[] tmp = {Constants.UNASSIGNMENT_FAILED, Constants.ACTIVITY_MODIFIEDBY, activity.getTripId(), Constants.UNASSIGNMENT_INITIATED};
                    inputList.add((tmp));
                }
                result = jdbcTemplate.batchUpdate(QueryConstants.UPDATE_TRIPACTIVITY_STATUS, inputList);
                count = Arrays.stream(result).filter(s -> s >0).toArray();
                log.info(count.length + " row has been successfully updated. ");
            } catch (Exception e) {
                throw new TripApplicationException("Exception occured on updating status of trip unassignment ", e);

            }
        }
    }

    
    @Override
    public void updateTripActivityStatus(TripActivityDetails tripActivity,String oldStatus) {
        
    		try {
    			
    			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
    			MapSqlParameterSource parameters = new MapSqlParameterSource();
    			parameters.addValue("status", tripActivity.getStatus());
    			parameters.addValue("modifiedBy", Constants.UNASSIGNMENT_FLOW);
    			parameters.addValue("tripId", tripActivity.getTripId());
    			parameters.addValue("oldStatus", oldStatus);
    					
    			namedParameterJdbcTemplate.update(QueryConstants.UPDATE_TRIPACTIVITY_STATUS, parameters);
    			
            } catch (Exception e) {
                throw new TripApplicationException("Exception occured on updateTripActivityStatus ", e);

            }
    }

    
	@Override
	public void insertTripActivity(TripActivityDetails tripActivity) {
		try {
			 jdbcTemplate.update(QueryConstants.INSERT_TRIP_ACTIVITY, tripActivity.getTripId(), tripActivity.getAssignedVehicle(), tripActivity.getVehiclePartner(), tripActivity.getStatus() , Constants.UNASSIGNMENT_FLOW , Constants.UNASSIGNMENT_FLOW);
		}
		catch(Exception e) {
			log.error("Unable to insert trip " + e);
			throw new TripApplicationException("unable to insert trip activity!");
		}
		
	}
}
