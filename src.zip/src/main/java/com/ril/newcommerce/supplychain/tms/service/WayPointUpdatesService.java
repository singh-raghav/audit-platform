package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.WayPointUpdates;
import com.ril.newcommerce.supplychain.tms.response.OrderExcelViewResponse;

public interface WayPointUpdatesService {
	
	public void insertToWayPointUpdate(List<WayPointUpdates> wayPointUpdates);
	public List<WayPointUpdates> getWayPointUpdates(String tripId);

    String getLastUpdate(String orderId);

    List<OrderExcelViewResponse> getOrderViewExcel(String tripId);
}
