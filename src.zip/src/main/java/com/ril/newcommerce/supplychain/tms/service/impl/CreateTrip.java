package com.ril.newcommerce.supplychain.tms.service.impl;

import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.dao.TripSequenceDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.NodeOrdeRoute;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripIdDetails;
import com.ril.newcommerce.supplychain.tms.service.NodeOrderRouteService;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;

@Component
public class CreateTrip 
{
	@Autowired
	private TripsDAO tripDAO;
	
	@Autowired
	TripOrdersService tripOrderService;
	
	@Autowired
	TripService tripService;
	
	@Autowired
	NodeOrderRouteService nodeOrderRouteservice;
	
	@Value("${trip.create.max.count}")
	private int count;
	
	@Autowired
	private TripSequenceDAO tripSequenceDAO;
	
	
	public final Trip createtrip(Trip trip, 
			TripAdditionalDetail additionalDetails,Set<String> nextTripIds,Set<String> prevtripIds,List<NodeOrdeRoute> nodeOrders,TripIdDetails tripIdDetails)
	{
		tripDAO.insertToTrip(trip,tripIdDetails,count);
		tripOrderService.insertToTripConsignment(trip);
		tripSequenceDAO.insertToTripSequence(trip);
		
		if (null != additionalDetails)
		{
			additionalDetails.setTripId(trip.getTripId());
			tripService.insertTripAdditionalDetails(additionalDetails);
		}
		
		if(!CollectionUtils.isEmpty(nextTripIds) && !nextTripIds.contains(null))
			tripService.insertToTripHierarchy(trip.getExternalReferenceId(), nextTripIds,trip.getCreatedBy());
		
		if(!CollectionUtils.isEmpty(prevtripIds) && !prevtripIds.contains(null))
			tripService.insertToTripHierarchy(prevtripIds, trip.getExternalReferenceId(),trip.getCreatedBy());
		
		nodeOrderRouteservice.createNodeOrderRoute(nodeOrders);
		return trip;
	}
	
	public final Trip createShuttleTrip(Trip trip, 
			TripAdditionalDetail additionalDetails,Set<String> nextTripIds,Set<String> prevtripIds,List<NodeOrdeRoute> nodeOrders,TripIdDetails tripIdDetails)
	{
		tripDAO.insertToTrip(trip,tripIdDetails,count);
		tripOrderService.insertToTripConsignment(trip);
		tripSequenceDAO.insertToTripSequence(trip);
		if (null != additionalDetails) {
			additionalDetails.setTripId(trip.getTripId());
			tripService.insertTripAdditionalDetails(additionalDetails);
		}
		
		return trip;
	}
}
