package com.ril.newcommerce.supplychain.tms.service;

public interface UpdatedOrderUtilService {
    void update(String orderId, String fromState);

    String remove(String orderId);

    void delete(String orderId);
}
