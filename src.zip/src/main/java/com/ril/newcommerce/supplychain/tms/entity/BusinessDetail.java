package com.ril.newcommerce.supplychain.tms.entity;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class BusinessDetail {
	
	private String stateCode;
	private String stateId;
	private String stateName;
	private String gstin;
	private String address;
	
	public String getCode() {
		return stateCode;
	}
	public void setCode(String code) {
		this.stateCode = code;
	}
	public String getId() {
		return stateId;
	}
	public void setId(String id) {
		this.stateId = id;
	}
	public String getName() {
		return stateName;
	}
	public void setName(String name) {
		this.stateName = name;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
