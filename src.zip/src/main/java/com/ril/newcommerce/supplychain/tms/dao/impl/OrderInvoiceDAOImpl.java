package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.OrderInvoiceDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.InvoiceMapper;
import com.ril.newcommerce.supplychain.tms.entity.Invoice;
import com.ril.newcommerce.supplychain.tms.enums.EwayBillStatus;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill.Trip.TripOrders.TripOrder;
import com.ril.newcommerce.supplychain.tms.tibco.invoice.entity.InvoiceDetail;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;


/**
 * B1.Divya
 */

@Repository
public class OrderInvoiceDAOImpl implements OrderInvoiceDAO {

	private static final Logger log = LoggerFactory.getLogger(TripsDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int insertOrderInvoiceDetails(Invoice invoice) {
		log.info("Inserting in to consignment invoice ");
		String query = QueryConstants.INSERT_TO_CONSIGNMENT_INVOICE;
		int count = 0;
		try {
			count = jdbcTemplate.update(query,
					new Object[]{invoice.getOrderNo(), invoice.getInvoiceNo(), invoice.getShipmentNo(),
							invoice.getInvoiceAmount(), invoice.getInvoiceDate(),
							invoice.getEwayBillStatus(), invoice.getCreatedBy(),
							invoice.getFlowName(), invoice.getAmountToBeCollected(), new Timestamp(System.currentTimeMillis()), invoice.getMop()});

		} catch (Exception e) {
			log.error("Exception occured in OrderInvoiceDAOImpl insertOrderInvoiceDetails",e);
			throw new DataProcessingException("Got Exception in OrderInvoiceDAOImpl insertOrderInvoiceDetails",e);
		}
		return count;

	}

	@Override
	public List<Invoice> getInvoicesForTrip(String tripId,List<String> status) {
		log.info("Getting invoice details for shipments for trip id :{}" ,tripId);
		List<Invoice> invoiceList=new ArrayList<>();
		if(!CollectionUtils.isEmpty(status) && !StringUtils.isEmpty(tripId))
		{
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		StringBuilder queryBuilder= new StringBuilder();
		queryBuilder.append(QueryConstants.GET_INVOICE_DETAILS_FOR_TRIP);

			parameters.addValue("status", status);
			parameters.addValue("tripId", tripId);
			queryBuilder.append(" AND TC.SHIPMENT_STATUS IN(:status) AND TC.TRIP_ID =:tripId");
		try{
			invoiceList=namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new InvoiceMapper());
		}
		catch(Exception e)
		{
			log.error("Exception occured on getAllInvoiceForTrip of OrderInvoiceDAOImpl",e);
			throw new TripApplicationException("Exception occured in getAllInvoiceForTrip of OrderInvoiceDAOImpl", e);
		}
	}
		return invoiceList;
	}

	@Override
	public int updateEwayBillStatus(List<TripOrder> tripOrders) {
		log.info("updating ewaybill status in consignment invoice for orders "+tripOrders.size());
		int[] result = null;
		int[] count = null;
		try {
			List<Object[]> inputList = new ArrayList<Object[]>();
			for (TripOrder order : tripOrders) {
				Object[] tmp = { order.getEwayBillNumber(), order.getStatus().toUpperCase(),
						FlowName.EWAYBILLRESPONSE.getValue(), order.getOrderNo() };
				inputList.add(tmp);
			}
			result = jdbcTemplate.batchUpdate(QueryConstants.UPDATE_EWAYBILL_NUMBER_AND_STATUS, inputList);
			count = Arrays.stream(result).filter(s -> s > 0).toArray();
			log.info(count.length + " row has been successfully updated. ");
		}

		catch (Exception e) {

		}
		return count.length;
	}
	@Override
	public boolean isEwayBillGenerated(String tripId) {

		try {
			List<Map<String, Object>> list = jdbcTemplate.queryForList(QueryConstants.IS_EWAY_BILL_GENERATED, tripId);

			if (CollectionUtils.isEmpty(list))
				return true;

		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on checking if ewaybill is generated or not ", e);
		}

		return false;
	}

	@Override
	public List<Invoice> findOrderInvoiceByTripId(String tripId) {
		//TODO: discuss about implementation
		return new ArrayList<>();
	}

	@Override
	public List<Invoice> findOrderInvoiceByShipmentNo(String shipmentNo) {
		//TODO: discuss about implementation
		return new ArrayList<>();
	}

	@Override
	public int insertConsignmentInvoiceDetails(InvoiceDetail invoiceDetails) {
		log.info("Inserting in to consignment invoice for return order");
		String query = QueryConstants.INSERT_TO_CONSIGNMENT_INVOICE;
		int count = 0;
		try {
			count = jdbcTemplate.update(query,
					new Object[] { invoiceDetails.getInvoiceHeader().getOrderNo(), invoiceDetails.getInvoiceHeader().getInvoiceNo(), null,
					Math.abs(invoiceDetails.getInvoiceHeader().getTotalAmount()), DateUtility.parseXMLDateStr(invoiceDetails.getInvoiceHeader().getDateInvoiced().toString()),
							EwayBillStatus.NOT_GENERATED.value(),FlowName.RETURNINVOICE.getValue(),FlowName.RETURNINVOICE.getValue(),0.0, new Timestamp(System.currentTimeMillis()), Constants.NA});

		} catch (Exception e) {
			log.error("Exception occured in OrderInvoiceDAOImpl insertOrderInvoiceDetails",e);
			throw new DataProcessingException("Got Exception in OrderInvoiceDAOImpl insertOrderInvoiceDetails",e);
		}
		return count;

    }

    @Override
    public int getInvoiceCount(String OrderId) {
        String query = QueryConstants.GET_COUNT_OF_INVOICE_FOR_GIVEN_ORDER;
        try {
            Integer count = jdbcTemplate.queryForObject(query, new Object[]{OrderId}, Integer.class);
            return null == count ? 0 : count;

        } catch (Exception e) {
            throw new TripApplicationException("Exception occurred on getting trip in getTripCountOnGivenDay..", e);
        }
    }
}
