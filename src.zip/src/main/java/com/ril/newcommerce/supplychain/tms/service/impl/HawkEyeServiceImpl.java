package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.entity.rest.hawkeye.*;
import com.ril.newcommerce.supplychain.tms.externalApis.HawkeyeFeign;
import com.ril.newcommerce.supplychain.tms.service.HawkEyeService;
import com.ril.vms.deadpool.securitycore.JwtTokenProvider;
import com.ril.vms.deadpool.util.AppUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

@Service
public class HawkEyeServiceImpl implements HawkEyeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(HawkEyeServiceImpl.class);

    @Autowired
    HawkeyeFeign hawkeyeFeign;

    @Value("${hawkeye.client}")
    private String hawkeyeClient;

    @Value("${hawkeye.defaultUserName}")
    private String hawkeyeDefaultUserName;

    @Value("${hawkeye.defaultPassword}")
    private String hawkeyeDefaultPassword;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Override
    public HawkeyeLoginOutput authenticate(HawkeyeLoginInput hawkeyeLoginInput) {
        LOGGER.info("calling login api of Hawkeye");

        return hawkeyeFeign.login(hawkeyeLoginInput);
    }

    @Override
    public LocalDateTime getExpiryTime(HawkeyeLoginOutput hawkeyeLoginOutput){

        Authentication authentication = jwtTokenProvider.getAuthentication(hawkeyeLoginOutput.getResult().getAccessToken());
        AppUser appUser = (AppUser) authentication.getPrincipal();
        LOGGER.info("EXP_TIME_EPOCH = {}",appUser.getExp());
        LocalDateTime localDateTime = LocalDateTime.ofEpochSecond(Long.parseLong(appUser.getExp()), 0, ZoneOffset.UTC);
        LOGGER.info("EXP_TIME_HUMAN = {}",localDateTime);

        return localDateTime;

    }

    @Override
    public HawkeyeCreateUserOutput createUser(HawkeyeCreateUserInput hawkeyeCreateUserInput) {
        //first call authenticate method with admin user then with that token
        HawkeyeLoginInput hawkeyeLoginInput = HawkeyeLoginInput.builder()
                .clientName(hawkeyeClient)
                .username(hawkeyeDefaultUserName)
                .password(hawkeyeDefaultPassword)
                .build();

        HawkeyeLoginOutput hawkeyeLoginOutput = authenticate(hawkeyeLoginInput);

        if(hawkeyeLoginOutput.getStatusCode().equals("200")){
            String token = hawkeyeLoginOutput.getResult().getAccessToken();
            LOGGER.info("calling createUser api of Hawkeye");
            return hawkeyeFeign.createUser("Bearer "+token, hawkeyeCreateUserInput);
        }else {
            return HawkeyeCreateUserOutput.builder()
                    .statusCode(hawkeyeLoginOutput.getStatusCode())
                    .success(hawkeyeLoginOutput.getSuccess())
                    .errorMessage(hawkeyeLoginOutput.getErrorMessage())
                    .build();
        }
    }

    @Override
    public String resetPasswordForOthers(HawkeyeResetPasswordInput hawkeyeResetPasswordInput){

        try {
            hawkeyeFeign.initiateResetForOthers(hawkeyeResetPasswordInput);
        }catch(Exception ex){
            LOGGER.error("ERROR while calling Hawkeye resetpassword -- ",ex);
            return ex.getMessage();
        }
        return null;

    }

    @Override
    public String changePassword(String token, HawkeyeChangePasswordInput hawkeyeChangePasswordInput){

        try {
            hawkeyeFeign.changePassword(token, hawkeyeChangePasswordInput);
        }catch(Exception ex){
            LOGGER.error("ERROR while calling Hawkeye changePassword -- ",ex);
            return ex.getMessage();
        }
        return null;

    }
}
