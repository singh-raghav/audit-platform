package com.ril.newcommerce.supplychain.tms.externalApis;

import com.ril.newcommerce.supplychain.tms.entity.rest.sterling.SterlingCreateUserRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "sterlingService", url = "${sterling.endpoint}")
public interface SterlingFeign {

    @PostMapping(value="/smcfs/restapi/executeFlow/RFManageUsers", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Object> createUser(@RequestHeader("Authorization") String token,@RequestBody
            SterlingCreateUserRequest sterlingCreateUserRequest);

}
