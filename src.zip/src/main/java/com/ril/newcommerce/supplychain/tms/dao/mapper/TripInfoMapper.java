package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;

/**
B1.Divya
*/

public class TripInfoMapper implements ResultSetExtractor<List<TripConsignmentInfo>> {

	@Override
	public List<TripConsignmentInfo> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<TripConsignmentInfo> tripConsignmentInfo = new ArrayList<TripConsignmentInfo>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			TripConsignmentInfo consignmentInfo=new TripConsignmentInfo();
			consignmentInfo.setTripId(rs.getString("TRIP_ID"));
			consignmentInfo.setOrderId(rs.getString("ORDER_ID"));
			consignmentInfo.setOrderClassification(rs.getString("ORDER_CLASSIFICATION"));
			consignmentInfo.setShipmentNo(rs.getString("SHIPMENT_NO"));
			consignmentInfo.setNextNodeId(rs.getString("NODE_ID"));
			consignmentInfo.setLatitude(rs.getBigDecimal("LATITUDE"));
			consignmentInfo.setLongitute(rs.getBigDecimal("LONGITUDE"));
			consignmentInfo.setSlotStart(rs.getTimestamp("SLOT_START"));
			consignmentInfo.setSlotEnd(rs.getTimestamp("SLOT_END"));
			consignmentInfo.setSequenceNo(rs.getInt("SEQUENCE_NO"));
			consignmentInfo.setPlannedArrival(rs.getTimestamp("PLANNED_ARRIVAL"));
			consignmentInfo.setPlanneddispatch(rs.getTimestamp("PLANNED_DISPATCH"));
			consignmentInfo.setDeliveryZoneId(rs.getString("DELIVERY_ZONE_ID"));
			
			tripConsignmentInfo.add(consignmentInfo);
		}
		return tripConsignmentInfo;
	}
	

}
