package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;
import java.util.Map;

import com.ril.newcommerce.supplychain.tms.entity.NodeOrdeRoute;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge.Trips.Trip.Orders;

public interface NodeOrderRouteService {
	
	public List<NodeOrdeRoute> getRouteIdsByNodeAndOrder(String nodeId, List<String> orderId);
	
	public void updateCurrentRouteId(String nodeId, String routeId, List<String> orderIds);
	
public void updatePreviousRouteId(String routeId,String preRoutId,List<String> orderIds);
	
	public void updateNextRouteId(String routeId,String nextRoutId,List<String> orderIds);
	
public void updateNextRouteId(Map<String, List<String>> tripWithOrders,String newExternalRouteId);
	
	public void updatePreviousRouteId(Map<String, List<String>> tripWithOrders,String newExternalRouteId);
	
	public void createNodeOrderRoute(List<NodeOrdeRoute> nodeOrders);

}
