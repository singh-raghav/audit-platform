package com.ril.newcommerce.supplychain.tms.configurations;

import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
public class RestApiValidationExceptionController {

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResponseMessage> handleValidationExceptions( MethodArgumentNotValidException ex) {

        List<String> errorList = new ArrayList<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errorList.add(errorMessage);
        });

        return Utility.getfailureMsg("Validation Error", errorList, HttpStatus.BAD_REQUEST);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ResponseMessage> handleConstraintViolationException( ConstraintViolationException exception) {

        List<String> errorList = new ArrayList<>();
        exception.getConstraintViolations().forEach((error) -> {
            String errorMessage = error.getMessage();
            errorList.add(errorMessage);
        });

        return Utility.getfailureMsg("Validation Error", errorList, HttpStatus.BAD_REQUEST);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = { MissingServletRequestParameterException.class })
    public ResponseEntity<ResponseMessage> handleMissingServletRequestParameterException(MissingServletRequestParameterException ex) {
        String message = ex.getParameterName() + " cannot be empty";
        return Utility.getfailureMsg("Validation Error -- "+message,HttpStatus.BAD_REQUEST);
    }
}
