package com.ril.newcommerce.supplychain.tms.service.barcode;

import net.sourceforge.barbecue.Barcode;
import net.sourceforge.barbecue.BarcodeFactory;
import net.sourceforge.barbecue.BarcodeImageHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

public class BarCodeGenerator {
    private static final Logger log = LoggerFactory.getLogger(BarCodeGenerator.class);

    public String generate(String input) {

        //Get 128B Barcode instance from the Factory
        Barcode barcode = null;
        try {
            barcode = BarcodeFactory.createCode128B(input);

            barcode.setBarHeight(5);
            barcode.setBarWidth(1);
            barcode.setDrawingText(false);

            File baseDir = new File(".");
            File outDir = new File(baseDir, "out");
            outDir.mkdirs();
            String fileName = input + ".jpg";
            File imgFile = new File("./out", fileName);
            BarcodeImageHandler.savePNG(barcode, imgFile);

            return "url(file:./out/" + fileName + ")";
        } catch (Exception e) {
            log.error("Barcode generation faild! ", e);
        }
        return "url(file:./out/" + StringUtils.EMPTY + ")";
    }
}
