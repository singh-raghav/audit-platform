package com.ril.newcommerce.supplychain.tms.enums;

import java.util.HashMap;
import java.util.Map;

/**
B1.Divya
*/

public enum FleetType {
	
	DEDICATE("DEDICATED"),
	MARKET("MARKET");
	
	private String value;
	
	private FleetType(String value){
		this.value=value;
	}
	
	public String getValue(){
		return this.value;
	}

	private static final Map<String, FleetType> lookup = new HashMap<>();
	
	static {
		for (FleetType fleetType : FleetType.values())
			lookup.put(fleetType.getValue(), fleetType);
	}

	public static FleetType get(String value) {
		return lookup.get(value);
	}
	

}
