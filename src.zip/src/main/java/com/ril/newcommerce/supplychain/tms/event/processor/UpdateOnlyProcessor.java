package com.ril.newcommerce.supplychain.tms.event.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

@Component
@Qualifier(Constants.UPDATE_ONLY_PROCESSOR)
@Transactional(rollbackFor=Exception.class)
public class UpdateOnlyProcessor extends BasicProcessor {
	
	@Autowired
	private UpdateOnlyFactory updateOnlyfactory;
	
private static final Logger log = LoggerFactory.getLogger(UpdateOnlyProcessor.class);
	
	public void processEvent(TripEventInput event, Trip trip) { 
				
		super.processEvent(event, trip);
		
		log.info("Logged the event : {} " ,event.getTripId());
		
		IUpdateOnlyProcessor processor=updateOnlyfactory.getProcessor(event);
		processor.processEvent(event, trip);
	}

}
