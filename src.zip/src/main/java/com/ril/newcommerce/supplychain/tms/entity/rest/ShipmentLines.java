package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"ShipmentLine"
})*/
public class ShipmentLines {

	@JsonProperty("ShipmentLine")
	private List<ShipmentLine> shipmentLine = null;

	@JsonProperty("ShipmentLine")
	public List<ShipmentLine> getShipmentLine() {
		return shipmentLine;
	}

	@JsonProperty("ShipmentLine")
	public void setShipmentLine(List<ShipmentLine> shipmentLine) {
		this.shipmentLine = shipmentLine;
	}

}