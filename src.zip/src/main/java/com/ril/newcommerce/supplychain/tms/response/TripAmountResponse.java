package com.ril.newcommerce.supplychain.tms.response;

import com.ril.newcommerce.supplychain.tms.util.DateUtility;

import java.sql.Timestamp;

public class TripAmountResponse implements Comparable<TripAmountResponse> {
    private String date;
    private Double cashCollected;
    private Double cashShort;
    private Double cashToBeCollected;
    private String sdpId;
    private String sDPManagerName;
    private String rRLId;
    private String storeName;
    private String storeAddress;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Double getCashCollected() {
        return cashCollected;
    }

    public void setCashCollected(Double cashCollected) {
        this.cashCollected = cashCollected;
    }

    public Double getCashShort() {
        return cashShort;
    }

    public void setCashShort(Double cashShort) {
        this.cashShort = cashShort;
    }

    public Double getCashToBeCollected() {
        return cashToBeCollected;
    }

    public void setCashToBeCollected(Double cashToBeCollected) {
        this.cashToBeCollected = cashToBeCollected;
    }

    public String getSdpId() {
        return sdpId;
    }

    public void setSdpId(String sdpId) {
        this.sdpId = sdpId;
    }

    public String getsDPManagerName() {
        return sDPManagerName;
    }

    public void setsDPManagerName(String sDPManagerName) {
        this.sDPManagerName = sDPManagerName;
    }

    public String getrRLId() {
        return rRLId;
    }

    public void setrRLId(String rRLId) {
        this.rRLId = rRLId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreAddress() {
        return storeAddress;
    }

    public void setStoreAddress(String storeAddress) {
        this.storeAddress = storeAddress;
    }

    @Override
    public int compareTo(TripAmountResponse o) {
        Timestamp timestampFom = DateUtility.convertStringToTimeStamp(date, "dd-MM-yyyy");
        Timestamp timestampTo = DateUtility.convertStringToTimeStamp(o.getDate(), "dd-MM-yyyy");
        return timestampFom.compareTo(timestampTo);
    }
}
