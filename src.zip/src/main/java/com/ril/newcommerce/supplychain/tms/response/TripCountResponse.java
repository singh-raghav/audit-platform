package com.ril.newcommerce.supplychain.tms.response;

import lombok.Data;

@Data
public class TripCountResponse {
    String sdpId;
    Integer createdTrips;
    Integer loadingInProgress;
}
