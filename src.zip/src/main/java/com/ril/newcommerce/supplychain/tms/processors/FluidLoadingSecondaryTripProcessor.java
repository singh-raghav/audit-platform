package com.ril.newcommerce.supplychain.tms.processors;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.AdhocTripRequest;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.*;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest;
import com.ril.newcommerce.supplychain.tms.util.Utility;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.jms.Message;
import javax.jms.TextMessage;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * nishant.kamal
 */

@Service
@Qualifier("createFluidLoadingSecondaryTripProcessor")
public class FluidLoadingSecondaryTripProcessor implements Processor{

    private static final Logger log = LoggerFactory.getLogger(PublishTripProcessor.class);

    @Autowired
    private JAXBContextConfig jAXBContextConfig;

    @Autowired
    private TripService tripService;

    @Autowired
    private TripOrdersService tripOrderService;

    @Autowired
    private ConsignmentLabelService consignmentLabelService;

    @Value("${trip.status.queue}")
    private String queueName;

    @Autowired
    private JMSPublisher jmsPublisher;

    @Autowired
    private KafkaRestProxyService commonAuditEventPublisher;

    @Autowired
    private AdhocTripRequestService adhocTripRequestService;

    @Override
    public void processMessage(Message message, String flowName) throws ParsingException, Exception {
        try {
            StringReader reader = new StringReader(((TextMessage) message).getText());

            TripPublish tripPublishRequest = (TripPublish) jAXBContextConfig.getJaxbContextInstance(TripPublish.class)
                    .createUnmarshaller().unmarshal(reader);

            String tripId = tripPublishRequest.getTrip().getId();
            int version = tripPublishRequest.getTrip().getVersion();
            if (StringUtils.isBlank(tripId)) {
                throw new ParsingException("TripId cannot be null for creating tripFeed");
            }

            log.info("starting the process to create trip feed for tripId {}", tripId);

            Trip trip = tripService.getTrip(tripId); // get trip info

            validate(trip, version, tripId);

            List<String> status = new ArrayList<>();
            status.add(OrderStatus.ACTIVE.getValue());
            List<TripConsignmentInfo> tripConsignmentInfo = tripOrderService.getTripConsignmentInfo(tripId, status);
            log.info("consignment size {}", tripConsignmentInfo.size());

            createSecondaryTrip(trip, tripConsignmentInfo);


            log.info("published tripfeed response :{}", tripId);
        } catch (ParsingException par) {
            throw new ParsingException("Parsing error while parsing publish trip message", par);
        } catch (Exception e) {
            log.error("Error while processing trip ", e);
            throw new TripApplicationException("Exception occurred while creating  tripfeed", e);
        }
    }

    //To create secondary trip
    private void createSecondaryTrip(Trip trip, List<TripConsignmentInfo> tripConsignmentInfo) {
        if (CollectionUtils.isEmpty(tripConsignmentInfo)) {
            throw new ValidationException("Orders cannot be empty");
        } else {
            try {

                List<String> shipmentNos = tripConsignmentInfo.stream().map(mapper -> mapper.getShipmentNo())
                        .collect(Collectors.toList());

                log.info("Request for manual trip for number of shipments {}", shipmentNos.size());
                List<String> nodeIds = new ArrayList<>();
                nodeIds.add(trip.getSourceNode());

                List<AdhocTripRequest> adhocTripRequests = new ArrayList<>();
                String hubNodeId = tripConsignmentInfo.get(0).getNextNodeId(); //Node Id of hub to create secondary trip
                TripRequest tripRequest = createRequestFortrip(tripConsignmentInfo, hubNodeId,
                        adhocTripRequests);

                adhocTripRequests.forEach(c -> c.setStatus(Constants.PENDING));
                adhocTripRequests.forEach(c -> c.setCreatedBy(FlowName.LOADINGCOMPLETE.getValue()));
                adhocTripRequests.forEach(c -> c.setFlowName(FlowName.LOADINGCOMPLETE.getValue()));
                if(!CollectionUtils.isEmpty(adhocTripRequests)) {
                    adhocTripRequestService.insertToAdhocTripRequest(adhocTripRequests);
                }

                sendtoAudit(tripRequest, trip.getSourceNode());

                jmsPublisher.publishMessage(queueName, tripRequest, FlowName.MANUALTRIP.getValue(),
                        Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER,
                                Constants.BUSINESS_VALUE_ONE, tripConsignmentInfo.get(0).getTripId(),
                                "RequestType","FluidLoadManualTrip", Constants.BUSINESS_KEY_TWO, Constants.TRIP_TYPE, Constants.BUSINESS_VALUE_TWO,
                                trip.getMovementType().getValue(), Constants.BUSINESS_KEY_THREE, Constants.FLUID_OR_NON_FLUID,
                                Constants.BUSINESS_VALUE_THREE,Constants.FLUID), TripRequest.class);

                log.info("Request sent for fluid loading creating secondary trip for number of shipments {}", shipmentNos.size());
            } catch (Exception e) {
                log.error("exception occured during processign shipments for manual trip ", e.getMessage());
                throw new TripApplicationException(e.getMessage());
            }
        }
    }

    private TripRequest createRequestFortrip(List<TripConsignmentInfo> tripConsignmentInfo, String nodeId, List<AdhocTripRequest> adhocTripRequests) {

        Map<String, List<TripRequest.Trips.Trip.Orders.Order>> tripWithOrders = new HashMap<>();
        for (TripConsignmentInfo info : tripConsignmentInfo) {
            if (null != tripWithOrders.get(info.getTripId())) {
                List<TripRequest.Trips.Trip.Orders.Order> order = tripWithOrders.get(info.getTripId());
                TripRequest.Trips.Trip.Orders.Order o = new TripRequest.Trips.Trip.Orders.Order();
                o.setOrderId(info.getOrderId());
                o.setShipmentId(info.getShipmentNo());
                order.add(o);
            } else {
                List<TripRequest.Trips.Trip.Orders.Order> order = new ArrayList<>();
                TripRequest.Trips.Trip.Orders.Order o = new TripRequest.Trips.Trip.Orders.Order();
                o.setOrderId(info.getOrderId());
                o.setShipmentId(info.getShipmentNo());
                order.add(o);
                tripWithOrders.put(info.getTripId(), order);
            }
        }
        return createRequest(tripWithOrders, nodeId, adhocTripRequests);
    }

    private TripRequest createRequest(Map<String, List<TripRequest.Trips.Trip.Orders.Order>> tripWithOrders, String node, List<AdhocTripRequest> adhocTripRequests) {
        TripRequest request = new TripRequest();
        if (!MapUtils.isEmpty(tripWithOrders)) {
            TripRequest.Trips trips = new TripRequest.Trips();
            List<com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest.Trips.Trip> listOfTrip = new ArrayList<>();
            for (Map.Entry<String, List<TripRequest.Trips.Trip.Orders.Order>> entry : tripWithOrders.entrySet()) {
                com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest.Trips.Trip trip = new com.ril.newcommerce.supplychain.tms.tibco.entity.TripRequest.Trips.Trip();
                trip.setId(entry.getKey());
                trip.setNodeId(node);

                TripRequest.Trips.Trip.Orders orders = new TripRequest.Trips.Trip.Orders();
                orders.setOrder(entry.getValue());
                trip.setOrders(orders);
                listOfTrip.add(trip);

                List<AdhocTripRequest> adhocRequest = createAdhocRequest(entry, node);
                adhocTripRequests.addAll(adhocRequest);
            }
            trips.setTrip(listOfTrip);
            request.setTrips(trips);
        }
        return request;

    }

    private List<AdhocTripRequest> createAdhocRequest(Map.Entry<String, List<TripRequest.Trips.Trip.Orders.Order>> entry, String node) {
        List<AdhocTripRequest> adhocRequest = new ArrayList<>();
        for (TripRequest.Trips.Trip.Orders.Order order : entry.getValue()) {
            AdhocTripRequest request = new AdhocTripRequest();

            request.setTripId(entry.getKey());
            request.setNodeId(node);
            request.setOrderId(order.getOrderId());
            adhocRequest.add(request);
        }
        log.info("Adhoc trip request inserted, no. of rows {}", adhocRequest.size());
        return adhocRequest;
    }

    private void validate(Trip trip, int version, String tripId) {
        if (null != trip) {
            if (trip.getVersion() > version) {
                throw new ValidationException("version received  is lesser than in original staste for tripId"
                        + trip.getTripId() + "version present " + trip.getVersion() + " and reveived " + version);
            } else if (trip.getVersion() < version) {
                log.info("Sent to retry queue to publish trip trip version {} and received {} ", trip.getVersion(), version);
                throw new TripApplicationException("Trip version in db is " + trip.getVersion() + " and received is " + version);
            }
        } else {
            log.info("Trip doesn't exisit in DB, sent to retry queue {} ", tripId);
            throw new TripApplicationException("Trip doesn't exisit in DB, sent to retry queue " + tripId);
        }

    }

    private void sendtoAudit(TripRequest tripRequest, String nodeId) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String request = objectMapper.writeValueAsString(tripRequest);
            commonAuditEventPublisher.publishToCommonAuditPlatform(Constants.TRIP_APP, nodeId, Constants.MANUAL_TRIP, System.currentTimeMillis(), request);
        } catch (Exception ex) {
            log.error(ex.getMessage());
        }
    }
}
