/**
 * @author satya1.prakash
 *
 */
package com.ril.newcommerce.supplychain.tms.entity;

public class ATSResponse {
	
	private Data data;
	private String status;
	
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "ATSResponse [data=" + data + ", status=" + status + ", getData()=" + getData() + "]";
	}

}
