package com.ril.newcommerce.supplychain.tms.notification;

public class MessageContent {
	private String unFormattedMessage;
	private FormattedMessage FormattedMessage;

	@Override
	public String toString() {
		{
			return " [unFormattedMessage = " + unFormattedMessage
					+ ", FormattedMessage = " + FormattedMessage + "]";
		}
	}

	public String getUnFormattedMessage() {
		return unFormattedMessage;
	}

	public void setUnFormattedMessage(String unFormattedMessage) {
		this.unFormattedMessage = unFormattedMessage;
	}

	public FormattedMessage getFormattedMessage() {
		return FormattedMessage;
	}

	public void setFormattedMessage(FormattedMessage formattedMessage) {
		FormattedMessage = formattedMessage;
	}
}
