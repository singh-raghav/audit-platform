package com.ril.newcommerce.supplychain.tms.response;

import lombok.Data;

@Data
public class OrderCountResponse {

    String sdpId;
    Integer totalCount;
    Integer invoicedCount;
    Integer stagedCount;

}
