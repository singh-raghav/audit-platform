package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;

/**
B1.Divya
*/

public interface TripOrdersDAO {

	public void insertToTripConsignment(Trip trip);

	public int updateShipmentStatus( String status, List<String> shipmentnos, String tripId,String modifiedBy,String flowName,String nodeId,String clauseStatus);

	public void updateShipmentStatus(String status, List<String> orderIds, String modifiedBy,String flowName);

	public int deleteTripConsignment(List<String> shipmentNos, String nodeId,String status);

	public List<TripConsignmentInfo> getTripConsignmentInfo(List<String> tripIds, List<String> nodeIds,List<String> status,String externalRefId,List<String> shipmentNos,List<String> orderIds);

	public List<TripConsignmentInfo> getTripConsignmentInfo(String tripId,List<String> status);

	public int updateShipments(List<String> shipmentnos, String tripId, String nodeId);

	public int deleteTripConsignmentByTripId(List<String> shipmentNos, String tripId);

	Integer getSuspendedConsignmentsCount(String shipmentNo, String orderId);
}
