package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.dao.WayPointUpdatesDAO;
import com.ril.newcommerce.supplychain.tms.entity.WayPointUpdates;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.response.OrderExcelViewResponse;
import com.ril.newcommerce.supplychain.tms.service.WayPointUpdatesService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class WayPointUpdatesServiceImpl implements WayPointUpdatesService {

	private static final Logger log = LoggerFactory.getLogger(WayPointUpdatesServiceImpl.class);

	@Autowired
	private WayPointUpdatesDAO wayPointUpdatesDAO;

	@Override
	public void insertToWayPointUpdate(List<WayPointUpdates> wayPointUpdates) {
		try {
			if(!CollectionUtils.isEmpty(wayPointUpdates))
				wayPointUpdatesDAO.insertToWayPointUpdate(wayPointUpdates);
		} catch (Exception e) {
			log.error("Exception occured while inserting way point updates ",
					e);
			throw new DataProcessingException(
					"Exception occured while inserting way point updates ", e);
		}

	}

	@Override
	public List<WayPointUpdates> getWayPointUpdates(String tripId) {
		List<WayPointUpdates> wayPoinUpdates = null;
		try {

			wayPoinUpdates = wayPointUpdatesDAO.getWayPointUpdates(tripId);
		} catch (Exception e) {
			log.error("Exception ocurred getting waypoint details ",
					e);
			throw new DataProcessingException("Exception ocurred getting waypoint details ", e);
		}
		return wayPoinUpdates;
	}

    @Override
    public String getLastUpdate(String orderId) {
        if (!StringUtils.isBlank(orderId)) {
            return wayPointUpdatesDAO.getLastUpdate(orderId);
        }
        return null;
    }

    @Override
	public List<OrderExcelViewResponse> getOrderViewExcel(String tripId) {
		List<OrderExcelViewResponse> viewResponses;

		try {
			viewResponses = wayPointUpdatesDAO.getOrderViewExcel(tripId);
		} catch (Exception e) {
			log.error("Exception occurred getting OrderExcelViewResponse ", e);
			throw new DataProcessingException("Exception occurred getting OrderExcelViewResponse ", e);
		}
		return viewResponses;
	}

}
