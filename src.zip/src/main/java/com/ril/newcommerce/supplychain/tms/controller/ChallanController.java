package com.ril.newcommerce.supplychain.tms.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.MetaData;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.service.ChallanService;
import com.ril.newcommerce.supplychain.tms.service.PdfDeletionService;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanCreator;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanRemover;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanRequest;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanRetriver;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanValidator;
import com.ril.newcommerce.supplychain.tms.service.challan.PickupChallanGenerator;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;
import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
@RestController
@RequestMapping("/trip-mgmt")
public class ChallanController {

	private static final Logger log = LoggerFactory.getLogger(ChallanController.class);
	
	@Autowired
	private ChallanService challanService;
	
	@Autowired
	private PickupChallanGenerator pickupChallanGenerator;
	
	@Autowired
	private ChallanRemover deliveryChallanRemover;
	
	@Autowired
	private ChallanCreator challanCreator;
	
	@Autowired
	private ChallanRetriver challanRetriver;
	 
	@Autowired
	private PdfDeletionService pdfDeletionService;
	
	@Autowired
	private ChallanValidator validator;
		
	@PostMapping(value ="/v2/trips/{tripId}/deliveryChallans" , consumes=MediaType.APPLICATION_JSON_VALUE ,  produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> createDeliveryChallan(@PathVariable(value="tripId" , required=true) String tripId , 
			@RequestHeader(value = Constants.NODE_ID,required = true) String nodeId ,
			@RequestBody ChallanRequest challanRequest , HttpServletRequest httpRequest){
		log.info("Generate Delivery challan for trip : {} - {} ", tripId , challanRequest);
		
		try {
		
			validator.validateChallanRequest(challanRequest);
			
			challanRequest.setTripId(tripId);
			challanRequest.setNodeId(nodeId);
			challanRequest.setUserId(Utility.getUserId(httpRequest));
			
			challanCreator.createDeliveryChallan(challanRequest);
			
			return  Utility.getSuccessMsg("Delivery Challans generated sucessfully!");
		}
		catch (ValidationException  | TripApplicationException e) {
			return  Utility.getfailureMsg(e.getMessage() , HttpStatus.BAD_REQUEST);
		}
		catch (Exception e) {
			log.error("Exception Occured on generating Delivery challan {} " , e);
			return  Utility.getfailureMsg("Unable to generate delivery challan! Please Try Again!!");
		}
	}
	
	@GetMapping(value = "/v2/trips/{tripId}/deliveryChallans" ,  produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamSource> downloadAllDeliveryChallan(@PathVariable(value = "tripId", required = true) String tripId,
			@RequestParam(value = Constants.NODE_ID, required = true) String nodeId) {
		log.info("Get All delivery challans for trip  : {}", tripId);

		try {
					
			return challanRetriver.getAllChallansByTrip(tripId, nodeId);
			
		} catch (Exception e) {
			log.error("Exception Occured on generating All Delivery challan {} ", e);
		}
		finally {
			pdfDeletionService.deletePDf();
		}
		return null;
	}
	
	@GetMapping(value = "/v2/trips/{tripId}/pickupChallans" ,  produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamSource> downloadAllPickupChallan(@PathVariable(value = "tripId", required = true) String tripId,
			@RequestParam(value = Constants.NODE_ID,required = true) String nodeId , HttpServletRequest httpRequest ) {
		log.info("Download all pickup challan for  : {}", tripId);

		try {
			String userId =Utility.getUserId(httpRequest);
			
			return pickupChallanGenerator.getAllPickupChallanByTrip(tripId, userId, nodeId);
			
		} catch (Exception e) {
			log.error("Exception Occured on generating All pickup challan "+ e);
		}
		finally {
			pdfDeletionService.deletePDf();
		}
		return null;
	}
	
	@GetMapping(value = "/v2/trips/{tripId}/deliveryChallans/{challanId}" ,  produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<InputStreamSource> downloadDeliveryChallan(@PathVariable(value = "tripId", required = true) String tripId,
			@PathVariable(value = "challanId", required = true) String challanId,
			@RequestParam(value = Constants.NODE_ID, required = true) String nodeId) {
		log.info("Get deliveryChallan id  : {}", challanId);

		try {
			return challanRetriver.getDeliveryChallan(challanId,nodeId,tripId);
			
		}catch(ValidationException e) {
			return  ResponseEntityFactory.getPDFResponseFailure(e.getMessage());
		}
		catch (Exception e) {
			log.error("Exception Occured on generating Delivery challan {} ", e);
		}
		finally {
			pdfDeletionService.deletePDf();
		}
		return ResponseEntityFactory.getPDFResponseFailure("Unable to Generate Delivery Challan!");
	}
	
	
	@DeleteMapping(value = "/v2/trips/{tripId}/deliveryChallans/{challanId}" ,  produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> deleteChallan(@PathVariable(value="tripId" , required=true) String tripId , 
			@PathVariable(value="challanId" , required=true) String challanId,
			@RequestHeader(value = Constants.NODE_ID,required = true) String nodeId, HttpServletRequest httpRequest ){
		log.info("Delete Delivery challan id : {}", challanId);

		try {
			validator.validateNodeId(nodeId);
			String userId =Utility.getUserId(httpRequest);
			deliveryChallanRemover.deleteDeliveryChallan(challanId,nodeId,userId);
			return Utility.getSuccessMsg("Deleted challan successfully!");
			
		}catch (ValidationException e) {
			return Utility.getfailureMsg(e.getMessage());
		}catch (Exception e) {
			log.error("Exception Occured on generating Delivery challan {} ", e);
			return Utility.getfailureMsg("Unable to delete delivery challan!");
		}	
	}
	
	
	@GetMapping(value = "/v1/returnItems/qualities" ,  produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getReturnItemQualities() {
		log.info("Get ReturnItem Qualities ");
		try {
			List<MetaData> qualities = challanService.getReturnItemQualities();
			return Utility.getSuccessMsg(qualities);
			
		} catch (Exception e) {
			log.error("Exception Occured on getting return item qualities {} ", e);
			return Utility.getfailureMsg("Unable to get return item qualities!");
		}	
		
	}
	
}
