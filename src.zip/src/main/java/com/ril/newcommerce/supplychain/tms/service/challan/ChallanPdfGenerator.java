package com.ril.newcommerce.supplychain.tms.service.challan;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.PDF_EXT;

import java.util.UUID;
import java.util.concurrent.Callable;

import javax.xml.transform.Source;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.ArticleInfo;
import com.ril.newcommerce.supplychain.tms.entity.DeliveryChallan;
import com.ril.newcommerce.supplychain.tms.exception.PdfCreationException;
import com.ril.newcommerce.supplychain.tms.pdf.PDFGenerator;
import com.ril.newcommerce.supplychain.tms.pdf.SourceFactory;

/**
 * Creates one delivery challan.
 * @author Jeevi.Natarajan
 *
 */
public class ChallanPdfGenerator implements Callable<String> {

    private PDFGenerator pdfGenerator;
    private String challanTemplatePath;
    private DeliveryChallan challan;
    private ArticleInfo articleInfo;
    
    public ChallanPdfGenerator(DeliveryChallan challan,String challanTemplatePath,
    		PDFGenerator pdfGenerator,ArticleInfo articleInfo) {
    	this.challanTemplatePath = challanTemplatePath;
    	this.pdfGenerator = pdfGenerator;
    	this.articleInfo = articleInfo;
    	this.challan = challan;
    }

    private static final Logger log = LoggerFactory.getLogger(ChallanPdfGenerator.class);

    @Override
	public String call() throws Exception  {
      
        try {
        	Source src = SourceFactory.getInstance(new DeliveryChallanXMLReaderNew(), new ChallanInputSource(challan, articleInfo));
            String pdfName = Constants.DELIVERY_CHALLAN_PREFIX + UUID.randomUUID() + PDF_EXT;
            pdfGenerator.generate(src, pdfName, challanTemplatePath);
        	return pdfName;
        } catch (Exception e) {
            log.error("Exception occured on creating Pdf" + e);
            throw new PdfCreationException("Unable to generate Deliverychallan");
        }
		
    }

   
}
