package com.ril.newcommerce.supplychain.tms.entity;

import java.sql.Timestamp;

import lombok.Data;



public class Hub {

	private String nodeId;
	private int sequence;
	private Timestamp plannedArrivalTime;
	private Timestamp plannedDispatchTime;
	private Timestamp actualArrivalTime;
	private Timestamp actualDispatchTime;
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public Timestamp getPlannedArrivalTime() {
		return plannedArrivalTime;
	}
	public void setPlannedArrivalTime(Timestamp plannedArrivalTime) {
		this.plannedArrivalTime = plannedArrivalTime;
	}
	public Timestamp getPlannedDispatchTime() {
		return plannedDispatchTime;
	}
	public void setPlannedDispatchTime(Timestamp plannedDispatchTime) {
		this.plannedDispatchTime = plannedDispatchTime;
	}
	public Timestamp getActualArrivalTime() {
		return actualArrivalTime;
	}
	public void setActualArrivalTime(Timestamp actualArrivalTime) {
		this.actualArrivalTime = actualArrivalTime;
	}
	public Timestamp getActualDispatchTime() {
		return actualDispatchTime;
	}
	public void setActualDispatchTime(Timestamp actualDispatchTime) {
		this.actualDispatchTime = actualDispatchTime;
	}
	
}
