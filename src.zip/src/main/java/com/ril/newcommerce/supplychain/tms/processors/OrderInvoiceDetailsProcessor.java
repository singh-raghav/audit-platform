
package com.ril.newcommerce.supplychain.tms.processors;

import com.google.common.collect.Lists;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.impl.OrderDetailsDAOImpl;
import com.ril.newcommerce.supplychain.tms.entity.Invoice;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.enums.EwayBillStatus;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.enums.PaymentMethodType;
import com.ril.newcommerce.supplychain.tms.event.processor.OrderStateMachineProcessor;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.OrderInvoiceService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import com.ril.newcommerce.supplychain.tms.tibco.invoice.entity.InvoiceDetail;
import com.ril.newcommerce.supplychain.tms.tibco.invoice.entity.InvoiceDetail.InvoiceHeader.Order.PaymentMethods.PaymentMethod;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import com.ril.newcommerce.supplychain.tms.util.OrderStatusFeedFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.UnmarshalException;
import java.io.StringReader;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.ORDER_INVOICE_DETAILS_PROCESSOR;

/**
B1.Divya
*/
@Service
@Qualifier(ORDER_INVOICE_DETAILS_PROCESSOR)
public class OrderInvoiceDetailsProcessor implements Processor {
	
	private static final Logger log = LoggerFactory.getLogger(OrderInvoiceDetailsProcessor.class);

	@Autowired
	private OrderInvoiceService orderInvoiceService;

	@Autowired
	private OrderDetailsDAOImpl orderDetailsService;


	@Autowired
	OrderStateMachineProcessor orderStateMachineProcessor;

	@Autowired
	private JAXBContextConfig jAXBContextConfig;

	@Autowired
	private JMSPublisher publisher;

	@Value("${tripapp.queue}")
	private String queueName;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {
		try {
			long start = System.currentTimeMillis();
			StringReader reader = new StringReader(((TextMessage) message).getText());
			InvoiceDetail orderInvoice =  (InvoiceDetail) jAXBContextConfig.getJaxbContextInstance(InvoiceDetail.class).createUnmarshaller().unmarshal(reader);
			//InvoiceDetail orderInvoice = (InvoiceDetail) marshaller.unMarshall((TextMessage) message);
			log.debug("Order invoice message :{} ",message);
			Invoice invoice =getInvoice(orderInvoice,flowName);
			log.info("Order Invoice {}",invoice.getInvoiceNo());
			orderInvoiceService.addOrderInvoiceDetails(invoice);
			publishOrderStatusFeed(invoice);
			log.info("Execution time for OrderInvoiceDetailsProcessor {} milliseconds", System.currentTimeMillis() - start);
		} catch (UnmarshalException par) {
			throw new ParsingException("Parsing error while parsing invoice details", par);
		} catch (Exception e) {
			log.error("Error while processing invoice details ", e);
			throw new Exception("Exception occurred while invoice details", e);
		}
	}

	private void publishOrderStatusFeed(Invoice invoice) {

		OrderDetails orderDetails = new OrderDetails();
		orderDetails.setShipmentNo(invoice.getShipmentNo());
		orderDetails.setOrderId(invoice.getOrderNo());

		publisher.inputToQueue(queueName, OrderStatusFeedFactory.getInstance(Lists.newArrayList(orderDetails), OrderState.INVOICED, ORDER_INVOICE_DETAILS_PROCESSOR), FlowName.ORDER_STATUS_UPDATE.getValue(), null, OrderStatusFeed.class);
	}

	private Invoice getInvoice(InvoiceDetail orderInvoice,String flowName) throws ParseException {
		Invoice invoice =new Invoice();

		String date=DateUtility.convertStringToFormattedDate(orderInvoice.getInvoiceHeader().getDateInvoiced(),Constants.EXTERNAL_SYSTEMS_DATE_FORMAT,Constants.DATE_FORMAT);
		Date formattedDate =DateUtility.parseXMLDateStr(date);
		invoice.setInvoiceDate(formattedDate);
		invoice.setOrderNo(orderInvoice.getInvoiceHeader().getOrderNo());
		invoice.setShipmentNo(orderInvoice.getInvoiceHeader().getShipment().getShipmentNo());
		invoice.setInvoiceNo(orderInvoice.getInvoiceHeader().getInvoiceNo());

		Double invoiceAmount = orderInvoice.getInvoiceHeader().getTotalAmount();
		invoice.setInvoiceAmount(invoiceAmount);
		invoice.setEwayBillStatus(EwayBillStatus.NOT_GENERATED.value());
		invoice.setCreatedBy(flowName);
		invoice.setFlowName(flowName);

		List<PaymentMethod> paymentMethod=orderInvoice.getInvoiceHeader().getOrder().getPaymentMethods().getPaymentMethod();

		Double prepaid = 0.0;
		if (null != paymentMethod) {
			prepaid = paymentMethod.stream().filter(
					obj -> obj.getPaymentType().equals(PaymentMethodType.JPB.getValue()) ||
							obj.getPaymentType().equals(PaymentMethodType.CREDIT.getValue())
			).mapToDouble(obj -> obj.getTotalCharged()).sum();
		}

		Double amountToBeCollected = invoiceAmount - prepaid;
		invoice.setAmountToBeCollected(amountToBeCollected);
		invoice.setMop(getMop(amountToBeCollected, prepaid));

		return invoice;

	}

	private String getMop(Double amountToBeCollected, double prepaidAmount) {

		if (prepaidAmount > 0 && amountToBeCollected > 0.0) {
			return Constants.MOP_PREPAID_AND_COD;
		} else if (amountToBeCollected <= 0.0) {
			return Constants.MOP_PREPAID;
		} else if (amountToBeCollected > 0) {
			return Constants.MOP_COD;
		} else {
			log.error("Something wrong in finding MOP");
			return "";
		}
	}

}
