/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.SettlementUpdateDao;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripAdditionalDetailsMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripSettleDetailsMapper;
import com.ril.newcommerce.supplychain.tms.entity.TripAdditionalDetails;
import com.ril.newcommerce.supplychain.tms.entity.TripSettleDetails;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;

/**
 * @author Raghav1.Singh
 *
 */
@Repository
public class SettlementUpdateDaoImpl implements SettlementUpdateDao {
	
	private static final Logger log = LoggerFactory.getLogger(SettlementUpdateDaoImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<TripSettleDetails> getOrderDetails(String tripId) {
		 
		List<TripSettleDetails> tripSettleDetailsList = null;
		try {
			
			tripSettleDetailsList = jdbcTemplate.query(QueryConstants.SETTLEMENT_UPDATE_GET_ORDER_DETAILS,
					new Object[] {tripId}, new TripSettleDetailsMapper());
			
		} catch (DataAccessException e) {
			
			log.error("SETTLEMENT_UPDATE_GET_ORDER_DETAILS query failed");
			throw new TripApplicationException("Exception ocurred in getting settlementUpdate order details ", e);
			
		}
		
		return tripSettleDetailsList;
	}

	@Override
	public List<TripAdditionalDetails> getTripDetails(String tripId) {
		// TODO 
		List<TripAdditionalDetails> tripAdditionalDetailsList = null;
		
		try {
			
			tripAdditionalDetailsList = jdbcTemplate.query(QueryConstants.SETTLEMENT_UPDATE_GET_TRIP_DETAILS,
					new Object[] {tripId}, new TripAdditionalDetailsMapper());
			
		} catch (DataAccessException e) {
			
			log.error("SETTLEMENT_UPDATE_GET_TRIP_DETAILS query failed");
			throw new TripApplicationException("Exception ocurred in getting settlementUpdate trip details ", e);
		}
		return tripAdditionalDetailsList;
	}

}
