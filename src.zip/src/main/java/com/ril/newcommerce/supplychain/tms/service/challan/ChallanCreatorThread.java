package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.entity.BusinessDetail;
import com.ril.newcommerce.supplychain.tms.entity.rest.Node;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.service.NodeService;
import com.ril.newcommerce.supplychain.tms.util.Utility;


/**
 * This is used to generate a DeliveryChallan / Pickup Challan
 * 
 * We generate one challanId per returnOrder.
 * We get list of articles for a returnOrder. Below scenarios are possible.
 * 	1. No record exists for that returnOrder in delivery_challan_articles table.
 *  2. Some records exists with same quality (example : existing GOOD quality , new also GOOD quality)
 *  3. Some records exists with different quality (example : existing GOOD quality , new quality is BAD)
 * 
 * --- So , the logic is ..
 * 	1. Fetch all existing articles from table for the given returnOrder (if any)
 *  2. split the input challan articles into two list
 *  	a. toBeInserted : articles which are there in the new input, but not on the table. 
 *  	b. toBeUpdated : articles which are there in the existing table and on the new list. 
 *  3. When ever we have some existing article. we use the same challanId for all the articles(both for toBeUpdated,toBeInserted)
 *  4. If it is DC , update the challanId in return_items table.
 *  5. if toBeInserted list is not null , insert those items.
 *  6. if toBeUpdated list is not null, update those items.
 *  
 * 
 * @author Jeevi.Natarajan
 *
 */


public class ChallanCreatorThread implements Callable<String> {
	
	private static final Logger log = LoggerFactory.getLogger(ChallanCreatorThread.class);

	private NodeService nodeService;
	private InboundDAO inboundDAO;
	private String returnOrderId;
	private List<ChallanArticle> articles;
	private String hubId;
	private boolean isPickup; //This we set for pickup challan.
	
	
	public ChallanCreatorThread(NodeService nodeService, InboundDAO inboundDAO, String returnOrderId,
			List<ChallanArticle> articles, String hubId ,boolean skipChallanIdupdate) {
		super();
		this.nodeService = nodeService;
		this.inboundDAO = inboundDAO;
		this.returnOrderId = returnOrderId;
		this.articles = articles;
		this.hubId = hubId;
		this.isPickup = skipChallanIdupdate;
	}

	
	@Override
	public String call() throws Exception {
		
		try {
			log.info("Generating challan for returnOrderId : {} hub : {}  ispickup : {} " , returnOrderId, hubId , isPickup);
			if (CollectionUtils.isNotEmpty(articles)) {
				
				List<ChallanArticle> toBeUpdated = new ArrayList<>();				
				segregateArticles(toBeUpdated);
				String challanId = getChallanId(toBeUpdated);
				       
				// Do a bulk insert to the article table.. 
	            if(CollectionUtils.isNotEmpty(articles)) {
		            List<ChallanArticle>failedArticles = inboundDAO.insertDeliverychallanArticles(articles,hubId); //things aren't supposed to fail..
		            if(CollectionUtils.isNotEmpty(failedArticles)) {
		            	log.info("Failed Articles are  : {} " , failedArticles);		            	
		            	throw new TripApplicationException("Failed to insert some articles " );
		            }
	            }
	            if(CollectionUtils.isNotEmpty(toBeUpdated)) 
	            	inboundDAO.updateDeliverychallanArticles(toBeUpdated);  
	            
	            updateChallanId(challanId);	
				
			}  
		}
		catch (Exception e) {
			log.error("Error occurred on adding Deliverychallan articles " + e);
			return returnOrderId;
		}
		
		return null;
	}
	
	private String generateChallanIdForNode(String hubId , boolean isPickup) {
		Node hub = nodeService.getNodeDetailsByNodeId(hubId);	
		BusinessDetail hubBusinessDetail = inboundDAO.getBusinessDetails(hub.getRegionCode()); 
		if(isPickup)
			return generatePickupChallanId(hubBusinessDetail.getId());
		else
			return generateDeliveryChallanId(hubBusinessDetail.getId());
	}
		
	private String generateDeliveryChallanId(String stateId) {
		String	seq = inboundDAO.getDeliveryChallanSeq(); //If there is an exception.. it will be cascaded.
		return stateId+"EG"+Utility.getCurrentFinancialYearStr()+seq;
	}

	private String generatePickupChallanId(String stateId) {
		String	seq = inboundDAO.getPickupChallanSeq();//If there is an exception.. it will be cascaded.
		return stateId+"REG"+Utility.getCurrentFinancialYearStr()+seq;
	}
	
	/**
	 * This method seggregates the articles and sets the proper challan id.
	 * @param toBeUpdated
	 */
	private void segregateArticles(List<ChallanArticle> toBeUpdated ) {
		
		List<ChallanArticle> existingChallanArticles = inboundDAO.getChallanArticlesByReturnOrderId(Arrays.asList(returnOrderId));
        log.info("Existing Artciles  : {} " , existingChallanArticles);
        log.info("New  Artciles  : {} " , articles);
       	
        if(CollectionUtils.isNotEmpty(existingChallanArticles)) {
        	
        	toBeUpdated.addAll(articles);
        	toBeUpdated.retainAll(existingChallanArticles); //Its to be updated.... All existing need not be updated.. only the once in articles needs to be 	        	            
        	
        	articles.removeAll(toBeUpdated); //to be inserted
        	
        	//Now set the existing challanId to all articles.
            String existingChallanId =existingChallanArticles.get(0).getChallanId();
            		           		                    
            toBeUpdated.forEach(article -> article.setChallanId(existingChallanId));
            articles.forEach(article -> article.setChallanId(existingChallanId));		            
        }
        else { 
        	String challanId = generateChallanIdForNode(hubId,isPickup);
			articles.forEach(article -> article.setChallanId(challanId)); // Populate the challanId		
        }
        
        log.info("To be updated articles : {} " , toBeUpdated);
        log.info("To be inserted articles : {} " , articles);
       
	}
	
	private String getChallanId(List<ChallanArticle> toBeUpdated) {
		String challanId ="";	            
        if(CollectionUtils.isNotEmpty(articles)) 
        	challanId = articles.get(0).getChallanId();	            
        else if(CollectionUtils.isNotEmpty(toBeUpdated)) 
        	challanId = toBeUpdated.get(0).getChallanId();	            
        else
        	throw new ValidationException("No Article to insert or update!");
      	
        return challanId;
	}
	
	private void updateChallanId(String challanId) {
		try {
        	if (!isPickup && StringUtils.isNotBlank(returnOrderId)) 	           
        		inboundDAO.updateChallanIdConstrained(returnOrderId, challanId); // This throws validation exception if challan was updated.	            	
    	}
    	catch (ValidationException e) {
    		log.error("Unable to insert the challan Id " + e);    	
    		throw e;
    	}
	}
}
