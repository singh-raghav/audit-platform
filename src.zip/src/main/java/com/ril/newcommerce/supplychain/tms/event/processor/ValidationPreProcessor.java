package com.ril.newcommerce.supplychain.tms.event.processor;

import java.util.List;

import javax.validation.ValidationException;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.enums.TripType;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.validators.IValidate;
import com.ril.newcommerce.supplychain.tms.validators.ValidationFactory;

/**
 * 
 * @author jeevi.natarajan
 *
 */
@Component
@Qualifier(Constants.VALIDATION_PRE_PROCESSOR)
public class ValidationPreProcessor implements IPreProcessor  {
	
	@Autowired
	private ValidationFactory validationFactory;

	private static final Logger log = LoggerFactory.getLogger(ValidationPreProcessor.class);
	
	@Override
	public void preProcessEvent(TripEventInput event, Trip trip) {
	
		String action = event.getAction().name();

		log.info("Running Validations for trip : {} and action: {} ..." , trip.getTripId(), action);
		
		if(event.getAction() == TripEvent.ASSIGN) {
			
			if(TripType.FC_HUB.getValue().equals(trip.getTripType()))
				action = Constants.ASSIGN_FC_TRIP;
			else if(TripType.HUB_CUSTOMER.getValue().equals(trip.getTripType()))
				action = Constants.ASSIGN_HUB_TRIP;
			else
				throw new ValidationException("Invalid TripType!!");
		}
		
		else if(event.getAction() == TripEvent.REASSIGN) {
			
			if(TripType.FC_HUB.getValue().equals(trip.getTripType()))
				action = Constants.REASSIGN_FC_TRIP;
			else if(TripType.HUB_CUSTOMER.getValue().equals(trip.getTripType()))
				action = Constants.REASSIGN_HUB_TRIP;
			else
				throw new ValidationException("Invalid TripType!!");
		}
		
		else if(event.getAction() == TripEvent.END) {
			if(TripType.FC_HUB.getValue().equals(trip.getTripType()))
				action = Constants.END_FC_TRIP;
			else if(TripType.HUB_CUSTOMER.getValue().equals(trip.getTripType()))
				action = Constants.END_HUB_TRIP;
			else
				throw new ValidationException("Invalid TripType!!");
			
		}
		
		else if(event.getAction() == TripEvent.SETTLE) {
			if(TripType.FC_HUB.getValue().equals(trip.getTripType()))
				action = Constants.SETTLE_FC_TRIP;
			else if(TripType.HUB_CUSTOMER.getValue().equals(trip.getTripType()))
				action = Constants.SETTLE_HUB_TRIP;
			else if(TripType.HUB_FC.getValue().equals(trip.getTripType()))
				action =Constants.SETTLE_HUB_FC_TRIP;
			else
				throw new ValidationException("Invalid TripType!!");
			
		}
		
	
		//Get the list of validators
		List<IValidate> validate = validationFactory.getValidators(action);
		
		if(CollectionUtils.isNotEmpty(validate)) 
			validate.forEach(validator -> validator.validate(event, trip)); 
		
		log.info("Validations Success for trip : {} and action : {} ..." , trip.getTripId() , action);
			
	}

}
