package com.ril.newcommerce.supplychain.tms.entity.rest;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LinePriceInfo {

	@JsonProperty("LineTotal")
	private String lineTotal;
	
	@JsonProperty("LineTotal")
	public String getLineTotal() {
		return lineTotal;
	}

	@JsonProperty("LineTotal")
	public void setLineTotal(String lineTotal) {
		this.lineTotal = lineTotal;
	}
	
}
