package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.response.TripAmount;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TripAmountMapper implements ResultSetExtractor<List<TripAmount>> {

    @Override
    public List<TripAmount> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<TripAmount> tripAmounts = new ArrayList<TripAmount>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            TripAmount tripAmount = new TripAmount();
            tripAmount.setDate(rs.getString("TRIP_SETTLED_DATE"));
            tripAmount.setKey(rs.getString("KEY"));
            tripAmount.setValue(rs.getString("VALUE"));
            tripAmounts.add(tripAmount);
        }
        return tripAmounts;
    }

}
