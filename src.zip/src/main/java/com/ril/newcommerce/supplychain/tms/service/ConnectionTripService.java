/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.ConnectionTrip;

/**
 * @author Raghav1.Singh
 *
 */
public interface ConnectionTripService {
	
	public ConnectionTrip createConnection(List<String> connectionList, String nodeId);
	
	public void addConnection(List<String> connectionList, String nodeId, String tripId);

}
