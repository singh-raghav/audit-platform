/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;
import java.util.Map;

import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.Trip;

/**
 * @author Raghav1.Singh
 *
 */
public interface TripSequenceService {
	
	public void deassociateTripSequence(Trip trip, List<Consignment> actualConsignment, List<Consignment> removedConsignment,String modifiedBy);
	public Map<String,List<Hub>> getTripSequence(List<String> tripIds,List<String> nodeIds);
	public Map<String,List<Hub>> getTripSequence(String tripId);
	public void deassociateTripSequence(String tripId,List<String> nodeIds);
	 

}
