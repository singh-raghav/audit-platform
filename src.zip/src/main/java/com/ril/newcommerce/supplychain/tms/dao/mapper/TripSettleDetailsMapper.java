/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.entity.TripSettleDetails;

/**
 * @author Raghav1.Singh
 *
 */
public class TripSettleDetailsMapper implements ResultSetExtractor<List<TripSettleDetails>> {

	@Override
	public List<TripSettleDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
		 
		List<TripSettleDetails> list = new ArrayList<TripSettleDetails>();
		
		while(rs.next()) {
			
			TripSettleDetails tripSettleDetails = new TripSettleDetails();
			tripSettleDetails.setOrderId(rs.getString("FWD_ORDER_ID"));
			tripSettleDetails.setShipmentNo(rs.getString("SHIPMENT_NO"));
			tripSettleDetails.setAmountPaid(rs.getFloat("AMOUNT_PAID"));
			tripSettleDetails.setRoundOffAmount(rs.getFloat("ROUND_OFF_AMOUNT"));
			tripSettleDetails.setShortAmount(0.0);
			list.add(tripSettleDetails);
			
		}
		
		return list;
	}

}
