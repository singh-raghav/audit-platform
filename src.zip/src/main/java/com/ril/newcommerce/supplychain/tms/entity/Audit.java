package com.ril.newcommerce.supplychain.tms.entity;

import java.sql.Timestamp;

/**
B1.Divya
*/

public class Audit
{
	private String eventSource;
	private String businessOperation;
	private String trackingId;
	private Timestamp eventCreationTime;
	private String event;
	public String getEventSource() {
		return eventSource;
	}
	public void setEventSource(String eventSource) {
		this.eventSource = eventSource;
	}
	public String getBusinessOperation() {
		return businessOperation;
	}
	public void setBusinessOperation(String businessOperation) {
		this.businessOperation = businessOperation;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	
	public Timestamp getEventCreationTime() {
		return eventCreationTime;
	}
	public void setEventCreationTime(Timestamp eventCreationTime) {
		this.eventCreationTime = eventCreationTime;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	
	
}
