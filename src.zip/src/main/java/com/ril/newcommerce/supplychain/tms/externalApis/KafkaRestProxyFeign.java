package com.ril.newcommerce.supplychain.tms.externalApis;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "kafkaRestProxyService", url = "${kafkaRestProxyService.endpoint}")
public interface KafkaRestProxyFeign {

    @PostMapping(value = "/messaging/restKafka/v1/producer",consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<?> publish(@RequestHeader(value = "clientId") String clientId,
                              @RequestHeader(value = "serviceName") String serviceName,
                              @RequestHeader(value = "apiKey") String apiKey,
                              @RequestBody String message);

    }
