package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.io.IOException;
import java.util.Collections;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.TripReconcileDAO;
import com.ril.newcommerce.supplychain.tms.entity.ATSResponse;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.rest.HubTripDetails;
import com.ril.newcommerce.supplychain.tms.settlement.entity.TripReconcile;
import com.ril.newcommerce.supplychain.tms.util.EncoderUtil;

@Component
public class TripReconcileDAOImpl implements TripReconcileDAO {
	
	private static final Logger log = LoggerFactory.getLogger(TripReconcileDAOImpl.class);
	
	@Value("${ats.base.url}")
	private String baseUrl;
	@Value("${reconcile.hubtrip.url}")
	private String url;
	@Value("${reconcile.hubtrip.username}")
	private String username;
	@Value("${reconcile.hubtrip.password}")
	private String password;


	@Override
	public ATSResponse getAssetForReconcile(String tripId) {
		String finalUrl = baseUrl + "/trips/" + tripId + "/assets";
		log.info("ATS url for getting pending assets.. "+ baseUrl);
		ATSResponse tripSummary = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<String> response = restTemplate.getForEntity(finalUrl, String.class);
			ObjectMapper mapper = new ObjectMapper();
			log.info("ATS request body for getting pending assets.. "+ response.getBody());
			tripSummary = mapper.readValue(response.getBody(), ATSResponse.class);
			log.debug("ATS response for getting pending assets.. "+ tripSummary);
		} catch (Exception e) {
			log.error("unable to fetch response from ATS.. so setting the default error value..  " + e );
		}
	 return tripSummary;
	}

	

}
