package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

public class VehicleResponseMessage {

	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";

	private List<Vehicle> vehicles;
	private String status = FAILURE;
	private ErrorMessage errors;
	private String message;
	
	public List<Vehicle> getVehicles() {
		return vehicles;
	}
	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public ErrorMessage getErrors() {
		return errors;
	}
	public void setErrors(ErrorMessage errors) {
		this.errors = errors;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}	
	
	@Override
	public String toString() {
		return "VehicleResponseMessage [vehicles=" + vehicles + ", status=" + status + ", errors=" + errors
				+ ", message=" + message + ", getVehicles()=" + getVehicles() + ", getErrors()=" + getErrors() + "]";
	}
}
