package com.ril.newcommerce.supplychain.tms.exception;

public class ExcelCreationException extends RuntimeException {
    public ExcelCreationException(String message) {
        super(message);
    }

    public ExcelCreationException(String s, Exception e) {
        super(s, e);
    }
}
