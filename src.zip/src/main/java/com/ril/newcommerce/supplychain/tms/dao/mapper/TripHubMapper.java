package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Hub;

/**
B1.Divya
*/

public class TripHubMapper implements ResultSetExtractor<Map<String,List<Hub>>> {
	@Override
	public Map<String,List<Hub>> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String,List<Hub>> map =new HashMap<String, List<Hub>>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
		List<Hub> hubList=null;
		if(! map.containsKey(rs.getString("TRIP_ID")))
		{
			hubList=new ArrayList<Hub>();
			Hub hub=new Hub();
			hub.setNodeId(rs.getString("NODE_ID"));
			hub.setSequence(rs.getInt("SEQUENCE_NO"));
			hub.setPlannedArrivalTime(rs.getTimestamp("PLANNED_ARRIVAL"));
			hub.setPlannedDispatchTime(rs.getTimestamp("PLANNED_DISPATCH"));
			hub.setActualArrivalTime(rs.getTimestamp("ACTUAL_ARRIVAL"));
			hub.setActualDispatchTime(rs.getTimestamp("ACTUAL_DISPATCH"));
			
			hubList.add(hub);
			map.put(rs.getString("TRIP_ID"), hubList);
		}
		else
		{
			hubList=map.get(rs.getString("TRIP_ID"));
			Hub hub=new Hub();
			hub.setNodeId(rs.getString("NODE_ID"));
			hub.setSequence(rs.getInt("SEQUENCE_NO"));
			hub.setPlannedArrivalTime(rs.getTimestamp("PLANNED_ARRIVAL"));
			hub.setPlannedDispatchTime(rs.getTimestamp("PLANNED_DISPATCH"));
			hub.setActualArrivalTime(rs.getTimestamp("ACTUAL_ARRIVAL"));
			hub.setActualDispatchTime(rs.getTimestamp("ACTUAL_DISPATCH"));
			hubList.add(hub);
		}
		}
		return map;
	}

}
