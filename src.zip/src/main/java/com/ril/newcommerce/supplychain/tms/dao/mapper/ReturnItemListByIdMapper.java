package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;

public class ReturnItemListByIdMapper implements ResultSetExtractor<Map<String,List<ReturnItem>>> {

	@Override
	public Map<String,List<ReturnItem>> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String,List<ReturnItem>> returnItemMap = new HashMap<>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			
			ReturnItem  returnItem = new ReturnItem();
			
			returnItem.setChallanId(rs.getString("CHALLAN_ID"));
			returnItem.setReturnOrderId(rs.getString("RETURN_ORDER_ID"));
			returnItem.setFwdOrderId(rs.getString("FORWARD_ORDER_ID"));
			returnItem.setItemId(rs.getString("ITEM_ID"));
			returnItem.setPrimeLineNo(rs.getString("PRIME_LINE_NO"));
			returnItem.setItemName(rs.getString("ITEM_NAME"));
			returnItem.setOrderedQuantity(rs.getDouble("ORDERED_QTY"));
			returnItem.setHsnCode(rs.getString("HSN_CODE"));
			returnItem.setUnitPrice(rs.getDouble("UNIT_PRICE"));
			returnItem.setUom(rs.getString("UOM"));
			returnItem.setRecievedQuantity(rs.getDouble("RECEIVED_QTY"));
			returnItem.setInvoicedQuanity(rs.getDouble("INVOICED_QTY"));
			returnItem.setReturnType(rs.getString("RETURN_TYPE"));
			
			returnItemMap.putIfAbsent(returnItem.getReturnOrderId(), new ArrayList<>());
			returnItemMap.get(returnItem.getReturnOrderId()).add(returnItem);
			
		}
		return returnItemMap;
	}
}
