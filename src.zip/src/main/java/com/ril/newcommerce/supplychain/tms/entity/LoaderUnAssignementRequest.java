package com.ril.newcommerce.supplychain.tms.entity;

import com.ril.newcommerce.supplychain.tms.constants.Constants;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class LoaderUnAssignementRequest {
	
	private String vehicleId;
	
	private String action;
	
	public LoaderUnAssignementRequest(String vehicleId) {
		this.vehicleId = vehicleId;
		this.action=Constants.LOADER_UNASSIGNMENT;
	}

	public String getVehicleId() {
		return vehicleId;
	}
	
	
	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}
	
	public String getAction() {
		return action;
	}
	
	public void setAction(String action) {
		this.action = action;
	}
	
}
