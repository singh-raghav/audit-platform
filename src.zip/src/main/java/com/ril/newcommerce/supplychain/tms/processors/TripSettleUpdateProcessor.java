
package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.TripAdditionalDetails;
import com.ril.newcommerce.supplychain.tms.entity.TripSettleDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.RRLResponse;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.SettlementUpdateService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.SettlementUpdate;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripSettleUpdate;
import com.ril.newcommerce.supplychain.tms.util.RestClient;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * @author Raghav1.Singh
 *
 */

@Service
@Qualifier(Constants.TRIP_SETTLE_UPDATE_PROCESSOR)
public class TripSettleUpdateProcessor implements Processor {
	
	private static final Logger log = LoggerFactory.getLogger(TripSettleUpdateProcessor.class);
	
	@Autowired
	private RestClient restClient;
	
	@Autowired 
	private JAXBContextConfig jAXBContextConfig;
	
	@Autowired
	private JMSPublisher jmsPublisher;
	
	@Autowired
	private SettlementUpdateService settlementUpdateService;
	
	@Value("${trip.status.queue}")
	private String queueName;
	
	@Value("${ncs.nodeRrlMappingUrl}")
	private String nodeRrlMappingUrl;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {
		
		try {
			StringReader reader = new StringReader(((TextMessage) message).getText());
			
			TripSettleUpdate tripSettleUpdate = (TripSettleUpdate)jAXBContextConfig.
					                            getJaxbContextInstance(TripSettleUpdate.class).
					                            createUnmarshaller().unmarshal(reader);
			
			log.info("Unmarshalling of TripSettleUpdate done successfully..");
			
			String tripId = tripSettleUpdate.getTripId();
			if (StringUtils.isBlank(tripId)) {
				throw new ParsingException("TripId cannot be null for creating SettlementUpdate");
			}
			
			log.info("start creating SettlementUpdate for tripId {}", tripId);
			
			List<TripSettleDetails> orderDetailsList = settlementUpdateService.getCodOrderDetails(tripId);
			
			List<TripAdditionalDetails> tripDetailsList = settlementUpdateService.getTripAdditionalDetails(tripId);
			
			SettlementUpdate messageToPublish = createPublishMessage(tripSettleUpdate,orderDetailsList,tripDetailsList);
			
			publishSettlementUpdate(messageToPublish);
			
			log.info("Posdm posting done successfully to OMS for tripId {}", tripId);
			
		}
		catch(ParsingException ex) {
			throw new ParsingException("Parsing error while parsing TripSettleUpdate message",ex);
		}
		catch (Exception e) {
			log.error("Error while processing TripSettleUpdate", e);
			throw new TripApplicationException("Exception occurred while processing TripSettleUpdate", e);
		}
		
	}
	
	private SettlementUpdate createPublishMessage(TripSettleUpdate tripSettleUpdate, List<TripSettleDetails> orderDetailsList, 
			                                      List<TripAdditionalDetails> tripDetailsList) throws Exception {
		
		String cashToBeCollected = null, cashCollected = null;
		for (TripAdditionalDetails obj : tripDetailsList) {
			if(obj.getKey().equalsIgnoreCase("CASH_TO_BE_COLLECTED"))
				cashToBeCollected=obj.getValue();
			else if(obj.getKey().equalsIgnoreCase("CASH_COLLECTED"))
				cashCollected=obj.getValue();
		}

        if (null == cashToBeCollected || null == cashCollected) {
            throw new Exception("Trip additional details doesn't have Cash details for the trip yet. TripId : " + tripSettleUpdate.getTripId());
        }

		double tripCollectibleAmount = Double.valueOf(cashToBeCollected);
		double tripCollectedAmount = Double.valueOf(cashCollected);		
		double tripAmountDifference = tripCollectibleAmount-tripCollectedAmount;
		
		if(tripAmountDifference!=0) {
			
			orderDetailsList.sort((order1,order2)->{
				if(order1.getAmountPaid()==order2.getAmountPaid())
					return 0;
				else if(order1.getAmountPaid()<order1.getAmountPaid())
					return 1;
				else
					return -1;
			}); 
			
			int i=0;
			while(tripAmountDifference!=0) {
				if(orderDetailsList.get(i).getAmountPaid()>tripAmountDifference) {
					orderDetailsList.get(i).setShortAmount(tripAmountDifference);
					break;
				}else if(orderDetailsList.get(i).getAmountPaid()<tripAmountDifference) {
					orderDetailsList.get(i).setShortAmount(tripAmountDifference);
					tripAmountDifference-=orderDetailsList.get(i).getAmountPaid();
					++i;
				}else {
					orderDetailsList.get(i).setShortAmount(tripAmountDifference);
					tripAmountDifference-=orderDetailsList.get(i).getAmountPaid();
				}
			}			
		}
		
		SettlementUpdate settlementUpdate = new SettlementUpdate();
		SettlementUpdate.Orders orders = new SettlementUpdate.Orders();
		List<SettlementUpdate.Orders.Order> orderList = new ArrayList<>();
		
		for(TripSettleDetails obj : orderDetailsList) {
			SettlementUpdate.Orders.Order order = new SettlementUpdate.Orders.Order();
			order.setOrderNo(obj.getOrderId());
			order.setShipmentNo(obj.getShipmentNo());
			order.setCollectibleAmount(new BigDecimal(obj.getAmountPaid()+obj.getRoundOffAmount()).setScale(2, RoundingMode.HALF_UP));
			order.setCollectedAmount(new BigDecimal(obj.getAmountPaid()-obj.getShortAmount()).setScale(2, RoundingMode.HALF_UP));
			order.setShortageAmount(new BigDecimal(obj.getShortAmount()).setScale(2, RoundingMode.HALF_UP));
			order.setRoundOffAmount(new BigDecimal(obj.getRoundOffAmount()).setScale(2, RoundingMode.HALF_UP));		
			orderList.add(order);
		}
		
		orders.setOrder(orderList);
		settlementUpdate.setTripId(tripSettleUpdate.getTripId());
		settlementUpdate.setEventTimeStamp(tripSettleUpdate.getEventTimeStamp());
		settlementUpdate.setFCPLSiteCode(tripSettleUpdate.getNodeId());
		
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		params.add("nodeIds", tripSettleUpdate.getNodeId());
		RRLResponse response = (RRLResponse)restClient.get(nodeRrlMappingUrl, new HashMap<>(),
				                params, RRLResponse.class, null);
		
		if(!CollectionUtils.isEmpty(response.getNodeRRLMappings())) {
			settlementUpdate.setRRLSiteCode(response.getNodeRRLMappings().get(0).getRrlId());			
		}else {
			log.info("No RRL site available for the given FCPL site code {}", tripSettleUpdate.getNodeId());
			settlementUpdate.setRRLSiteCode("NA");			
		}		
		
		settlementUpdate.setOrders(orders);			
		
		return settlementUpdate;
	}
	
	private void publishSettlementUpdate(SettlementUpdate settlementUpdate) throws Exception {
		
		jmsPublisher.publishMessage(queueName, settlementUpdate, FlowName.SETTLEMENTUPDATE.getValue(), 
				Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
						settlementUpdate.getTripId()), SettlementUpdate.class);
	}

}
