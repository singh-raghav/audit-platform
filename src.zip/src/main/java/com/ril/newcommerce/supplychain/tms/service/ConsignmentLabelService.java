package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ril.newcommerce.supplychain.tms.response.HuCountResponse;
import com.ril.newcommerce.supplychain.tms.tibco.stagingupdate.entity.Shipment;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentCount;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate.Labels.Label;

/**
B1.Divya
*/
@Service
public interface ConsignmentLabelService {
	
	public Map<String, TripConsignmentCount> getConsignmentDetailsByTrip(List<String> tripIds,List<String> sourceNode);

	public int saveShipmentLabel(Set<ConsignmentLabel> shipmentLabels);
	
	public void updateStatusOfLabels(List<Label> labels, String modifiedBy);

	public int updateStatusOfShipmentLabel(Shipment shipment, String flowName);

	public Integer getLabelsCountForShipment(String shipmentNo);

	public List<Label> getStatusOfLabels(List<Label> labels);
	
	public  Map<String, Map<String, List<ConsignmentLabel>>> getTripConsignmentLabel(String tripIds, String sourceNode);

	List<ConsignmentLabel> getConsignmentLabel (String shipmentNo);

    List<HuCountResponse> huCountForSDP(List<String> nodeIds, String startDate, String endDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs);
}
