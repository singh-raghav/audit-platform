package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

/**
 * 
 * Default scope is singleton
 * @author Jeevi.Natarajan
 *
 */
@Configuration
public class ChallanPdfExecutorService {

	private static final Logger log = LoggerFactory.getLogger(ChallanExecutorService.class);
	    
	private ExecutorService challanPdfExecutor;
	
	@Value("${challan.pdf.threadpool.size}")
	private Integer poolSize;
	
	public ChallanPdfExecutorService() {
		challanPdfExecutor =  Executors.newFixedThreadPool(poolSize==null?10:poolSize);
	}
	
	public ExecutorService getPdfChallanExecutor() {
		return challanPdfExecutor;
	}
	
	public void shutdownPdfChallanExecutor() {
		
		try {
			challanPdfExecutor.shutdown();
			challanPdfExecutor.awaitTermination(5000,TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			log.error("Exception occured on shutting doown challanPdfExecutor");
		}
		
		log.info("Shutdown of challanPdfExecutor Successfull!");
	}
	
}
