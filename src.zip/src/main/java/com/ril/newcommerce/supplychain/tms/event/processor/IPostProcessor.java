package com.ril.newcommerce.supplychain.tms.event.processor;

import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

/**
 * 
 * @author jeevi.natarajan
 *
 */
public interface IPostProcessor {
	public void postProcessEvent(TripEventInput event, Trip trip);
}
