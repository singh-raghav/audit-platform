package com.ril.newcommerce.supplychain.tms.service;

public interface PdfDeletionService {

    void deletePDf();

}
