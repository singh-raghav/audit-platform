package com.ril.newcommerce.supplychain.tms.entity;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

/**
B1.Divya
*/

@Data
public class Seal {

	private String nodeId;
	private List<String> seals = new ArrayList<>();
}
