package com.ril.newcommerce.supplychain.tms.enums;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * B1.Divya
 */

public enum LabelType {

	TOTE("Tote"), BAG("Bag"), HU("HU");

	private String value;

	private LabelType(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}
public static final Set<String> lookup = new HashSet<>();
	
	static {
		for (LabelType labelType : LabelType.values())
			lookup.add(labelType.getValue());
	}

	
}
