package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.UnmarshalException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.EwayBillStatus;
import com.ril.newcommerce.supplychain.tms.enums.OrderClassification;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.OrderDetailsService;
import com.ril.newcommerce.supplychain.tms.service.OrderInvoiceService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill;
import com.ril.newcommerce.supplychain.tms.tibco.entity.EwayBill.Trip.TripOrders.TripOrder;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
B1.Divya
*/

@Service
@Qualifier("ewayBillResponseProcessor")
public class EwayBillResponseProcessor implements Processor {
	private static final Logger log = LoggerFactory.getLogger(EwayBillResponseProcessor.class);

	@Autowired 
	private JAXBContextConfig jAXBContextConfig;
	
	@Autowired
	private OrderInvoiceService orderInvoiceService;
	
	@Autowired
	private OrderDetailsService orderService;
	
	@Autowired 
	TripService tripService;
	
	@Autowired
	private JMSPublisher jmsPublisher;
	
	@Value("${trip.status.queue}")
	private String queueName;
	
	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {
		try {
			StringReader reader = new StringReader(((TextMessage) message).getText());
			EwayBill ewayBillResponse = (EwayBill) jAXBContextConfig.getJaxbContextInstance(EwayBill.class).createUnmarshaller().unmarshal(reader);
			
			Trip trip=tripService.getTrip(ewayBillResponse.getTrip().getTripNo());
			
			log.info("Got ewaybil response for trip id {},",trip.getTripId());
			
			List<String> fwdOrderIds= new ArrayList<String>();
			List<Consignment> returnOrders= new ArrayList<>();
			List<String> status = new ArrayList<String>();
			status.add(OrderStatus.ACTIVE.getValue());
			
			List<Consignment> consignments = orderService.getTripOrderAndAdditionalDetails(ewayBillResponse.getTrip().getTripNo(),
					ewayBillResponse.getTrip().getNodeId(), status, null,null);
			
			filterOrderIds(consignments,fwdOrderIds,returnOrders);
			
			
			orderInvoiceService.updateEwayBillStatusForOrders(ewayBillResponse.getTrip().getTripOrders().getTripOrder());
			
			String ewayStatus=getEwayBillStatusForTrip(ewayBillResponse,fwdOrderIds);
			
			updateEwayBillStatusForTrip(ewayBillResponse,ewayStatus,trip);
			
			publishEwayBill(ewayBillResponse,ewayStatus,returnOrders,trip);
		} catch (UnmarshalException par) {
			throw new ParsingException("Parsing error while parsing ewaybill response", par);
		} catch (Exception e) {
			log.error("Error while processing ewaybill response ", e);
			throw new Exception("Exception occurred while parsing ewaybill response", e);
		}
	}
	

	private void filterOrderIds(List<Consignment> consignments,List<String> fwdOrderIds, List<Consignment> returnOrder) {
		//Filtering only the forward Ids.
		 fwdOrderIds.addAll(consignments.stream()
											.filter(consignment->OrderClassification.Forward.getValue().equals(consignment.getOrderClassification()))
											.map(mapper -> mapper.getOrderId())
											.collect(Collectors.toList())); 
		returnOrder.addAll(consignments.stream()
				.filter(consignment->OrderClassification.Return.getValue().equals(consignment.getOrderClassification()))
				.collect(Collectors.toList())); 
		
	}


	private String getEwayBillStatusForTrip(EwayBill ewayBillResponse,List<String> fwdOrderIds) throws InterruptedException, ExecutionException
	{
		
		boolean pending = false, failed = false;
		String value = null;
		Map<String, String> ewayBillOrderResponse = ewayBillResponse.getTrip().getTripOrders().getTripOrder().stream()
				.collect(Collectors.toMap(TripOrder::getOrderNo, TripOrder::getStatus));
		
		for (String orderId : fwdOrderIds) {
			if (null != ewayBillOrderResponse.get(orderId)) {
				if (EwayBillStatus.FAILED.value().equalsIgnoreCase(ewayBillOrderResponse.get(orderId))) {
					failed = true;
				}
			} else {
				log.info("Not got ewayBill response form order id {} for trip id {} ",orderId,ewayBillResponse.getTrip().getTripNo());
				pending = true;
				break;
			}
		}

		if (pending)
			value = EwayBillStatus.PENDING.value();
		else if (failed)
			value = EwayBillStatus.FAILED.value();
		else
			value = EwayBillStatus.SUCCESS.value();
		
		log.info("EwayBill status from trip {} is {}",ewayBillResponse.getTrip().getTripNo(),value);

		return value;
	}
	 
	private void updateEwayBillStatusForTrip(EwayBill ewayBillResponse,String ewayStatus,Trip trip)
	{
				// get node if from trip
				
				TripAdditionalDetail additionalDetails = new TripAdditionalDetail(ewayBillResponse.getTrip().getTripNo(),
						trip.getSourceNode(), Constants.EWAYBILL, ewayStatus);
				tripService.updateTripAdditionalDetails(additionalDetails);
		
	}
	
	private void publishEwayBill(EwayBill ewayBillResponse,String ewayStatus,List<Consignment> returnOrders,Trip trip)
	{
		if(EwayBillStatus.SUCCESS.value().equals(ewayStatus)){
			log.info("Published ewaybill messgae to delivery");
			
			updateResponseWithReturnOrder(ewayBillResponse, returnOrders,trip);
			
			jmsPublisher.publishMessage(queueName, ewayBillResponse, FlowName.EWAYBILLPUBLISH.getValue(),
					Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
							ewayBillResponse.getTrip().getTripNo()),EwayBill.class);
		}
		
	}


	private void updateResponseWithReturnOrder(EwayBill ewayBillResponse, List<Consignment> returnOrders,Trip trip) {
		
		ewayBillResponse.getTrip().setVehicleNO(trip.getAssignedVehicle());
		ewayBillResponse.getTrip().setDeliveryPartner(trip.getAssignedDpId());
		List<TripOrder> tripOrders=ewayBillResponse.getTrip().getTripOrders().getTripOrder();
		
		for(Consignment returnConsignment:returnOrders)
		{
		TripOrder tripOrder=new TripOrder();
		tripOrder.setOrderNo(returnConsignment.getOrderId());
		tripOrder.setShipmentNo(returnConsignment.getShipmentNo());
		tripOrder.setStatus(EwayBillStatus.NOT_REQUIRED.value());
		tripOrders.add(tripOrder);
		}
		
	}
}
