package com.ril.newcommerce.supplychain.tms.service.impl;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.service.challan.ChallanExecutorService;


@Configuration
public class TripExecutor {
	
	private static final Logger log = LoggerFactory.getLogger(TripExecutor.class);
    
	private ExecutorService executor;
	
	@Value("${trip.threadpool.size}")
	private int poolSize;
	
	
	@Bean
	public ExecutorService getTripExecutor() {
		executor= Executors.newFixedThreadPool(poolSize);
		return executor;
	}
	
	public void shutdownExecutor() {

		try {
			executor.shutdown();
			executor.awaitTermination(5000, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			log.error("Exception occured on shutting doown trip executors");
		}

		log.info("Trip executors are shutdown");
	}

}
