package com.ril.newcommerce.supplychain.tms.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.dao.OrderInvoiceDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripReconcileDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.ATSResponse;
import com.ril.newcommerce.supplychain.tms.entity.AssetsToBeReturned;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.WayPointUpdates;
import com.ril.newcommerce.supplychain.tms.entity.rest.ReturnItemCheck;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.ReturnItemQuality;
import com.ril.newcommerce.supplychain.tms.enums.TripType;
import com.ril.newcommerce.supplychain.tms.service.ReconcileService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.service.WayPointUpdatesService;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReturnedAsset;

/**
B1.Divya
*/
@Service
public class ReconcileServiceImpl implements ReconcileService
{
	private static final Logger log = LoggerFactory.getLogger(ReconcileServiceImpl.class);

	@Autowired
	TripsDAO tripsDAO;
	
	@Autowired
	private TripReconcileDAO tripReconcileDao;
	
	@Autowired
	private OrderInvoiceDAO orderInvoiceDao;

	@Autowired
	private InboundDAO inBoundDAO;
	
	@Autowired
	private TripService tripservice;
	
	@Autowired
	WayPointUpdatesService wayPointUpdatesService;
	
	@Override
	public ReturnItemCheck checkReturnItemMisMatchForHubTrip(String tripId) {
		ReturnItemCheck returnItemsCheck = new ReturnItemCheck();
		List<ReconcileArticle> reconcileArticles = new ArrayList<ReconcileArticle>();
		List<Trip> trips = tripsDAO.getTripDetails(Arrays.asList(tripId));
		Trip trip=trips.get(0);
		if(trip.getTripType().equalsIgnoreCase(TripType.HUB_CUSTOMER.getValue())){
			List<WayPointUpdates> wayPointsReceived=wayPointUpdatesService.getWayPointUpdates(trip.getTripId());
			List<String> orderIds = wayPointsReceived.stream().filter(wayPointUpdates -> wayPointUpdates.getShouldReconcile()=='Y').map(i->i.getOrderId()).collect(Collectors.toList());
			log.info("List of orders from delivery service {} "+orderIds);
			//list of return orders from invoice
			returnItemsCheck.setWayPointUpdates(wayPointsReceived);

			if (!CollectionUtils.isEmpty(orderIds)) {
				reconcileArticles = tripsDAO.getReturnItems(orderIds);
				List<String> returnOrdersIds = reconcileArticles.stream().map(i -> i.getFwdOrderId()).distinct().collect(Collectors.toList());
				log.info("List of return orders from return invoice {} " + returnOrdersIds.toString());
				returnItemsCheck.setReconcileArticles(reconcileArticles);
				if (!CollectionUtils.isEmpty(orderIds) && !CollectionUtils.isEmpty(returnOrdersIds) && orderIds.size() == returnOrdersIds.size()) {
					returnItemsCheck.setReturnMissMatch(false);
				} else {
					returnItemsCheck.setReturnMissMatch(true);
					orderIds.removeAll(returnOrdersIds);
					returnItemsCheck.setFailureMessage("Return invoice for order " + orderIds.toString() + " is missing !");
				}
			} else {
				returnItemsCheck.setReturnMissMatch(false);
			}
		} else {
			returnItemsCheck.setReturnMissMatch(false);
		}

		return returnItemsCheck;
	}

	@Override
	public List<Trip> getTripDetails(String tripId, String includeRecon, String nodeId,
			List<ReconcileArticle> returnItems, List<WayPointUpdates> waypointUpdates) throws Exception {
		String tripIds[] = tripId.split(",");
		List<String> tripIdList = Arrays.asList(tripIds);
		List<String> nodeIds=Arrays.asList(nodeId);
		List<Trip> trips =null;
		trips = tripsDAO.getTripDetails(tripIdList);
		List<ReturnedAsset> returnedAssets = new ArrayList<ReturnedAsset>();

		tripservice.setTripStatictisc(trips,nodeIds);
		try {
			// to get details for reconciliation
			if (null != includeRecon && includeRecon.equalsIgnoreCase("true")) {
				Trip trip = trips.get(0);
				ATSResponse returnAssetResponse = tripReconcileDao.getAssetForReconcile(trip.getTripId());
				log.debug("Asset response for trip is {} " + returnAssetResponse);
				if (trip.getTripType().equalsIgnoreCase(TripType.HUB_CUSTOMER.getValue())) {
					trip = getHubTripDetailToReconcile(returnItems, trip,waypointUpdates);
					//setPendingAssetCount(returnAssetResponse, trip);
					returnedAssets = getListOfReturnedAssets(returnAssetResponse);
					trip.setReturnedAssets(returnedAssets);
				} else {
					// to get returned assets of FC
					returnedAssets = getListOfReturnedAssets(returnAssetResponse);
					trip.setReturnedAssets(returnedAssets);
					setFcTripReconDetails(trip);
				}
			}
		} catch (Exception ex) {
			log.error("Error in getting trip data {} ", ex);
		}
     return trips;
	}
	private Trip getHubTripDetailToReconcile(List<ReconcileArticle> returnItems, Trip trip, List<WayPointUpdates> waypointUpdates) {
		trip.setInitialCash(Double.parseDouble(null!=tripsDAO.getInitialAmount(trip.getTripId())?tripsDAO.getInitialAmount(trip.getTripId()):"0.0"));
		if(trip.getTripType().equalsIgnoreCase(TripType.HUB_CUSTOMER.getValue())) {
			List<WayPointUpdates> deliveredOrderList = waypointUpdates.stream().filter(i->i.getStatus().equalsIgnoreCase(OrderStatus.ORDER_DELIVERED.getValue())).collect(Collectors.toList());
			List<WayPointUpdates> partiallyDeliveredOrderList = waypointUpdates.stream().filter(i-> i.getStatus().equalsIgnoreCase(OrderStatus.PARTIALLY_DELIVERED.getValue())).collect(Collectors.toList());
			trip.setDeliveredOrders(deliveredOrderList.isEmpty()?0:deliveredOrderList.size());
			trip.setPartiallyDeliveredOrders(partiallyDeliveredOrderList.isEmpty()?0:partiallyDeliveredOrderList.size());
			trip.setUnDeliveredOrders(waypointUpdates.isEmpty()?0:waypointUpdates.size()-(trip.getDeliveredOrders()+trip.getPartiallyDeliveredOrders()));

			double expectedCashOnCod = (waypointUpdates.isEmpty() ? 0.0 :
					waypointUpdates.stream().mapToDouble(i -> (i.getAmountPaid())).sum());

			double cashCollectedForDeliveredOrder = (deliveredOrderList.isEmpty()?0.0:
					deliveredOrderList.stream().mapToDouble(i -> (i.getAmountPaid())).sum());

			double cashCollectedForpartiallyDeliveredOrder = (partiallyDeliveredOrderList.isEmpty() ? 0.0 :
					partiallyDeliveredOrderList.stream().mapToDouble(i->(i.getAmountPaid())).sum());

			double cashNotCollected =
					expectedCashOnCod - cashCollectedForpartiallyDeliveredOrder - cashCollectedForDeliveredOrder;

			trip.setCashToBeCollected(new BigDecimal( (trip.getInitialCash() + expectedCashOnCod)).setScale(2, RoundingMode.HALF_UP).doubleValue());
			trip.setCashBalance(new BigDecimal(cashNotCollected).setScale(2, RoundingMode.HALF_UP).doubleValue());
			trip.setCashCollected((cashCollectedForDeliveredOrder + cashCollectedForpartiallyDeliveredOrder));

		}
		if(null!=trip.getTripConsignmentCount()) {
			trip.setDeliveredTasks(trip.getTripConsignmentCount().getPlannedOrderCount()-trip.getTripConsignmentCount().getMissedOrderCount());
			trip.setUnassignedTasks(trip.getTripConsignmentCount().getMissedOrderCount());
		}else {
			trip.setDeliveredTasks(0);
			trip.setUnassignedTasks(0);
		}		
		trip.setReconcileArticles(returnItems);
//		getAmountToBeCollected(trip,returnItems,waypointUpdates);
		return trip;
	}
	
//	private void getAmountToBeCollected(Trip trip, List<ReconcileArticle> returnItems, List<WayPointUpdates> waypointUpdates) {
//		double prepaidAmount = 0.0;
//		double amountToBeCollected = 0.0;
//		ArrayList<String> statusList = new ArrayList<>();
//		statusList.add("Active");
//		List<com.ril.newcommerce.supplychain.tms.entity.Invoice> orderInvoices=orderInvoiceDao.getInvoicesForTrip(trip.getTripId(),statusList);
//		if(null!=orderInvoices) {
//			prepaidAmount = orderInvoices.stream().mapToDouble(i->i.getInvoiceAmount() - i.getAmountToBeCollected()).sum();
//			for(com.ril.newcommerce.supplychain.tms.entity.Invoice invoice:orderInvoices) {
//				List<ReconcileArticle> reconcileArticles = new ArrayList<ReconcileArticle>();
//				double returnOrderPrice = 0.0;
//				if(null!=returnItems)
//				  reconcileArticles = returnItems.stream().filter(i->i.getFwdOrderId().equalsIgnoreCase(invoice.getOrderNo())).collect(Collectors.toList());
//				if(null!=reconcileArticles)
//				   returnOrderPrice = reconcileArticles.stream().mapToDouble(i->i.getPricePerItem()*i.getPricePerItem()).sum();
//				if(invoice.getAmountToBeCollected()>=returnOrderPrice)
//					amountToBeCollected = amountToBeCollected + (invoice.getAmountToBeCollected() - returnOrderPrice);
//				else
//					amountToBeCollected = amountToBeCollected + 0.0;
//			}
//		}
//		trip.setCashToBeCollected(Math.round((trip.getInitialCash()+amountToBeCollected)*100.0) / 100.0);
//		trip.setCashBalance(Math.round(amountToBeCollected * 100.0) / 100.0);
//		trip.setPrepaidAmount(prepaidAmount);
//	}
	
	private List<ReturnedAsset> getListOfReturnedAssets(ATSResponse returnAssetResponse) {
		List<ReturnedAsset> returnedAssets = new ArrayList<ReturnedAsset>();
		for(AssetsToBeReturned assetsToBeReturned:returnAssetResponse.getData().getAssetInfo().getAssetsToBeReturned()) {
			ReturnedAsset returnedAsset = new ReturnedAsset();
			returnedAsset.setSerialNo(null==returnedAssets || returnedAssets.isEmpty()? 1 : returnedAssets.size()+1);
			returnedAsset.setType(assetsToBeReturned.getAssetType());
			returnedAsset.setPicked(Integer.parseInt(assetsToBeReturned.getCount()));
			returnedAssets.add(returnedAsset);
		}
		return returnedAssets;
	}
	
	private void setFcTripReconDetails(Trip trip){

		List<ChallanArticle> deliveryChallanArticlesList = inBoundDAO.getReturnItemsAgainstTrip(trip.getTripId(),Arrays.asList(ReturnItemQuality.GOOD.name(),ReturnItemQuality.BAD.name()));

		if(CollectionUtils.isNotEmpty(deliveryChallanArticlesList)) {
			
			List<String> returnOrderIds = deliveryChallanArticlesList.stream().map(article-> article.getReturnOrderId()).collect(Collectors.toList());
			Map<String,ReturnItem> returnItems = inBoundDAO.getReturnItemById(returnOrderIds);
			
			for(ChallanArticle article : deliveryChallanArticlesList) {
				String itemId = article.getArticleCode();
				ReturnItem item = returnItems.get(itemId);
				if(item!=null)
				{
					article.setArticleDesc(item.getItemName());
					article.setRate(item.getUnitPrice());
					article.setFwdOrderId(item.getFwdOrderId());
					article.setReturnType(item.getReturnType());
				}
			}
			
			List<ReconcileArticle> reconcileArticles = new ArrayList<>();
	
			int serialNoForReturnItems=1;
			for(ChallanArticle deliveryChallanArticle : deliveryChallanArticlesList){
				ReconcileArticle reconcileArticle = new ReconcileArticle();
				reconcileArticle.setSerialNo(serialNoForReturnItems++);
				reconcileArticle.setOrderId(deliveryChallanArticle.getReturnOrderId());
				reconcileArticle.setFwdOrderId(deliveryChallanArticle.getFwdOrderId());
				reconcileArticle.setArticleId(deliveryChallanArticle.getArticleCode());
				reconcileArticle.setArticleName(deliveryChallanArticle.getArticleDesc());
				reconcileArticle.setQuantity(deliveryChallanArticle.getQuantity());
				reconcileArticle.setReturnType(deliveryChallanArticle.getReturnType());
				reconcileArticle.setStatus(Constants.UNDELIVERED);
				reconcileArticle.setPricePerItem(deliveryChallanArticle.getRate());
				reconcileArticles.add(reconcileArticle);
			}
	
			trip.setReconcileArticles(reconcileArticles);
		}

	}
}
