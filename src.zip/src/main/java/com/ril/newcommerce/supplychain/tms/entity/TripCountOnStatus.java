package com.ril.newcommerce.supplychain.tms.entity;

/**
B1.Divya
*/

public class TripCountOnStatus {
	
	private int createdTripsCount;
	private int assignedTripsCount;
	private int loadingTripsCount;
	private int loadingCompletedTripsCount;
	private int startedTripsCount;
	private int toBeSettledTripsCount;
	private int settledTripsCount;
	private int cancelledTripsCount;
	
	public int getCreatedTripsCount() {
		return createdTripsCount;
	}
	public void setCreatedTripsCount(int createdTripsCount) {
		this.createdTripsCount = createdTripsCount;
	}
	public int getAssignedTripsCount() {
		return assignedTripsCount;
	}
	public void setAssignedTripsCount(int assignedTripsCount) {
		this.assignedTripsCount = assignedTripsCount;
	}
	public int getLoadingTripsCount() {
		return loadingTripsCount;
	}
	public void setLoadingTripsCount(int loadingTripsCount) {
		this.loadingTripsCount = loadingTripsCount;
	}
	public int getLoadingCompletedTripsCount() {
		return loadingCompletedTripsCount;
	}
	public void setLoadingCompletedTripsCount(int loadingCompletedTripsCount) {
		this.loadingCompletedTripsCount = loadingCompletedTripsCount;
	}
	public int getStartedTripsCount() {
		return startedTripsCount;
	}
	public void setStartedTripsCount(int startedTripsCount) {
		this.startedTripsCount = startedTripsCount;
	}
	public int getToBeSettledTripsCount() {
		return toBeSettledTripsCount;
	}
	public void setToBeSettledTripsCount(int toBeSettledTripsCount) {
		this.toBeSettledTripsCount = toBeSettledTripsCount;
	}
	public int getSettledTripsCount() {
		return settledTripsCount;
	}
	public void setSettledTripsCount(int settledTripsCount) {
		this.settledTripsCount = settledTripsCount;
	}
	public int getCancelledTripsCount() {
		return cancelledTripsCount;
	}
	public void setCancelledTripsCount(int cancelledTripsCount) {
		this.cancelledTripsCount = cancelledTripsCount;
	}
}
