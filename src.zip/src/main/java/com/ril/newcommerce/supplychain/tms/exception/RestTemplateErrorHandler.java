package com.ril.newcommerce.supplychain.tms.exception;

import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
B1.Divya
*/

public class RestTemplateErrorHandler implements ResponseErrorHandler 
{

	@Override
	public void handleError(ClientHttpResponse httpResponse) throws IOException {
		
		if (httpResponse.getStatusCode() == HttpStatus.REQUEST_TIMEOUT) {
			throw new RequestTimedOutException("Request has been Timedout!");
		}
		else if (httpResponse.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR) {
			throw new NetworkCommunicationException(Utility.getConcatinatedString("Exception occured in rest call ",
					httpResponse.getStatusCode().series().value()));
		} else if (httpResponse.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR) {
			throw new NetworkCommunicationException(Utility.getConcatinatedString("Exception occured in rest call ",
					httpResponse.getStatusCode().series().value()));

		}
		

	}

	@Override
	public boolean hasError(ClientHttpResponse httpResponse) throws IOException {
		return (httpResponse.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR);
	}

}
