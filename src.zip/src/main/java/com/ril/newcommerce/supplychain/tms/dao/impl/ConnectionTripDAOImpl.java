/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.ConnectionTripDAO;
import com.ril.newcommerce.supplychain.tms.entity.ConnectionTrip;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;

/**
 * @author Raghav1.Singh
 *
 */

@Repository
public class ConnectionTripDAOImpl implements ConnectionTripDAO {
	
	private static final Logger log = LoggerFactory.getLogger(ConnectionTripDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void insertToTrip(ConnectionTrip connectionTrip) {
		
		try {
			jdbcTemplate.update(QueryConstants.INSERT_CONNECTION_TRIP, new PreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					
					ps.setString(1, connectionTrip.getTripId());
					ps.setString(2, connectionTrip.getTripType());
					ps.setString(3, connectionTrip.getSourceNodeId());
					ps.setTimestamp(4, connectionTrip.getTripCreationTime());
					ps.setTimestamp(5, connectionTrip.getTripCreationTime());
					ps.setString(6, connectionTrip.getStatus());
					ps.setString(7, connectionTrip.getCreatedBy());
					ps.setString(8, connectionTrip.getExternalRefId());
					ps.setString(9, connectionTrip.getFlowname());
					ps.setString(10, connectionTrip.getMovementType().getValue());
					
					
				}
			});
			log.info("Inserted connectionTrip data in trip table successfully with tripId {}", connectionTrip.getTripId());
			
		} catch (Exception e) {
			log.error("Exception occured during inserting connectionTrip data in trip table", e);
			throw new DataProcessingException("Got Exception while inserting connection trip details in trip table", e);
		}

	}

	@Override
	public void insertToTripSequence(ConnectionTrip connectionTrip) {
			
		try {
			if(connectionTrip.getConnections()!=null && !connectionTrip.getConnections().isEmpty()) {
				
				List<Object[]> inputList = new ArrayList<Object[]>();
				int size = 0;
				for(String str : connectionTrip.getConnections()) {
					Object[] temp = {connectionTrip.getTripId(),str,++size,connectionTrip.getCreatedBy(),
							         connectionTrip.getTripCreationTime(),connectionTrip.getFlowname()};
					inputList.add(temp);
				}
				jdbcTemplate.batchUpdate(QueryConstants.INSERT_CONNECTION_TRIP_SEQUENCE, inputList);
				log.info("Inserted ConnectionTrip data in trip Sequence table successfully with tripId {}", connectionTrip.getTripId());
				
			}
		} catch (Exception e) {
			log.error("Exception occured during inserting connectionTrip data in trip sequence table", e);
			throw new DataProcessingException("Exception occured during inserting data in trip sequence", e);
		}

	}

	@Override
	public void insertToTripSequence(ConnectionTrip connectionTrip, int size) {
		
		try {
			if(connectionTrip.getConnections()!=null && !connectionTrip.getConnections().isEmpty()) {
				
				List<Object[]> inputList = new ArrayList<Object[]>();
				for(String str : connectionTrip.getConnections()) {
					Object[] temp = {connectionTrip.getTripId(),str,++size,connectionTrip.getCreatedBy(),
							         connectionTrip.getTripCreationTime(),connectionTrip.getFlowname()};
					inputList.add(temp);
				}
				jdbcTemplate.batchUpdate(QueryConstants.INSERT_CONNECTION_TRIP_SEQUENCE, inputList);
				log.info("Updated ConnectionTrip data in trip Sequence table successfully for tripId {}", connectionTrip.getTripId());
				
			}
		} catch (Exception e) {
			log.error("Exception occured during updating connectionTrip data in trip sequence table", e);
			throw new DataProcessingException("Exception occured during updating data in trip sequence", e);
		}
		
	}

	@Override
	public int getCountOfConnections(String tripId) {
				
		int count = 0;
		List<String> list = new ArrayList<String>();
		try {
			
			list = jdbcTemplate.queryForList(QueryConstants.GET_COUNT_OF_CONNECTIONS, String.class, new Object[] {tripId});
			
		} catch (Exception e) {	
			
			log.error("Exception occured during updating connectionTrip data in trip sequence table", e);
			throw new DataProcessingException("Exception occured during updating data in trip sequence", e);
		}
		
		 if (list!=null && !list.isEmpty())
			 count = list.size();
		 
		return count;
	}

	@Override
	public List<String> getConnections(String tripId) {
		 
		List<String> connectionList = new ArrayList<String>();
		
		try {
			
			connectionList = jdbcTemplate.queryForList(QueryConstants.GET_CONNECTIONS, String.class, new Object[] {tripId});
			
		} catch (Exception e) {
			
			log.error("Exception occured during updating connectionTrip data in trip sequence table", e);
			throw new DataProcessingException("Exception occured during updating data in trip sequence", e);
		}
		
		return connectionList;
	}

}
