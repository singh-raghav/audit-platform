package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.response.TripCountResponse;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TripCountResponseMapper implements ResultSetExtractor<List<TripCountResponse>> {

    @Override
    public List<TripCountResponse> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<TripCountResponse> tripCountResponses = new ArrayList<>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            TripCountResponse tripCountResponse = new TripCountResponse();
            tripCountResponse.setSdpId(rs.getString("SDP_ID"));
            tripCountResponse.setLoadingInProgress(rs.getInt("LOADING_IN_PROGRESS"));
            tripCountResponse.setCreatedTrips(rs.getInt("TRIPS_CREATED"));
            tripCountResponses.add(tripCountResponse);
        }
        return tripCountResponses;
    }
}
