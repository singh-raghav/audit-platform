package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.NodeOrdeRoute;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.NodeOrderRouteService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Merge.Trips.Trip.Orders;

@Service
@Qualifier(Constants.POST_MERGE_PROCESSOR)
public class PostMergeProcessor implements Processor {
	
	private static final Logger log = LoggerFactory.getLogger(PostMergeProcessor.class);
	
	@Autowired
	private NodeOrderRouteService nodeOrderRouteservice;
	
	
	@Autowired
	private TripService tripService;
	
	@Autowired 
	private JAXBContextConfig jAXBContextConfig;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception 
	{
		StringReader reader = new StringReader(((TextMessage) message).getText());
		Merge mergeDetails = (Merge) jAXBContextConfig.getJaxbContextInstance(Merge.class).createUnmarshaller().unmarshal(reader);
		String tripId= mergeDetails.getId();
		int version=mergeDetails.getVersion();
		
		Trip trip = tripService.getTrip(tripId);
		
		log.info("Post merge processor called for {}",tripId );
		
		validate(trip,version);
		
		if(CollectionUtils.isEmpty(mergeDetails.getTrips().getTrip()))
		{
			throw new ValidationException("Post merge processor :Trip list cannot be empty ");
		}
		log.info("updating hierarchy and node order deatisl after merge for trip {}",trip.getTripId());
		
		updateTripHierarchy(mergeDetails,trip);
		
		updateNodeOrderRoute(mergeDetails,trip);
		
		log.info("Post merge processor successfully completed {} ",trip.getTripId());
	}

	private void updateNodeOrderRoute(Merge mergeDetails,Trip trip) {
		List<String> tripIds=mergeDetails.getTrips().getTrip().stream().map(m->m.getId()).collect(Collectors.toList());
		
		List<Trip> trips=tripService.getTripDetails(tripIds);
		
		Map<String, Orders> tripWithOrders = mergeDetails.getTrips().getTrip().stream()
				.collect(Collectors.toMap(com.ril.newcommerce.supplychain.tms.tibco.entity.Merge.Trips.Trip::getId,
						com.ril.newcommerce.supplychain.tms.tibco.entity.Merge.Trips.Trip::getOrders));
		Map<String, List<String>> tripWithOrdersList=new HashMap<>();
		
		for(Entry<String, Orders> entry:tripWithOrders.entrySet())
		{
			List<String> orders =entry.getValue().getOrder().stream().map(mapper->mapper.getOrderId()).collect(Collectors.toList());
			Trip  tripObj=trips.stream().filter(f->f.getTripId().equals(entry.getKey())).findAny().orElse(null);
			tripWithOrdersList.put(tripObj.getExternalReferenceId(), orders);			
		}
		
		nodeOrderRouteservice.updateNextRouteId(tripWithOrdersList, trip.getExternalReferenceId());
		nodeOrderRouteservice.updatePreviousRouteId(tripWithOrdersList, trip.getExternalReferenceId());
		
		log.info("node order route successfully updated for {}", trip.getExternalReferenceId());
		
	}

	private void updateTripHierarchy(Merge mergeDetails, Trip trip) 
	{
		String nodeId=mergeDetails.getTrips().getTrip().get(0).getNodeId();
		
		List<String> orderIdsToMerge = mergeDetails.getTrips().getTrip().stream()
				.flatMap(m -> m.getOrders().getOrder().stream()).map(mapper -> mapper.getOrderId())
				.collect(Collectors.toList());
		
		List<NodeOrdeRoute> orderRoute = nodeOrderRouteservice.getRouteIdsByNodeAndOrder(nodeId, orderIdsToMerge);

		Set<String> nextRouteIds = orderRoute.stream().map(mapper -> mapper.getNextRouteId())
				.collect(Collectors.toSet());
		Set<String> prevRouteIds = orderRoute.stream().map(mapper -> mapper.getPreviousRouteId())
				.collect(Collectors.toSet());

		if (!CollectionUtils.isEmpty(nextRouteIds) && !nextRouteIds.contains(null))
			tripService.insertToTripHierarchy(trip.getExternalReferenceId(), nextRouteIds, trip.getCreatedBy());

		if (!CollectionUtils.isEmpty(prevRouteIds) && !prevRouteIds.contains(null))
			tripService.insertToTripHierarchy(prevRouteIds, trip.getExternalReferenceId(), trip.getCreatedBy());

	}
	private void validate(Trip trip, int version) {
		 if(trip.getVersion() < version)
		{
			log.info("Sent to retry queue to publish trip trip version {} and received {} ",trip.getVersion(),version);
			throw new TripApplicationException("Trip version in db is " +trip.getVersion() +" and received is "+version);
		}
		
	}


}
