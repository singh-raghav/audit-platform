package com.ril.newcommerce.supplychain.tms.repository;

import com.ril.newcommerce.supplychain.tms.entity.ExternalUserCreationFailure;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ExternalUserCreationFailureRepository extends JpaRepository<ExternalUserCreationFailure, String> {
}
