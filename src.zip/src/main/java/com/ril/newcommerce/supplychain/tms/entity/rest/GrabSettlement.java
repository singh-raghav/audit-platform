package com.ril.newcommerce.supplychain.tms.entity.rest;

/**
B1.Divya
*/

public class GrabSettlement {
	
	private String success;
	private String errorCode;
	private String errorDescription;
	private String dttm;
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public String getDttm() {
		return dttm;
	}
	public void setDttm(String dttm) {
		this.dttm = dttm;
	}
	@Override
	public String toString() {
		return "GrabSettlement [success=" + success + ", errorCode=" + errorCode + ", errorDescription="
				+ errorDescription + ", dttm=" + dttm + "]";
	}
	
	
	

}
