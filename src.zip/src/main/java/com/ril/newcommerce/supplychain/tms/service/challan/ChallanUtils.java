package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ril.newcommerce.supplychain.tms.entity.ArticleInfo;
import com.ril.newcommerce.supplychain.tms.entity.AssetMasterData;
import com.ril.newcommerce.supplychain.tms.entity.DeliveryChallan;
import com.ril.newcommerce.supplychain.tms.entity.ItemCondition;
import com.ril.newcommerce.supplychain.tms.entity.Party;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.enums.ReturnItemQuality;
import com.ril.newcommerce.supplychain.tms.util.DeliveryChallanConfig;
import com.ril.newcommerce.supplychain.tms.util.SingleElementCollector;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class ChallanUtils {
	
	
	private static final Logger log = LoggerFactory.getLogger(ChallanUtils.class);

	/**
	 * 	
	 * @param returnItems
	 * @return
	 */
	public static Map<String, Map<ReturnItemQuality,Double>> convertItemQuantites(List<ReturnItem> returnItems) {
		Map<String , Map<ReturnItemQuality,Double>> itemQuantities = new HashMap<>(); // <ItemId ,  <GOOD , quantity> > 
		
		returnItems.forEach(item -> {
			Map<ReturnItemQuality,Double> map = new HashMap<>();
			for(ItemCondition condition : item.getItemsCondition()) {
				map.put(condition.getQuality(), condition.getQuantity());
			}
			itemQuantities.put(item.getItemId(), map);
		});
		
		return itemQuantities;
		
	}
	
	/** 
	 * This will have only 
	 * @param returnItemsfromDB
	 * @param itemQuantities
	 * @param quality
	 */
	private static void apportioningUtil(List<ReturnItem> returnItemsfromDB , Map<String, Map<ReturnItemQuality,Double>> itemQuantities,int quality) {
		
		ReturnItemQuality currentQuality =  ReturnItemQuality.getQualityByOrder(quality);
		
		if(currentQuality==null || CollectionUtils.isEmpty(returnItemsfromDB))
			return;
		
		String currItemId = returnItemsfromDB.get(0).getItemId();
		
		Map<ReturnItemQuality,Double> currQualities = itemQuantities.get(currItemId);
		double curInputQuantity = currQualities.get(currentQuality);
		
		for(ReturnItem item : returnItemsfromDB) {
	
			double quantity = item.getInvoicedQuanity()==null?0:item.getInvoicedQuanity();

			if(quantity<=0)
				continue;
		 
			if(quantity<=curInputQuantity) {
				
				item.addItemCondition(new ItemCondition(currentQuality,quantity));
				item.setInvoicedQuanity(0.0);
				
				curInputQuantity -= quantity;
			}
			else if(curInputQuantity>0){ //currInputQuanitty < quantity

				item.addItemCondition(new ItemCondition(currentQuality,curInputQuantity));
				item.setInvoicedQuanity(quantity-curInputQuantity);
				curInputQuantity=0;
			}
			
			if(curInputQuantity<=0)
				break;
		}
		
		apportioningUtil(returnItemsfromDB, itemQuantities, quality+1);
		
	}
	
	public static List<ReturnItem> applyApportioningOnReturnItems(List<ReturnItem> returnItemsfromDB , List<ReturnItem> inputReturnItems) {
		
		List<ReturnItem> apportionedItems = new ArrayList<>();
		
		if(!CollectionUtils.isEmpty(returnItemsfromDB) && !CollectionUtils.isEmpty(inputReturnItems)) {
			
			Map<String, Map<ReturnItemQuality,Double>> inputItemQuantitiesMap =  convertItemQuantites(inputReturnItems);
		
			log.info("ItemQuality : {} " , inputItemQuantitiesMap);
			
			//Sort return items based on ItemId. 
			Collections.sort(returnItemsfromDB, (a,b)-> a.getItemId().compareTo(b.getItemId()));
					
			int end=0;
		
			while(end<returnItemsfromDB.size()) {
				
				String itemId = returnItemsfromDB.get(end).getItemId();
				String curItemId = returnItemsfromDB.get(end).getItemId();
				List<ReturnItem> subList = new ArrayList<>();
				
				while(curItemId.equals(itemId) && end < returnItemsfromDB.size()) {
					subList.add(returnItemsfromDB.get(end));
					end++;
					itemId = curItemId;
					if(end<returnItemsfromDB.size())
						curItemId = returnItemsfromDB.get(end).getItemId();
				}
				
				//Now i collected all the orders for specific item... Now apportion it
				apportioningUtil(subList, inputItemQuantitiesMap, 1);
				
				apportionedItems.addAll(subList); // Has apportioned qty.
				
			}
		}
		
		return apportionedItems;
	}
	
	
	public static Map<String,List<ChallanArticle>> getReturnItemsArticles(String tripId , String userId , List<ReturnItem> apportionedReturnItems) {

		Map<String,List<ChallanArticle>> orderChallanArticlesMap = new HashMap<>();
		
		for(ReturnItem item : apportionedReturnItems) {
		
			String returnOrderId = item.getReturnOrderId();
			
			log.info("item conditions : {} - {} " ,  returnOrderId ,  item.getItemsCondition());
			
			for(ItemCondition condition : item.getItemsCondition()) {
				ChallanArticle article = new ChallanArticle(null, tripId,
						item.getReturnOrderId(), item.getItemId() , ArticleType.RETURN_ITEM.name() , condition.getQuantity() , condition.getQuality() ,userId);
				
				orderChallanArticlesMap.putIfAbsent(returnOrderId, new ArrayList<>());
			    orderChallanArticlesMap.get(returnOrderId).add(article);
			}
		}
		log.info("orderChallanArticlesMap : {} " ,orderChallanArticlesMap);
		return orderChallanArticlesMap;
	}
	
	
	public static Map<String,List<ChallanArticle>> getChallanArticles(List<ReturnItem> inputReturnItems , List<ReturnItem> returnItemsfromDB,
			List<AssetMasterData> assets , String tripId , String userId){
		
		Map<String,List<ChallanArticle>> orderChallanArticlesMap = new HashMap<>(); //This has orderId , deliveryChallan Article.
		if(CollectionUtils.isNotEmpty(returnItemsfromDB) && CollectionUtils.isNotEmpty(inputReturnItems)) {
			List<ReturnItem> apportionedItems =  applyApportioningOnReturnItems(returnItemsfromDB, inputReturnItems);
			log.info("Apportioned Items : {} " , apportionedItems);
			orderChallanArticlesMap.putAll(getReturnItemsArticles(tripId, userId, apportionedItems));
		}
		
		if(CollectionUtils.isNotEmpty(assets))
			orderChallanArticlesMap.putAll(getAssetArticles(assets , tripId, userId));
		
		return orderChallanArticlesMap;
	}
 
	public static Map<String,List<ChallanArticle>>  getAssetArticles(List<AssetMasterData> assets ,String tripId , String userId) {
		Map<String,List<ChallanArticle>> orderChallanArticlesMap = new HashMap<>();
		for(AssetMasterData asset :  assets) {  
			if(asset.getQuantity()<=0) 
				continue;
			
			ChallanArticle article = new ChallanArticle(null, tripId,UUID.randomUUID().toString(), asset.getAssetName() , ArticleType.ASSET.name()
																														,asset.getQuantity() , ReturnItemQuality.GOOD ,userId);
						
			orderChallanArticlesMap.putIfAbsent(ArticleType.ASSET.name(), new ArrayList<>());
			orderChallanArticlesMap.get(ArticleType.ASSET.name()).add(article);
			
		}
		return orderChallanArticlesMap;
	}

	public static void populateChallanArticleDetails(List<AssetMasterData> assetMasterDatas, DeliveryChallanConfig dcConfig, DeliveryChallan challan, Party consignee, Party consignor, List<ChallanArticle> articles, String hubId) {
		challan.setPlaceOfBusiness(consignor.getAddress());
		challan.setConsignee(consignee); //FC
		challan.setConsignor(consignor); //Whoever is sending back.
		challan.setRegdOffice(dcConfig.getRegOffice());
		challan.setPhone(dcConfig.getPhone());
		challan.setCIN(dcConfig.getCin());
		challan.setPAN(dcConfig.getPan());
		challan.setWebsite(dcConfig.getWebsite());
		challan.setOrderWiseInfo(getOrderWiseInfo(articles,assetMasterDatas));
		challan.setModeOfTransport(dcConfig.getModeOfTransport());
		challan.setHubId(hubId);
	}

	private static Map<String,ArticleInfo> getOrderWiseInfo(List<ChallanArticle> challanArticles,List<AssetMasterData> assetMasterDatas){
		
		Map<String,ArticleInfo> orderwiseArticleDetails = new HashMap<>();
		
		challanArticles.forEach(article -> {
			
			String orderId = article.getReturnOrderId();
			if(ArticleType.ASSET.name().equals(article.getArticleType())) { 
				orderId = ArticleType.ASSET.name();
				String assetName = article.getArticleCode();
				AssetMasterData masterData = assetMasterDatas.stream()
																.filter(asset -> asset.getAssetName().equals(assetName))
																.collect(SingleElementCollector.toSingleElement());
				article.setHsnCode(masterData.getHsnCode());
				article.setRate(masterData.getPrice());
				article.setBaseValue(article.getQuantity() * article.getRate());
				article.setArticleCode(masterData.getAssetId());
				article.setArticleDesc(masterData.getAssetName());
				article.setUOM(masterData.getUom());
				article.setReturnOrderId(orderId);
			}
			
			orderwiseArticleDetails.putIfAbsent(orderId , new ArticleInfo());
			orderwiseArticleDetails.get(orderId).getArticles().add(article);
			
		});
		
		return orderwiseArticleDetails;
	}
}
