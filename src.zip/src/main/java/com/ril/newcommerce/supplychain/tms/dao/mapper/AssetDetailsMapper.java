package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;

/**
 * @author Jeevi.Natarajan
 *
 */
public class AssetDetailsMapper implements ResultSetExtractor<Map<String , List<ChallanArticle>>> {

	@Override
	public Map<String , List<ChallanArticle>> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String , List<ChallanArticle>>  challanVsArticles = new HashMap<>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		
		while (rs.next()) {
			
			ChallanArticle article = new ChallanArticle();
			article.setChallanId(rs.getString("CHALLAN_ID"));
			article.setTripId(rs.getString("TRIP_ID"));
			article.setReturnOrderId(rs.getString("RETURN_ORDER_ID"));
			article.setArticleCode(rs.getString("ARTICLE_ID"));
			article.setArticleType(ArticleType.ASSET.name());
			Double quantity = rs.getDouble("QTY");
			article.setQuantity((quantity==null)?0:quantity);
			
			challanVsArticles.putIfAbsent(article.getChallanId(), new ArrayList<>());
			challanVsArticles.get(article.getChallanId()).add(article);
		
		}
		
		return challanVsArticles;
		
	}

}
