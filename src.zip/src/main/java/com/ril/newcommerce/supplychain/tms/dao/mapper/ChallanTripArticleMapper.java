package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;

public class ChallanTripArticleMapper implements RowMapper<ChallanArticle> {
	
	@Override
	public ChallanArticle mapRow(ResultSet rs, int arg1) throws SQLException {
	
		ChallanArticle article = new ChallanArticle();
		article.setChallanId(rs.getString("CHALLAN_ID"));
		article.setTripId(rs.getString("TRIP_ID"));
		article.setReturnOrderId(rs.getString("RETURN_ORDER_ID"));
		article.setArticleCode(rs.getString("ARTICLE_ID"));
		article.setQuantity(rs.getDouble("QTY"));
		
		return article;	
	}
	
}