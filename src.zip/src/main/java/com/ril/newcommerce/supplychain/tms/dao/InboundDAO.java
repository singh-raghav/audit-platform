package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ril.newcommerce.supplychain.tms.entity.BusinessDetail;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public interface InboundDAO {

	public String getDeliveryChallanSeq() ;
	
	public String getPickupChallanSeq();
	
	public List<BusinessDetail> getBusinessDetails(List<String> stateCodes);

	public Map<String, BusinessDetail> getBusinessDetailsBystateCode(List<String> stateCodes);
	
	public BusinessDetail getBusinessDetails(String stateCode);
	
	public List<ChallanArticle> insertDeliverychallanArticles(List<ChallanArticle> challanArticles,String nodeId);
	
	public void updateDeliverychallanArticles(List<ChallanArticle> challanArticles);
	
	public List<ReturnItem> getReturnItems(List<String> returnOrderIds);
	
	public Map<String,ReturnItem> getReturnItemById(List<String> returnOrderIds);
	
	public void updateChallanIdConstrained(String returnOrderId , String challanId);
	
	public void updateChallanId(String returnOrderId , String challanId);
	
	public void deleteChallanArticle(List<String> returnOrderIds);
	
	public Set<String> getAvailableOrders(String nodeId,String orderSrcNodeId);
	
	public List<String> getAvailableOrdersByOrderId(List<String> returnOrderIds);
	
	public List<ReturnItem> getReturnItemAccumulated(List<String> returnOrderIds);
	
	public Map<String,Integer> getReturnOrderCount(List<String> tripIds);
	
	public List<ChallanArticle> getReturnItemsAgainstTrip(String tripId,List<String> qualities);
	
	public void insertIntoDeliveryChalanArticles(List<ReconcileArticle> reconcileArticleList, String tripId);

	public void updateChallanIdByOrderIds(List<String> returnOrderIds, String challanId);
	
	public List<String> getChallanIds(String tripId,String nodeId);
	
	public Map<String,String> getPDRIdAndSourceNode(String tripId);

	public Map<String,Map<String , Set<String>>> getChallanIds(List<String> tripIds);
	
	public void addReturnItems(List<ReturnItem> returnItems,String flowName);
	
	public Map<String,String> getSourceNode(List<String> orderIds);
	
	public String getChallanId(String returnOrderId);
	
	public void updateChallantripId(List<String> orderIds , String tripId);
	
	public List<ChallanArticle> getChallanArticlesAgainstTrip(String tripId, String hubId);
	
	public List<ReturnItem> getItemAccumulatedByOrderId(List<String> returnOrderIds);
		
	public Map<String, List<ChallanArticle>> getArticlesByReturnOrderId(List<String> challanIds,String tripId);
	
	public List<ChallanArticle> getChallanArticles(String challanId);
	
	public Map<String,List<ReturnItem>> getReturnItemsByReturnOrderId(List<String> returnOrderIds,List<String> challanIds);

	public List<ChallanArticle> getChallanArticlesByReturnOrderId(List<String> orderIds);

	

}
