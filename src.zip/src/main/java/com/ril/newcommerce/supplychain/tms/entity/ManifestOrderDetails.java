package com.ril.newcommerce.supplychain.tms.entity;

public class ManifestOrderDetails {
	
	private int seqNo;
	private String orderId;
	private String shipmentNo;
	private String orderType;
	private String customerName;
	private String customerAddress;
	private String customerPincode;
	private String invoiceNo;
	private Double invoiceValue;
	private Double amountToBeCollected;
	private String ewbNo;
	private String ewbStatus;
	private String phoneNumber;
	private String mop;

	public int getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getShipmentNo() {
		return shipmentNo;
	}
	public void setShipmentNo(String shipmentNo) {
		this.shipmentNo = shipmentNo;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerPincode() {
		return customerPincode;
	}
	public void setCustomerPincode(String customerPincode) {
		this.customerPincode = customerPincode;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public Double getInvoiceValue() {
		return invoiceValue;
	}
	public void setInvoiceValue(Double invoiceValue) {
		this.invoiceValue = invoiceValue;
	}
	public Double getAmountToBeCollected() {
		return amountToBeCollected;
	}
	public void setAmountToBeCollected(Double amountToBeCollected) {
		this.amountToBeCollected = amountToBeCollected;
	}
	public String getEwbNo() {
		return ewbNo;
	}
	public void setEwbNo(String ewbNo) {
		this.ewbNo = ewbNo;
	}
	public String getEwbStatus() {
		return ewbStatus;
	}
	public void setEwbStatus(String ewbStatus) {
		this.ewbStatus = ewbStatus;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getMop() {
		return mop;
	}

	public void setMop(String mop) {
		this.mop = mop;
	}
}
