package com.ril.newcommerce.supplychain.tms.configurations;

public class UnAuthorizedErrorObject {
    private String reason = "authToken expired/Invalid authToken";

    public String toString() {
        return "UnAuthorizedErrorObject(reason=" + getReason() + ")";
    }

    public String getReason() {
        return this.reason;
    }
}
