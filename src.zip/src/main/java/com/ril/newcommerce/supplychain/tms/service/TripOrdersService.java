package com.ril.newcommerce.supplychain.tms.service;

import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;

import java.util.List;



public interface TripOrdersService {
	
	public void insertToTripConsignment(Trip trip);
	
	public int updateShipmentStatus( String status, List<String> shipmentnos, String tripId,String modifiedBy,String flowName,String nodeId,String statusClause) throws Exception;
	
	public List<TripConsignmentInfo> getTripConsignmentInfo(List<String> tripIds, List<String> nodeIds,List<String> status,String externalRefId,List<String> shipmentNos,List<String> orderIds);

	public void deleteTripConsignment(List<String> shipmentNos, String nodeId, String value);
	
	public void updateShipmentStatus(String status, List<String> orderIds, String modifiedBy,String flowName);
	
	public List<TripConsignmentInfo> getTripConsignmentInfo(String tripId, List<String> status);
	
	public int updateShipments(List<String> shipmentnos, String tripId,String nodeId) throws Exception;
	
	public void mergeTripConsignment(List<Consignment> consignments, String tripId,String createdBy, String flowName, String nodeId, boolean flag);

	boolean isShipmentSuspended(String shipment, String orderId);
}
