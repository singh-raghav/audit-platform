package com.ril.newcommerce.supplychain.tms.processors.order.statusupdate;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.service.OrderInvoiceService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Qualifier(Constants.ORDER_PROCESSOR.INVOICED_PRE_PROCESSOR)
@Service
public class OrderStatusInvoicedPreProcessor implements OrderStatusUpdatePreProcessor {

    @Autowired
    private OrderInvoiceService orderInvoiceService;

    @Override
    public boolean validateUpdate(OrderStatusFeed.Order order) {
        if (!isOrderInvoiced(order)) {
            throw new TripApplicationException("Order status update to INVOICED failed as order not yet invoiced. Order Id : " + order.getOrderId() + "Shipment No : " + order.getShipmentNo());
        }
        return false;
    }

    private boolean isOrderInvoiced(OrderStatusFeed.Order order) {
        return orderInvoiceService.isOrderInvoiced(order.getOrderId());
    }
}
