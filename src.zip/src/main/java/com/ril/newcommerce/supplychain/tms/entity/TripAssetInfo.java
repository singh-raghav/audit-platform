/**
 * @author satya1.prakash
 *
 */
package com.ril.newcommerce.supplychain.tms.entity;

import java.util.List;

public class TripAssetInfo {
	
	private List<AssetsToBeReturned> assetsToBeReturned;

	public List<AssetsToBeReturned> getAssetsToBeReturned() {
		return assetsToBeReturned;
	}

	public void setAssetsToBeReturned(List<AssetsToBeReturned> assetsToBeReturned) {
		this.assetsToBeReturned = assetsToBeReturned;
	}

	@Override
	public String toString() {
		return "TripAssetInfo [assetsToBeReturned=" + assetsToBeReturned + ", getAssetsToBeReturned()="
				+ getAssetsToBeReturned() + "]";
	}	
}
