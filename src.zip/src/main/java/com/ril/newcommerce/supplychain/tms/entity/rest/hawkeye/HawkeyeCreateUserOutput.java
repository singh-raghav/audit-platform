package com.ril.newcommerce.supplychain.tms.entity.rest.hawkeye;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HawkeyeCreateUserOutput implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;

    String success;
    String statusCode;
    String errorMessage;
    private Result result;
}
