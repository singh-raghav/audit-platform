package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripReconcileDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripSequenceDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.*;
import com.ril.newcommerce.supplychain.tms.entity.rest.NodeRRLMappings;
import com.ril.newcommerce.supplychain.tms.entity.rest.RRLMappingResponse;
import com.ril.newcommerce.supplychain.tms.enums.*;
import com.ril.newcommerce.supplychain.tms.event.processor.TripEventProcessor;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.response.TripAmount;
import com.ril.newcommerce.supplychain.tms.response.TripAmountResponse;
import com.ril.newcommerce.supplychain.tms.response.TripCountResponse;
import com.ril.newcommerce.supplychain.tms.response.TripLazyLoadResponse;
import com.ril.newcommerce.supplychain.tms.service.*;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.tibco.entity.VehicleState;
import com.ril.newcommerce.supplychain.tms.util.*;
import com.ril.vms.deadpool.securitycore.JwtTokenProvider;
import com.ril.vms.deadpool.util.AppUser;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;


/**
 * B1.Divya
 */

@Service
@EnableAsync
public class TripServiceImpl implements TripService {

	private static final Logger log = LoggerFactory.getLogger(TripServiceImpl.class);

	@Autowired
	TripsDAO tripsDAO;

	@Autowired
	OrderInvoiceService orderInvoiceService;

	@Autowired
	TripOrdersService tripOrderService;

	@Autowired
	private TripReconcileDAO tripReconcileDao;

	@Autowired
	private InboundDAO inBoundDAO;
	
	@Lazy
	@Autowired
	@Qualifier(Constants.TRIP_EVENT_PROCESSOR)
	private TripEventProcessor eventProcessor;
	
	@Autowired
	private RestClient restClient;

	@Value("${ewayBillDataProcessor.url}")
	private String ewatBillUrl;

	@Value("${ewayBillDataProcessor.userName}")
	private String ewayBillUserName;

	@Value("${ewayBillDataProcessor.password}")
	private String ewayBillPassowrd;

	@Value("${thread.future.timeout}")
	private int timeOut;
	
	@Value("${trip.create.max.count}")
	private int maxcount;
	
	@Autowired
	private TripExecutor executor;
	
	@Autowired
    private JMSPublisher jmsPublisher;
	
	 @Value("${trip.assignment.vms.queue}")
	 private String vmsTopicName;
	 
	 @Value("${tripapp.queue}")
	private String queueName;

	@Autowired
	private ConsignmentLabelService consignmentLabelService;
	
	@Autowired
	private TripSequenceDAO tripSequenceDAO;

	@Value("${vms.host}")
	private String vmsHost;

	@Value("${vms.nodeRRLMappingUrl}")
	private String nodeRRLMappingUrl;

	@Autowired
	private DayLevelAckGenerationService dayLevelAckGenerationService;

	@Autowired
	private JwtTokenProvider jwtTokenProvider;


	@Override
	public Trip getTrip(String tripId) {
		return tripsDAO.getTripById(tripId);
	}
	
	@Override
	public String getVendorId(String tripId) {
		
		String vendorId = "";
		
		try {
		List<TripAdditionalDetail> additionalDetails = tripsDAO.getTripAdditionalDetails(Arrays.asList(tripId), Constants.VENDOR_ID);
		
		if(CollectionUtils.isNotEmpty(additionalDetails)) {
			vendorId = additionalDetails.get(0).getValue();
		}
		
		} catch (Exception e) {
			log.error("Exception occured while fetching vendorId  ", e);
			//Not throwing it back..
		}
		
		return vendorId;
	}

	@Override
	public String getVendorName(String tripId) {
		
		String vendorName = "";
		
		try {
		List<TripAdditionalDetail> additionalDetails = tripsDAO.getTripAdditionalDetails(Arrays.asList(tripId), Constants.VENDOR_NAME);
		
		if(CollectionUtils.isNotEmpty(additionalDetails)) 
			vendorName = additionalDetails.get(0).getValue();
		
		
		} catch (Exception e) {
			log.error("Exception occured while fetching vendorName  ", e);
			//Not throwing it back..
		}
		
		return vendorName;
	}
	
	@Override
	public com.ril.newcommerce.supplychain.tms.entity.Trips getTrips(List<String> nodeName,Map<String,Object> filters) throws InterruptedException, ExecutionException {

		long startTime = System.currentTimeMillis();
		log.info("Inside getTrips of TripServiceImpl for nodeNames :{}", nodeName);

		List<Trip> tripList = null;
		com.ril.newcommerce.supplychain.tms.entity.Trips trips = new com.ril.newcommerce.supplychain.tms.entity.Trips();
		TripCountOnStatus count = null;
		try {
			String toDate = DateUtility.getToDate(filters.get(Constants.TO_DATE) !=null ?filters.get(Constants.TO_DATE).toString():"");
			String fromDate = DateUtility.getFromDate(filters.get(Constants.FROM_DATE) !=null ?filters.get(Constants.FROM_DATE).toString():"");
			String tripId = filters.get(Constants.TRIPID)!=null?filters.get(Constants.TRIPID).toString():"";
			MovementType mvType= Utility.getTripMovementType(filters.get(Constants.MOVEMENT_TYPE) !=null?filters.get(Constants.MOVEMENT_TYPE).toString() :"");
			filters.put(Constants.MOVEMENT_TYPE, mvType);
			filters.put(Constants.TO_DATE, toDate);
			filters.put(Constants.FROM_DATE, fromDate);

			if (TripUtil.isInboundTrips(filters)) {

				filters.put(Constants.STATUS, getStatusFilter(mvType, (String) filters.get(Constants.STATUS)));
				tripList = tripsDAO.getInboundTrips(nodeName, filters);

			} else if (TripUtil.isOutBoundTrips(filters)) {

				String nodeType = (String) filters.get(Constants.NODE_TYPE);
				String status = (String) filters.get(Constants.STATUS);

				if (TripUtil.isAmountToBeCollectedRequiredInTripsView(status,nodeType)) {
					tripList = tripsDAO.getTripsInfoWithAmountToBeCollected(nodeName, filters);
				} else if (TripUtil.isAmountCollectedRequiredInTripsView(status,nodeType)) {
					tripList = tripsDAO.getTripsInfoWithAmountCollected(nodeName, filters);
				} else {
					tripList = tripsDAO.getTripsInfo(nodeName, filters);
				}
			}

			trips.setTrip(tripList);

			if (null != tripList && !tripList.isEmpty() && filters.get(Constants.STATISTICS) !=null && Constants.INCLUDE.equals(filters.get(Constants.STATISTICS).toString())) {
				log.info("Number of trips fetched : {}", tripList.size());
				// inbound pass node id of fctrips not the logged in user node id
				if (TripUtil. isInboundTrips(filters)) {
					Set<String> nodeIds = tripList.stream().map(mapper -> mapper.getSourceNode())
							.collect(Collectors.toSet());
					List<String> nodeList = new ArrayList<>(nodeIds);
					setTripStatictisc(tripList, nodeList);
				} else
					setTripStatictisc(tripList, nodeName);
				trips.setTrip(tripList);
			}
			if (filters.get(Constants.STATISTICS) !=null && Constants.INCLUDE.equals(filters.get(Constants.STATISTICS).toString())) {
				count = getTripCountofAllstatus(nodeName, toDate, fromDate, tripId, mvType,filters);
				trips.setTripCountOnStatus(count);
			}
		} catch (Exception e) {
			log.error("Exception occured while providing trips deatils in getTrips of TripServiceImpl ", e);
			throw new TripApplicationException("Exception occured in getTrips of TripServiceImpl ", e);
		}
		log.info("getTrips in service layer -- [{}]ms", (System.currentTimeMillis() - startTime));
		return trips;
	}

	@Override
	public void setTripStatictisc(List<Trip> tripList,List<String> nodeIds) throws InterruptedException, ExecutionException, TimeoutException
	{
		long startTime = System.currentTimeMillis();
		log.info("Number of trips fetched : {}", tripList.size());
		Collection<Future<?>> futures = new LinkedList<Future<?>>();
		List<String> tripIdList = tripList.stream().map(mapper -> mapper.getTripId())
				.collect(Collectors.toList());
		List<String> referenceIds =tripList.stream().map(mapper -> mapper.getExternalReferenceId())
				.collect(Collectors.toList());
		Future<Map<String, TripConsignmentCount>> tripConsignmentCount = null;
		Future<List<TripAdditionalDetail>> tripAdditionalDetails = null;
		Future<Map<String,String>> driverNumber = null;
		Future<Map<String, List<Hub>>> tripHubDetails = null;
		Future<Map<String, List<String>>> childTripCount = null;
		Future<List<TripConsignmentInfo>> tripConsignmentInfo=null;
		Future<Map<String,Map<String , Set<String>>>> challanDetails=null;
		Future<Map<String,Integer>> returnOrdersCount = null;
		
		if (!tripIdList.isEmpty()) {
			tripConsignmentCount = executor.getTripExecutor().submit(() -> consignmentLabelService.getConsignmentDetailsByTrip(tripIdList, nodeIds));
			tripAdditionalDetails = executor.getTripExecutor().submit(() -> tripsDAO.getTripAdditionalDetails(tripIdList, null));
			driverNumber  = executor.getTripExecutor().submit(() -> tripsDAO.getDriverNumber(tripIdList));
			tripHubDetails = executor.getTripExecutor().submit(() -> tripSequenceDAO.getTripSequence(tripIdList,null));
			childTripCount = executor.getTripExecutor().submit(() -> tripsDAO.getChildTripIds(referenceIds));

			List<String> status=new ArrayList<>();
			status.add(OrderStatus.ACTIVE.getValue());
			status.add(OrderStatus.RESCHEDULED.getValue());

			tripConsignmentInfo = executor.getTripExecutor().submit(() -> tripOrderService.getTripConsignmentInfo(tripIdList,nodeIds,status,null,null,null));
			challanDetails=executor.getTripExecutor().submit(() -> inBoundDAO.getChallanIds(tripIdList));
			returnOrdersCount = executor.getTripExecutor().submit(() -> inBoundDAO.getReturnOrderCount(tripIdList));
			
			futures.add(tripConsignmentCount);
			futures.add(tripAdditionalDetails);
			futures.add(tripHubDetails);
			futures.add(childTripCount);
			futures.add(driverNumber);
			futures.add(tripConsignmentInfo);
			futures.add(challanDetails);
			futures.add(returnOrdersCount);
			for (Future<?> future : futures) {
				future.get(timeOut,TimeUnit.SECONDS);
			}
		}
		log.debug("Executers executed for getting trips details");

		Map<String, List<Seal>> tripSeals=null;
		Map<String, String> tripEwayStatus=null;
		Map<String, String> intialAmount=null;
		Map<String, String> vendorIds=null;
		Map<String, String> vendorNames=null;
		Map<String, String> driverNumbers=null;
		Map<String,List<TripConsignmentInfo>> tripConsignment=null;
		Map<String,Map<String , Set<String>>> tripDeliveryChallanDetails=null;
		Map<String,Integer> returnOrderCountMap = null;

		if(null!=tripAdditionalDetails && !CollectionUtils.isEmpty(tripAdditionalDetails.get()))
		{
			tripSeals=getTripSealDetails(tripAdditionalDetails.get());

			tripEwayStatus = tripAdditionalDetails.get().stream().filter(f->f.getKey().equals(Constants.EWAYBILL))
					.collect(Collectors.toMap(TripAdditionalDetail::getTripId, TripAdditionalDetail::getValue));

			intialAmount = tripAdditionalDetails.get().stream().filter(f->f.getKey().equals(Constants.INTITIAL_AMOUNT))
					.collect(Collectors.toMap(TripAdditionalDetail::getTripId, TripAdditionalDetail::getValue));
		
			vendorIds = tripAdditionalDetails.get().stream().filter(e -> e.getValue()!=null && e.getValue().equals(Constants.VENDOR_ID))
					.collect(Collectors.toMap(TripAdditionalDetail::getTripId, TripAdditionalDetail::getValue));

			vendorNames = tripAdditionalDetails.get().stream().filter(e -> e.getValue()!=null && e.getValue().equals(Constants.VENDOR_NAME))
					.collect(Collectors.toMap(TripAdditionalDetail::getTripId, TripAdditionalDetail::getValue));
		}
		
		if(!MapUtils.isEmpty(driverNumber.get())){
			driverNumbers =driverNumber.get();
		}
		if(null!=tripConsignmentInfo && !CollectionUtils.isEmpty(tripConsignmentInfo.get()))
		{
			tripConsignment=getTripConsignmentInfo(tripConsignmentInfo.get());
		}
		if(null !=challanDetails && !MapUtils.isEmpty(challanDetails.get()))
		{
			tripDeliveryChallanDetails=challanDetails.get();
		}
		if(returnOrdersCount!=null) {
			returnOrderCountMap =  returnOrdersCount.get();
		}
		
		for (Trip trip : tripList) {
			Collection<Future<?>> futuresList = new LinkedList<Future<?>>();

			Future<Integer> loadedOrderCountFuture =
					executor.getTripExecutor().submit(() -> tripsDAO.getLoadedOrderCount(trip.getTripId()));
			futuresList.add(loadedOrderCountFuture);

			Future<Integer> loadedHUCountFuture =
					executor.getTripExecutor().submit(() -> tripsDAO.getLoadedHUCount(trip.getTripId()));
			futuresList.add(loadedHUCountFuture);

			for (Future<?> future : futuresList) {
				future.get(timeOut, TimeUnit.SECONDS);
			}

			if (tripConsignmentCount != null && tripConsignmentCount.get().get(trip.getTripId()) != null)
				trip.setTripConsignmentCount(tripConsignmentCount.get().get(trip.getTripId()));

			if (!MapUtils.isEmpty(tripSeals))
				trip.setSeal(tripSeals.get(trip.getTripId()));

			if (tripHubDetails != null && tripHubDetails.get().get(trip.getTripId()) != null)
			{
				trip.setHub(tripHubDetails.get().get(trip.getTripId()));
			}

			if (!MapUtils.isEmpty(tripEwayStatus))
			{
				trip.setEwayBillStatus(tripEwayStatus.get(trip.getTripId()));
			}
			if(!MapUtils.isEmpty(intialAmount) && null!=intialAmount.get(trip.getTripId()))
			{
					trip.setInitialCash(Double.valueOf(intialAmount.get(trip.getTripId())));
			}
			
			if(!MapUtils.isEmpty(vendorIds) && null!=vendorIds.get(trip.getTripId())){
					trip.setVendorId(vendorIds.get(trip.getTripId()));
			}
			
			if(!MapUtils.isEmpty(vendorNames) && null!=vendorNames.get(trip.getTripId())){
				trip.setVendorName(vendorNames.get(trip.getTripId()));
			}
			if(!MapUtils.isEmpty(driverNumbers) && trip.getAssignedDpId()!=null && null!=driverNumbers.get(trip.getAssignedDpId())) {
				trip.setDriverMobileNumber(driverNumbers.get(trip.getAssignedDpId()));
			}
		
			if(!MapUtils.isEmpty(tripDeliveryChallanDetails) && null != tripDeliveryChallanDetails.get(trip.getTripId()))
			{
				trip.setChallanIdsPerHub(tripDeliveryChallanDetails.get(trip.getTripId()));
			}
			trip.setHasReturnOrders(false);
			if(MapUtils.isNotEmpty(returnOrderCountMap)) {
				int count  = (returnOrderCountMap.get(trip.getTripId())==null)?0:returnOrderCountMap.get(trip.getTripId());
				trip.setHasReturnOrders(count>0);
			}

			if(!MapUtils.isEmpty(tripConsignment) && !CollectionUtils.isEmpty(tripConsignment.get(trip.getTripId())))
			{
				TripConsignmentCount count = trip.getTripConsignmentCount();
				if (null == count)
					count = new TripConsignmentCount();

				count.setPlannedOrderCount(tripConsignment.get(trip.getTripId()).size());
				List<String> invoiceNumbers = tripConsignment.get(trip.getTripId()).stream().filter(mapper->null!=mapper.getInvoice().getInvoiceNo())
						.map(mapper -> mapper.getInvoice().getInvoiceNo()).collect(Collectors.toList());
				count.setInvoicedOrderCount(invoiceNumbers.size());
				trip.setTripConsignmentCount(count);
			}

			if (childTripCount != null && childTripCount.get().get(trip.getTripId()) != null) {
				trip.setAssociatedTrips(childTripCount.get().get(trip.getTripId()));
				String href="/trip-mgmt/v1/trips/";
				List<String> associatedTripIds=childTripCount.get().get(trip.getTripId());
				Map<String, String> queryParam=new HashMap<>();
				queryParam.put(Constants.INCLUDERECON, Constants.FALSE);
				Set<LinkDetails> links=Utility.getLinks(associatedTripIds,queryParam, href, HttpMethod.GET,Constants.TRIP, MediaType.APPLICATION_JSON);
				trip.setLinks(links);
			}
			
			//call asset for totes and bags count
			if(trip.getStatus().equals(TripState.SETTLEMENT_PENDING) || trip.getStatus().equals(TripState.SETTLED))
			{
				ATSResponse returnAssetResponse = tripReconcileDao.getAssetForReconcile(trip.getTripId());
				setPendingAssetCount(returnAssetResponse, trip);
			}

			trip.setTotalLoadedOrderCount(loadedOrderCountFuture.get());
			trip.setTotalLoadedHuCount(loadedHUCountFuture.get());
		}

		log.info("setTripStatictisc time  -- [{}]ms", (System.currentTimeMillis() - startTime));
	}
	private Map<String, List<TripConsignmentInfo>> getTripConsignmentInfo(List<TripConsignmentInfo> consignmentInfo)
	{
		Map<String, List<TripConsignmentInfo>> result =
				consignmentInfo.stream().collect(Collectors.groupingBy(TripConsignmentInfo::getTripId));
		return result;
	}

	private Map<String, List<Seal>> getTripSealDetails(List<TripAdditionalDetail> tripaddtionalDetails)
	{
		Map<String, List<Seal>> tripSeals = new HashMap<String, List<Seal>>();

		for (TripAdditionalDetail additionalDetails : tripaddtionalDetails)
		{
			if (additionalDetails.getKey().equals(Constants.SEAL)) {
				boolean present = false;
				List<Seal> sealList = null;
				List<String> sealIdsList = null;
				if (!tripSeals.containsKey(additionalDetails.getTripId())) {
					sealList = new ArrayList<>();
					Seal seal = new Seal();
					seal.setNodeId(additionalDetails.getNodeId());
					List<String> sealIds = new ArrayList<>();
					sealIds.add(additionalDetails.getValue());
					seal.setSeals(sealIds);
					sealList.add(seal);
					tripSeals.put(additionalDetails.getTripId(), sealList);
				} else {
					sealList = tripSeals.get(additionalDetails.getTripId());

					for (Seal s : sealList) {
						if (s.getNodeId().equals(additionalDetails.getNodeId())) {
							present = true;
							sealIdsList = s.getSeals();
							sealIdsList.add(additionalDetails.getValue());
						}

					}
					if (!present) {
						Seal seal = new Seal();
						seal.setNodeId(additionalDetails.getNodeId());
						List<String> sealIds = new ArrayList<>();
						sealIds.add(additionalDetails.getValue());
						seal.setSeals(sealIds);
						sealList.add(seal);

					}
				}

			}
		}
		return tripSeals;

	}
	private TripCountOnStatus getTripCountofAllstatus(List<String> nodeIds,String toDate, String fromDate,String tripId,MovementType mvType, Map<String, Object> filters )
	{
		TripCountOnStatus count=new TripCountOnStatus();;
		Map<String, Integer> tripCount=tripsDAO.getTripCountOnTripStatus(nodeIds, toDate,  fromDate ,tripId,mvType,filters);
		if (!MapUtils.isEmpty(tripCount)) {
			for (Map.Entry<String, Integer> entry : tripCount.entrySet()) {
				if (TripState.CREATED.getValue().equals(entry.getKey()))
					count.setCreatedTripsCount(entry.getValue());
				else if (TripState.ASSIGNED.getValue().equals(entry.getKey()))
					count.setAssignedTripsCount(entry.getValue());
				else if (TripState.LOADING_COMPLETED.getValue().equals(entry.getKey()))
					count.setLoadingCompletedTripsCount(entry.getValue());
				else if (TripState.LOADING_INPROGRESS.getValue().equals(entry.getKey()))
					count.setLoadingTripsCount(entry.getValue());
				else if (TripState.INTRANSIT.getValue().equals(entry.getKey()))
					count.setStartedTripsCount(entry.getValue());
				else if (TripState.SETTLEMENT_PENDING.getValue().equals(entry.getKey()))
					count.setToBeSettledTripsCount(entry.getValue());
				else if (TripState.SETTLED.getValue().equals(entry.getKey()))
					count.setSettledTripsCount(entry.getValue());
				else if (TripState.CANCELLED.getValue().equals(entry.getKey()))
					count.setCancelledTripsCount(entry.getValue());

			}
		}
		return count;
	}

	@Override
	public List<VehicleStatus> getVehicleStatus(List<String> vehicleIds) {

		List<VehicleStatus> vehicleStatus = new ArrayList<>();

		List<String> assignedVehicle = tripsDAO.getVehicleAssignmentStatus(vehicleIds);

		vehicleIds.forEach(vehicle -> vehicleStatus.add(new VehicleStatus(vehicle, assignedVehicle.contains(vehicle))));

		return vehicleStatus;

	}

	@Override
	public int getTripCountByGivenDate(String date, String nodeId,String movementType) {
		int count = 0;
		try {
			count = tripsDAO.getTripCountOnGivenDate(date, nodeId,movementType);
		} catch (Exception e) {
			log.error("Got Exception while getting trip count in getTripCountByGivenDate of TripServiceImpl", e);
			throw new TripApplicationException(
					"Got Exception while getting trip count in getTripCountByGivenDate of TripServiceImpl", e);
		}
		return count;
	}

	@Override
	public void createtrip(Trip trip,TripIdDetails tripIdDetails) {
		try {
			tripsDAO.insertToTrip(trip,tripIdDetails,maxcount);
			tripOrderService.insertToTripConsignment(trip);
			tripSequenceDAO.insertToTripSequence(trip);
		} catch (Exception e) {
			log.error("Got Exception while inserting trip details in trip table in createtrip of TripServiceImpl", e);
			throw new DataProcessingException(
					"Got Exception while inserting trip details in trip table in createtrip of TripServiceImpl", e);
		}

	}

	@Override
	public void insertTripOrderAndSequenceDetails(Trip trip) {
		try {
			tripOrderService.insertToTripConsignment(trip);
			tripSequenceDAO.insertToTripSequence(trip);
		} catch (Exception e) {
			log.error(
					"Got Exception while inserting trip details in trip consignment in insertTripOrderAndSequenceDetails of TripServiceImpl",
					e);
			throw new DataProcessingException(
					"Got Exception while inserting trip details in trip consignment in insertTripOrderAndSequenceDetails of TripServiceImpl",
					e);
		}
	}

	@Override
	public List<Trip> getTrips(HashMap<String, Object> filter) {
		List<Trip> trips = new ArrayList<>();
		try {
			trips = tripsDAO.getTrip(filter);
		} catch (Exception e) {
			log.error("Got Exception while getting trip details getTrips of TripServiceImpl", e);
			throw new TripApplicationException("Got Exception while getting trip details getTrips of TripServiceImpl",
					e);
		}

		return trips;
	}

	@Override
	public void insertToTripHierarchy(String tripId, Set<String> associatedTripIds,String system) {
		try {
			tripsDAO.insertToTripHierarchy(tripId, associatedTripIds,system);
		} catch (Exception e) {
			log.error("Exception occured while inserting trip hierarchy in insertToTripHierarchy of TripServiceImpl ",
					e);
			throw new DataProcessingException(
					"Exception occured while inserting trip hierarchy in insertToTripHierarchy of TripServiceImpl ", e);
		}

	}

	@Override
	public void insertToTripHierarchy(Set<String> associatedTripIds, String tripId,String system) {
		try {
			tripsDAO.insertToTripHierarchy(associatedTripIds, tripId,system);
		} catch (Exception e) {
			log.error("Exception occured while inserting trip hierarchy in insertToTripHierarchy of TripServiceImpl ",
					e);
			throw new DataProcessingException(
					"Exception occured while inserting trip hierarchy in insertToTripHierarchy of TripServiceImpl ", e);
		}

	}
	
	@Override
	public void deassociateTripHierarchy(Map<String,String> tripIds) {
		try {
			if (!MapUtils.isEmpty(tripIds)) {
				tripsDAO.deassociateTripHierarchy(tripIds);
			}
		} catch (Exception e) {
			throw new TripApplicationException(
					"Exception occured while inserting trip hierarchy in insertToTripHierarchy of TripServiceImpl ", e);
		}
	}
	
	@Override
	public void mergeOrdersInTrip(List<Consignment> consignments, Map<String, List<Hub>> tripSequence, String tripId,
			String createdBy, String flowName, String nodeId)
	{
		consignments.forEach(c -> c.setShipmentStatus(OrderStatus.ACTIVE.getValue()));
		consignments.forEach(c -> c.setCreatedBy(createdBy));
		consignments.forEach(c -> c.setFlowName(flowName));
		Set<String> nextDestinationIds = consignments.stream().map(mapper -> mapper.getNextNodeId())
				.collect(Collectors.toSet());
		Set<String> nodeIdsNotLinked = new HashSet<>(nextDestinationIds);
		List<Hub> newNodes = new ArrayList<>();
		List<Hub> hubs = new ArrayList<Hub>();
		int sequence=0;

		if(!MapUtils.isEmpty(tripSequence))
		{
			hubs = tripSequence.get(tripId);
			Set<String> nodeIdsLinked = hubs.stream().map(m -> m.getNodeId()).collect(Collectors.toSet());
			nodeIdsNotLinked.removeAll(nodeIdsLinked);
			
			Hub hubObj = Collections.max(hubs, Comparator.comparing(s -> s.getSequence()));
			 sequence = hubObj.getSequence();
		}

		Trip trip = new Trip();
		trip.setTripId(tripId);
		trip.setConsignment(consignments);
		if (!CollectionUtils.isEmpty(nodeIdsNotLinked)) {
			for (String id : nodeIdsNotLinked) {
				Hub obj = new Hub();
				obj.setNodeId(id);
				obj.setSequence(sequence + 1);
				obj.setPlannedArrivalTime(new Timestamp(System.currentTimeMillis()));
				obj.setPlannedDispatchTime(new Timestamp(System.currentTimeMillis()));
				newNodes.add(obj);
				sequence++;
			}

		}
		trip.setHub(newNodes);
		List<String> shipmentNos=consignments.stream().map(mapper->mapper.getShipmentNo()).collect(Collectors.toList());
		tripOrderService.deleteTripConsignment(shipmentNos, nodeId, OrderStatus.INACTIVE.getValue());
		tripOrderService.insertToTripConsignment(trip);
		tripSequenceDAO.insertToTripSequence(trip);

	}

	@Override
	public List<Trip> getTripDetails(String tripId, String includeRecon, String nodeId, List<ReconcileArticle> returnItems) throws Exception {
		String tripIds[] = tripId.split(",");
		List<String> tripIdList = Arrays.asList(tripIds);
		List<String> nodeIds=Arrays.asList(nodeId);
		List<Trip> trips =null;
		trips = tripsDAO.getTripDetails(tripIdList);
		try {
			setTripStatictisc(trips,nodeIds);
		} catch (Exception ex) {
			log.error("Error in getting trip data method getTripDetails {} ", ex);
			throw new TripApplicationException("unable to fectch trips");
		}
     return trips;
	}


	private void setPendingAssetCount(ATSResponse returnAssetResponse,Trip trip)
	{
		Integer totesToBeCollected = 0;
		Integer bagToBeCollected = 0;
		try {
			if ((null != returnAssetResponse.getData()) && !CollectionUtils.isEmpty(returnAssetResponse.getData().getAssetInfo().getAssetsToBeReturned())) {
				for (AssetsToBeReturned assetsToBeReturned : returnAssetResponse.getData().getAssetInfo().getAssetsToBeReturned()) {
					if (assetsToBeReturned.getAssetType().contains(Constants.TOTE))
						totesToBeCollected = totesToBeCollected + Integer.parseInt(assetsToBeReturned.getCount());
					else if (assetsToBeReturned.getAssetType().contains(Constants.BAG))
						bagToBeCollected = bagToBeCollected + Integer.parseInt(assetsToBeReturned.getCount());
				}
			}
			trip.setToteToBeCollected(totesToBeCollected);
			trip.setBagToBeCollected(bagToBeCollected);
		}
		catch (Exception e ){
			log.error("exception in set pending asset: {}", e);
		}
	}


	@Override
	public void updateTripAdditionalDetails(TripAdditionalDetail additionalDetails) {

		try {
			tripsDAO.updateTripAdditionalDetails(additionalDetails);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating trip additional details", e);
		}
	}

	@Override
	public void insertTripAdditionalDetails(TripAdditionalDetail additionalDetail)
	{
		List<TripAdditionalDetail> additionalDetails=new ArrayList<>();
		additionalDetails.add(additionalDetail);
		try {
			tripsDAO.insertTripAdditionalDetails(additionalDetails);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on inserting additional details", e);
		}

	}

	@Override
	@Async
	public void retryEwaybillGeneration(String tripId, String tripType) throws InterruptedException, JSONException {

		log.info("Sending request for retry ewaybill generation");
		String base64Creds = Utility.getBase64EncodedString(ewayBillUserName + ":" + ewayBillPassowrd);
		Map<String, String> headers=new HashMap<>();
		headers.put(Constants.AUTHORIZATION,"Basic " +base64Creds);

		JSONObject inputObject = new JSONObject();
		inputObject.put("tripId", tripId);
		inputObject.put("tripType", tripType);
		String requestBody = inputObject.toString();

		restClient.post(ewatBillUrl, headers , null, requestBody);

	}

	@Override
	public void updateTripVersion(String tripId,String flowName,String modifedBy) {
		try {
			tripsDAO.updateTripVersion(tripId,flowName,modifedBy);
		} catch (Exception e) {
			log.error("Exception occured on updating trip version" +
					"", e);
			throw new DataProcessingException(
					"Exception occured on updating trip version", e);
		}
	}

	@Override
	public List<Trip> getTripDetails(List<String> tripIds) {
		if(!CollectionUtils.isEmpty(tripIds))
		{
			try{
				return tripsDAO.getTripDetails(tripIds);
			}
			catch(Exception e)
			{
				throw new TripApplicationException(" Exception occured while retriening trip details ",e);
			}
		}
		return null;
		}
	

	public Map<String, List<String>> getNumberChildTrips(List<String> tripIds) {
		try {
			return tripsDAO.getNumberOfChildTrips(tripIds);
		} catch (Exception e) {
			log.error("Exception occured while getting child trips TripServiceImpl ",
					e);
			throw new DataProcessingException(
					"Exception occured while getting child trips TripServiceImpl  ", e);
		}
	}

	@Override
	public boolean isTripStared(String shipmentNo) {

		if (!StringUtils.isBlank(shipmentNo)) {
			return tripsDAO.getStartedTripCount(shipmentNo) > 0;
		}
		throw new TripApplicationException("shipmentNo required to fetch started trip count.");
	}

	@Override
	public List<TripLazyLoadResponse> getTripForOrder(String shipmentNo, String nodeId) {
		if (!StringUtils.isBlank(shipmentNo)) {
			return tripsDAO.getTripDetailsForGivenOrders(shipmentNo, nodeId);
		}
		return new ArrayList<>();
	}
	
	@Override
	public boolean istripCancelled(List<Consignment> actaulConsignments,Trip trip,String modifiedBy,TripEvent event)
	{
		if(CollectionUtils.isEmpty(actaulConsignments))
		{
			log.info("Trip is  empty {}",trip.getTripId());
			TripEventInput eventInput =new TripEventInput();
			eventInput.setTripId(trip.getTripId());
			eventInput.setAction(event);
			eventInput.setModifiedBy(modifiedBy);
			eventInput.setNodeId(trip.getSourceNode());
			eventInput.setFlowName(Constants.SPLIT);
			
			eventProcessor.processEvent(eventInput);
			
			return true;
			
		}
		return false;
	}
	
	@Override
	@Transactional(rollbackFor = Exception.class , propagation = Propagation.REQUIRES_NEW)
	public void moveTripToCancelledState(Trip trip, String modifiedby) {

		try {
			TripEventInput eventInput = new TripEventInput();
			eventInput.setTripId(trip.getTripId());
			eventInput.setAction(TripEvent.CANCEL);
			eventInput.setModifiedBy(modifiedby);
			eventInput.setNodeId(trip.getSourceNode());
			eventInput.setFlowName(modifiedby);

			eventProcessor.processEvent(eventInput);
			
			publishMessage(trip,eventInput);
		} catch (Exception e) {
			log.error("Error occured while moving trip to cancelled state {} ", trip.getTripId());
			log.error("error :: ", e);
			throw new TripApplicationException(e);
		}
	}

	private void publishMessage(Trip trip,TripEventInput event)
	{
		try {
			updateTripVersion(trip.getTripId(), event.getFlowName(), event.getModifiedBy());

			TripPublish tripPublishMessage = Utility.createMessageToPublishTrip(trip.getTripId(), trip.getVersion() + 1,
					false);

			jmsPublisher.inputToQueue(queueName,
					tripPublishMessage, FlowName.PUBLISHTRIP.getValue(), Utility.getMap(Constants.BUSINESS_KEY_ONE,
							Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE, tripPublishMessage.getTrip().getId()),
					TripPublish.class);

			if (trip.getAssignedVehicle() != null && !trip.getAssignedVehicle().isEmpty()) {
				jmsPublisher.publishMessage(vmsTopicName,
						Utility.createVehicleState(trip.getAssignedVehicle(), trip.getTripId(), event.getModifiedBy(),
								Constants.UNASSIGN),
						PublishFlowName.VEHICLE_STATE.getValue(), Utility.getMap(Constants.BUSINESS_KEY_ONE,
								Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE, trip.getTripId()),
						VehicleState.class);
			}
		} catch (Exception e) {
			throw new TripApplicationException(e);
		}

	}
	
	@Override
	 public List<Trip> getTripsTobeCancelled(List<String> tripStatus,List<String> shipmentstatus,String unit,int fetchSize,int interval)
	 {
		 try
		 {
			 return tripsDAO.getTripsTobeCancelled(tripStatus, shipmentstatus, unit, fetchSize, interval);
		 }
		 catch(Exception e)
		 {
			 log.error("exception occured while fetching trip for cancellation "+e);
			 throw new TripApplicationException("Exception ocurred getting trips for cancellation  ", e); 
		 }
	 }

	@Override
	public List<TripAmountResponse> getTripAmount(String startDate, String endDate, String nodeId) throws ParseException {

		if (StringUtils.isBlank(startDate) || StringUtils.isBlank(endDate)) {
			throw new ValidationException("Start Date and end date is required");
		}

		Date endDateDate = new SimpleDateFormat(Constants.DATE_FORMAT_dd_MM_yyyy).parse(endDate);
		endDateDate = DateUtils.addDays(endDateDate, 1);

		Date startDateDate = new SimpleDateFormat(Constants.DATE_FORMAT_dd_MM_yyyy).parse(startDate);

		String startDateFormatted = DateUtility.getToDate(new SimpleDateFormat(Constants.DATE_FORMAT_dd_MM_yyyy).format(startDateDate));
		String endDateFormatted = DateUtility.getFromDate(new SimpleDateFormat(Constants.DATE_FORMAT_dd_MM_yyyy).format(endDateDate));
		List<TripAmount> tripAmount = tripsDAO.getTripAmount(startDateFormatted, endDateFormatted, nodeId);

		Map<String, Map<String, Double>> dateAmountMap = new HashMap<>();
		double totalAmount;
		for (TripAmount amount : tripAmount) {
			dateAmountMap.putIfAbsent(amount.getDate(), new HashMap<>());
			dateAmountMap.get(amount.getDate()).putIfAbsent(amount.getKey(), 0.00);
			totalAmount = new BigDecimal(dateAmountMap.get(amount.getDate()).get(amount.getKey()) + Double.parseDouble( amount.getValue()))
					.setScale(2, RoundingMode.HALF_UP).doubleValue();
			dateAmountMap.get(amount.getDate()).put(amount.getKey(), totalAmount);
		}

		double cashShort;
		Double cashToBeCollected, cashCollected;
		List<TripAmountResponse> tripAmountResponses = new ArrayList<>();
		for (Map.Entry<String, Map<String, Double>> dateAmountEntry : dateAmountMap.entrySet()) {
			TripAmountResponse tripAmountResponse = new TripAmountResponse();
			cashCollected = dateAmountEntry.getValue().get("CASH_COLLECTED");
			cashToBeCollected = dateAmountEntry.getValue().get("CASH_TO_BE_COLLECTED");

			tripAmountResponse.setDate(dateAmountEntry.getKey());
			tripAmountResponse.setCashCollected(cashCollected);
			tripAmountResponse.setCashToBeCollected(cashToBeCollected);
			cashShort = new BigDecimal(cashToBeCollected - cashCollected)
					.setScale(2, RoundingMode.HALF_UP).doubleValue();
			tripAmountResponse.setCashShort(cashShort);
			tripAmountResponses.add(tripAmountResponse);
		}

		Collections.sort(tripAmountResponses);
		return tripAmountResponses;

	}

	@Override
	public ResponseEntity getDayLevelAck(String fromDate, String toDate, String nodeId, String token) throws ParseException {
		List<TripAmountResponse> tripAmount = getTripAmount(fromDate, fromDate, nodeId);
		if (CollectionUtils.isEmpty(tripAmount)) {
			return ResponseEntityFactory.textResponse("No record found!");
		} else {
			MultiValueMap<String, String> param = new LinkedMultiValueMap<>();
			param.add("nodeIds", nodeId);
			TripAmountResponse tripAmountResponse = tripAmount.get(0);
			RRLMappingResponse rrlMappingResponse = (RRLMappingResponse) restClient.get(vmsHost.concat(nodeRRLMappingUrl), new HashMap<>(), param, RRLMappingResponse.class, null);

			if (CollectionUtils.isEmpty(rrlMappingResponse.getNodeRRLMappings())) {
				return ResponseEntityFactory.textResponse(String.format("No store mapping found for node %s", nodeId));
			}

			Authentication authentication = jwtTokenProvider.getAuthentication(token);
			tripAmountResponse.setsDPManagerName(((AppUser) authentication.getPrincipal()).getUsername());
			tripAmountResponse.setSdpId(nodeId);

			NodeRRLMappings mappings = rrlMappingResponse.getNodeRRLMappings().get(0);
			tripAmountResponse.setrRLId(mappings.getRrlId());
			tripAmountResponse.setStoreName(mappings.getSiteName());
			tripAmountResponse.setStoreAddress(mappings.getSiteAddress());

			return dayLevelAckGenerationService.createPdf(tripAmountResponse, nodeId);
		}
	}

	@Override
	public List<TripCountResponse> getTripCount(List<String> nodeIds, List<String> sdpIds, String startDate, String endDate) {

		if (!CollectionUtils.isEmpty(sdpIds)) {

			if ((null != endDate) && (null != startDate)) {
				startDate = DateUtility.getToDate(startDate);
				endDate = DateUtility.getFromDate(endDate);
			}
			return tripsDAO.getTripCountForSDP(nodeIds, sdpIds, startDate, endDate);
		}
		return new ArrayList<>();
	}

    private List<String> getStatusFilter(MovementType mvType, String statusfilter)
	{
		
		List<String> status = new ArrayList<>();
		if (StringUtils.isEmpty(statusfilter) && null != mvType && mvType.equals(MovementType.SHUTTLE)) {
			status.add(TripState.INTRANSIT.getValue());
			status.add(TripState.SETTLEMENT_PENDING.getValue());
			status.add(TripState.SETTLED.getValue());
		} else if(StringUtils.isEmpty(statusfilter)) {
			status.add(TripState.LOADING_COMPLETED.getValue());
			status.add(TripState.INTRANSIT.getValue());
		}
		else
			status.add(statusfilter);

		return status;
	}

	public Map<String, DestinationNodesDeliveryZoneIds> getDeliveryZonesAndDestinationNodesForTrips(
			List<String> nodeIds, Map<String, Object> filters){

		String toDate = DateUtility.getToDate(filters.get(Constants.TO_DATE) !=null ?
															filters.get(Constants.TO_DATE).toString():"");
		String fromDate = DateUtility.getFromDate(filters.get(Constants.FROM_DATE) !=null ?
															filters.get(Constants.FROM_DATE).toString():"");
		MovementType mvType= Utility.getTripMovementType(filters.get(Constants.MOVEMENT_TYPE) !=null?
															filters.get(Constants.MOVEMENT_TYPE).toString() :"");
		filters.put(Constants.MOVEMENT_TYPE, mvType);
		filters.put(Constants.TO_DATE, toDate);
		filters.put(Constants.FROM_DATE, fromDate);
		return tripsDAO.getDeliveryZonesAndDestinationNodesForTrips(nodeIds, filters);
	}
}
