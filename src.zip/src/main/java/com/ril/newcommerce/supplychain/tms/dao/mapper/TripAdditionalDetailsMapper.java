/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.entity.TripAdditionalDetails;

/**
 * @author Raghav1.Singh
 *
 */
public class TripAdditionalDetailsMapper implements ResultSetExtractor<List<TripAdditionalDetails>> {

	@Override
	public List<TripAdditionalDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
		
		List<TripAdditionalDetails> list = new ArrayList<TripAdditionalDetails>();
		
		while(rs.next()) {
			
			TripAdditionalDetails tripAdditionalDetails = new TripAdditionalDetails();
			tripAdditionalDetails.setKey(rs.getString("KEY"));
			tripAdditionalDetails.setValue(rs.getString("VALUE"));
			list.add(tripAdditionalDetails);
			
		}
		
		return list;
	}

}
