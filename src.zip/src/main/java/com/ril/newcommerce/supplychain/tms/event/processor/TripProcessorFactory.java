package com.ril.newcommerce.supplychain.tms.event.processor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;

@Component
public class TripProcessorFactory {

	@Autowired
	@Qualifier(Constants.TRIP_STATE_MACHINE_PROCESSOR)
	private IProcessor statemachineProcessor;

	@Autowired
	@Qualifier(Constants.DO_NOTHING_PROCESSOR)
	private IProcessor doNothingProcessor;
	
	@Autowired
	@Qualifier(Constants.UPDATE_ONLY_PROCESSOR)
	private IProcessor updateOnlyProcessor;

	public IProcessor getProcessor(TripEvent event) {

		switch (event) {
		
			case UNLOADING_START:
				return doNothingProcessor;
			case SPLIT:
			case MERGE:
			case CHECK_IN:
			case CHECK_OUT:
			case UNLOADING_COMPLETE:
			case REPORTRECONCILE:
			case REASSIGN:
			case MANUAL_TRIP:
			case SHUTTLE_TRIP:
				return updateOnlyProcessor;
			default:
				return statemachineProcessor;

		}
	}

}
