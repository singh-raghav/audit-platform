package com.ril.newcommerce.supplychain.tms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.util.ResponseMessage;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
B1.Divya
*/
@RestController
@RequestMapping(value = "/trip-mgmt/v1/trips")
public class ExternalApiController {
	
	@Autowired
	private TripService tripService;
	
	private static final Logger log = LoggerFactory.getLogger(ExternalApiController.class);
	
	@GetMapping(value = "/asset/{tripId}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getTripDetails(@PathVariable String tripId , HttpServletRequest request){
		log.info("Request for trip details for tripId from asset :{}", tripId);
		List<Trip> trips = null;
		String nodeId = request.getHeader(Constants.NODE_ID);		
		try {
			trips = tripService.getTripDetails(tripId,null,nodeId,null);
		} catch(Exception ex) {
			return Utility.getfailureMsg("Failed to get trip");
		}			
		return Utility.getSuccessMsg(trips);		
	}

}
