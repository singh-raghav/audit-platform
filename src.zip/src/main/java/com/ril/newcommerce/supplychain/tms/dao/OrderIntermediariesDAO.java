package com.ril.newcommerce.supplychain.tms.dao;

import com.ril.newcommerce.supplychain.tms.entity.OrderIntermediaries;

import java.util.List;

public interface OrderIntermediariesDAO {
    public void insertRow(List<OrderIntermediaries> orderIntermediaries);
}
