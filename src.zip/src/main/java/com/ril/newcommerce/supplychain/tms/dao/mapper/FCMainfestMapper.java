package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.HubDetail;
import com.ril.newcommerce.supplychain.tms.enums.ConsignmentLabelStatus;

public class FCMainfestMapper implements ResultSetExtractor<List<HubDetail>> {

	@Override
	public List<HubDetail> extractData(ResultSet rs) throws SQLException, DataAccessException {
		rs.setFetchSize(Constants.FETCH_SIZE);
		
		List<HubDetail>hubDetails = new ArrayList<HubDetail>();
		String prevHubId = null;
		Set<String> loadedHUs = null;
		Set<String> loadedOrders = null;
		HubDetail hub = null;
		while (rs.next()) {
			
			String hubId = rs.getString("NODE_ID");
			
			if(StringUtils.isBlank(prevHubId) || !prevHubId.equals(hubId)) { //First hub or 
			
				hub = new HubDetail(); //New hub so add the details...
				
				loadedHUs = new HashSet<String>();
				loadedOrders = new HashSet<String>();
		
				hub.setHubCode(hubId);
				hub.setSequence(rs.getInt("SEQUENCE_NO"));
				hub.setLoadedHUs(loadedHUs);
				hub.setLoadedOrders(loadedOrders);
				hubDetails.add(hub);	
			}
		
			prevHubId = hubId;
			String status = rs.getString("STATUS");
			
			if(ConsignmentLabelStatus.DAMAGED.value().equals(status) || ConsignmentLabelStatus.MISSED.value().equals(status))
				continue;
			
			loadedHUs.add(rs.getString("LABEL_ID"));
			loadedOrders.add(rs.getString("SHIPMENT_NO"));
			
		}
		return hubDetails;
	}

}
