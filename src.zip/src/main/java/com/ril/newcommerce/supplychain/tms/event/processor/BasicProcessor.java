package com.ril.newcommerce.supplychain.tms.event.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
@Transactional(rollbackFor=Exception.class)
public class BasicProcessor implements IProcessor {
	
	private static final Logger log = LoggerFactory.getLogger(BasicProcessor.class);
	
	@Autowired
	protected TripsDAO tripDao;
	
	
	@Override
	public void processEvent(TripEventInput event, Trip trip) {
		
			log.info("Logging the event : {} ", event.getTripId()); // Will be
																	// moved out
																	// the
																	// system.
			tripDao.insertEvent(event);
	}
}
