package com.ril.newcommerce.supplychain.tms.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.ManifestDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.FCMainfestMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.ManifestOrdersMapper;
import com.ril.newcommerce.supplychain.tms.entity.HubDetail;
import com.ril.newcommerce.supplychain.tms.entity.ManifestOrderDetails;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;

@Repository
public class ManifestDAOImpl implements ManifestDAO {
	
	private static final Logger log = LoggerFactory.getLogger(ManifestDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public List<HubDetail> getHubWiseLoadedHUCount(String tripId) {
		
		log.info("Fetching Hub wise loaded HU counts for tripId : {} " ,  tripId);
		
		List<HubDetail> hubDetails =null;
		try {
			hubDetails = jdbcTemplate.query(QueryConstants.GET_SHIPMENT_LABEL_TRIP_MAPPING , new Object[] {tripId} , new FCMainfestMapper());
		}
		catch (Exception e) {
			log.error("Error on fetching Hub wise loaded HU count : " + e);
			throw new TripApplicationException("Error on fetching Hub wise loaded HU count : " + e);
		}
		
		return hubDetails;
	
	}

	@Override
	public List<ManifestOrderDetails> getManifestOrders(String tripId, List<String> status) {
		log.info("Getting order details for trip id :{}" ,tripId);
		List<ManifestOrderDetails> ordersList=new ArrayList<>();
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("tripId", tripId);
		parameters.addValue("status", status);
		String query = QueryConstants.GET_ORDER_DETAIL_FOR_MANIFEST;
		try{
			ordersList=namedParameterJdbcTemplate.query(query, parameters, new ManifestOrdersMapper());
		}
		catch(Exception e)
		{
			log.error("Exception occured on getManifestOrders of ManifestDAOImpl",e);
			throw new TripApplicationException("Exception occured in getManifestOrders of ManifestDAOImpl", e);
		}
		return ordersList;
	}

}
