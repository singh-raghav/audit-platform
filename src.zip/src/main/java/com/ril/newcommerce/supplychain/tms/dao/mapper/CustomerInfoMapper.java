package com.ril.newcommerce.supplychain.tms.dao.mapper;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.util.DeliveryChallanConfig;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class CustomerInfoMapper implements ResultSetExtractor<Map<String,OrderDetails>> {

	@Override
	public Map<String,OrderDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String,OrderDetails> orderDetails = new HashMap<>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			OrderDetails order = new OrderDetails();
			order.setOrderId(rs.getString("ORDER_ID"));
			order.setCustomerId(rs.getString("CUSTOMER_ID"));
			order.setCustomerName(rs.getString("CUSTOMER_NAME"));
			order.setCustomerAddress(rs.getString("CUSTOMER_ADDRESS"));
			order.setCustomerState(rs.getString("CUSTOMER_STATE"));
			order.setCustomerPincode(rs.getString("CUSTOMER_PINCODE"));
			order.setCustomerStateCode(rs.getString("CUSTOMER_STATE_CODE"));
			order.setCustomerGstn(rs.getString("CUSTOMER_GSTN"));
			
			orderDetails.put(order.getOrderId(),order);
		}
		return orderDetails;
	}
}
