package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.WayPointUpdates;
import com.ril.newcommerce.supplychain.tms.response.OrderExcelViewResponse;

/**
B1.Divya
*/

public interface WayPointUpdatesDAO
{
	public void insertToWayPointUpdate(List<WayPointUpdates> wayPointUpdates);

	public List<WayPointUpdates> getWayPointUpdates(String tripId);

	List<OrderExcelViewResponse> getOrderViewExcel(String tripId);

    String getLastUpdate(String orderId);
}
