package com.ril.newcommerce.supplychain.tms.enums;

/**
B1.Divya
*/

public enum OrderType {
	
	B2B("B2B"),
	B2B2C("B2B2C"),
	B2C("B2C");
	
	private String value;
	
	private OrderType(String value){
		this.value=value;
	}
	
	public String getValue(){
		return this.value;
	}

}
