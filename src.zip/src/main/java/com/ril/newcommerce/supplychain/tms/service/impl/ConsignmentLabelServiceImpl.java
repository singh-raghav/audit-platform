package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.ConsignmentLabelDAO;
import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentCount;
import com.ril.newcommerce.supplychain.tms.enums.ConsignmentLabelStatus;
import com.ril.newcommerce.supplychain.tms.enums.LabelType;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.response.HuCountResponse;
import com.ril.newcommerce.supplychain.tms.service.ConsignmentLabelService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate.Labels.Label;
import com.ril.newcommerce.supplychain.tms.tibco.stagingupdate.entity.Shipment;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * B1.Divya
 */

@Service
public class ConsignmentLabelServiceImpl implements ConsignmentLabelService {
	
	private static final Logger log = LoggerFactory.getLogger(ConsignmentLabelServiceImpl.class);

	@Autowired
	ConsignmentLabelDAO consignmentLabelDAO;

	@Override
	public int saveShipmentLabel(Set<ConsignmentLabel> shipmentLabels) {
		int count = 0;
		if (!shipmentLabels.isEmpty())
			try {
				count = consignmentLabelDAO.saveShipmentLabel(shipmentLabels);
			} catch (Exception e) {
				log.error("got exception while saving add label ",e );
				throw new DataProcessingException("Got Exception in ConsignmentLabelServiceImpl saveShipmentLabel",e);
			}
		log.info("successfully added label feed :{} ",count);
		return count;

	}

	@Override
	public void updateStatusOfLabels(List<Label> labels,String modifiedBy) {
		try {
			if (!labels.isEmpty()) {
				consignmentLabelDAO.updateStatusOfShipmentLabel(labels,modifiedBy);
			}
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured during updating label status ", e);
		}
	}

	@Override
	public int updateStatusOfShipmentLabel(Shipment shipment, String flowName) {

		List<String> labels = shipment.getLabels().getLabel().stream().map(label -> label.getLabelId()).collect(Collectors.toList());

		log.info("Updating label status to Staged. shipment no: {}, labels {}  ", shipment.getShipmentNo(), labels);
		return consignmentLabelDAO.updateStatusOfShipmentLabel(
				shipment.getShipmentNo(),
				ConsignmentLabelStatus.STAGED.value(),
				flowName,
				labels
				);
	}

	@Override
	public Integer getLabelsCountForShipment(String shipmentNo) {

		log.info("Validating all the labels are staged for shipment no : {}", shipmentNo);

		return consignmentLabelDAO.getLabelsCountForShipment(shipmentNo);
	}

	@Override
	public List<Label> getStatusOfLabels(List<Label> labels) {
		
		List<Label> updatesStatusList=labels.stream().map(Label::new).collect(Collectors.toList());
			//labels.forEach(l->updatesStatusList.add(l));
		
		
		if(CollectionUtils.isNotEmpty(updatesStatusList))
		{
			for(Label label:updatesStatusList)
			{
				if (label.getLabelMissing().equals(Constants.YES)) {
					if (StringUtils.isNotBlank(label.getMissingStatus()) && (
							label.getMissingStatus().equals(ConsignmentLabelStatus.HUB_LOAD_DAMAGED.value())
							|| label.getMissingStatus().equals(ConsignmentLabelStatus.HUB_UNLOAD_DAMAGED
									.value())
							|| label.getMissingStatus().equals( ConsignmentLabelStatus.FC_LOAD_DAMAGED
									.value()))) {
						label.setMissingStatus(ConsignmentLabelStatus.DAMAGED.value());
					} else {
						label.setMissingStatus(ConsignmentLabelStatus.MISSED.value());
					}
				} else if (label.getLabelMissing().equals(Constants.NO)) {
					label.setMissingStatus(ConsignmentLabelStatus.PICKED.value());
				}
			}
		}
		
		return updatesStatusList;
		
	}
	
	@Override
	public Map<String, Map<String, List<ConsignmentLabel>>> getTripConsignmentLabel(String tripId, String sourceNode) {

		if(!StringUtils.isEmpty(tripId) && !StringUtils.isEmpty(sourceNode))
		{
			List<String> tripIds=new ArrayList<>();
			tripIds.add(tripId);

			List<String> sourceNodes =new ArrayList<>();
			sourceNodes.add(sourceNode);

			return consignmentLabelDAO.getTripConsignmentLabel(tripIds, sourceNodes);
		}
		return null;
	}

	@Override
	public List<ConsignmentLabel> getConsignmentLabel(String shipmentNo) {
		if (!StringUtils.isBlank(shipmentNo)) {
			return consignmentLabelDAO.getConsignmentLabel(shipmentNo);
		}
		return new ArrayList<>();
	}

	@Override
	public List<HuCountResponse> huCountForSDP(List<String> nodeIds, String startDate, String endDate, String orderId, List<String> orderStatus, String mId, String pinCode, List<String> destHubs) {

		if ((null != endDate) && (null != startDate)) {
			startDate = DateUtility.getToDate(startDate);
			endDate = DateUtility.getFromDate(endDate);
		}

		return consignmentLabelDAO.getHUCountForSDP(nodeIds, startDate, endDate, orderId, orderStatus, mId, pinCode, destHubs);
	}

	@Override
	public Map<String, TripConsignmentCount> getConsignmentDetailsByTrip(List<String> tripIds,
			List<String> sourceNode) {
		long startTime = System.currentTimeMillis();
		Map<String, TripConsignmentCount> tripConsignmentLabel = new HashMap<String, TripConsignmentCount>();
		Map<String, Map<String, List<ConsignmentLabel>>> tripConsignment = consignmentLabelDAO.getTripConsignmentLabel(tripIds,
				sourceNode);

		for (Map.Entry<String, Map<String, List<ConsignmentLabel>>> trip : tripConsignment.entrySet()) {
			TripConsignmentCount tripConsignmentCount = new TripConsignmentCount();
			HashSet<String> missedTotesInTrip = new HashSet<>();
			HashSet<String> missedBagsIntrip = new HashSet<>();
			HashSet<String> missedHusInTrip = new HashSet<>();
			HashSet<String> presentTotesInTrip = new HashSet<>();
			HashSet<String> presentBagsIntrip = new HashSet<>();
			HashSet<String> presentHusInTrip = new HashSet<>();
			int missedOrders = 0;
			for (Map.Entry<String, List<ConsignmentLabel>> shipmentNo : trip.getValue().entrySet()) {
				int totalLabelIdSize = shipmentNo.getValue().size();
				HashSet<String> missedTotes = new HashSet<>();
				HashSet<String> missedBags = new HashSet<>();
				HashSet<String> missedHus = new HashSet<>();
				HashSet<String> presentTotes = new HashSet<>();
				HashSet<String> presentBags = new HashSet<>();
				HashSet<String> presentHus = new HashSet<>();
				for (ConsignmentLabel label : shipmentNo.getValue()) {
					if (ConsignmentLabelStatus.MISSED.value().equals(label.getStatus())
							|| ConsignmentLabelStatus.DAMAGED.value().equals(label.getStatus())) {
						if (LabelType.TOTE.getValue().equals(label.getLabelType())) {
							missedTotes.add(label.getLabelId());
						} else if (LabelType.BAG.getValue().equals(label.getLabelType())) {
							missedBags.add(label.getLabelId());
						} else if (LabelType.HU.getValue().equals(label.getLabelType())) {
							missedHus.add(label.getLabelId());
						}
					} else {
						if (LabelType.TOTE.getValue().equals(label.getLabelType())) {
							presentTotes.add(label.getLabelId());
						} else if (LabelType.BAG.getValue().equals(label.getLabelType())) {
							presentBags.add(label.getLabelId());
						} else if (LabelType.HU.getValue().equals(label.getLabelType())) {
							presentHus.add(label.getLabelId());
						}
					}

				}
				if (totalLabelIdSize == missedTotes.size() + missedBags.size() + missedHus.size())
					missedOrders++;
				missedTotesInTrip.addAll(missedTotes);
				missedBagsIntrip.addAll(missedBags);
				missedHusInTrip.addAll(missedHus);
				presentTotesInTrip.addAll(presentTotes);
				presentBagsIntrip.addAll(presentBags);
				presentHusInTrip.addAll(presentHus);

			}
			tripConsignmentCount.setMissedBag(missedBagsIntrip.size());
			tripConsignmentCount.setMissedHu(missedHusInTrip.size());
			tripConsignmentCount.setMissedOrderCount(missedOrders);
			tripConsignmentCount.setMissedTote(missedTotesInTrip.size());
			tripConsignmentCount.setPresentBag(presentBagsIntrip.size());
			tripConsignmentCount.setPresentHu(presentHusInTrip.size());
			tripConsignmentCount.setPresentTote(presentTotesInTrip.size());
			tripConsignmentLabel.put(trip.getKey(), tripConsignmentCount);
		}
		log.info("getConsignmentDetailsByTrip in service layer -- [{}]ms", (System.currentTimeMillis() - startTime));
		return tripConsignmentLabel;
	}
}
