package com.ril.newcommerce.supplychain.tms.event.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

@Component
@Qualifier(Constants.DO_NOTHING_PREPROCESSOR)
public class DoNothingPreProcessor implements IPreProcessor{

	private static final Logger log = LoggerFactory.getLogger(DoNothingPreProcessor.class);
	
	@Override
	public void preProcessEvent(TripEventInput event, Trip trip) {
		log.info("pre processed event for trip : {} " , trip.getTripId());
	}

}
