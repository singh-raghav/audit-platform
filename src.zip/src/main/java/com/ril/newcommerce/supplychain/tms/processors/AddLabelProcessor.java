package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.UnmarshalException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.ConsignmentLabelService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipment;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipment.Containers.Container;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Shipment.Extn.ExtnLabelInfoList.ExtnLabelInfo;

/**
 * B1.Divya
 */

@Service
@Qualifier("addLabelProcessor")
public class AddLabelProcessor implements Processor {
	
	private static final Logger log = LoggerFactory.getLogger(AddLabelProcessor.class);

	@Autowired 
	private JAXBContextConfig jAXBContextConfig;

	@Autowired
	private ConsignmentLabelService consignmentLabelService;

	@Override
	public void processMessage(Message message,String flowName) throws ParsingException, Exception {
		try{
			
		StringReader reader = new StringReader(((TextMessage) message).getText());
		Shipment shipment =  (Shipment) jAXBContextConfig.getJaxbContextInstance(Shipment.class).createUnmarshaller().unmarshal(reader);

		log.debug("Add label messages : {}", message);
		Set<ConsignmentLabel> labels = getShipmentLableFromShipment(shipment);
		log.info("Addlabel received for {} ",shipment.getShipmentNo());
		consignmentLabelService.saveShipmentLabel(labels);
		}
		catch (UnmarshalException par) {
			throw new ParsingException("Parsing error while parsing labelfeed", par);
		} catch (Exception e) {
			log.error("Error while processing labelfeed ", e);
			throw new Exception("Exception occurred while processing labelfeed", e);
		}
	}

	private Set<ConsignmentLabel> getShipmentLableFromShipment(Shipment shipment) {
		Set<ConsignmentLabel> consignmentLabels = new HashSet<>();
		if (shipment != null && shipment.getContainers() != null && shipment.getExtn() != null) {

			for (Container container : shipment.getContainers().getContainer()) {

				ConsignmentLabel consignmentLabel = new ConsignmentLabel();
				consignmentLabel.setLabelId(container.getContainerNo());
				consignmentLabel.setShipmentNo(shipment.getShipmentNo());
				ExtnLabelInfo extInfo = shipment.getExtn().getExtnLabelInfoList().getExtnLabelInfo().stream()
						.filter(e -> container.getContainerNo().equals(e.getLabelId())).findFirst().orElse(null);
				consignmentLabel.setLabelType(extInfo.getLabelType());
				consignmentLabel.setParentLabelId(extInfo.getParentLabelId());
				consignmentLabels.add(consignmentLabel);

				List<ConsignmentLabel> consignmentLabelList = new ArrayList<>();
				consignmentLabelList = getConsignmentLabel(consignmentLabelList, extInfo, shipment);
				consignmentLabels.addAll(consignmentLabelList);

			}

		}
		log.info("Label feed :{}",consignmentLabels.size());
		return consignmentLabels;
	}

	private List<ConsignmentLabel> getConsignmentLabel(List<ConsignmentLabel> consignmentLabelList,
			ExtnLabelInfo extInfo, Shipment shipment) {

		if (null!= extInfo.getParentLabelId()) {
			ExtnLabelInfo extInfoParentId = shipment.getExtn().getExtnLabelInfoList().getExtnLabelInfo().stream()
					.filter(e -> extInfo.getParentLabelId().equals(e.getLabelId())).findFirst().orElse(null);
			ConsignmentLabel label = new ConsignmentLabel();
			label.setLabelId(extInfoParentId.getLabelId());
			label.setParentLabelId(extInfoParentId.getParentLabelId());
			label.setShipmentNo(shipment.getShipmentNo());
			label.setLabelType(extInfoParentId.getLabelType());
			consignmentLabelList.add(label);

			getConsignmentLabel(consignmentLabelList, extInfoParentId, shipment);
		}
		return consignmentLabelList;
	}
}
