package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class FetchNodeResponse {

	private String statusCode;
	private String timeStamp;
	private List<Node> nodeDetails;
	
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public List<Node> getNodeDetails() {
		return nodeDetails;
	}
	public void setNodeDetails(List<Node> nodeDetails) {
		this.nodeDetails = nodeDetails;
	}
	
}
