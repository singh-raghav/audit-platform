package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Customer;

/**
 * B1.Divya
 */

public class TripConsignmentMapper implements ResultSetExtractor<List<Consignment>> {

	@Override
	public List<Consignment> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<Consignment> consignmentList = new ArrayList<Consignment>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			Consignment consignment=new Consignment();
			consignment.setOrderId(rs.getString("ORDER_ID"));
			consignment.setOrderDate(rs.getTimestamp("ORDER_DATE"));
			consignment.setOrderClassification(rs.getString("ORDER_CLASSIFICATION"));
			consignment.setOrderType(rs.getString("ORDER_TYPE"));
			consignment.setOrderStatus(rs.getString("ORDER_STATUS"));
			consignment.setShipmentNo(rs.getString("SHIPMENT_NO"));
			consignment.setNextNodeId(rs.getString("NODE_ID"));
			consignment.setShipmentStatus(rs.getString("SHIPMENT_STATUS"));
			consignment.setSlotStart(rs.getTimestamp("SLOT_START"));
			consignment.setSlotEnd(rs.getTimestamp("SLOT_END"));
			consignment.setLatitude(rs.getBigDecimal("LATITUDE"));
			consignment.setLongitute(rs.getBigDecimal("LONGITUDE"));
			consignment.setDeliveryZoneId(rs.getString("DELIVERY_ZONE_ID"));
			Customer customer =new Customer();
			customer.setId(rs.getString("ID"));
			customer.setPincode(rs.getString("PINCODE"));
			customer.setName(rs.getString("NAME"));
			customer.setAddress(rs.getString("ADDRESS"));
			consignment.setCustomer(customer);
			
			consignmentList.add(consignment);
		}
		return consignmentList;
	}
	

}
