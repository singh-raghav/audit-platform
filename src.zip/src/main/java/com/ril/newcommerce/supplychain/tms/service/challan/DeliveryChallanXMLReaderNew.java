package com.ril.newcommerce.supplychain.tms.service.challan;

import java.io.IOException;
import java.util.Arrays;
import java.util.stream.Collectors;

import com.ril.newcommerce.supplychain.tms.service.barcode.BarCodeGenerator;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.ArticleInfo;
import com.ril.newcommerce.supplychain.tms.entity.DeliveryChallan;
import com.ril.newcommerce.supplychain.tms.entity.Party;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.pdf.tools.AbstractObjectReader;

public class DeliveryChallanXMLReaderNew extends AbstractObjectReader {
    public void parse(InputSource input) throws IOException, SAXException {
        if (input instanceof ChallanInputSource) {
            parse(((ChallanInputSource) input).getDeliveryChallan() , ((ChallanInputSource) input).getArticleInfo());
        } else {
            throw new SAXException("Unsupported InputSource specified. "
                    + "Must be a ProjectTeamInputSource");
        }
    }

    public void parse(DeliveryChallan deliveryChallan , ArticleInfo articleInfo) throws SAXException {
        if (deliveryChallan == null) {
            return;
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        //Start the document
        handler.startDocument();

        //Generate SAX events for the ProjectTeam
        generateFor(deliveryChallan , articleInfo);

        //End the document
        handler.endDocument();
    }

    protected void generateFor(DeliveryChallan deliveryChallan , ArticleInfo articleInfo) throws SAXException {
        if (deliveryChallan == null) {
            throw new NullPointerException("Parameter deliveryChallan must not be null");
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }
        String barcode = new BarCodeGenerator().generate(deliveryChallan.getChallanId());
        handler.startElement("deliveryChallan");
        handler.element("topic", deliveryChallan.getChallanId().contains("REG")?"":"RELIANCE RETAIL LIMITED");
        handler.element("barcode", barcode);
        boolean isAssets = ArticleType.ASSET.name().equals(articleInfo.getArticles().get(0).getArticleType());
        handler.element("challanName", isAssets?"Delivery Challan":"Goods Returns Delivery Challan");
        handler.element("challanId", deliveryChallan.getChallanId());
        handler.element("placeOfBusiness", deliveryChallan.getPlaceOfBusiness());
        handler.element("createdOn", java.time.LocalDate.now().toString());

        handler.element("totalInvoiceValue", String.valueOf(articleInfo.getTotalInvoiceValue()));
        handler.element("totalQuantity", String.valueOf(articleInfo.getTotalQuantity()));
        int counter = 1;
        for (ChallanArticle article : articleInfo.getArticles()) {
            generateFor(article, counter);
            counter++;
        }

        String tripId = CollectionUtils.isNotEmpty(articleInfo.getArticles())?articleInfo.getArticles().get(0).getTripId():Constants.NOT_APPLICABLE;
        String returnOrderId = Constants.NOT_APPLICABLE;
        if(!isAssets && CollectionUtils.isNotEmpty(articleInfo.getArticles()))
            returnOrderId =articleInfo.getArticles().get(0).getReturnOrderId();


        handler.startElement("consignee");
        generateFor(deliveryChallan.getConsignee(),tripId,returnOrderId, deliveryChallan.getHubId());
        handler.endElement("consignee");

        handler.startElement("consignor");
        generateFor(deliveryChallan.getConsignor(),null,null,null);
        handler.endElement("consignor");

        handler.endElement("deliveryChallan");
    }

    private void generateFor(Party party,  String tripId, String orderId,String hubId) throws SAXException {
        if (party == null) {
            return;
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        handler.element("address", StringUtils.join(Arrays.stream(StringUtils.split(party.getAddress(), ",")).filter(s -> !StringUtils.isBlank(s)).collect(Collectors.toList()), ", "));
        handler.element("gstin", party.getGstin());
        handler.element("modeOfTransport", party.getModeOfTransport());
        handler.element("stateCode", party.getStateCode());
        handler.element("truckOperator", party.getTruckOperator());
        handler.element("vehicleNo", party.getVehicleNo());
        handler.element("tripId", tripId);
        handler.element("orderId", orderId);
        handler.element("hubId", hubId);
    }

    private void generateFor(ChallanArticle article, int counter) throws SAXException {
        if (article == null) {
            return;
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        handler.startElement("article");
        handler.element("slNo", String.valueOf(counter));
        handler.element("articleCode", article.getArticleCode());
        handler.element("articleDesc", article.getArticleDesc());
        handler.element("hsnCode", article.getHsnCode());
        handler.element("quantity", String.valueOf(article.getQuantity()));
        handler.element("uom", article.getUOM());
        handler.element("rate", String.valueOf(article.getRate()));
        handler.element("baseValue", String.valueOf(article.getBaseValue()));
        handler.endElement("article");
    }
}
