package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ril.newcommerce.supplychain.tms.enums.ReturnItemQuality;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanArticle;

	
public class ItemQualityMapper implements RowMapper<ChallanArticle> {

		@Override
		public ChallanArticle mapRow(ResultSet rs, int arg1) throws SQLException {
		
			ChallanArticle article = new ChallanArticle();
			article.setChallanId(rs.getString("CHALLAN_ID"));
			article.setReturnOrderId(rs.getString("RETURN_ORDER_ID"));
			article.setArticleCode(rs.getString("ARTICLE_ID"));
			String quality = rs.getString("QUALITY");
			article.setQuality(ReturnItemQuality.getQualityByName(quality));
			
			return article;	
		}
	
}


