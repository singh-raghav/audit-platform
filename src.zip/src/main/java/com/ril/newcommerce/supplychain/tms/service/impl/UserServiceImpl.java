package com.ril.newcommerce.supplychain.tms.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.UserDetailDAO;
import com.ril.newcommerce.supplychain.tms.entity.ExternalUserCreationFailure;
import com.ril.newcommerce.supplychain.tms.entity.UserDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.FluidResponse;
import com.ril.newcommerce.supplychain.tms.entity.rest.hawkeye.*;
import com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails.ClusterDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails.NodeDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails.NodeDetailsResponse;
import com.ril.newcommerce.supplychain.tms.entity.rest.oldtripapp.OldTripAppCreateUserRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.oldtripapp.OldTripAppCreateUserResponse;
import com.ril.newcommerce.supplychain.tms.entity.rest.sterling.ContactPersonInfo;
import com.ril.newcommerce.supplychain.tms.entity.rest.sterling.SterlingCreateUserRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.sterling.UserGroupList;
import com.ril.newcommerce.supplychain.tms.entity.rest.sterling.UserGroupLists;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.*;
import com.ril.newcommerce.supplychain.tms.enums.AccountStatus;
import com.ril.newcommerce.supplychain.tms.enums.ExternalSystem;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;
import com.ril.newcommerce.supplychain.tms.enums.UserRoles;
import com.ril.newcommerce.supplychain.tms.externalApis.OldTripAppFeign;
import com.ril.newcommerce.supplychain.tms.externalApis.SterlingFeign;
import com.ril.newcommerce.supplychain.tms.repository.ExternalUserCreationFailureRepository;
import com.ril.newcommerce.supplychain.tms.repository.UserDetailsRepository;
import com.ril.newcommerce.supplychain.tms.service.HawkEyeService;
import com.ril.newcommerce.supplychain.tms.service.UserService;
import com.ril.newcommerce.supplychain.tms.util.RestClient;
import com.ril.newcommerce.supplychain.tms.util.Utility;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    @Autowired
    private HawkEyeService hawkEyeService;

    @Autowired
    private NodeDetailApiServiceImpl nodeDetailApiService;

    @Value("${hawkeye.client}")
    private String hawkeyeClient;

    @Autowired
    private SterlingFeign sterlingFeign;

    @Value("${sterling.username}")
    private String sterlingUserName;

    @Value("${sterling.password}")
    private String sterlingPassword;

    @Value("${userCreation.oldTripApp.apiCall}")
    private String callOldTripUserCreationApi;

    @Value("${userCreation.sterling.apiCall}")
    private String callSteringUserCreationApi;

    @Autowired
    private ExternalUserCreationFailureRepository externalUserCreationFailureRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private OldTripAppFeign oldTripAppFeign;

    @Autowired
    private UserDetailDAO userDetailDAO;
    
	@Autowired
	private RestClient restClient;
	
    @Value("${vms.host}")
	private String vmsHost;

	@Value("${vms.fluidLoadingUrl}")
	private String fluidLoading;
	
	@Value("${vms.fluidLoadingUrl.end}")
	private String fluidLoadingEnd;
	
    @Override
    public UserDetailResponse getUserDetails(String userName){

        UserDetailResponse userDetailResponse = null;

        UserDetails userDetails = findUserByUserName(userName);
        if(userDetails==null){
            return null;
        }
        if(userDetails.getRole().equals(UserRoles.Admin)){
            userDetailResponse = UserDetailResponse.builder()
                    .userRole(UserRoles.Admin.toString())
                    .displayName("Administrator")
                    .username(userName)
                    .firstName(userDetails.getFirstName())
                    .lastName(userDetails.getLastName())
                    .accountStatus(userDetails.getAccountStatus())
                    .build();
        }
        else if(userDetails.getRole().equals(UserRoles.ClusterManager)){

            NodeDetailsResponse nodeDetailsResponse = nodeDetailApiService.getNodeDetails(userDetails.getNodeId(), userDetails.getNodeType(),true);

                if(nodeDetailsResponse.getStatusCode()==200){
                    ClusterDetails clusterDetails = nodeDetailsResponse.getClusterDetails().get(0);
                    List<Node> nodeList = new ArrayList<>();
                    for(NodeDetails childNodesFC : clusterDetails.getChildNodes()){
                   FluidResponse fluidResponse = (FluidResponse)restClient.get(vmsHost.concat(fluidLoading+childNodesFC.getNodeId()+fluidLoadingEnd), new HashMap<>(), new LinkedMultiValueMap<>() , FluidResponse.class, null);
                   boolean flagEnabled = "Y".equals(fluidResponse.getFluidLoad().getFlag()) ? true : false;
                        for(NodeDetails childNodesHub : childNodesFC.getChildNodes()){
                            Node nodeHub = Node.builder()
                                    .nodeId(childNodesHub.getNodeId())
                                    .nodeName(childNodesHub.getName())
                                    .nodeType(childNodesHub.getNodeType())
                                    .isFluidLoadingEnabled(flagEnabled)
                                    .build();

                            nodeList.add(nodeHub);
                        }
                        Node nodeFc = Node.builder()
                                .nodeId(childNodesFC.getNodeId())
                                .nodeName(childNodesFC.getName())
                                .nodeType(childNodesFC.getNodeType())
                                .isFluidLoadingEnabled(flagEnabled)
                                .build();

                        nodeList.add(nodeFc);
                    }

                    Cluster cluster = Cluster.builder()
                            .clusterId(clusterDetails.getClusterId())
                            .clusterName(clusterDetails.getName())
                            .nodes(nodeList)
                            .build();

                    List<Cluster> clusterList = new ArrayList<>();
                    clusterList.add(cluster);


                    userDetailResponse = UserDetailResponse.builder()
                            .userRole(UserRoles.ClusterManager.toString())
                            .displayName("Cluster Manager")
                            .clusters(clusterList)
                            .username(userName)
                            .firstName(userDetails.getFirstName())
                            .lastName(userDetails.getLastName())
                            .accountStatus(userDetails.getAccountStatus())
                            .build();

                }else{
                    return null;
                }


        }
        else {

                NodeDetailsResponse nodeDetailsResponse = nodeDetailApiService.getNodeDetails(userDetails.getNodeId(), userDetails.getNodeType(),true);

                if(nodeDetailsResponse.getStatusCode()==200){
                    NodeDetails nodeDetails = nodeDetailsResponse.getNodeDetails().get(0);
                   List<Node> nodeList = new ArrayList<>();
                   boolean isCoLocated=StringUtils.isEmpty(nodeDetails.getCoHostId())||userDetails.getNodeId().equals(nodeDetails.getCoHostId())?false:true;
                   String nodeId = (nodeDetails.getNodeType().equals(Constants.HUB)) ? nodeDetails.getParentNodeId() : userDetails.getNodeId();
                   FluidResponse fluidResponse = (FluidResponse)restClient.get(vmsHost.concat(fluidLoading+nodeId+fluidLoadingEnd), new HashMap<>(), new LinkedMultiValueMap<>() , FluidResponse.class, null); 
                   boolean flagEnabled = "Y".equals(fluidResponse.getFluidLoad().getFlag()) ? true : false;
                   		Node node = Node.builder()
                                .nodeId(nodeDetails.getNodeId())
                                .nodeName(nodeDetails.getName())
                                .nodeType(nodeDetails.getNodeType())
                                .isCoLocated(isCoLocated)
                                .isFluidLoadingEnabled(flagEnabled)
                                .build();
                        nodeList.add(node);
                   	
                    Cluster cluster = Cluster.builder()
                            .clusterId(nodeDetails.getClusterId())
                            .nodes(nodeList)
                            .build();

                    List<Cluster> clusterList = new ArrayList<>();
                    clusterList.add(cluster);

                    String userRole="", displayName="";
                    if(userDetails.getRole().equals(UserRoles.NodeManager)){
                        userRole = UserRoles.NodeManager.toString();
                        displayName = "Node Manager";
                    }
                    if(userDetails.getRole().equals(UserRoles.FcManager)){
                        userRole = UserRoles.FcManager.toString();
                        displayName = "Fc Manager";
                    }
                    if(userDetails.getRole().equals(UserRoles.Putaway)){
                        userRole = UserRoles.Putaway.toString();
                        displayName = "PutAway";
                    }
                    if(userDetails.getRole().equals(UserRoles.Developer)){
                        userRole = UserRoles.Developer.toString();
                        displayName = "Developer";
                    }
                    if(userDetails.getRole().equals(UserRoles.LoaderUnloader)){
                        userRole = UserRoles.LoaderUnloader.toString();
                        displayName = "Loader Unloader";
                    }
                    if(userDetails.getRole().equals(UserRoles.DeliveryPartner)){
                        userRole = UserRoles.DeliveryPartner.toString();
                        displayName = "Delivery Partner";
                    }

                    userDetailResponse = UserDetailResponse.builder()
                            .userRole(userRole)
                            .displayName(displayName)
                            .clusters(clusterList)
                            .username(userName)
                            .firstName(userDetails.getFirstName())
                            .lastName(userDetails.getLastName())
                            .accountStatus(userDetails.getAccountStatus())
                            .build();

                }
                else {
                    return null;
                }
            }

        return userDetailResponse;
    }

    @Override
    public UserDetails findUserByUserName(String userName) {

        return userDetailsRepository.findByUserName(userName);

    }

    @Override
    public void saveUser(UserDetails userDetails) {
        userDetailsRepository.save(userDetails);
    }

    @Transactional
    @Override
    public void createUser(CreateUserRequest createUserRequest, String userId) throws Exception{

        String nodeId, nodeType, clusterId;
        Cluster cluster = createUserRequest.getClusters().get(0);
        clusterId = cluster.getClusterId();
        if(cluster.getNodes()!=null && cluster.getNodes().size()>0){
            Node node = cluster.getNodes().get(0);
            nodeType = node.getNodeType();
            nodeId = node.getNodeId();

        }else{
            nodeType = NodeType.CLUSTER.toString();
            nodeId = cluster.getClusterId();
        }

        UserDetails userDetails = UserDetails.builder()
                .userName(createUserRequest.getUserName())
                .accountStatus(AccountStatus.ACTIVE)
                .address(createUserRequest.getAddress())
                .altContactNo(createUserRequest.getAltContactNo())
                .altContactPerson(createUserRequest.getAltContactPerson())
                .emailId(createUserRequest.getEmailId())
                .firstName(createUserRequest.getFirstName())
                .lastName(createUserRequest.getLastName())
                .mobileNo(createUserRequest.getMobileNo())
                .nodeId(nodeId)
                .nodeType(NodeType.valueOf(nodeType))
                .role(createUserRequest.getRole())
                .updatedAt(LocalDateTime.now())
                .updatedBy(userId)
                .clusterId(clusterId)
                .invalidAttempts(0)
                .state(createUserRequest.getState())
                .pincode(createUserRequest.getPincode())
                .build();

        List<UserDetails> userDetailsList = userDetailsRepository.findAllByUserNameOrEmailId(createUserRequest.getUserName(), createUserRequest.getEmailId());
        if(userDetailsList!=null && userDetailsList.size()>0){
            throw new Exception("UserName or EmailId already exist");
        }

        HawkeyeCreateUserOutput user = hawkEyeService.createUser(getHawkeyeCreateUserInput(createUserRequest));

        userDetails.setHawkeyeUserId(user.getResult().getId());
        userDetailsRepository.save(userDetails);

        if("Y".equals(callOldTripUserCreationApi) && (createUserRequest.getRole().equals(UserRoles.DeliveryPartner) ||
                createUserRequest.getRole().equals(UserRoles.LoaderUnloader))){
            createUserInSterling(createUserRequest,nodeId, nodeType, userId);
        }

        if("Y".equals(callOldTripUserCreationApi)){
            createUserInOldTripApp(createUserRequest,nodeId, nodeType, userId);
        }


    }

    private void createUserInSterling(CreateUserRequest createUserRequest, String nodeId, String nodeType, String userId){


        String userGroupId="",dataSecurityGroupId="";
        if(createUserRequest.getRole().equals(UserRoles.DeliveryPartner)){
            userGroupId="Delivery_Partner";
            dataSecurityGroupId="DeliveryPartner";
        }
        if(createUserRequest.getRole().equals(UserRoles.LoaderUnloader)){
            userGroupId="Loader/Unloader";
        }

        ContactPersonInfo contactPersonInfo = ContactPersonInfo.builder()
                .EMailID(createUserRequest.getEmailId())
                .FirstName(createUserRequest.getFirstName())
                .LastName(createUserRequest.getLastName())
                .MobilePhone(createUserRequest.getMobileNo())
                .build();

        UserGroupLists userGroupLists = new UserGroupLists();
        UserGroupList userGroupList = UserGroupList.builder()
                .UsergroupId(userGroupId)
                .build();
        userGroupLists.setUserGroupList(userGroupList);

        String encryptedPwd = Utility.get_SHA_256_SecurePassword(createUserRequest.getSecret(), Constants.SALT.toString());

        com.ril.newcommerce.supplychain.tms.entity.rest.sterling.User user = com.ril.newcommerce.supplychain.tms.entity.rest.sterling.User.builder()
                .UserGroupLists(userGroupLists)
                .Activateflag("Y")
                .ContactPersonInfo(contactPersonInfo)
                .DataSecurityGroupId(dataSecurityGroupId)
                .Localecode("en_IN_IST")
                .Loginid(createUserRequest.getUserName())
                .NodeType(nodeType)
                .OrganizationKey(nodeId)
                .Password(encryptedPwd)
                .Role(createUserRequest.getRole().toString())
                .Username(createUserRequest.getUserName())
                .Action("CREATE")
                .build();


        SterlingCreateUserRequest sterlingCreateUserRequest = SterlingCreateUserRequest.builder().User(user).build();

        try {
            callSterlingApi(sterlingCreateUserRequest);
        }catch(Exception ex){
          LOGGER.info("ERROR---- ",ex);
            try {
                ExternalUserCreationFailure externalUserCreationFailure = ExternalUserCreationFailure.builder()
                        .system(ExternalSystem.STERLING)
                        .userName(createUserRequest.getUserName())
                        .createdAt(LocalDateTime.now())
                        .createdBy(userId)
                        .error(ex.getMessage())
                        .request(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(sterlingCreateUserRequest))
                        .build();

                externalUserCreationFailureRepository.save(externalUserCreationFailure);
            }
            catch (Exception ex1){
                LOGGER.info("ERROR_Inside -- ",ex1);
            }
        }
    }

    private void createUserInOldTripApp(CreateUserRequest createUserRequest, String nodeId, String nodeType, String userId){


        String userGroupId="", storeId="";

        String clusterId = createUserRequest.getClusters().get(0).getClusterId();
        if(createUserRequest.getRole().equals(UserRoles.DeliveryPartner)){
            userGroupId="Delivery_Partner";
        }
        if(createUserRequest.getRole().equals(UserRoles.LoaderUnloader)){
            userGroupId="Loader/Unloader";
        }
        if(createUserRequest.getRole().equals(UserRoles.NodeManager)){
            userGroupId="Store_Manager";
            storeId=nodeId;
        }
        if(createUserRequest.getRole().equals(UserRoles.ClusterManager)){
            userGroupId="City_Manager";
        }

        com.ril.newcommerce.supplychain.tms.entity.rest.oldtripapp.User user = com.ril.newcommerce.supplychain.tms.entity.rest.oldtripapp.User.builder()
                .isDeleted("N")
                .role(userGroupId)
                .firstName(createUserRequest.getFirstName())
                .lastName(createUserRequest.getLastName())
                .mobileNo(createUserRequest.getMobileNo())
                .address(createUserRequest.getAddress())
                .loginID(createUserRequest.getUserName())
                .emailID(createUserRequest.getEmailId())
                .altContactPerson(createUserRequest.getAltContactPerson())
                .altContactNo(createUserRequest.getAltContactNo())
                .password(createUserRequest.getSecret())
                .rePassword(createUserRequest.getSecret())
                .clusterId(clusterId)
                .store(storeId)
                .nodeType(nodeType)
                .build();

        OldTripAppCreateUserRequest oldTripAppCreateUserRequest = OldTripAppCreateUserRequest.builder()
                .user(user)
                .hub(false)
                .build();


        try {
            OldTripAppCreateUserResponse oldTripAppCreateUserResponse = callOldTripAppCreateUserApi(oldTripAppCreateUserRequest);
            if(oldTripAppCreateUserResponse.getData().getResponse()!="ADD_SUCCESS"){
                throw new Exception(objectMapper.writeValueAsString(oldTripAppCreateUserResponse));
            }
        }catch(Exception ex){
            LOGGER.info("ERROR---- ",ex);
            try {
                ExternalUserCreationFailure sterlingCreateUserFailure = ExternalUserCreationFailure.builder()
                        .system(ExternalSystem.OLDTRIPAPP)
                        .userName(createUserRequest.getUserName())
                        .createdAt(LocalDateTime.now())
                        .createdBy(userId)
                        .error(ex.getMessage())
                        .request(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(oldTripAppCreateUserRequest))
                        .build();

                externalUserCreationFailureRepository.save(sterlingCreateUserFailure);
            }
            catch (Exception ex1){
                LOGGER.info("ERROR_Inside -- ",ex1);
            }



        }

    }

    @Override
    public OldTripAppCreateUserResponse callOldTripAppCreateUserApi(OldTripAppCreateUserRequest oldTripAppCreateUserRequest){
        LOGGER.info("calling create user api of OldTripApp");
        return oldTripAppFeign.createUser(oldTripAppCreateUserRequest);
    }

    @Override
    public String reprocessUser(String id) throws Exception{

        String errorMessage = "";
        ExternalUserCreationFailure externalUserCreationFailure = externalUserCreationFailureRepository.findById(id).orElse(null);

        if(externalUserCreationFailure==null){
            throw new Exception("Invalid ID");
        }
        ExternalSystem systemName = externalUserCreationFailure.getSystem();
        String request = externalUserCreationFailure.getRequest();

        try {
            if (systemName.equals(ExternalSystem.STERLING)) {
                SterlingCreateUserRequest sterlingCreateUserRequest = objectMapper.readValue(request, SterlingCreateUserRequest.class);
                callSterlingApi(sterlingCreateUserRequest);
                externalUserCreationFailureRepository.deleteById(id);
            }
            if (systemName.equals(ExternalSystem.OLDTRIPAPP)) {
                OldTripAppCreateUserRequest oldTripAppCreateUserRequest = objectMapper.readValue(request, OldTripAppCreateUserRequest.class);
                OldTripAppCreateUserResponse oldTripAppCreateUserResponse = callOldTripAppCreateUserApi(oldTripAppCreateUserRequest);
                if (oldTripAppCreateUserResponse.getData().getResponse()!="ADD_SUCCESS") {
                    throw new Exception(oldTripAppCreateUserResponse.toString());
                }
                externalUserCreationFailureRepository.deleteById(id);
            }
        }catch(Exception ex){

            externalUserCreationFailure.setCreatedAt(LocalDateTime.now());
            externalUserCreationFailure.setError(ex.getMessage());

            externalUserCreationFailureRepository.save(externalUserCreationFailure);

            errorMessage = ex.getMessage();
        }
        return errorMessage;
    }

    @Override
    public ResponseEntity<Object> callSterlingApi(SterlingCreateUserRequest sterlingCreateUserRequest){

        String encodedPassword = Base64.getEncoder().encodeToString((sterlingUserName + ":" + sterlingPassword).getBytes());
        LOGGER.info("calling create user api of Sterling");
        return sterlingFeign.createUser("Basic " + encodedPassword, sterlingCreateUserRequest);
    }

    private HawkeyeCreateUserInput getHawkeyeCreateUserInput(CreateUserRequest createUserRequest){

        Principal principal = Principal.builder()
                .emailId(createUserRequest.getEmailId())
                .firstname(createUserRequest.getFirstName())
                .lastname(createUserRequest.getLastName())
                .username(createUserRequest.getUserName())
                .build();

        Roles roles = Roles.builder().name(createUserRequest.getRole().toString()).build();
        List<Roles> rolesList = new ArrayList<>();
        rolesList.add(roles);

        User user  = User.builder().principal(principal).roles(rolesList).build();

        Secret secret = Secret.builder().password(createUserRequest.getSecret()).passwordType("RAW").build();

        return HawkeyeCreateUserInput.builder()
                .clientName(hawkeyeClient)
                .secret(secret)
                .sendNotification("false")
                .user(user)
                .build();

    }

    @Override
    public void updateUser(UpdateUserRequest updateUserRequest) throws  Exception {

        UserDetails userDetails = findUserByUserName(updateUserRequest.getUserName());
        if(userDetails == null){
            throw new Exception("Invalid UserName");
        }

        if(updateUserRequest.getFirstName()!=null){
            userDetails.setFirstName(updateUserRequest.getFirstName());
        }
        if(updateUserRequest.getLastName()!=null){
            userDetails.setLastName(updateUserRequest.getLastName());
        }
        if(updateUserRequest.getMobileNo()!=null){
            userDetails.setMobileNo(updateUserRequest.getMobileNo());
        }
        if(updateUserRequest.getAltContactPerson()!=null){
            userDetails.setAltContactPerson(updateUserRequest.getAltContactPerson());
        }
        if(updateUserRequest.getAltContactNo()!=null){
            userDetails.setAltContactNo(updateUserRequest.getAltContactNo());
        }
        if(updateUserRequest.getAddress()!=null){
            userDetails.setAddress(updateUserRequest.getAddress());
        }
        if(updateUserRequest.getAccountStatus()!=null){
            userDetails.setAccountStatus(updateUserRequest.getAccountStatus());
        }
        if(updateUserRequest.getState()!=null){
            userDetails.setState(updateUserRequest.getState());
        }
        if(updateUserRequest.getPincode()!=null){
            userDetails.setPincode(updateUserRequest.getPincode());
        }

        userDetailsRepository.save(userDetails);

    }

    @Override
    public void resetPassword(UpdateUserRequest updateUserRequest, String managerId) throws Exception {

        UserDetails userDetailsManager = findUserByUserName(managerId);
        if(userDetailsManager == null){
            throw new Exception("Invalid logged in User");
        }

        UserDetails userDetails = findUserByUserName(updateUserRequest.getUserName());
        if(userDetails == null){
            throw new Exception("Invalid UserName passed");
        }


        HawkeyeResetPasswordInput hawkeyeResetPasswordInput = HawkeyeResetPasswordInput.builder()
                .clientName(hawkeyeClient)
                .emailId(userDetails.getEmailId())
                .resetEmailRecipient(userDetailsManager.getEmailId())
                .build();
        LOGGER.info("Calling hawkeye resetPasswordForOthers api for {} against email {}" ,userDetails.getEmailId(), userDetailsManager.getEmailId());
        String errorMessage = hawkEyeService.resetPasswordForOthers(hawkeyeResetPasswordInput);
        if(errorMessage!=null)
        {
            throw new Exception("Reset password failed - "+errorMessage);
        }
    }

    @Override
    public void changePassword(String token, UpdateUserRequest updateUserRequest) throws Exception{
        UserDetails userDetails = findUserByUserName(updateUserRequest.getUserName());
        if(userDetails == null){
            throw new Exception("Invalid UserName passed");
        }

        HawkeyeChangePasswordInput hawkeyeChangePasswordInput = HawkeyeChangePasswordInput.builder()
                .emailId(userDetails.getEmailId())
                .oldPassword(updateUserRequest.getCurrentSecret())
                .newPassword(updateUserRequest.getNewSecret())
                .build();

        String errorMessage = hawkEyeService.changePassword(token, hawkeyeChangePasswordInput);
        if(errorMessage!=null)
        {
            throw new Exception("Change password failed - "+errorMessage);
        }
    }

    @Override
    public UserListResponse getUserList(String nodeId, String clusterId, boolean ignoreNodeIdHeader,
                                         boolean ignoreDeletedUsers,Integer pageSize, Integer pageIndex,
                                         String searchKeyword, UserRoles userRole, String lastLoginFrom,
                                         String lastLoginTo) throws Exception{

        return userDetailDAO.getUserList(nodeId, clusterId, ignoreNodeIdHeader,
        ignoreDeletedUsers, pageSize, pageIndex,
                searchKeyword, userRole, lastLoginFrom,
                lastLoginTo);

    }

}

