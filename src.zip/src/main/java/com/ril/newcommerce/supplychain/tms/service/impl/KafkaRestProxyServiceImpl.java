package com.ril.newcommerce.supplychain.tms.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.entity.rest.commonAuditPlatform.CommonAuditPlatformInput;
import com.ril.newcommerce.supplychain.tms.externalApis.KafkaRestProxyFeign;
import com.ril.newcommerce.supplychain.tms.service.KafkaRestProxyService;

@Service
public class KafkaRestProxyServiceImpl implements KafkaRestProxyService {

    @Value("${kafkaRestProxyService.clientId}")
    private String kafkaRestClientId;

    @Value("${kafkaRestProxyService.commonAudit.serviceName}")
    private String kafkaRestAuditPlatformServiceName;

    @Value("${kafkaRestProxyService.apiKey}")
    private String kafkaRestApiKey;

    @Autowired
    private KafkaRestProxyFeign kafkaRestProxyFeign;

    private static final Logger log = LoggerFactory.getLogger(KafkaRestProxyServiceImpl.class);


    public void publishToCommonAuditPlatform(String eventSource, String trackingId, String businessOperation,
                                             long eventCreationTime, String event) throws Exception{

        CommonAuditPlatformInput commonAuditPlatformInput = CommonAuditPlatformInput.builder()
                .eventSource(eventSource)
                .trackingId(trackingId)
                .businessOperation(businessOperation)
                .eventCreationTime(eventCreationTime)
                .event(event)
                .build();
        ObjectMapper objectMapper = new ObjectMapper();
        String input = objectMapper.writeValueAsString(commonAuditPlatformInput);

        log.debug("Pushing to audit platform : {} " , input);
        kafkaRestProxyFeign.publish(kafkaRestClientId, kafkaRestAuditPlatformServiceName, kafkaRestApiKey, input);
        log.info("Sucessfully pushed event to Audit platform");

    }
}
