package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.ConsignmentLabel;


/**
 * B1.Divya
 */

public class TripConsignmentLabel implements ResultSetExtractor<Map<String, Map<String, List<ConsignmentLabel>>>> {

	@Override
	public Map<String, Map<String, List<ConsignmentLabel>>> extractData(ResultSet rs)
			throws SQLException, DataAccessException {

		Map<String, Map<String, List<ConsignmentLabel>>> tripConsignmentLabel = new HashMap<String, Map<String, List<ConsignmentLabel>>>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {
			String tripId = rs.getString("TRIP_ID");
			String shipmentNo = rs.getString("SHIPMENT_NO");
			String labelType = rs.getString("LABEL_TYPE");
			String status = rs.getString("STATUS");
			String labelId = rs.getString("LABEL_ID");
			String nodeId= rs.getString("NODE_ID");
			String parentLabelId = rs.getString("PARENT_LABEL_ID");

			Map<String, List<ConsignmentLabel>> consginmentLabelStatus = null;
			if (!tripConsignmentLabel.containsKey(tripId)) {
				consginmentLabelStatus = new HashMap<>();
				ConsignmentLabel label = getLabel(shipmentNo, labelId, labelType, status,nodeId, parentLabelId);
				List<ConsignmentLabel> labelList = new ArrayList<ConsignmentLabel>();
				labelList.add(label);

				consginmentLabelStatus.put(shipmentNo, labelList);

				tripConsignmentLabel.put(tripId, consginmentLabelStatus);
			}
			else {
				consginmentLabelStatus = tripConsignmentLabel.get(tripId);
				if (!consginmentLabelStatus.containsKey(shipmentNo)) {
					List<ConsignmentLabel> labelList = new ArrayList<ConsignmentLabel>();
					ConsignmentLabel label = getLabel(shipmentNo, labelId, labelType, status,nodeId, parentLabelId);
					labelList.add(label);
					consginmentLabelStatus.put(shipmentNo, labelList);
				} else {
					List<ConsignmentLabel> labelList = consginmentLabelStatus.get(shipmentNo);
					ConsignmentLabel label = getLabel(shipmentNo, labelId, labelType, status,nodeId, parentLabelId);
					labelList.add(label);
				}
			}
		}

		return tripConsignmentLabel;
	}

	private ConsignmentLabel getLabel(String shipmentNo, String labelId, String labelType, String status,
									  String nodeId, String parentLabelId) {
		ConsignmentLabel label = new ConsignmentLabel();
		label.setShipmentNo(shipmentNo);
		label.setLabelId(labelId);
		label.setLabelType(labelType);
		label.setStatus(status);
		label.setNodeId(nodeId);
		label.setParentLabelId(parentLabelId);
		return label;
	}

}
