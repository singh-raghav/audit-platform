package com.ril.newcommerce.supplychain.tms.processors;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.SetUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.enums.LabelType;
import com.ril.newcommerce.supplychain.tms.enums.OrderClassification;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.service.OrderDetailsService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate.Labels.Label;

/**
 * B1.Divya
 * 
 */

@Component
public class EvaluateMessage {
	private static final Logger log = LoggerFactory.getLogger(EvaluateMessage.class);

	@Autowired
	TripService tripService;

	@Autowired
	OrderDetailsService orderDetailsService;

	public TripEvent evaluateMessage(Object object, String name) {
		try {
			TripStatusUpdate tripStatus = (TripStatusUpdate) object;

			String tripId = tripStatus.getTripNo();

			Trip trip = tripService.getTrip(tripId);

			List<String> status = new ArrayList<>();
			status.add(OrderStatus.ACTIVE.getValue());

			List<Consignment> consignments = orderDetailsService.getTripOrderDetails(tripId, trip.getSourceNode(),
					status, null, null);

			Set<String> returnShipments = consignments.stream().filter(
					consignment -> OrderClassification.Return.getValue().equals(consignment.getOrderClassification()))
					.map(m -> m.getShipmentNo()).collect(Collectors.toSet());

			if (null == tripStatus.getLabels() && CollectionUtils.isEmpty(returnShipments) ) {
				return TripEvent.CANCEL;
			}

			else if (null == tripStatus.getLabels() && !CollectionUtils.isEmpty(returnShipments) )
				return TripEvent.COMPLETE_LOADING;

			Set<String> inActiveshipments = new HashSet<>();
			Set<String> loadedShipments = new HashSet<>();
			if (null != tripStatus.getLabels() && !CollectionUtils.isEmpty(tripStatus.getLabels().getLabel())) {
				Map<String, List<Label>> loaderLabel = tripStatus.getLabels().getLabel().stream().collect(Collectors
						.groupingBy(Label::getShipmentNo, HashMap::new, Collectors.toCollection(ArrayList::new)));

				for (Entry<String, List<Label>> entry : loaderLabel.entrySet()) {
					boolean isMissing = entry.getValue().stream()
							.filter(m -> LabelType.lookup.contains(m.getLabelType()))
							.allMatch(m -> Constants.YES.equals(m.getLabelMissing()));
					if (isMissing)
						inActiveshipments.add(entry.getKey());
					else
						loadedShipments.add(entry.getKey());
				}

			}

			if (tripStatus.getOrders() != null && !CollectionUtils.isEmpty(tripStatus.getOrders().getOrder()))
				inActiveshipments.addAll(tripStatus.getOrders().getOrder().stream().map(m -> m.getShipmentNo())
						.collect(Collectors.toSet()));

			if (inActiveshipments.containsAll(loadedShipments) && CollectionUtils.isEmpty(returnShipments))
				return TripEvent.CANCEL;

			return TripEvent.COMPLETE_LOADING;

		}

		catch (ValidationException validEx) {
			throw new ValidationException(validEx);
		} catch (Exception e) {
			throw new TripApplicationException(e);
		}
	}
}
