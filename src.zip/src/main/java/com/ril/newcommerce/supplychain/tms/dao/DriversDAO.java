package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.rest.Drivers;

public interface DriversDAO {

	List<Drivers> getAvailableDrivers(String nodeId);

}
