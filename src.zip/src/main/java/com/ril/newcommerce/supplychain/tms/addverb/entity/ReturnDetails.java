package com.ril.newcommerce.supplychain.tms.addverb.entity;

import java.util.List;
//Bean to post return details to SAP
public class ReturnDetails {

	private String tripId;
	private String hubId;
	private String fcID;
	private String vehicle;
	private String deliveryPartner;
	private String date;
	private String comments;
	private List<ReturnedProductDetails> returnedProducts;
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public String getHubId() {
		return hubId;
	}
	public void setHubId(String hubId) {
		this.hubId = hubId;
	}
	public String getFcID() {
		return fcID;
	}
	public void setFcID(String fcID) {
		this.fcID = fcID;
	}
	public List<ReturnedProductDetails> getReturnedProducts() {
		return returnedProducts;
	}
	public void setReturnedProducts(List<ReturnedProductDetails> returnedProducts) {
		this.returnedProducts = returnedProducts;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getVehicle() {
		return vehicle;
	}
	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}
	public String getDeliveryPartner() {
		return deliveryPartner;
	}
	public void setDeliveryPartner(String deliveryPartner) {
		this.deliveryPartner = deliveryPartner;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	


}
