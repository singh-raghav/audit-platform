package com.ril.newcommerce.supplychain.tms.notification;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.util.RestClient;

@Service
public class EmailNotificationService {
	
	private static final Logger log = LoggerFactory.getLogger(EmailNotificationService.class);
	
	@Value("${ne.rest.url}")
	private String neUrl;

	@Value("${ne.transaction.id}")
	private String transactionId;

	@Value("${ne.sourcesystem}")
	private String sourceSystem;

	@Value("${ne.appkey}")
	private String appKey;

	@Value("${ne.appname}")
	private String appName;

	@Value("${ne.enterprise.id}")
	private String enterpriseId;

	@Value("${ne.fromemail}")
	private String fromEmailId;

	@Value("${ne.toemail}")
	private String toEmailId;
	
	@Autowired
	private RestClient restClient;
	
	@Autowired
	private ObjectMapper objectMapper;

	public void postNotificationEmail(String eventType, String eventDetails,
			String subject) throws URISyntaxException, JsonGenerationException, JsonMappingException, IOException {

		log.info("EmailNotificationService: postNotificationEmail method starts.....");

		NotificationRequest neRequest = new NotificationRequest();
		Body requestBody = new Body();
		Notification notification = new Notification();
		NotificationType notificationType = new NotificationType();
		MessageContent messageContent = new MessageContent();
		CommunicationDetails communicationDetails = new CommunicationDetails();
		Header header = new Header();
		FormattedMessage formattedMessage = new FormattedMessage();

		// feeding data to send NE service
		neRequest.setAppName(appName);
		neRequest.setAppKey(appKey);
		neRequest.setEnterpriseId(enterpriseId);

		communicationDetails.setToEmailId(toEmailId);
		communicationDetails.setFromEmail(fromEmailId);
		communicationDetails.setSubject(subject);

		notificationType.setEmail(true);

		formattedMessage.setEmailMessage(eventDetails);

		messageContent.setFormattedMessage(formattedMessage);

		notification.setCommunicationDetails(communicationDetails);
		notification.setNotificationType(notificationType);
		notification.setMessageContent(messageContent);

		requestBody.setNotification(notification);

		header.setDateTime(ZonedDateTime.now().toEpochSecond());
		header.setMessageGroup("INTERNALEVENT");
		header.setMessageType(eventType);
		header.setSourceSystem(Constants.TRIP_APP);
		header.setTransactionId(Constants.TRIP_APP
				+ new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss")
						.format(new Date()));

		neRequest.setBody(requestBody);
		neRequest.setHeader(header);

		String result = (String) restClient.post(neUrl, null, null, neRequest, String.class);
		
		log.info("NE uri is-- {} -Requestbody is--------->>>>>> : {} " , neUrl , objectMapper.writeValueAsString(neRequest) );
		
		log.info("NE response is------------<<<<<<<" + result);
		log.info("EmailNotificationService: postNotificationEmail method ends.....");
	}

}
