package com.ril.newcommerce.supplychain.tms.notification;

public class Notification {
	private String attachmentURLs;

	private CommunicationDetails communicationDetails;

	private NotificationType notificationType;

	private MessageContent messageContent;

	@Override
	public String toString() {
		return " [attachmentURLs = " + attachmentURLs
				+ ", communicationDetails = " + communicationDetails
				+ ", notificationType = " + notificationType
				+ ", messageContent = " + messageContent + "]";
	}

	public String getAttachmentURLs() {
		return attachmentURLs;
	}

	public void setAttachmentURLs(String attachmentURLs) {
		this.attachmentURLs = attachmentURLs;
	}

	public CommunicationDetails getCommunicationDetails() {
		return communicationDetails;
	}

	public void setCommunicationDetails(CommunicationDetails communicationDetails) {
		this.communicationDetails = communicationDetails;
	}

	public NotificationType getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(NotificationType notificationType) {
		this.notificationType = notificationType;
	}

	public MessageContent getMessageContent() {
		return messageContent;
	}

	public void setMessageContent(MessageContent messageContent) {
		this.messageContent = messageContent;
	}

}
