package com.ril.newcommerce.supplychain.tms.dao.impl;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.*;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripIdDetails;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.response.TripAmount;
import com.ril.newcommerce.supplychain.tms.response.TripCountResponse;
import com.ril.newcommerce.supplychain.tms.response.TripLazyLoadResponse;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.Driver;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.Vehicle;
import com.ril.newcommerce.supplychain.tms.util.DestinationNodesDeliveryZoneIds;
import com.ril.newcommerce.supplychain.tms.util.TripUtil;
import com.ril.newcommerce.supplychain.tms.util.Utility;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

/**
 * B1.Divya
 */

@Repository
public class TripsDAOImpl implements TripsDAO {

	private static final Logger log = LoggerFactory.getLogger(TripsDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;


	@Override
	public Map<String, Integer> getTripCountOnTripStatus(List<String> nodeIds, String toDate, String fromDate, String tripId,MovementType mvType, Map<String, Object> filters) {
		log.info("Fetching trip count on status in getTripCountOnTripStatus" );
		StringBuilder queryBuilder=new StringBuilder();
		
		if(null!=filters.get(Constants.INBOUND) && Constants.TRUE.equals(filters.get(Constants.INBOUND).toString()))
			queryBuilder.append(QueryConstants.GET_TRIP_COUNT_ON_STATUS_ON_INBOUND);
		else
			queryBuilder.append(QueryConstants.GET_TRIP_COUNT_ON_STATUS);
		
		Map<String, Integer> queryResult = null;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeIds", nodeIds);
		parameters.addValue("fromDate", fromDate);
		parameters.addValue("toDate", toDate);

		if (!StringUtils.isEmpty(tripId)) {
			tripId = "%" + tripId + "%";
			queryBuilder.append(" AND T.TRIP_ID LIKE :tripId");

			parameters.addValue("tripId", tripId);
		}
		
		if (null!=mvType) {
			queryBuilder.append(" AND T.MOVEMENT_TYPE =:movementType ");
			parameters.addValue("movementType", mvType.getValue());
		}
			
		queryBuilder.append(" GROUP BY T.STATUS");
		
		try {
			queryResult = namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new ResultSetExtractor<Map>() {
				@Override
				public Map extractData(ResultSet rs) throws SQLException, DataAccessException {
					HashMap<String, Integer> mapRet = new HashMap<String, Integer>();
					while (rs.next()) {
						mapRet.put(rs.getString("status"), rs.getInt("trip_count"));
					}
					return mapRet;
				}
			});
		} catch (Exception e) {
			log.error("Exception occured while fetching trip count on status in getTripCountOnTripStatus of TripsDAOImpl ", e);
			throw new TripApplicationException("Exception occured on getTripCountOnTripStatus of TripsDAOImpl", e);
		}
		return queryResult;
	}

	@Override
	public List<TripAdditionalDetail> getTripAdditionalDetails(List<String> tripIds, String key) {
		log.info("Getting trip seal details for tripIds ");
		List<TripAdditionalDetail> queryResult = null;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		StringBuilder query = new StringBuilder( QueryConstants.GET_TRIP_ADDITIONAL_DETAILS);
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("tripId", tripIds);
		if(!StringUtils.isEmpty(key))
		{
		query.append(" AND KEY IN(:key)");
		parameters.addValue("key", key);
		
		}
		
		try {
			queryResult = namedParameterJdbcTemplate.query(query.toString(), parameters, new TripSealMapper());
		} catch (Exception e) {
			log.error("Exception occured while fetching trip seal details in getTripSeals of TripsDAOImpl ", e);
			throw new TripApplicationException("Exception occured on getTripSeals of TripsDAOImpl", e);
		}
		return queryResult;
	}
	
	@Override
	public Map<String,String> getDriverNumber(List<String> tripIds) {
		 Map<String,String> userIdVsMobileNumber = null;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripIds", tripIds);
			
			List<Map<String, Object>> res = namedParameterJdbcTemplate.queryForList(QueryConstants.GET_USER_DETAILS_BY_TRIP,parameters);
			if(CollectionUtils.isNotEmpty(res))
				userIdVsMobileNumber = res.stream().collect(Collectors.toMap(rs-> (String)rs.get("user_name"), rs-> ((String)rs.get("mobile_no"))));
		}
		catch (Exception e) {
			log.error("Exception occurred on fetching userIdVsMobileNumber ids by tripid " + e);
			throw new TripApplicationException("Exception occurred on  fetching userIdVsMobileNumber by tripid ", e);
		}
		return userIdVsMobileNumber;
	}
	
	@Override
	public String getDriverNumberByTrip(String tripId) {
		List<String> mobileNumbers=null;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripIds", Arrays.asList(tripId));
			
			mobileNumbers =  namedParameterJdbcTemplate.query(QueryConstants.GET_USER_DETAILS_BY_TRIP,parameters , (rs,count) -> rs.getString("mobile_no") );
		}		
		catch (Exception e) {
			log.error("Exception occurred on fetching userIdVsMobileNumber ids by tripid " + e);
			throw new TripApplicationException("Exception occurred on  fetching userIdVsMobileNumber by tripid ", e);
		}
		return CollectionUtils.isEmpty(mobileNumbers)?"":mobileNumbers.get(0);
	}

	@Override
	public List<Trip> getTripsInfo(List<String> nodeIds, Map<String,Object> filters) {
		log.info("Inside getTripsInfo of TripsDAOImpl :{} ", nodeIds);
		List<Trip> tripInfo = null;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeIds", nodeIds);
		Integer pageSize= (Integer) filters.get(Constants.PAGE_SIZE);
		Integer pageIndex=(Integer) filters.get(Constants.PAGE_INDEX);
		String tripId=filters.get(Constants.TRIPID) !=null ?filters.get(Constants.TRIPID).toString():null;
		StringBuilder queryBuilder = new StringBuilder();
		if(null!= pageSize && null!=pageIndex)
		{
			int startIndex = 0;
			int endIndex = 0;
			queryBuilder.append("SELECT * FROM (SELECT  V.*, ROW_NUMBER() OVER(ORDER BY MODIFIED_TS DESC) AS SEQNUM  FROM (");
			queryBuilder.append(QueryConstants.GET_TRIPS);

			if(filters.get(Constants.STATUS) !=null && !StringUtils.isEmpty(filters.get(Constants.STATUS).toString()))
			{
				queryBuilder.append(" AND T.STATUS =:status");
				parameters.addValue("status", filters.get(Constants.STATUS).toString());
			}
			if(filters.get(Constants.MOVEMENT_TYPE) !=null && !StringUtils.isEmpty(filters.get(Constants.MOVEMENT_TYPE).toString()))
			{
				queryBuilder.append(" AND T.MOVEMENT_TYPE =:movementType");
				parameters.addValue("movementType", filters.get(Constants.MOVEMENT_TYPE).toString());
			}
			if(!StringUtils.isEmpty(tripId))
			{
				tripId="%" + tripId+"%";
				queryBuilder.append(" AND T.TRIP_ID LIKE :tripId");

				parameters.addValue("tripId", tripId);
			}

			queryBuilder.append(" AND T.CREATED_TS BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
		            +"AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF')");
			queryBuilder.append(") V )  WHERE SEQNUM>= :startIndex AND SEQNUM<= :endIndex");

			 endIndex = Integer.valueOf(pageSize) * Integer.valueOf(pageIndex);
			 startIndex = (endIndex - Integer.valueOf(pageSize)) + 1;
			parameters.addValue("startIndex", startIndex);
			parameters.addValue("endIndex", endIndex);
			parameters.addValue("fromDate", filters.get(Constants.FROM_DATE).toString());
			parameters.addValue("toDate", filters.get(Constants.TO_DATE).toString());
		}
		else
		{
			queryBuilder.append(QueryConstants.GET_TRIPS);
			List<String> statusList=new ArrayList<>();
			statusList.add(TripState.CREATED.getValue());
			statusList.add(TripState.ASSIGNED.getValue());
			queryBuilder.append(" AND T.STATUS IN (:statusList)");
			parameters.addValue("statusList", statusList);

			if (null != filters.get(Constants.FROM_DATE) && !StringUtils.isEmpty(filters.get(Constants.FROM_DATE).toString()) &&
					null != filters.get(Constants.TO_DATE) && !StringUtils.isEmpty(filters.get(Constants.TO_DATE).toString())) {

				queryBuilder.append(" AND T.CREATED_TS BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
						+ "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF')");
				parameters.addValue("fromDate", filters.get(Constants.FROM_DATE).toString());
				parameters.addValue("toDate", filters.get(Constants.TO_DATE).toString());
			}

			if (filters.get(Constants.MOVEMENT_TYPE) != null && !StringUtils.isEmpty(filters.get(Constants.MOVEMENT_TYPE).toString())) {
				queryBuilder.append(" AND T.MOVEMENT_TYPE =:movementType");
				parameters.addValue("movementType", filters.get(Constants.MOVEMENT_TYPE).toString());
			}
		}

		try {
			tripInfo = namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new TripMapper());
		} catch (Exception e) {
			log.error("Exception occured while fetching trips deatils in getTripsInfo of TripsDAOImpl ", e);
			throw new TripApplicationException("Exception occured on getTripsInfo of TripsDAOImpl ", e);
		}

		return tripInfo;
	}

	@Override
	public List<Trip> getTripsInfoWithAmountToBeCollected(List<String> nodeName, Map<String, Object> filters) {

		log.info("Inside getTripsInfoWithAmountToBeCollected for nodeName:{} ", nodeName);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeIds", nodeName);
		Integer pageSize = (Integer) filters.get(Constants.PAGE_SIZE);
		Integer pageIndex = (Integer) filters.get(Constants.PAGE_INDEX);
		StringBuilder queryBuilder = new StringBuilder();

		if (null != pageSize && null != pageIndex) {

			queryBuilder.append("SELECT * FROM (SELECT  V.*, ROW_NUMBER() OVER(ORDER BY MODIFIED_TS DESC) AS SEQNUM  FROM (");
			queryBuilder.append(QueryConstants.GET_TRIPS_JOIN_WAYPOINT);

			if (filters.get(Constants.STATUS) != null && !StringUtils.isEmpty(filters.get(Constants.STATUS).toString())) {
				queryBuilder.append(" AND T.STATUS =:status");
				parameters.addValue("status", filters.get(Constants.STATUS).toString());
			}

			if (filters.get(Constants.MOVEMENT_TYPE) != null && !StringUtils.isEmpty(filters.get(Constants.MOVEMENT_TYPE).toString())) {
				queryBuilder.append(" AND T.MOVEMENT_TYPE =:movementType");
				parameters.addValue("movementType", filters.get(Constants.MOVEMENT_TYPE).toString());
			}

			String tripId = filters.get(Constants.TRIPID) != null ? filters.get(Constants.TRIPID).toString() : null;
			if (!StringUtils.isEmpty(tripId)) {
				tripId = "%" + tripId + "%";
				queryBuilder.append(" AND T.TRIP_ID LIKE :tripId");
				parameters.addValue("tripId", tripId);
			}

			queryBuilder.append(" AND T.CREATED_TS BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
					+ "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF')");

			queryBuilder.append(" group by T.trip_id,T.TYPE,T.SOURCE_NODE,T.PLANNED_START, " +
					"T.PLANNED_END,T.ACTUAL_START,T.ACTUAL_END,T.STATUS,T.ASSIGNED_VEHICLE, " +
					"T.VRN_ID,T.DP_ID,T.DP_NAME,T.CREATED_TS,T.FLEET_TYPE,T.SUGGESTED_VEHICLE_TYPE, T.START_KM, T.END_KM, " +
					"T.SUGGESTED_VEHICLE_NO, T.PLANNED_KM, T.EXTERNAL_REF_ID,T.MODIFIED_TS,T.VERSION,T.CREATED_BY, " +
					"T.MOVEMENT_TYPE  ) V )  WHERE SEQNUM>= :startIndex AND SEQNUM<= :endIndex");

			int endIndex = Integer.valueOf(pageSize) * Integer.valueOf(pageIndex);
			int startIndex = (endIndex - Integer.valueOf(pageSize)) + 1;
			parameters.addValue("startIndex", startIndex);
			parameters.addValue("endIndex", endIndex);
			parameters.addValue("fromDate", filters.get(Constants.FROM_DATE).toString());
			parameters.addValue("toDate", filters.get(Constants.TO_DATE).toString());

			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			try {
				return namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new TripDetailsWaypointsAmountMapper());
			} catch (Exception e) {
				log.error("Exception occurred on getTripsInfoWithAmountToBeCollected call. ", e);
				throw new TripApplicationException("Exception occurred on getTripsInfoWithAmountToBeCollected call. ", e);
			}
		}
		return new ArrayList<>();
	}

	@Override
	public List<Trip> getTripsInfoWithAmountCollected(List<String> nodeName, Map<String, Object> filters) {

		log.info("Inside getTripsInfoWithAmountCollected for nodeName:{} ", nodeName);

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeIds", nodeName);
		Integer pageSize = (Integer) filters.get(Constants.PAGE_SIZE);
		Integer pageIndex = (Integer) filters.get(Constants.PAGE_INDEX);
		StringBuilder queryBuilder = new StringBuilder();

		if (null != pageSize && null != pageIndex) {

			queryBuilder.append("SELECT * FROM (SELECT  V.*, ROW_NUMBER() OVER(ORDER BY MODIFIED_TS DESC) AS SEQNUM  FROM (");
			queryBuilder.append(QueryConstants.GET_TRIPS_JOIN_ADDITIONAL_DETAILS);

			if (filters.get(Constants.STATUS) != null && !StringUtils.isEmpty(filters.get(Constants.STATUS).toString())) {
				queryBuilder.append(" AND T.STATUS =:status");
				parameters.addValue("status", filters.get(Constants.STATUS).toString());
			}

			if (filters.get(Constants.MOVEMENT_TYPE) != null && !StringUtils.isEmpty(filters.get(Constants.MOVEMENT_TYPE).toString())) {
				queryBuilder.append(" AND T.MOVEMENT_TYPE =:movementType");
				parameters.addValue("movementType", filters.get(Constants.MOVEMENT_TYPE).toString());
			}

			String tripId = filters.get(Constants.TRIPID) != null ? filters.get(Constants.TRIPID).toString() : null;
			if (!StringUtils.isEmpty(tripId)) {
				tripId = "%" + tripId + "%";
				queryBuilder.append(" AND T.TRIP_ID LIKE :tripId");
				parameters.addValue("tripId", tripId);
			}

			queryBuilder.append(" AND T.CREATED_TS BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
					+ "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF')");

			queryBuilder.append(" ) V )  WHERE SEQNUM>= :startIndex AND SEQNUM<= :endIndex");

			int endIndex = Integer.valueOf(pageSize) * Integer.valueOf(pageIndex);
			int startIndex = (endIndex - Integer.valueOf(pageSize)) + 1;
			parameters.addValue("startIndex", startIndex);
			parameters.addValue("endIndex", endIndex);
			parameters.addValue("fromDate", filters.get(Constants.FROM_DATE).toString());
			parameters.addValue("toDate", filters.get(Constants.TO_DATE).toString());

			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			try {
				return namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new TripDetailsWaypointsAmountMapper());
			} catch (Exception e) {
				log.error("Exception occurred on getTripsInfoWithAmountCollected call. ", e);
				throw new TripApplicationException("Exception occurred on getTripsInfoWithAmountCollected call. ", e);
			}
		}
		return new ArrayList<>();
	}

	@Override

	public List<Trip> getInboundTrips(List<String> nodeIds,Map<String,Object> filters) {
		log.info("Inside getInboundTrips of TripsDAOImpl :{} ", nodeIds);
		List<Trip> tripInfo = null;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT * FROM (SELECT  V.*, ROW_NUMBER() OVER(ORDER BY TRIP_ID) AS SEQNUM  FROM (");
		queryBuilder.append(QueryConstants.GET_INBOUND_TRIPS);
		String tripId=filters.get(Constants.TRIPID) !=null ?filters.get(Constants.TRIPID).toString():null;
		int startIndex = 0;
		int endIndex = 0;
		endIndex = Integer.valueOf((Integer)filters.get(Constants.PAGE_SIZE)) * Integer.valueOf((Integer)filters.get(Constants.PAGE_INDEX));
		startIndex = (endIndex - (Integer)filters.get(Constants.PAGE_SIZE)) + 1;
		parameters.addValue("nodeIds", nodeIds);
		parameters.addValue("fromDate", filters.get(Constants.FROM_DATE));
		parameters.addValue("toDate", filters.get(Constants.TO_DATE));
		parameters.addValue("startIndex", startIndex);
		parameters.addValue("endIndex", endIndex);
		parameters.addValue("status", (List<String>)filters.get(Constants.STATUS));

		if(filters.get(Constants.MOVEMENT_TYPE) !=null && !StringUtils.isEmpty(filters.get(Constants.MOVEMENT_TYPE).toString()))
		{
			queryBuilder.append(" AND T.MOVEMENT_TYPE=:movementType ");
			parameters.addValue("movementType",filters.get(Constants.MOVEMENT_TYPE).toString());
			
			if(MovementType.FTL.getValue().equals(filters.get(Constants.MOVEMENT_TYPE).toString()))
			{
				queryBuilder.append(" and TS.ACTUAL_DISPATCH is null ");
			}
			
		}
			if(!StringUtils.isEmpty(tripId))
			{
				tripId="%" + tripId+"%";
				queryBuilder.append(" AND T.TRIP_ID LIKE :tripId");

				parameters.addValue("tripId", tripId);
			}

			queryBuilder.append(" ORDER BY T.MODIFIED_TS DESC ) V ) WHERE SEQNUM>= :startIndex AND SEQNUM<= :endIndex");

		try {
			tripInfo = namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new TripMapper());
		} catch (Exception e) {
			log.error("Exception occured while fetching inbound trips deatils in getTripsInfo of TripsDAOImpl ", e);
			throw new TripApplicationException("Exception occured on getInboundTrips of TripsDAOImpl ", e);
		}

		return tripInfo;
	}

	@Override
	public Map<String, List<String>> getNumberOfChildTrips(List<String> tripIds) {
		log.info("Getting child trip Ids for  tripIds in getNumberOfChildTrips()");
		Map<String, List<String>> tripWithChildTrip = new HashMap<>();
		if (!tripIds.isEmpty()) {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripIds", tripIds);

			try {
				tripWithChildTrip = namedParameterJdbcTemplate.query(QueryConstants.GET_CHILD_ROUTE_ID_COUNT,
						parameters, new TripHierarchyMapper());
			} catch (Exception e) {
				log.error("Exception occured while fetching child trips in getNumberOfChildTrips of TripsDAOImpl ", e);
				throw new TripApplicationException("Exception occured on getNumberOfChildTrips of TripsDAOImpl ", e);
			}
		}
		return tripWithChildTrip;
	}

	@Override
	public Map<String, List<String>> getChildTripIds(List<String> referenceIds) {
		log.info("Getting child trip Ids for  tripIds in getNumberOfChildTrips()");
		Map<String, List<String>> tripWithChildTrip = new HashMap<>();
		if (!referenceIds.isEmpty()) {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("referenceIds", referenceIds);

			try {
				tripWithChildTrip = namedParameterJdbcTemplate.query(QueryConstants.GET_CHILD_TRIP_IDS,
						parameters, new TripHierarchyMapper());
			} catch (Exception e) {
				log.error("Exception occured while fetching child trips in getNumberOfChildTrips of TripsDAOImpl ", e);
				throw new TripApplicationException("Exception occured on getNumberOfChildTrips of TripsDAOImpl ", e);
			}
		}
		return tripWithChildTrip;
	}

	@Override
	public Trip getTripById(String tripId) {
		HashMap<String,Object> filter =  new HashMap<String, Object>();
		filter.put(Constants.TRIPID , tripId);

		List<Trip>  trips = getTrip(filter);
		if(!CollectionUtils.isEmpty(trips))
			return trips.get(0);

		return null;
	}

	public List<Trip> getTrip(HashMap<String, Object> filter) {

		List<Trip> trips = null;
		StringBuilder query= new StringBuilder(QueryConstants.GET_TRIP);
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		if(!filter.isEmpty()){
		if (null!=filter.get(Constants.TRIPID)  && null!=filter.get(Constants.STATUS)  && null!=filter.get(Constants.NODE_ID) ) {
			query.append(" WHERE TRIP_ID=:tripId AND STATUS NOT IN (:status) AND SOURCE_NODE=:node ");
			parameters.addValue("tripId",filter.get(Constants.TRIPID) );
			parameters.addValue("status", filter.get(Constants.STATUS));
			parameters.addValue("node", filter.get(Constants.NODE_ID));
		} else if (null!=filter.get(Constants.STATUS)  && null!=filter.get(Constants.NODE_ID)) {
			query.append(" WHERE STATUS NOT IN (:status) AND SOURCE_NODE=:node ");
			parameters.addValue("status", filter.get(Constants.STATUS));
			parameters.addValue("node", filter.get(Constants.NODE_ID));
		} else if (null!=filter.get(Constants.TRIPID) && null!=filter.get(Constants.NODE_ID)) {
			query.append(" WHERE TRIP_ID=:tripId AND SOURCE_NODE=:node ");
			parameters.addValue("tripId", filter.get(Constants.TRIPID));
			parameters.addValue("node", filter.get(Constants.NODE_ID));
		} 
		else if(null!=filter.get(Constants.STATUS) && null!=filter.get(Constants.INTERVAL) && null!=filter.get(Constants.UNIT) && null!=filter.get(Constants.FETCH_SIZE_JOB))
		{
			query.append("WHERE STATUS=:status AND MODIFIED_TS < SYSTIMESTAMP - numtodsinterval(:interval,:unit) AND ROWNUM<=:fetchSize ORDER BY MODIFIED_TS ASC");
			parameters.addValue("status", filter.get(Constants.STATUS));
			parameters.addValue("interval", filter.get(Constants.INTERVAL));
			parameters.addValue("unit", filter.get(Constants.UNIT));
			parameters.addValue("fetchSize", filter.get(Constants.FETCH_SIZE_JOB));
		}
		else if (null!=filter.get(Constants.TRIPID)) {
			query.append(" WHERE TRIP_ID=:tripId");
			parameters.addValue("tripId", filter.get(Constants.TRIPID));
		} else if (null!=filter.get(Constants.NODE_ID)) {
			query.append(" WHERE SOURCE_NODE=:node");
			parameters.addValue("node", filter.get(Constants.NODE_ID));
		}
		else if (null!=filter.get(Constants.FLOWNAME) && null!=filter.get(Constants.REFERENCEID)) {
			query.append(" WHERE FLOW_NAME=:flowName AND EXTERNAL_REF_ID IN (:referenceId)");
			parameters.addValue("flowName",  filter.get(Constants.FLOWNAME));
			parameters.addValue("referenceId",  filter.get(Constants.REFERENCEID));
		}
		}
		try {
				trips = namedParameterJdbcTemplate.query(query.toString(), parameters, new TripMapper());

		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on getTrip of TripsDAOImpl", e);
		}

		return trips;
	}

	@Override
	public void updateTripStatus(String tripId, TripState status) {

		try {
			jdbcTemplate.update(QueryConstants.UPDATE_TRIP_STATUS, status.getValue(), tripId );
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updateTripStatus of TripsDAOImpl ", e);
		}
	}

	@Override
	public void updateStartKm(String tripId, double startKM,String modifiedBy) {

		try {
			jdbcTemplate.update(QueryConstants.UPDATE_START_KM, startKM,modifiedBy, tripId );
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating startKM. ", e);
		}
	}

	@Override
	public void updateEndKm(String tripId, Double endKM,String modifiedBy) {

		try {
			jdbcTemplate.update(QueryConstants.UPDATE_END_KM, endKM, modifiedBy, tripId );
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating EndKM ", e);
		}
	}


	@Override
	public void insertTripAdditionalDetails(List<TripAdditionalDetail> additionalDetails) {

		try {
			jdbcTemplate.batchUpdate(
					QueryConstants.ADD_TRIP_ADDITIONAL_DETAILS,
					new BatchPreparedStatementSetter() {

						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {
							ps.setString(1,additionalDetails.get(i).getTripId());
							ps.setString(2,additionalDetails.get(i).getNodeId());
							ps.setString(3,additionalDetails.get(i).getKey());
							ps.setString(4,additionalDetails.get(i).getValue());
						}

						@Override
						public int getBatchSize() {
							return additionalDetails.size();
						}
					});

		}
		catch (Exception e) {
			throw new TripApplicationException("Exception occured on inserting the trip additional details ", e);
		}

	}

	@Override
	public void updateDriverDetails(String tripId, Driver driver, Vehicle vehicle,String modifiedBy) {

		try {
			jdbcTemplate.update(QueryConstants.UPDATE_DRIVER_DETAILS, vehicle.getVehicleNo(),driver.getDriverId(),driver.getDriverName(),
					vehicle.getFleetType().toUpperCase(),vehicle.getVehicleType(),vehicle.getVrnId(),modifiedBy ,tripId);

		} catch (Exception e) {
			log.error("Exception occured on updating vehicle , driver details : " + e);
			throw new TripApplicationException("Exception occured on updating driver , vehicle details "+ e);
		}
	}

	@Override
	public void updateVehicleDetails(String tripId, String vehicleId, String driverId , String driverName ,String userId) {

		try {
			jdbcTemplate.update(QueryConstants.UPDATE_VEHICLE_DETAILS,vehicleId,driverId,driverName,userId,tripId);

		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating driver , vehicle details ", e);
		}
	}

	@Override
	public List<String> getVehicleAssignmentStatus(List<String> vehicleIds) {

		List<String> vehicleStatus=null;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("vehicles", vehicleIds);

			vehicleStatus = namedParameterJdbcTemplate.query(QueryConstants.GET_VEHICLE_ASSIGNMENT, parameters,
					(ResultSet rs, int rowNum) -> rs.getString(Constants.VECHICLE_NO));


		}catch (Exception e) {
			throw new TripApplicationException("Exception on fetching vehicle status ", e);
		}

		return vehicleStatus;

	}

	@Override
	public void insertEvent(TripEventInput event) {
		try {

			jdbcTemplate.update(QueryConstants.LOG_TRIP_EVENT,event.getTripId() , event.getNodeId(),event.getAction().name()
					,event.getFlowName(),event.getEventCreationTime(),event.getModifiedBy());

		} catch (Exception e) {
			throw new DataProcessingException("Exception occured on logging trip event..", e);
		}

	}

	@Override
	public void insertToTrip(Trip trip,TripIdDetails tripIdDetails,int count) {
		try {
			if(count>0)
			{
			tripIdDetails.setSequence(tripIdDetails.getSequence()+1);
			String tripId=Utility.createTripId(trip.getSourceNode(), tripIdDetails.getTripDate(), tripIdDetails.getSequence(),trip.getMovementType());
			trip.setTripId(tripId);
			jdbcTemplate.update(QueryConstants.INSERT_TO_TRIP, new PreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, trip.getTripId());
					ps.setString(2, trip.getTripType());
					ps.setString(3, trip.getSourceNode());
					ps.setTimestamp(4, trip.getPlannedStartTime());
					ps.setTimestamp(5, trip.getPlannedEndTime());
					ps.setString(6, trip.getStatus());
					ps.setString(7, trip.getFleetType().toUpperCase());
					ps.setString(8, trip.getVehicleModel());
					ps.setString(9, trip.getSuggestedVehicleNo());
					ps.setString(10, trip.getExternalReferenceId());
					ps.setString(11, trip.getFlowName());
					ps.setString(12, trip.getCreatedBy());
					ps.setString(13, trip.getCreatedBy());
					ps.setBigDecimal(14, trip.getLatitude());
					ps.setBigDecimal(15, trip.getLongitude());
					ps.setDouble(16, trip.getPlannedKm());
					ps.setTimestamp(17, new Timestamp(System.currentTimeMillis()));
					ps.setTimestamp(18, new Timestamp(System.currentTimeMillis()));
					ps.setString(19, trip.getMovementType().getValue());
				}


			});
			}
			else
			{
				throw new DataProcessingException("Got Exception while inserting trip details in trip table");
			}
		}
		catch (DuplicateKeyException dupKeyEx)
		{
			log.warn("Entry already exists for primary id {} ");
			insertToTrip( trip, tripIdDetails, count-1);
		}
		catch (Exception e) {
			throw new DataProcessingException("Got Exception while inserting trip details in trip table", e);
		}

	}


	@Override
	public int getTripCountOnGivenDate(String date, String nodeId,String movementType) {

		String query = QueryConstants.GET_COUNT_OF_TRIPS_ON_GIVEN_DAY;
		Integer count = null;
		try {
			count = jdbcTemplate.queryForObject(query, new Object[] { date,nodeId,movementType }, Integer.class);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on getting trip in getTripCountOnGivenDay..", e);
		}
		return count;
	}

	@Override
	public void batchUpdateToTripHierarchy(String tripId, Set<String> associatedTripIds,String system) {
		try {
			if (null != tripId && null != associatedTripIds && !associatedTripIds.isEmpty()) {
				List<Object[]> inputList = new ArrayList<>();
				for (String associatedNextTripId : associatedTripIds) {
					Object[] tmp = { tripId, associatedNextTripId,system };
					inputList.add(tmp);
				}
				jdbcTemplate.batchUpdate(QueryConstants.INSERT_TO_TRIP_HIERARCHY, inputList);
				log.info("Trip hierarchy details  successfully inserted  in trip_hierarachy table",tripId);
			}
		}

		catch(DuplicateKeyException dupKeyEx)
		{
			log.warn("Entry already exists for primary id {} ",tripId);
			insertToTripHierarchy(tripId,associatedTripIds,system);
		}catch (Exception e) {
			throw new DataProcessingException("Exception occured during inserting data in trip sequence", e);

		}

	}

	@Override
	public void batchUpdateToTripHierarchy(Set<String> prevTripIds, String tripId,String system) {
		try {
			if (null != tripId && !CollectionUtils.isEmpty(prevTripIds)) {
				List<Object[]> inputList = new ArrayList<>();
				for (String prevTripId : prevTripIds) {
					Object[] tmp = { prevTripId, tripId,system };
					inputList.add(tmp);
				}
				jdbcTemplate.batchUpdate(QueryConstants.INSERT_TO_TRIP_HIERARCHY, inputList);
				log.info("Trip hierarchy details  successfully inserted  in trip_hierarachy table",tripId);
			}
		}

		catch(DuplicateKeyException dupKeyEx)
		{
			log.warn("Entry already exists for primary id {} ",tripId);
			insertToTripHierarchy(prevTripIds,tripId,system);
		}catch (Exception e) {
			throw new DataProcessingException("Exception occured during inserting data in trip sequence", e);

		}

	}

	@Override
	public void insertToTripHierarchy(String tripId, Set<String> associatedTripIds,String system) {
		try {
			if (null != tripId && null != associatedTripIds && !associatedTripIds.isEmpty()) {

				for (String associatedNextTripId : associatedTripIds) {
					try {
						jdbcTemplate.update(QueryConstants.INSERT_TO_TRIP_HIERARCHY, tripId, associatedNextTripId,
								system);
					} catch (DuplicateKeyException dupKeyEx) {
						log.warn("Entry already exists for primary id {} ", tripId);
					}
				}
				log.info("Trip hierarchy details  successfully inserted  in trip_hierarachy table",tripId);
			}
		}
		catch (Exception e) {
			throw new DataProcessingException("Exception occured during inserting data in trip sequence", e);

		}
	}
		@Override
		public void insertToTripHierarchy(Set<String> prevTripIds,String tripId,String system) {
			try {
				if (null != tripId && null != prevTripIds && !prevTripIds.isEmpty()) {
					for (String prevTripId : prevTripIds) {
						try{
						jdbcTemplate.update(QueryConstants.INSERT_TO_TRIP_HIERARCHY, prevTripId, tripId,
								system);
						}
						catch (DuplicateKeyException dupKeyEx) {
							log.warn("Entry already exists for primary id {} ", tripId);
						}
					}
					log.info("Trip hierarchy details  successfully inserted  in trip_hierarachy table",tripId);
				}
			}
			catch (Exception e) {
				throw new DataProcessingException("Exception occured during inserting data in trip sequence", e);

			}
		}

	@Override
	public int updateTripModifedDetails(String flowName,String modifiedBy, String tripId) {
		int result=0;
		try {
			result=jdbcTemplate.update(QueryConstants.UPDATE_TRIP_MODIFIED_DETAILS, flowName,modifiedBy, tripId );
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating startKM. ", e);
		}
		return result;
	}


	@Override
	public String getInitialAmount(String tripId) {
		String initialAmount=null;
		try{
			String  query=QueryConstants.GET_INITIAL_AMOUNT;
			initialAmount=jdbcTemplate.queryForObject(query, new Object[] { tripId}, String.class);
		}
		catch (Exception e) {
			log.error("Exception in getting initial amount ", e);
		}
		return initialAmount;
	}


	@Override
	public List<Trip> getTripDetails(List<String> tripIds) {
		List<Trip> trip = null;
		String query = QueryConstants.GET_LIST_OF_TRIP;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("tripId", tripIds);
		try {
			trip = namedParameterJdbcTemplate.query(query, parameters,new TripMapper());
		} catch (Exception e) {
			e.printStackTrace();

		}
		return trip;
	}

	@Override
	public void updateFcTripDetailsOnSettlement(String tripId, Double endKm, String flowName,String modifiedBy) {
		try {
			jdbcTemplate.update(QueryConstants.UPDATE_FCTRIP_DETAILS_ONSETTLE, endKm ,modifiedBy,flowName, tripId );
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating details on fc settlement ", e);
		}

	}

	@Override
	public void updateReturnItems(List<ReconcileArticle> reconcileArticles, String nodeId, String tripId) {
		try {
			if(null!=nodeId && null!=tripId && null!=reconcileArticles) {
				List<Object[]> inputList = new ArrayList<>();
				for(ReconcileArticle reconArt:reconcileArticles) {
					Object[] tmp = { reconArt.getUpdateQuantity(), nodeId,  reconArt.getOrderId(), reconArt.getArticleId(), reconArt.getPrimeLineNo()};
					inputList.add(tmp);
				}
				jdbcTemplate.batchUpdate(QueryConstants.UPDATE_RETURN_ITEM, inputList);
			}
		} catch(Exception ex) {
			log.error("Exception occured during updating received quantity for return_items ", ex);
			throw new DataProcessingException("Exception occured during updating received quantity for return_items ", ex);
		}

	}

	@Override
	public void updateActualArrival(String tripId, String nodeId,Timestamp arrivalTime,String flowname) {

		try {
			jdbcTemplate.update(QueryConstants.UPDATE_TRIP_SEQUENCE_ACTUAL_ARRIVAL, arrivalTime, flowname,flowname,tripId,nodeId);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating arrival time of trip", e);
		}
	}

	@Override
	public void updateActualDispatch(String tripId, String nodeId,Timestamp dispatchTime,String flowname) {

		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			StringBuilder query = new StringBuilder(QueryConstants.UPDATE_TRIP_SEQUENCE_ACTUAL_DISPATCH);
			parameters.addValue("dispatchTime", dispatchTime,Types.TIMESTAMP);
			parameters.addValue("tripId", tripId);
			parameters.addValue("flowname", flowname);
			if(!StringUtils.isEmpty(nodeId))
			{
				query.append(" AND NODE_ID=:nodeId " );
				parameters.addValue("nodeId", nodeId);
			}
			
			namedParameterJdbcTemplate.update(query.toString(),parameters);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating dispatch time of trip", e);
		}
		log.info("dispatch time updated for trip :{} ", tripId);
	}

	@Override
	public void updateTripAdditionalDetails(TripAdditionalDetail additionalDetails) {
		log.info("updating trip additional details for trip id : {} " ,additionalDetails.getTripId());
		try {
			jdbcTemplate.update(QueryConstants.UPDATE_ADDITIONAL_DETAILS, additionalDetails.getValue(), additionalDetails.getTripId(),additionalDetails.getKey(),additionalDetails.getNodeId());
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating trip additional details", e);
		}
	}

	@Override
	public String getEwayBillStatus(String tripId) {

		List<TripAdditionalDetail> additionalDetails =getTripAdditionalDetails(Arrays.asList(tripId), Constants.EWAYBILL);

		if(!CollectionUtils.isEmpty(additionalDetails)) {
			TripAdditionalDetail additionalDetail = additionalDetails.get(0);
			return additionalDetail.getValue();
		}

		return null;
	}




	@Override
	public void deleteTripAdditionalDetails(String tripId, String nodeId, String key) {

		log.info("Deleting additional information : tripId -  {} , nodeid -{} , key - {}    " , tripId , nodeId,key );

		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripId", tripId);
			parameters.addValue("key",key );
			parameters.addValue("nodeId", nodeId);
			namedParameterJdbcTemplate.update(QueryConstants.DELETE_ADDITIONAL_DETAILS, parameters);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured during deleting additional details ", e);
		}
	}

	@Override
	public void deleteTripAdditionalDetailsByTrip(String tripId, List<String> key) {

		log.info("Deleting additional information by trip id : tripId -  {} , nodeid -{} , key - {}    " , tripId ,key );

		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripId", tripId);
			parameters.addValue("key",key);
			namedParameterJdbcTemplate.update(QueryConstants.DELETE_ADDITIONAL_DETAILS_BY_TRIP, parameters);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured during deleting additional details by trip ", e);
		}
	}

	@Override
	public void updateTripVersion(String tripId,String flowName,String modifedBy) {

		try {
			jdbcTemplate.update(QueryConstants.UPDATE_TRIP_VERSION,flowName,modifedBy, tripId);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on updating trip version", e);
		}
	}

	@Override
	public void deassociateTripHierarchy(Map<String,String> tripIds) {
		try {
			List<Object[]> inputList = new ArrayList<Object[]>();
			for (Entry<String, String> entry:tripIds.entrySet()) {
				Object[] tmp = { entry.getKey(), entry.getValue() };
				inputList.add(tmp);
			}
			jdbcTemplate.batchUpdate(QueryConstants.DEASSOCIATE_TRIP_HIERARCHY,inputList);
		} catch (Exception e) {
			log.error("Exception occured on updating trip hierarchy", e);
			throw new TripApplicationException("Exception occured on updating trip hierarchy", e);
		}

	}
	@Override
	public List<Map<String, Object>> getActualDispatchTime(String tripId) {

		try {
			 return jdbcTemplate.queryForList(QueryConstants.GET_ACTUAL_DISPATCH_TIME, tripId);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured on getting actual dispatch time", e);
		}

	}

    @Override
    public List<TripLazyLoadResponse> getTripDetailsForGivenOrders(String shipmentNo, String nodeId) {

        if (StringUtils.isBlank(shipmentNo)) {
            return new ArrayList<>();
        }

        StringBuilder query = new StringBuilder(QueryConstants.GET_TRIPS_FOR_GIVEN_SHIPMENT);
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("shipmentNo", shipmentNo);

        try {
            return new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource()).query(query.toString(), parameters, new TripLazyLoadResponseMapper(nodeId));
        } catch (Exception e) {
            throw new TripApplicationException("Exception on getTripDetailsForGivenOrders ", e);
        }
    }

	@Override
	public List<String> getDeliveredOrders(String tripId) {
		List<String> orderIds=null;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("tripId", tripId);
			orderIds = namedParameterJdbcTemplate.query(QueryConstants.GET_DELIVERED_ORDERS, parameters, (ResultSet rs, int rowNum) -> rs.getString(Constants.FWD_ORDER_ID));
		}catch (Exception e) {
			throw new TripApplicationException("Exception on fetching delivered orders from waypoint_updates ", e);
		}
		return orderIds;
	}

	@Override
	public List<ReconcileArticle> getReturnItems(List<String> orderIds) {
		List<ReconcileArticle>  returnItems = null;
		String query = QueryConstants.GET_RETURN_ITEM;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("orderId", orderIds);
		try {
			returnItems = namedParameterJdbcTemplate.query(query, parameters,new ReturnArticlesMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception ocurred getting return Items ", e);
		}
		return returnItems;
	}

    @Override
    public int getStartedTripCount(String shipmentNo) {

        try {

            List<Trip> trips = jdbcTemplate.query(QueryConstants.GET_TRIPS_SHIPMENT, new Object[]{shipmentNo}, new TripMapper());
            for (Trip trip : trips) {

                if (TripUtil.isShuttleTrip(trip.getMovementType()) && TripUtil.tripSettled(trip.getStatus())) {
                    return 1;
                } else if (TripUtil.isFcTrip(trip.getTripType()) && TripUtil.isTripStarted(trip.getStatus())) {
                    return 1;
                }
            }

            return 0;

        } catch (Exception e) {
            throw new TripApplicationException("Exception occurred while getting started trip count.", e);
        }
    }

    @Override
    public List<Trip> getTripsTobeCancelled(List<String> tripStatus,List<String> shipmentstatus,String unit,int fetchSize,int interval)
    {
    	List<Trip> trips=new ArrayList<>();
    	String query = QueryConstants.GET_TRIPS_TOBE_CANCELLED;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("status", tripStatus);
		parameters.addValue("interval", interval);
		parameters.addValue("unit", unit);
		parameters.addValue("fetchSize", fetchSize);
		parameters.addValue("shipmentStatus", shipmentstatus);
		parameters.addValue("movementType", MovementType.FTL.getValue());
		try {
			trips = namedParameterJdbcTemplate.query(query, parameters,new TripMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception ocurred getting trips for cancellation  ", e);
		}
    	return trips;
    	
    }

	@Override
	public List<TripAmount> getTripAmount(String fromDate, String toDate, String nodeId) {

		if (StringUtils.isBlank(fromDate) || StringUtils.isBlank(toDate)) {
			throw new ValidationException("Start Date and end date is required");
		}

		List<TripAmount> tripAmounts;
		String query = QueryConstants.COLLECTED_AMOUNT_FOR_TRIP;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("fromDate", fromDate);
		parameters.addValue("toDate", toDate);
		parameters.addValue("nodeId", nodeId);

		try {
			tripAmounts = namedParameterJdbcTemplate.query(query, parameters, new TripAmountMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception ocurred getting getTripAmount  ", e);
		}
		return tripAmounts;
	}

	@Override
	public List<TripCountResponse> getTripCountForSDP(List<String> nodeIds, List<String> sdpIds, String fromDate, String toDate) {

		StringBuilder query = new StringBuilder(QueryConstants.TRIP_COUNT_SDP);
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("sdpIds", sdpIds);

		if (!StringUtils.isBlank(fromDate) && !StringUtils.isBlank(toDate)) {
			parameters.addValue("fromDate", fromDate);
			parameters.addValue("toDate", toDate);
			query.append(" AND t.created_ts BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
					+ "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF') ");
		}

		query.append(" group by ts.node_id");

		List<TripCountResponse> tripCountResponseList;
		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
			tripCountResponseList = namedParameterJdbcTemplate.query(query.toString(), parameters, new TripCountResponseMapper());
		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred while executing getTripCountForSDP ", e);
		}
		log.info("TRIP_COUNT_SDP query has been executed successfully, fetched Rows: {} ", tripCountResponseList.size());
		return tripCountResponseList;
	}

	@Override
	public Integer getLoadedOrderCount(String tripId) {
		StringBuilder queryBuilder = new StringBuilder(QueryConstants.GET_LOADED_ORDER_COUNT);
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("tripId", tripId);

		Map result = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource()).query(queryBuilder.toString(), parameters, new ResultSetExtractor<Map>() {
			@Override
			public Map extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map mapRet = new HashMap();
				while (rs.next()) {
					mapRet.put("total", rs.getInt("total"));
				}
				return mapRet;
			}
		});
		return (Integer) result.get("total");

	}

	@Override
	public Integer getLoadedHUCount(String tripId) {
		StringBuilder queryBuilder = new StringBuilder(QueryConstants.GET_LOADED_HU_COUNT);
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("tripId", tripId);

		Map result = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource()).query(queryBuilder.toString(), parameters, new ResultSetExtractor<Map>() {
			@Override
			public Map extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map mapRet = new HashMap();
				while (rs.next()) {
					mapRet.put("total", rs.getInt("total"));
				}
				return mapRet;
			}
		});
		return (Integer) result.get("total");

	}

	public Map<String, DestinationNodesDeliveryZoneIds> getDeliveryZonesAndDestinationNodesForTrips(List<String> nodeIds, Map<String,Object> filters){
		log.info("Inside getDeliveryZonesAndDestinationNodesForTrips of TripsDAOImpl :{} ", nodeIds);
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("nodeIds", nodeIds);

		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append(QueryConstants.GET_DELIVERY_ZONE_IDS_DESTINATION_NODES_FOR_TRIPS);
		List<String> statusList=new ArrayList<>();
		statusList.add(TripState.CREATED.getValue());
		statusList.add(TripState.ASSIGNED.getValue());
		queryBuilder.append(" AND T.STATUS IN (:statusList)");
		parameters.addValue("statusList", statusList);

		if (null != filters.get(Constants.FROM_DATE) && !StringUtils.isEmpty(filters.get(Constants.FROM_DATE).toString()) &&
				null != filters.get(Constants.TO_DATE) && !StringUtils.isEmpty(filters.get(Constants.TO_DATE).toString())) {

			queryBuilder.append(" AND T.CREATED_TS BETWEEN TO_TIMESTAMP(:fromDate,'YYYY-MM-DD HH24:MI:SS:FF') "
					+ "AND TO_TIMESTAMP(:toDate,'YYYY-MM-DD HH24:MI:SS:FF')");
			parameters.addValue("fromDate", filters.get(Constants.FROM_DATE).toString());
			parameters.addValue("toDate", filters.get(Constants.TO_DATE).toString());
		}
		if (filters.get(Constants.MOVEMENT_TYPE) != null && !StringUtils.isEmpty(filters.get(Constants.MOVEMENT_TYPE).toString())) {
			queryBuilder.append(" AND T.MOVEMENT_TYPE =:movementType");
			parameters.addValue("movementType", filters.get(Constants.MOVEMENT_TYPE).toString());
		}
		try {
			return getDeliveryZonesAndDestinationNodesResults(queryBuilder.toString(), parameters);
		} catch (Exception e) {
			log.error("Exception occured while fetching trips deatils in getDeliveryZonesAndDestinationNodesForTrips" +
						" of TripsDAOImpl ", e);
			throw new TripApplicationException("Exception occured on getDeliveryZonesAndDestinationNodesForTrips of" +
													" TripsDAOImpl ", e);
		}
	}

	private Map<String, DestinationNodesDeliveryZoneIds>  getDeliveryZonesAndDestinationNodesResults(
																String query, MapSqlParameterSource parameters){
		Map<String, DestinationNodesDeliveryZoneIds> result = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource()).query(query, parameters, new ResultSetExtractor<Map>() {
			@Override
			public Map<String, DestinationNodesDeliveryZoneIds> extractData(ResultSet rs) throws SQLException,
					DataAccessException {
				Map<String, DestinationNodesDeliveryZoneIds> mapRet = new HashMap<>();
				while (rs.next()) {
					String tripId = rs.getString("trip_id");
					String deliveryZoneId = rs.getString("delivery_zone_id");
					String destinationNodeId = rs.getString("node_id");
					if (StringUtils.isNotEmpty(tripId)) {
						mapRet.putIfAbsent(tripId, DestinationNodesDeliveryZoneIds.builder().build());
						mapRet.get(tripId).setTripId(tripId);
						if (StringUtils.isNotEmpty(deliveryZoneId)) {
							mapRet.get(tripId).getDeliveryZoneIds().add(deliveryZoneId);
						}
						if (StringUtils.isNotEmpty(destinationNodeId)) {
							mapRet.get(tripId).getDestinationNodes().add(destinationNodeId);
						}
					}
				}
				return mapRet;
			}
		});
		return result;
	}
}
