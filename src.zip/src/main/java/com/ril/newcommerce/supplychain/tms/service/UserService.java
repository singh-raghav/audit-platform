package com.ril.newcommerce.supplychain.tms.service;

import org.springframework.http.ResponseEntity;

import com.ril.newcommerce.supplychain.tms.entity.UserDetails;
import com.ril.newcommerce.supplychain.tms.entity.rest.oldtripapp.OldTripAppCreateUserRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.oldtripapp.OldTripAppCreateUserResponse;
import com.ril.newcommerce.supplychain.tms.entity.rest.sterling.SterlingCreateUserRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.CreateUserRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.UpdateUserRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.UserDetailResponse;
import com.ril.newcommerce.supplychain.tms.entity.rest.userdetails.UserListResponse;
import com.ril.newcommerce.supplychain.tms.enums.UserRoles;

public interface UserService {

    UserDetails findUserByUserName(String userName);

    void saveUser(UserDetails userDetails);

    UserDetailResponse getUserDetails(String userName);

    void createUser(CreateUserRequest createUserRequest, String userId) throws  Exception;

    ResponseEntity<Object> callSterlingApi(SterlingCreateUserRequest sterlingCreateUserRequest);

    OldTripAppCreateUserResponse callOldTripAppCreateUserApi(OldTripAppCreateUserRequest oldTripAppCreateUserRequest);

    String reprocessUser(String id) throws  Exception;

    void updateUser(UpdateUserRequest updateUserRequest) throws  Exception;

    void resetPassword(UpdateUserRequest updateUserRequest, String managerId) throws Exception;

    void changePassword(String token, UpdateUserRequest updateUserRequest) throws Exception;

    UserListResponse getUserList(String nodeId, String clusterId, boolean ignoreNodeIdHeader,
                                 boolean ignoreDeletedUsers, Integer pageSize, Integer pageIndex,
                                 String searchKeyword, UserRoles userRole, String lastLoginFrom,
                                 String lastLoginTo) throws Exception;


}
