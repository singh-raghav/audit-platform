package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.rest.GrabSettlement;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.tibco.grab.entity.Status;
import com.ril.newcommerce.supplychain.tms.tibco.grab.entity.TripSettlement;
import com.ril.newcommerce.supplychain.tms.util.RestClient;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
B1.Divya
*/

@Service
@Qualifier(Constants.PUBLISH_TO_GRAB)
public class PublishToGrab implements Processor {
	
	private static final Logger log = LoggerFactory.getLogger(PublishToGrab.class);
	
	@Autowired
	private RestClient restClient;
	
	@Value("${grab.settlement.url}")
	private String grabUrl;
	
	@Value("${grab.publicKey}")
	private String publicKey;
	
	@Value("${grab.secretKey}")
	private String secretKey;
	
	@Autowired
	private TripService tripService;
	
	@Autowired 
	private JAXBContextConfig jAXBContextConfig;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {
				
		StringReader reader = new StringReader(((TextMessage) message).getText());
		TripSettlement tripSettlementToGrab =  (TripSettlement) jAXBContextConfig.getJaxbContextInstance(TripSettlement.class).createUnmarshaller().unmarshal(reader);
		
		Trip trip= tripService.getTrip(tripSettlementToGrab.getTripId());
		
		
		if(tripSettlementToGrab.getStatus().equals(Status.SUCCESS) && !trip.getStatus().equals(TripState.SETTLED.getValue()))
		{
			throw new TripApplicationException("Trip state is not yet settled "+ trip.getStatus()+" " + trip.getTripId());
		}
		log.info("Preparing settlement feed to send to grab for tripId {}",trip.getTripId());
		String publishMessage=objectMarshaller(tripSettlementToGrab,TripSettlement.class);
		
		String hashKey=Utility.getHash(publishMessage, secretKey);
		Map<String, String> headers=getHeaders(hashKey);
		
		
		GrabSettlement grabResponse=(GrabSettlement) restClient.post(grabUrl, headers , null, publishMessage,GrabSettlement.class);
		
		if(grabResponse!=null)
			log.info("Grab response after settlement for tripId {} , {}",trip.getTripId(),grabResponse.toString());
		else
			log.info("Grab response after settlement for tripId {} ,{}",trip.getTripId(),grabResponse);
		
	}
	
	private Map<String, String> getHeaders(String hashKey)
	{
		Map<String, String> headers=new HashMap<>();
		headers.put(Constants.PUBLICKEY,publicKey);
		headers.put(Constants.HASHKEY,hashKey);
		headers.put("CONTENT_TYPE", MediaType.APPLICATION_XML.toString());
		
		return headers;
	}
	
	private String objectMarshaller(Object object, Class<?> clz) throws JAXBException 
	{
		StringWriter sw = new StringWriter();
		jAXBContextConfig.getJaxbContextInstance(clz).createMarshaller().marshal(object, sw);
		
		return sw.toString();
	}

}
