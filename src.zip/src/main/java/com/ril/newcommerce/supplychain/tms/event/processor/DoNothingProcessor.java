package com.ril.newcommerce.supplychain.tms.event.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;

/**
 * 
 * @author jeevi.natarajan
 *
 */

@Component
@Qualifier(Constants.DO_NOTHING_PROCESSOR)
@Transactional(rollbackFor=Exception.class)
public class DoNothingProcessor extends BasicProcessor{

	private static final Logger log = LoggerFactory.getLogger(DoNothingProcessor.class);
	
	@Override
	public void processEvent(TripEventInput event, Trip trip) { 
				
		super.processEvent(event, trip);
		log.info("Logged the event : {} " ,trip.getTripId());
		
	}

}
