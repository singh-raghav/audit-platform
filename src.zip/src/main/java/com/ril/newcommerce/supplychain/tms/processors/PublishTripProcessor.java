package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Trip.Orders;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Trip.Orders.Order;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
 * B1.Divya
 */

@Service
@Qualifier("publishTripProcessor")
public class PublishTripProcessor implements Processor {

	private static final Logger log = LoggerFactory.getLogger(PublishTripProcessor.class);

	@Autowired 
	private JAXBContextConfig jAXBContextConfig;
	
	@Autowired
	private TripService tripService;

	@Autowired
	private TripOrdersService tripOrderService;

	@Value("${trip.status.queue}")
	private String queueName;

	@Autowired
	private JMSPublisher jmsPublisher;

	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception {
		try {
			StringReader reader = new StringReader(((TextMessage) message).getText());
			
			TripPublish tripPublishRequest = (TripPublish) jAXBContextConfig.getJaxbContextInstance(TripPublish.class)
					.createUnmarshaller().unmarshal(reader);
			
			String tripId = tripPublishRequest.getTrip().getId();
			int version = tripPublishRequest.getTrip().getVersion();
			boolean isAdhocTrip=tripPublishRequest.getTrip().isIsAdhocTrip();
			if (StringUtils.isBlank(tripId)) {
				throw new ParsingException("TripId cannot be null for creating tripFeed");
			}

			log.info("starting the process to create trip feed for tripId {}", tripId);

			Trip trip = tripService.getTrip(tripId); // get trip info

			validate(trip, version, tripId);


				List<String> status = new ArrayList<>();
				status.add(OrderStatus.ACTIVE.getValue());

				List<TripConsignmentInfo> tripconsignmentInfo = tripOrderService.getTripConsignmentInfo(tripId, status);

				log.info("consignment size {}", tripconsignmentInfo.size());

				com.ril.newcommerce.supplychain.tms.tibco.entity.Trip response = createTripResponse(trip,
						tripconsignmentInfo,isAdhocTrip);

				
					jmsPublisher.publishMessage(queueName, response,
							FlowName.TRIPFEED.getValue(), Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER,
									Constants.BUSINESS_VALUE_ONE, tripId, Constants.BUSINESS_KEY_TWO, Constants.TRIP_TYPE ,
									Constants.BUSINESS_VALUE_TWO, trip.getMovementType().toString(),
							Constants.BUSINESS_KEY_THREE, Constants.FLUID_OR_NON_FLUID,
							Constants.BUSINESS_VALUE_THREE, Constants.NON_FLUID),
							com.ril.newcommerce.supplychain.tms.tibco.entity.Trip.class);

				log.info("published tripfeed response :{}", tripId);
		} 
		catch(ParsingException par)
		{
			throw new ParsingException("Parsing error while parsing publish trip message",par);
		}
		catch (Exception e) {
			log.error("Error while processing trip ", e);
			throw new TripApplicationException("Exception occurred while creating  tripfeed", e);
		}
	}

	

	private com.ril.newcommerce.supplychain.tms.tibco.entity.Trip createTripResponse(Trip trip,
			List<TripConsignmentInfo> tripconsignmentInfo,boolean isAdhocTrip) {
		
		com.ril.newcommerce.supplychain.tms.tibco.entity.Trip tripObj = new com.ril.newcommerce.supplychain.tms.tibco.entity.Trip();
		tripObj.setSourceSystemId(Constants.TRIP_APP);
		tripObj.setStartNodeId(trip.getSourceNode());
		tripObj.setStartNodeLatitude(trip.getLatitude());
		tripObj.setStartNodeLongitude(trip.getLongitude());
		tripObj.setTripId(trip.getTripId());
		tripObj.setVersion(trip.getVersion());
		tripObj.setMovementType(trip.getMovementType().getValue());
		
		if(isAdhocTrip)
			tripObj.setIsAdhocTrip(Constants.YES);
		
		tripObj.setPlannedStart(DateUtility.convertTimeStampToString(trip.getPlannedStartTime(),
				Constants.PUBLISH_DATE_FORMAT));
		tripObj.setPlannedEnd(
				DateUtility.convertTimeStampToString(trip.getPlannedEndTime(), Constants.PUBLISH_DATE_FORMAT));
		if(null !=trip.getAssignedVehicle())
			tripObj.setVehicleId(trip.getAssignedVehicle());
		
		tripObj.setTripStatus(trip.getStatus());
		tripObj.setDeliveryPartner(trip.getAssignedDpId());
		tripObj.setStartKm(trip.getStartKm());
		tripObj.setVehicleModel(trip.getVehicleModel());
		tripObj.setVehicleType(trip.getFleetType());
		String vendorId = tripService.getVendorId(trip.getTripId()); // DB call
		tripObj.setVendorId(vendorId);
		Orders orders = new Orders();
		List<Order> orderList = new ArrayList<>();
		if(!CollectionUtils.isEmpty(tripconsignmentInfo))
		{
		for (TripConsignmentInfo consignment : tripconsignmentInfo) {
			Order order = new Order();
			order.setOrderId(consignment.getOrderId());
			order.setShipmentId(consignment.getShipmentNo());
			order.setOrderType(consignment.getOrderClassification());
			order.setSequence(consignment.getSequenceNo());
						
			if(null !=consignment.getSlotStart())
				order.setSlotStart(DateUtility.convertTimeStampToString(consignment.getSlotStart(),
					Constants.PUBLISH_DATE_FORMAT));
			if(null!=consignment.getSlotEnd())
				order.setSlotEnd(DateUtility.convertTimeStampToString(consignment.getSlotEnd(),
						Constants.PUBLISH_DATE_FORMAT));
			
			order.setDestinationLatitude(consignment.getLatitude());
			order.setDestinationLongitude(consignment.getLongitute());
			Timestamp plannedArrivalInhub = consignment.getPlannedArrival();
			if(null!=plannedArrivalInhub)
			order.setEstimatedArrivalTime(
					DateUtility.convertTimeStampToString(plannedArrivalInhub, Constants.PUBLISH_DATE_FORMAT));
			
			Timestamp plannedDispatchInhub = consignment.getPlanneddispatch();
			if(null!=plannedDispatchInhub)
			order.setEstimatedDepartureTime(
					DateUtility.convertTimeStampToString(plannedDispatchInhub, Constants.PUBLISH_DATE_FORMAT));
			
			order.setDestinationId(consignment.getNextNodeId());
			order.setDeliveryZoneId(consignment.getDeliveryZoneId());
			orderList.add(order);
		}
		}
		orders.setOrder(orderList);
		tripObj.setOrders(orders);
		log.info("Created message for trip publish for tripId {} and  version {}",trip.getTripId(),trip.getVersion());
		return tripObj;
	}



	private void validate(Trip trip,int version,String tripId)
	{
		if(null!=trip)
		{
			 if (trip.getVersion() > version) {
				throw new ValidationException("version received  is lesser than in original staste for tripId"
						+ trip.getTripId() + "version present " + trip.getVersion() + " and reveived " + version);
			}
			else if(trip.getVersion() < version)
			{
				log.info("Sent to retry queue to publish trip trip version {} and received {} ",trip.getVersion(),version);
				throw new TripApplicationException("Trip version in db is " +trip.getVersion() +" and received is "+version);
			}
		}
		else
		{
			log.info("Trip doesn't exisit in DB, sent to retry queue {} ",tripId);
			throw new TripApplicationException("Trip doesn't exisit in DB, sent to retry queue "+tripId);	
		}
		
	}
}
