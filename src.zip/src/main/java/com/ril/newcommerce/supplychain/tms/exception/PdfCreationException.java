package com.ril.newcommerce.supplychain.tms.exception;

public class PdfCreationException extends RuntimeException {
    public PdfCreationException(String message) {
        super(message);
    }

    public PdfCreationException(String s, Exception e) {
        super(s,e);
    }
}
