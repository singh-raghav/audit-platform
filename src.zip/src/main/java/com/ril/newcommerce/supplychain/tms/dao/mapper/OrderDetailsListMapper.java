package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDetailsListMapper implements ResultSetExtractor<List<OrderDetails>> {
    @Override
    public List<OrderDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<OrderDetails> orderDetailsList = new ArrayList<OrderDetails>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            OrderDetails order = new OrderDetails();
            String orderId = rs.getString("ORDER_ID");
            if (orderDetailsList.stream().noneMatch(orderDetails -> orderDetails.getOrderId().equals(orderId))) {
                order.setOrderId(orderId);
                order.setShipmentNo(rs.getString("SHIPMENT_NO"));
                order.setOrderDate(rs.getTimestamp("ORDER_DATE"));
                order.setSlotStartTime(rs.getTimestamp("SLOT_START_TIME"));
                order.setOrderType(rs.getString("ORDER_TYPE"));
                order.setOrderClassification(rs.getString("ORDER_CLASSIFICATION"));
                order.setCustomerPincode(rs.getString("PINCODE"));
                order.setCustomerAddress(rs.getString("ADDRESS"));
                order.setOrderStatus(rs.getString("ORDER_STATUS"));
                order.setModifiedTime(rs.getTimestamp("MODIFIED_TIME"));
                order.setMid(rs.getString("MID"));
                order.setNextNode(rs.getString("NEXT_NODE"));
                order.setShipmentStatus(rs.getString("SHIPMENT_STATUS"));
                order.setTripType(rs.getString("TYPE"));
                order.setCustomerName(rs.getString("NAME"));
                order.setDeliveryZoneId(rs.getString("DELIVERY_ZONE_ID"));
                orderDetailsList.add(order);
            }
        }
        return orderDetailsList;
    }
}
