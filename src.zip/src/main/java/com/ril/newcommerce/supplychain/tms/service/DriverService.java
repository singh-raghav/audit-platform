package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.rest.Drivers;

public interface DriverService {

	List<Drivers> getAvailableDrivers(String nodeId);

}
