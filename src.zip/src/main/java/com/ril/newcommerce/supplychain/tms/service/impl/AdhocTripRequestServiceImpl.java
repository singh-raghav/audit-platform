package com.ril.newcommerce.supplychain.tms.service.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.dao.AdhocTripRequestDAO;
import com.ril.newcommerce.supplychain.tms.entity.AdhocTripRequest;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.service.AdhocTripRequestService;

@Service
public class AdhocTripRequestServiceImpl implements AdhocTripRequestService {
	
	private static final Logger log = LoggerFactory.getLogger(AdhocTripRequestServiceImpl.class);
	
	@Autowired
	AdhocTripRequestDAO adhocTripRequestDAO;

	@Override
	public void insertToAdhocTripRequest(List<AdhocTripRequest> tripRequest) {
		
		try {
			if (!CollectionUtils.isEmpty(tripRequest)) {
				adhocTripRequestDAO.insertToAdhocTripRequest(tripRequest);;
			}
		} catch (Exception e) {
			log.error("Exception occured while inserting adhoc request",e);
			throw new DataProcessingException("Exception occured while inserting adhoc request",e);
		}
		log.debug("successfully adhoc trip request");
	}

	@Override
	public List<AdhocTripRequest> getAdhoctripRequest(List<String> orders, String nodeId, String status) {
		if(!CollectionUtils.isEmpty(orders) && !StringUtils.isBlank(nodeId))
		{
			return adhocTripRequestDAO.getAdhoctripRequest(orders, nodeId, status);
		}
		return null;
	}

	@Override
	public void updateAdhocTripStatus(List<String> orders, String node, String status) {
		if(!CollectionUtils.isEmpty(orders) && !StringUtils.isBlank(node))
		{
			 adhocTripRequestDAO.updateAdhocTripStatus(orders, node, status);
		}
		
	}

}
