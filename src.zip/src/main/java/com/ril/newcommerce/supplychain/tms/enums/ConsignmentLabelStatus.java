package com.ril.newcommerce.supplychain.tms.enums;

/**
B1.Divya
*/

public enum ConsignmentLabelStatus {
	
	CREATED("Created"),
	STAGED("Staged"),
	DAMAGED("Damaged"),
	MISSED("Missed"),
	PICKED("Picked"),
	FC_LOAD_MISSING("FcLoadMissing"),
	FC_LOAD_DAMAGED("FcLoadDamaged"),
	HUB_LOAD_MISSING("HubLoadMissing"),
	HUB_LOAD_DAMAGED("HubLoadDamaged"),
	HUB_UNLOAD_MISSING("HubUnloadMissing"),
	HUB_UNLOAD_DAMAGED("HubUnloadDamaged");
	
	private String value;

	private ConsignmentLabelStatus(String value) {
		this.value = value;
	}
	
	public String value() {
		return value;
	}

}
