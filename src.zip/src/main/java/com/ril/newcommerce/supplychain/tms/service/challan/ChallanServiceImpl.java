package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.dao.InboundDAO;
import com.ril.newcommerce.supplychain.tms.entity.ATSResponse;
import com.ril.newcommerce.supplychain.tms.entity.AssetMasterData;
import com.ril.newcommerce.supplychain.tms.entity.MetaData;
import com.ril.newcommerce.supplychain.tms.entity.ReturnItem;
import com.ril.newcommerce.supplychain.tms.enums.ArticleType;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.ReturnItemQuality;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.service.ChallanService;
import com.ril.newcommerce.supplychain.tms.util.DeliveryChallanConfig;
import com.ril.newcommerce.supplychain.tms.util.RestClient;

@Service
public class ChallanServiceImpl implements ChallanService {

	private static final Logger log = LoggerFactory.getLogger(ChallanServiceImpl.class);

	@Autowired
	private InboundDAO inboundDAO;

	@Autowired
	private RestClient restClient;
	
	@Value("${ats.assettypes.url}")
	private String assetTypesUrl;

	@Autowired
	private DeliveryChallanConfig dcConfig;
	
	
	@Override
	public List<AssetMasterData> getAvailableAssets() {
		try {
			ATSResponse response = (ATSResponse) restClient.get(assetTypesUrl, null, null,ATSResponse.class,null);
			if(response==null) {
				throw new TripApplicationException("Unable to fetch asset information from ATS.");
			}
			
			return response.getData().getEntities();
		}
		catch (Exception e) {
			log.error("Error occurred on fetching assetTypes from ATS " + e);
			throw new TripApplicationException(e.getMessage());	
		}
	}
	
	@Override
	public Set<String> getAvailableOrders(String nodeId,String orderSrcNodeId) {
		try {
			return inboundDAO.getAvailableOrders(nodeId,orderSrcNodeId);
		}
		catch (TripApplicationException e) {
			throw e;
		}
	}
	
	@Override
	public List<MetaData> getReturnItemQualities() {
		try {
			
			List<MetaData> qualities = new ArrayList<>();
			for(ReturnItemQuality quality : ReturnItemQuality.values()) {
				qualities.add(new MetaData(quality.name() , dcConfig.getReturnQualities().get(quality.name())));
			}
			
			return qualities;
		}
		catch (Exception e) {
			throw new TripApplicationException("Unable to fetch qualites");
		}
	}
	
	
	@Override
	public List<String> getAvailableOrdersByOrderId(List<String> orderIds) {
		try {
			return inboundDAO.getAvailableOrdersByOrderId(orderIds);
		}
		catch (TripApplicationException e) {
			throw e;
		}
	}


	@Override
	public List<ReturnItem> getAvailableReturnItems(List<String> returnOrderIds) {
		try {
			return inboundDAO.getReturnItemAccumulated(returnOrderIds);
		}
		catch (TripApplicationException e) {
			throw e;
		}
	}

	@Override
	public Map<String, List<ChallanArticle>> getChallanArticles(List<String> challanIds,String tripId) {
		
		Map<String, List<ChallanArticle>> challanArticlesByOrderId = new HashMap<>();
		try {
			
			challanArticlesByOrderId = inboundDAO.getArticlesByReturnOrderId(challanIds,tripId);
					
			if(MapUtils.isEmpty(challanArticlesByOrderId))
				throw new ValidationException("No article found for given challan Ids : "+challanIds) ;		
			
			List<ChallanArticle> challanArticles = challanArticlesByOrderId.values().stream().flatMap(articles-> articles.stream()).collect(Collectors.toList());	
			List<String> returnOrderIds = challanArticles.stream().map(article->article.getReturnOrderId()).collect(Collectors.toList());
			
			if(CollectionUtils.isEmpty(returnOrderIds))
				throw new ValidationException("No returnOrderIds found! ");
			
			Map<String, List<ReturnItem>> returnItemsByOrderId = inboundDAO.getReturnItemsByReturnOrderId(returnOrderIds,null);
			
			if(MapUtils.isNotEmpty(returnItemsByOrderId)) {
				
				for(Entry<String, List<ReturnItem>> entry : returnItemsByOrderId.entrySet()) {
					
					List<ChallanArticle> articles = challanArticlesByOrderId.get(entry.getKey());
					List<ReturnItem> returnItems = entry.getValue();
					
					if(CollectionUtils.isNotEmpty(articles)) {
						while(articles.size()< returnItems.size()) { // Take deep copy.
							articles.add(new ChallanArticle(articles.get(0)));
						}
						
						//Now size shd be matching
						for(int i=0;i<returnItems.size();i++) {
							ReturnItem item = returnItems.get(i);
							ChallanArticle article = articles.get(i);
							setArticleDetails(article, item);
						}
					}
				}
			}
		}
		catch (TripApplicationException e) {
			log.error("Exception occurred on getting article details : ");
			throw e;
		}
		
		return challanArticlesByOrderId;
		
	}

	@Override
	public boolean hasReturnOrders(String tripId) {
		Map<String,String> orders =inboundDAO.getPDRIdAndSourceNode(tripId);
		return MapUtils.isNotEmpty(orders);
	}

	@Override
	public Map<String, Map<String, Set<String>>> getchallanIdsPerNode(List<String> tripIds) {
		return inboundDAO.getChallanIds(tripIds);
	}

	
	private void setArticleDetails(ChallanArticle article , ReturnItem item) {
		article.setArticleCode(item.getItemId());
		article.setArticleDesc(item.getItemName());
		article.setArticleType(ArticleType.RETURN_ITEM.name());
		article.setHsnCode(item.getHsnCode());
		article.setUOM(item.getUom());
		article.setRate(item.getUnitPrice());
		article.setNodeId(item.getNodeid());
		article.setReturnType(item.getReturnType());
		if(OrderStatus.CR_RETURNED.getValue().equals(article.getReturnType())) 
			article.setQuantity(item.getOrderedQuantity());
		else
			article.setQuantity(item.getInvoicedQuanity());
		
		article.setBaseValue(article.getQuantity() * article.getRate());
	}

	
	
	
	
	
	
	
	
}
