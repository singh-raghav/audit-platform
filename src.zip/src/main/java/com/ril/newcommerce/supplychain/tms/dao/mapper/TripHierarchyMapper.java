package com.ril.newcommerce.supplychain.tms.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ril.newcommerce.supplychain.tms.constants.Constants;

public class TripHierarchyMapper implements ResultSetExtractor<Map<String, List<String>>> {

	@Override
	public Map<String, List<String>> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String, List<String>> tripWithChildTrip = new HashMap<>();
		rs.setFetchSize(Constants.FETCH_SIZE);
		while (rs.next()) {

			if(!tripWithChildTrip.containsKey(rs.getString("TRIP_ID")))
			{
				 List<String> list=new ArrayList<>();
				 list.add(rs.getString("CHILD_TRIP_ID"));
				 tripWithChildTrip.put(rs.getString("TRIP_ID"),list);	 
			}
			else
			{
				List<String> list=tripWithChildTrip.get(rs.getString("TRIP_ID"));
				list.add(rs.getString("CHILD_TRIP_ID"));
			}
			
		
		}
		return tripWithChildTrip;

	}

}
