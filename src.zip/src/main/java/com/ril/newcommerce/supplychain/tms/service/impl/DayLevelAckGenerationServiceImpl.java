package com.ril.newcommerce.supplychain.tms.service.impl;

import com.ril.newcommerce.supplychain.tms.exception.PdfCreationException;
import com.ril.newcommerce.supplychain.tms.pdf.PDFGenerator;
import com.ril.newcommerce.supplychain.tms.pdf.SourceFactory;
import com.ril.newcommerce.supplychain.tms.pdf.model.daylevelack.DayLevelAckInputSource;
import com.ril.newcommerce.supplychain.tms.pdf.model.daylevelack.DayLevelAckXMLReader;
import com.ril.newcommerce.supplychain.tms.response.TripAmountResponse;
import com.ril.newcommerce.supplychain.tms.service.DayLevelAckGenerationService;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;
import com.ril.newcommerce.supplychain.tms.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.xml.transform.Source;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.*;

@Service
public class DayLevelAckGenerationServiceImpl implements DayLevelAckGenerationService {

    @Value("${pdf.daylevelack}")
    private String dayLevelXslSource;

    @Autowired
    private PDFGenerator pdfGenerator;

    private static final Logger log = LoggerFactory.getLogger(DayLevelAckGenerationServiceImpl.class);

    @Override
    public ResponseEntity createPdf(TripAmountResponse tripAmountResponse, String nodeId) {
        String pdfName;
        Source src;
        String errorMessage;

        try {
            src = SourceFactory.getInstance(new DayLevelAckXMLReader(), new DayLevelAckInputSource(tripAmountResponse, nodeId));
            pdfName = DAY_LEVEL_ACK + tripAmountResponse.getDate() + "_" + Utility.generateUniqueFileName() + PDF_EXT;
            pdfGenerator.generate(src, pdfName, dayLevelXslSource);


            return ResponseEntityFactory.getPDFResponseSuccess(pdfName);

        } catch (PdfCreationException e) {

            errorMessage = e.getMessage();
            log.error("{} : {}", errorMessage, e);

        } catch (Exception e) {

            errorMessage = MSG_OBJECT_CREATION_FAILED;
            log.error("Day level Acknowledgement pdf creation failed! {}", e);

        }
        return ResponseEntityFactory.getPDFResponseFailure(errorMessage);
    }
}
