package com.ril.newcommerce.supplychain.tms.pdf.model.hubmanifest;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.pdf.tools.AbstractObjectReader;
import org.apache.commons.lang3.StringUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public class HubManifestXMLReader extends AbstractObjectReader {
    public void parse(InputSource input) throws IOException, SAXException {
        if (input instanceof HubManifestInputSource) {
            parse(((HubManifestInputSource) input).getHubManifest());
        } else {
            throw new SAXException("Unsupported InputSource specified. "
                    + "Must be a ManifestInputSource");
        }
    }

    private void parse(HubManifest hubManifest) throws SAXException {
        if (hubManifest == null) {
            return;
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        //Start the document
        handler.startDocument();

        //Generate SAX events for the ProjectTeam
        generateFor(hubManifest);

        //End the document
        handler.endDocument();
    }

    private void generateFor(HubManifest hubManifest) throws SAXException {
        if (hubManifest == null) {
            throw new NullPointerException("Parameter hubManifest must not be null");
        }
        if (handler == null) {
            throw new IllegalStateException("ContentHandler not set");
        }

        handler.startElement("hubManifest");
        handler.element("deliveryPartner", hubManifest.getDeliveryPartner());
        handler.element("initialAmountGivenTo", hubManifest.getInitialAmountGivenTo());
        handler.element("totalNoOfOrders", hubManifest.getTotalNoOfOrders());
        handler.element("totalNoOfTotes", hubManifest.getTotalNoOfTotes());
        handler.element("tripDate", hubManifest.getTripDate());
        handler.element("tripId", hubManifest.getTripId());
        handler.element("vehicleNo", hubManifest.getVehicleNo());

        HubManifestTripDetailSummary hubManifestTripDetailSummary = hubManifest.getHubManifestTripDetailSummary();
        handler.element("totalBalance", hubManifestTripDetailSummary.getTotalBalance());
        handler.element("totalBillCollected", hubManifestTripDetailSummary.getTotalBillCollected());
        handler.element("totalPrepaidCollected", hubManifestTripDetailSummary.getTotalPrepaidCollected());
        handler.element("totalTotesMissing", hubManifestTripDetailSummary.getTotalTotesMissing());
        handler.element("totalTotesPresent", hubManifestTripDetailSummary.getTotalTotesPresent());

        for (HubManifestTripDetails hubManifestTripDetails : hubManifestTripDetailSummary.getHubManifestTripDetails()) {
            generateFor(hubManifestTripDetails);
        }
        handler.endElement("hubManifest");

    }

    private void generateFor(HubManifestTripDetails hubManifestTripDetails) throws SAXException {

        handler.startElement("hubTripDetails");
        handler.element("balance", hubManifestTripDetails.getBalance());
        handler.element("bill", hubManifestTripDetails.getBill());
        handler.element("collectedAsCash", hubManifestTripDetails.getCollectedAsCash());
        handler.element("collectedThroughCard", hubManifestTripDetails.getCollectedThroughCard());

        handler.element("destinationDetails", StringUtils.join(Arrays.stream(StringUtils.split(hubManifestTripDetails.getDestinationDetails(), ",")).filter(s -> !StringUtils.isBlank(s)).collect(Collectors.toList()), ", "));
        handler.element("mop", hubManifestTripDetails.getMop());

        handler.element("prepaid", hubManifestTripDetails.getPrepaid());
        handler.element("slNo", hubManifestTripDetails.getSlNo());
        setTable(hubManifestTripDetails.getDataTable());
        handler.endElement("hubTripDetails");
    }

    private void setTable(List<List<String>> dataTable) throws SAXException {
        for (List<String> row : dataTable) {
            handler.startElement("dataTable");
            handler.element("orderId", StringUtils.isEmpty(row.get(0)) ? Constants.NA : row.get(0));
            handler.element("ewayBillNum", StringUtils.isEmpty(row.get(1)) ? Constants.NA : row.get(1));
            handler.element("presentTote", StringUtils.isEmpty(row.get(2)) ? Constants.NA : row.get(2));
            handler.element("missingTote", StringUtils.isEmpty(row.get(3)) ? Constants.NA : row.get(3));
            handler.element("mop", StringUtils.isEmpty(row.get(4)) ? Constants.NA : row.get(4));
            handler.element("deliveryStatus", StringUtils.isEmpty(row.get(5)) ? Constants.NA : row.get(5));
            handler.element("remarks", Constants.EMPTY_STRING);

            handler.endElement("dataTable");
        }
    }
}
