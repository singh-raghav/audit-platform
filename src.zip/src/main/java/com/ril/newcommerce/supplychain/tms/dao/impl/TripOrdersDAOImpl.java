package com.ril.newcommerce.supplychain.tms.dao.impl;

import com.ril.newcommerce.supplychain.tms.constants.QueryConstants;
import com.ril.newcommerce.supplychain.tms.dao.TripOrdersDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripConsignmentInfoMapper;
import com.ril.newcommerce.supplychain.tms.dao.mapper.TripInfoMapper;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * B1.Divya
 */

@Repository
public class TripOrdersDAOImpl implements TripOrdersDAO {

	private static final Logger log = LoggerFactory.getLogger(TripOrdersDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	TripsDAO tripsDAO;
	

	@Override
	public void insertToTripConsignment(Trip trip) {

		try {
			if (null != trip.getConsignment() && !trip.getConsignment().isEmpty()) {
				List<Object[]> inputList = new ArrayList<>();
				for (Consignment consignment : trip.getConsignment()) {
					Object[] tmp = { trip.getTripId(), consignment.getShipmentNo(), consignment.getNextNodeId(),
							OrderStatus.ACTIVE.getValue(),consignment.getSlotStart(),consignment.getSlotEnd()
							,consignment.getLatitude(),consignment.getLongitute(),consignment.getCreatedBy(),consignment.getModifiedBy(), consignment.getFlowName(),
							new Timestamp(System.currentTimeMillis()),
							new Timestamp(System.currentTimeMillis()),consignment.getDeliveryZoneId() };
					inputList.add(tmp);
				}
				jdbcTemplate.batchUpdate(QueryConstants.INSERT_TO_TRIP_CONSIGNMENTS, inputList);
				
				log.info("Trip consignment details  successfully inserted  in trip_consignment table",trip.getTripId());
			}

		}
		catch (Exception e) {
			throw new DataProcessingException("Exception occured during inserting data in trip consignment", e);

		}

	}

	public void updateShipmentStatus(String status, List<String> orderIds, String modifiedBy,String flowName)
	{
		if (!CollectionUtils.isEmpty(orderIds)) {
			try {
				NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
						jdbcTemplate.getDataSource());
				MapSqlParameterSource parameters = new MapSqlParameterSource();
				parameters.addValue("status", status);
				parameters.addValue("orderIds", orderIds);
				parameters.addValue("modifiedBy", modifiedBy);
				parameters.addValue("flowName", flowName);
				namedParameterJdbcTemplate.update(QueryConstants.UPDATE_SHIPMENT_STATUS, parameters);
			} catch (Exception e) {
				throw new TripApplicationException("Exception occured on updating status of trip consignment ", e);

			}
		}
	}

	@Override
	public int updateShipmentStatus(String status, List<String> shipmentNos, String tripId, String modifiedBy,String flowName,String nodeId,String clauseStatus) {

		int count=0;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append(QueryConstants.UPDATE_SHIPMENT_STATUS_TRIP_CONSIGNMENT);
		if(StringUtils.isEmpty(tripId) && !StringUtils.isEmpty(nodeId))
		{
			parameters.addValue("nodeId", nodeId);	
			queryBuilder.append(" AND TRIP_ID IN(SELECT TRIP_ID FROM TRIP WHERE SOURCE_NODE=:nodeId)");
		}
		if(!StringUtils.isEmpty(tripId) && StringUtils.isEmpty(nodeId))
		{
			parameters.addValue("tripId", tripId);	
			queryBuilder.append(" AND TRIP_ID =:tripId");
		}
		if(!StringUtils.isEmpty(tripId) && !StringUtils.isEmpty(nodeId))
		{
			parameters.addValue("tripId", tripId);
			parameters.addValue("nodeId", nodeId);	
			queryBuilder.append(" AND TRIP_ID IN(SELECT TRIP_ID FROM TRIP WHERE TRIP_ID=:tripId AND SOURCE_NODE=:nodeId)");
		}
		
		if(!StringUtils.isEmpty(clauseStatus))
		{
			parameters.addValue("clauseStatus", clauseStatus);	
			queryBuilder.append(" AND SHIPMENT_STATUS=:clauseStatus ");
		}
		parameters.addValue("status", status);
		parameters.addValue("flowName", flowName);
		parameters.addValue("modifiedBy", modifiedBy);
		parameters.addValue("shipmentNos", shipmentNos);
		
		try {
			count = namedParameterJdbcTemplate.update(queryBuilder.toString(), parameters);
			
		} catch (Exception e) {
			
			throw new TripApplicationException("Exception occured on status of trip consignment ", e);
		}
	
		return count;
	}

	@Override
	public int deleteTripConsignment(List<String> shipmentNos, String nodeId, String status) {
		int result = 0;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("shipmentNos", shipmentNos);
		parameters.addValue("nodeId", nodeId);
		parameters.addValue("status", status);
		try {
			String query = QueryConstants.DELETE_TRIP_CONSIGNMENTS;
			result = namedParameterJdbcTemplate.update(query, parameters);
		} catch (Exception e) {
			throw new TripApplicationException("Exception occured during deleting consignment ", e);
		}
		return result;
	}
	
	@Override
	public List<TripConsignmentInfo> getTripConsignmentInfo(List<String> tripIds, List<String> nodeIds,
			List<String> status, String externalRefId, List<String> shipmentNos,List<String> orderIds)
	{
		List<TripConsignmentInfo> tripConsignment =new ArrayList<>();
		StringBuilder queryBuilder=new StringBuilder();
		queryBuilder.append(QueryConstants.GET_TRIP_CONSIGNMENT_INFO);
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		if(!CollectionUtils.isEmpty(tripIds) && !CollectionUtils.isEmpty(nodeIds) && !CollectionUtils.isEmpty(status)&& StringUtils.isNotBlank(externalRefId) 
				&& !CollectionUtils.isEmpty(shipmentNos))
		{
			parameters.addValue("tripIds", tripIds);
			parameters.addValue("nodeIds", nodeIds);
			parameters.addValue("externalRefId", externalRefId);
			parameters.addValue("status", status);
			parameters.addValue("shipmentNos", shipmentNos);
			queryBuilder.append(" WHERE T.SOURCE_NODE IN(:nodeIds) AND TC.TRIP_ID IN(:tripIds) AND TC.SHIPMENT_STATUS IN(:status) AND TC.SHIPMENT_NO IN(:shipmentNos)");
		}
		else if(!CollectionUtils.isEmpty(tripIds) && !CollectionUtils.isEmpty(nodeIds) && !CollectionUtils.isEmpty(shipmentNos))
		{
			parameters.addValue("tripIds", tripIds);
			parameters.addValue("nodeIds", nodeIds);
			parameters.addValue("shipmentNos", shipmentNos);
			queryBuilder.append(" WHERE T.SOURCE_NODE IN(:nodeIds) AND TC.TRIP_ID IN(:tripIds) AND TC.SHIPMENT_NO IN(:shipmentNos)");
		}
		
		else if(!CollectionUtils.isEmpty(tripIds) && !CollectionUtils.isEmpty(nodeIds) && !CollectionUtils.isEmpty(status))
		{
			parameters.addValue("tripIds", tripIds);
			parameters.addValue("nodeIds", nodeIds);
			parameters.addValue("status", status);
			queryBuilder.append(" WHERE T.SOURCE_NODE IN(:nodeIds) AND TC.TRIP_ID IN(:tripIds) AND TC.SHIPMENT_STATUS IN(:status)");
		}
		
		else if( !CollectionUtils.isEmpty(nodeIds) && !CollectionUtils.isEmpty(shipmentNos) && !CollectionUtils.isEmpty(status))
		{
			parameters.addValue("nodeIds", nodeIds);
			parameters.addValue("shipmentNos", shipmentNos);
			parameters.addValue("status", status);
			queryBuilder.append(" WHERE T.SOURCE_NODE IN(:nodeIds) AND TC.SHIPMENT_NO IN(:shipmentNos) AND TC.SHIPMENT_STATUS IN(:status)");
		}
		else if( !CollectionUtils.isEmpty(nodeIds) && !CollectionUtils.isEmpty(shipmentNos))
		{
			parameters.addValue("nodeIds", nodeIds);
			parameters.addValue("shipmentNos", shipmentNos);
			queryBuilder.append(" WHERE T.SOURCE_NODE IN(:nodeIds) AND TC.SHIPMENT_NO IN(:shipmentNos)");
		}
		else if(StringUtils.isNotBlank(externalRefId))
		{
			parameters.addValue("externalRefId", externalRefId);
			queryBuilder.append(" WHERE  T.EXTERNAL_REF_ID=:externalRefId");
		}
		else if(!CollectionUtils.isEmpty(orderIds))
		{
			parameters.addValue("orderIds", orderIds);
			queryBuilder.append(" WHERE  OD.ORDER_ID IN(:orderIds)");
		}
		
		try {
			tripConsignment = namedParameterJdbcTemplate.query(queryBuilder.toString(), parameters, new TripConsignmentInfoMapper());
		} catch (Exception e) {
			log.error("Exception occured while fetching trip order deatils in getTripsInfo of TripOrdersDAOImpl ", e);
			throw new TripApplicationException("Exception occured on getTripConsignmentInfo of TripOrdersDAOImpl ", e);
		}
		return tripConsignment;
	}

	@Override
	public List<TripConsignmentInfo> getTripConsignmentInfo(String tripId, List<String> status)
	{
		List<TripConsignmentInfo> tripConsignment =new ArrayList<>();
		String query=QueryConstants.GET_TRIP_ORDERS_BY_TRIPID;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		if(!StringUtils.isEmpty(tripId) && !CollectionUtils.isEmpty(status) )
		{
			parameters.addValue("tripId", tripId);
			parameters.addValue("status", status);
		}
		try {
			tripConsignment = namedParameterJdbcTemplate.query(query, parameters, new TripInfoMapper());
		} catch (Exception e) {
			log.error("Exception occured while fetching trip order deatils in getTripConsignmentInfo of TripOrdersDAOImpl by trip id ", e);
			throw new TripApplicationException("Exception occured on getTripConsignmentInfo of TripOrdersDAOImpl by trip id", e);
		}
		return tripConsignment;
	}



	@Override
	public int updateShipments(List<String> shipmentnos, String tripId, String nodeId) {

		int count=0;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append(QueryConstants.UPDATE_SHIPMENTS_TRIP_CONSIGNMENT);
		if(StringUtils.isEmpty(tripId) && !StringUtils.isEmpty(nodeId))
		{
			parameters.addValue("nodeId", nodeId);	
			queryBuilder.append(" AND TRIP_ID IN(SELECT TRIP_ID FROM TRIP WHERE SOURCE_NODE=:nodeId)");
		}
		if(!StringUtils.isEmpty(tripId) && !StringUtils.isEmpty(nodeId))
		{
			parameters.addValue("tripId", tripId);
			parameters.addValue("nodeId", nodeId);	
			queryBuilder.append(" AND TRIP_ID IN(SELECT TRIP_ID FROM TRIP WHERE TRIP_ID=:tripId AND SOURCE_NODE=:nodeId)");
		}
		
		parameters.addValue("shipmentNos", shipmentnos);
		
		try {
			count = namedParameterJdbcTemplate.update(queryBuilder.toString(), parameters);
			
		} catch (Exception e) {
			
			throw new TripApplicationException("Exception occured on status of trip consignment ", e);
		}
	
		return count;
	}

	@Override
	public int deleteTripConsignmentByTripId(List<String> shipmentNos, String tripId) {
		int result = 0;
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				jdbcTemplate.getDataSource());
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("shipmentNos", shipmentNos);
		parameters.addValue("tripId", tripId);
		try {
			String query = QueryConstants.DELETE_TRIP_CONSIGNMENTS_BY_TRIPID;
			result = namedParameterJdbcTemplate.update(query, parameters);
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new TripApplicationException("Exception occured during deleting consignment of method deleteTripConsignmentByTripId", e);
		}
		return result;
	}

	@Override
	public Integer getSuspendedConsignmentsCount(String shipmentNo, String orderId) {

		if (StringUtils.isBlank(shipmentNo) && StringUtils.isBlank(orderId)) {
			return 0;
		}
		String where;
		String param = "";
		if (!StringUtils.isBlank(shipmentNo)) {
			param = shipmentNo;
			where = "  and shipment_no in ( :shipmentNo ) ";
		} else {
			param = orderId;
			where = "  and shipment_no in ( select distinct(shipment_no) from order_details where order_id =:param ) ";
		}
		try {
			Integer count = jdbcTemplate.queryForObject(QueryConstants.SUSPENDED_ORDER_COUNT + where,
					new Object[]{param}, Integer.class);
			return null == count ? 0 : count;

		} catch (Exception e) {
			throw new TripApplicationException("Exception occurred while getting Suspended orders for Shipment" + shipmentNo, e);
		}
	}

}
