package com.ril.newcommerce.supplychain.tms.response;

import lombok.Builder;
import lombok.Data;
import org.xml.sax.InputSource;

import java.util.List;

@Builder
@Data
public class OrderListResponseFluidLoading extends InputSource {
    private List<OrderViewResponseForFluidLoading> orderList;
    private Integer orderCount;
}
