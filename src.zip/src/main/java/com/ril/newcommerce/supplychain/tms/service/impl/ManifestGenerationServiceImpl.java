package com.ril.newcommerce.supplychain.tms.service.impl;

import com.google.common.collect.Lists;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.ConsignmentLabelDAO;
import com.ril.newcommerce.supplychain.tms.dao.ManifestDAO;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.*;
import com.ril.newcommerce.supplychain.tms.entity.rest.Node;
import com.ril.newcommerce.supplychain.tms.enums.*;
import com.ril.newcommerce.supplychain.tms.exception.NetworkCommunicationException;
import com.ril.newcommerce.supplychain.tms.exception.PdfCreationException;
import com.ril.newcommerce.supplychain.tms.pdf.PDFGenerator;
import com.ril.newcommerce.supplychain.tms.pdf.SourceFactory;
import com.ril.newcommerce.supplychain.tms.pdf.builder.HubManifestBuilder;
import com.ril.newcommerce.supplychain.tms.pdf.model.hubmanifest.*;
import com.ril.newcommerce.supplychain.tms.pdf.model.manifest.ManifestInputSource;
import com.ril.newcommerce.supplychain.tms.pdf.model.manifest.ManifestXMLReader;
import com.ril.newcommerce.supplychain.tms.service.ManifestGenerationService;
import com.ril.newcommerce.supplychain.tms.service.NodeService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import com.ril.newcommerce.supplychain.tms.util.ResponseEntityFactory;
import com.ril.newcommerce.supplychain.tms.util.RestClient;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.xml.transform.Source;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.ril.newcommerce.supplychain.tms.constants.Constants.PDF.*;

/**
 *
 * @author Jeevi.Natarajan
 *
 */
@Service
public class ManifestGenerationServiceImpl implements ManifestGenerationService{

	private static final Logger log = LoggerFactory.getLogger(ManifestGenerationServiceImpl.class);


	@Autowired
	private TripsDAO tripDAO;

	@Autowired
	private ManifestDAO manifestDAO;
	
	@Autowired
	private TripService tripService;

	@Autowired
	private NodeService nodeService;

	@Autowired
	private PDFGenerator pdfGenerator;
	
	@Autowired
	private ConsignmentLabelDAO consignmentLabelDAO;

	@Autowired
	private HubManifestBuilder hubManifestBuilder;
	
	@Autowired
	private RestClient restClient;
	
	@Value("${vms.vehicle.url}")
	private String vehicleUrl;
	
	@Value("${pdf.hubManifest}")
	private String hubManifestXsl;
	
	@Value("${pdf.fcManifest}")
	private String fcManifest;

	@Override
	public ResponseEntity getManifest(String tripId, String nodeId) {

		log.info("Fetching manifest for :{} " ,tripId);
		//1. Load Trip
		Trip trip = tripDAO.getTripById(tripId);

		//2. Get Node details
		Node node = nodeService.getNodeDetailsByNodeId(trip.getSourceNode());
		if (node == null) {
			throw new NetworkCommunicationException("Node service is unreachable!!");
		}

		String pdfName;
		Source src;
		String xslSource;
		String errorMessage;
		try {

			if (NodeType.FC.name().equals(node.getNodeType())) {

				FCManifest manifest = getFCManifest(trip, node);
				src = SourceFactory.getInstance(new ManifestXMLReader(), new ManifestInputSource(manifest));
				pdfName = MANIFEST_PDF_PREFIX + manifest.getTripId().trim() + PDF_EXT;
				xslSource = fcManifest;

			} else {

				HubManifest hubManifest = hubManifestBuilder.build(nodeId, tripId);
				src = SourceFactory.getInstance(new HubManifestXMLReader(), new HubManifestInputSource(hubManifest));
				pdfName = MANIFEST_PDF_PREFIX + hubManifest.getTripId().trim() + PDF_EXT;
				xslSource = hubManifestXsl;

			}

			pdfGenerator.generate(src, pdfName, xslSource);
			return ResponseEntityFactory.getPDFResponseSuccess(pdfName);

		}catch (PdfCreationException e){
			errorMessage = e.getMessage();
			log.error("{} : {}", errorMessage, e);
		}
		catch (Exception e) {
			errorMessage = MSG_OBJECT_CREATION_FAILED;
			log.error("{} : {}", errorMessage, e);
		}
		return ResponseEntityFactory.getPDFResponseFailure(errorMessage);

	}

	private FCManifest getFCManifest(Trip trip , Node fc) {

		FCManifest manifest = new FCManifest();

		manifest.setTripId(trip.getTripId());
		manifest.setVechicleNumber(trip.getAssignedVehicle());
		manifest.setVehicleType(trip.getVehicleModel());
		manifest.setDriverName(trip.getAssignedDp());
		manifest.setStartKm(String.valueOf(trip.getStartKm()));
		manifest.setEndKm(String.valueOf(trip.getEndKm()));
		manifest.setMode(trip.getFleetType());
		manifest.setFcName(fc.getNodeId()+"/"+fc.getName());
		
		//Driver mobile number
		manifest.setDriverMobileNumber(tripDAO.getDriverNumberByTrip(trip.getTripId()));
		
		//vendor name
		manifest.setTruckOperator(tripService.getVendorName(trip.getTripId()));
		
		//2. get seal details...
		List<Seal> seals = getSeal(Lists.newArrayList(trip.getTripId()));

		//3. Get the loaded unloaded count.
		List<HubDetail>  hubDetails = manifestDAO.getHubWiseLoadedHUCount(trip.getTripId());
		updateNodeAddress(hubDetails);
		manifest.setHubDetails(hubDetails);

		//4. calculate the total orders , HUs.
		int totalHuCount = 0 , totalLoadedOrderCount=0;
		for(HubDetail hub : hubDetails) {
			totalHuCount += hub.getLoadedHUs().size();
			totalLoadedOrderCount += hub.getLoadedOrders().size();

			//Get the seals;
			if(CollectionUtils.isNotEmpty(seals)) {
				List<Seal> hubSeal = seals.stream()
											.filter(seal->seal.getNodeId().equals(hub.getHubCode()))
											.collect(Collectors.toList());

				String sealStr = "";
				if(CollectionUtils.isNotEmpty(hubSeal))
					sealStr = String.join(" | ", hubSeal.get(0).getSeals());

				hub.setSeals(sealStr);
			}

		}

		manifest.setTotalHUs(totalHuCount);
		manifest.setTotalOrders(totalLoadedOrderCount);

		return manifest;
	}

	private List<Seal> getSeal(List<String> trips) {
		List<TripAdditionalDetail> tripAdditionalDetails = tripDAO.getTripAdditionalDetails(trips, Constants.SEAL);
		Map<String, Seal> stringSealMap = new HashMap<>();
		for (TripAdditionalDetail tripAdditionalDetail : tripAdditionalDetails) {
			String nodeId = tripAdditionalDetail.getNodeId();
			Seal seal = stringSealMap.get(tripAdditionalDetail.getNodeId());
			String sealId = tripAdditionalDetail.getValue();
			if (null != seal) {
				seal.getSeals().add(sealId);
			} else {
				Seal newSeal = new Seal();
				List<String> sealIds = new ArrayList<>();
				sealIds.add(sealId);
				newSeal.setSeals(sealIds);
				newSeal.setNodeId(nodeId);
				stringSealMap.put(nodeId, newSeal);
			}
		}
		return stringSealMap.values().stream().collect(Collectors.toList());
	}

	private void updateNodeAddress(List<HubDetail> hubDetails) {
		try {
			List<String> hubCodeList = hubDetails.stream().map(hubDetail -> hubDetail.getHubCode()).collect(Collectors.toList());

			Map<String, Node> nodeMap = nodeService.getNodesByID(hubCodeList);	

			String location, address, hubCode;
			for (HubDetail hubDetail : hubDetails) {
				hubCode = hubDetail.getHubCode();
				address = nodeMap.get(hubCode).getAddress().toString();
				if (address != null) {
					location = hubCode.trim().concat(", ").concat(address.trim());
					hubDetail.setHubAdderss(location);
				} else {
					hubDetail.setHubAdderss(hubCode);
				}
			}
		} catch (Exception e) {
			log.error("Exception while updating NodeAddress");
		}
	}

	@Override
	public HubManifest getHubManifestDetails(String storeId, String tripId) throws Exception {
        HubManifest hubManifest = new HubManifest();
        List<ManifestOrderDetails> manifestOrderDetails;
        List<String> status = new ArrayList<String>();
        status.add(OrderStatus.ACTIVE.getValue());
        status.add(OrderStatus.RESCHEDULED.getValue());
        String dateFormat = "dd MMM yyyy";
        String errorMessage ="";
        try {
            if ((storeId != null && !storeId.isEmpty()) && (tripId != null && !tripId.isEmpty())) {
            	Trip trip = tripDAO.getTripById(tripId);
            	if(null!=trip && null!=trip.getTripId()) {
					manifestOrderDetails = manifestDAO.getManifestOrders(tripId, status);
					if(!CollectionUtils.isEmpty(manifestOrderDetails)) {
						int serialNo=0;
						hubManifest.setHubManifestTripDetailSummary(getHubManifestOrders( manifestOrderDetails, tripId, storeId));
						hubManifest.setTripId(trip.getTripId());
						hubManifest.setTripDate(DateUtility.convertTimeStampToString(trip.getPlannedStartTime(),dateFormat));
						hubManifest.setVehicleNo(trip.getAssignedVehicle());
						hubManifest.setDeliveryPartner(trip.getAssignedDp());
						groupByDestinationAndSlNo(hubManifest);
						hubManifest.setTotalNoOfOrders(String.valueOf(getTotalNoOfOrders(hubManifest)));
						//BUG 162186 to rewrite Sequence number in sorted order for hub manifest when we do split and merge like sequence was 1,3,4 to sequence 1,2,3
						if(!CollectionUtils.isEmpty(hubManifest.getHubManifestTripDetailSummary().getHubManifestTripDetails())) {
							for(HubManifestTripDetails hubManifestTripDetails:hubManifest.getHubManifestTripDetailSummary().getHubManifestTripDetails()) {
								hubManifestTripDetails.setSlNo(String.valueOf(++serialNo));			
								}							
						}
						return hubManifest;
					}
					else {
						errorMessage = "No shipment found for trip"+tripId;
						}

            	} else {
            		errorMessage ="Trip Details not found for trip"+tripId;
            		}
            }
        } catch (Exception ex) {
			errorMessage = "Exception occurred in getting order details for manifest of trip, "+ex;
          }
        log.error("{}", errorMessage);
		throw new Exception(errorMessage);
	}

	private int getTotalNoOfOrders(HubManifest hubManifest) {
		int total = 0;
		try {
			for (HubManifestTripDetails hubManifestTripDetail : hubManifest.getHubManifestTripDetailSummary().getHubManifestTripDetails()) {
				total += hubManifestTripDetail.getDataTable().size();
			}
			return total;
		} catch (Exception e) {
			log.error("Some issue while calculating order count");
		}
		return 0;
	}

	private HubManifestTripDetailSummary getHubManifestOrders(List<ManifestOrderDetails> manifestOrderDetails, String tripId, String storeId) {
		HubManifestTripDetailSummary hubManifestTripDetailSummary = new HubManifestTripDetailSummary();
		List<HubManifestTripDetails> hubManifestTripDetails = new ArrayList<HubManifestTripDetails>();
		List<String> tripIds = new ArrayList<String>();
		tripIds.add(tripId);
		List<String> sourceNode = new ArrayList<String>();
		sourceNode.add(storeId);
		HashSet<String> missedTotesInTrip = new HashSet<>();
		HashSet<String> missedBagsIntrip = new HashSet<>();
		HashSet<String> missedHusInTrip = new HashSet<>();
		HashSet<String> presentTotesInTrip = new HashSet<>();
		HashSet<String> presentBagsIntrip = new HashSet<>();
		HashSet<String> presentHusInTrip = new HashSet<>();
		double totalBillCollected = 0.0;
		double totalPrepaidCollected = 0.0;
		double totalBalance = 0.0;
		
		Map<String, Map<String, List<ConsignmentLabel>>> tripConsignment = consignmentLabelDAO.getTripConsignmentLabel(tripIds,sourceNode);
		Double amountToBeCollected;
		Double invoiceValue;
		double prepaidAmount;
		String mop;
		for(ManifestOrderDetails manifestOrderDetail:manifestOrderDetails) {
			StringBuilder customerAddress = new StringBuilder();
			HubManifestTripDetails hubManifestTripDetail = new HubManifestTripDetails();
			HashSet<String> missedTotes = new HashSet<>();
			HashSet<String> missedBags = new HashSet<>();
			HashSet<String> missedHus = new HashSet<>();
			HashSet<String> presentTotes = new HashSet<>();
			HashSet<String> presentBags = new HashSet<>();
			HashSet<String> presentHus = new HashSet<>();
			hubManifestTripDetail.setSlNo(String.valueOf(manifestOrderDetail.getSeqNo()));
			hubManifestTripDetail.setOrderDetails(manifestOrderDetail.getOrderId());
			if(null!= manifestOrderDetail.getEwbStatus() && manifestOrderDetail.getEwbStatus().equalsIgnoreCase(EwayBillStatus.GENERATED.value()))
				hubManifestTripDetail.seteWayBillNumber(manifestOrderDetail.getEwbNo());
			amountToBeCollected = manifestOrderDetail.getAmountToBeCollected();
			invoiceValue = manifestOrderDetail.getInvoiceValue();
			if (null != amountToBeCollected && null != invoiceValue) {
				prepaidAmount = invoiceValue - amountToBeCollected;
				totalPrepaidCollected = totalPrepaidCollected + prepaidAmount;
				hubManifestTripDetail.setPrepaid(String.valueOf(prepaidAmount));
				hubManifestTripDetail.setBalance(String.valueOf(amountToBeCollected));
				totalBalance = totalBalance + amountToBeCollected;
				if (!StringUtils.isBlank(mop = manifestOrderDetail.getMop())) {
					hubManifestTripDetail.setMop(mop);
				} else {
					//TODO: This can be removed once consignment_invoice start giving mop
					log.info("consignment_invoice don't have mop");
					hubManifestTripDetail.setMop(getMop(amountToBeCollected, prepaidAmount));
				}
			}
			if (null != invoiceValue) {
				hubManifestTripDetail.setBill(String.valueOf(invoiceValue));
				totalBillCollected = totalBillCollected + invoiceValue;
			}

			customerAddress.append(!StringUtils.isBlank(manifestOrderDetail.getCustomerName())?manifestOrderDetail.getCustomerName()+","+Constants.NEW_LINE:"")
			.append(!StringUtils.isBlank(manifestOrderDetail.getCustomerAddress())?manifestOrderDetail.getCustomerAddress()+","+Constants.NEW_LINE:"")
			.append(!StringUtils.isBlank(manifestOrderDetail.getCustomerPincode())?manifestOrderDetail.getCustomerPincode()+","+Constants.NEW_LINE:"")
			.append(!StringUtils.isBlank(manifestOrderDetail.getPhoneNumber())?"PHONE: "+ manifestOrderDetail.getPhoneNumber():"");
			hubManifestTripDetail.setDestinationDetails(customerAddress.toString());
			if (null !=tripConsignment.get(tripId) &&  null != tripConsignment.get(tripId).get(manifestOrderDetail.getShipmentNo())) {
				for (ConsignmentLabel label : tripConsignment.get(tripId).get(manifestOrderDetail.getShipmentNo())) {
					if (ConsignmentLabelStatus.MISSED.value().equals(label.getStatus())
							|| ConsignmentLabelStatus.DAMAGED.value().equals(label.getStatus())) {
						if (LabelType.TOTE.getValue().equals(label.getLabelType())) {
							missedTotes.add(label.getLabelId());
						} else if (LabelType.BAG.getValue().equals(label.getLabelType())) {
							missedBags.add(label.getLabelId());
						} else if (LabelType.HU.getValue().equals(label.getLabelType())) {
							missedHus.add(label.getLabelId());
						}
					} else {
						if (LabelType.TOTE.getValue().equals(label.getLabelType())) {
							presentTotes.add(label.getLabelId());
						} else if (LabelType.BAG.getValue().equals(label.getLabelType())) {
							presentBags.add(label.getLabelId());
						} else if (LabelType.HU.getValue().equals(label.getLabelType())) {
							presentHus.add(label.getLabelId());
						}
					}
				}
			} 
			
			if(!CollectionUtils.isEmpty(presentTotes) && !CollectionUtils.isEmpty(presentHus))
			    hubManifestTripDetail.setTotesPresent(Stream.concat(presentTotes.stream(), presentHus.stream()).collect(Collectors.toList()));
			else if(!CollectionUtils.isEmpty(presentTotes))
				hubManifestTripDetail.getTotesPresent().addAll(presentTotes);
			else if(!CollectionUtils.isEmpty(presentHus))
				hubManifestTripDetail.getTotesPresent().addAll(presentHus);
			
			if(!CollectionUtils.isEmpty(missedTotes) && !CollectionUtils.isEmpty(missedHus))
			    hubManifestTripDetail.setTotesMissing(Stream.concat(missedTotes.stream(), missedHus.stream()).collect(Collectors.toList()));
			else if(!CollectionUtils.isEmpty(presentTotes))
				hubManifestTripDetail.getTotesMissing().addAll(missedTotes);
			else if(!CollectionUtils.isEmpty(presentHus))
				hubManifestTripDetail.getTotesMissing().addAll(missedHus);			
			missedTotesInTrip.addAll(missedTotes);
			missedBagsIntrip.addAll(missedBags);
			missedHusInTrip.addAll(missedHus);
			presentTotesInTrip.addAll(presentTotes);
			presentBagsIntrip.addAll(presentBags);
			presentHusInTrip.addAll(presentHus);
			hubManifestTripDetails.add(hubManifestTripDetail);
		}
		hubManifestTripDetailSummary.setHubManifestTripDetails(hubManifestTripDetails);
		hubManifestTripDetailSummary.setTotalBillCollected(String.valueOf(totalBillCollected));
		hubManifestTripDetailSummary.setTotalPrepaidCollected(String.valueOf(totalPrepaidCollected));
		hubManifestTripDetailSummary.setTotalBalance(String.valueOf(totalBalance));
		hubManifestTripDetailSummary.setTotalTotesPresent(String.valueOf(presentTotesInTrip.size()+presentHusInTrip.size()));
		hubManifestTripDetailSummary.setTotalTotesMissing(String.valueOf(missedTotesInTrip.size()+missedHusInTrip.size()));
		return hubManifestTripDetailSummary;
	}

	private String getMop(Double amountToBeCollected, double prepaidAmount) {

		if (prepaidAmount > 0 && amountToBeCollected > 0.0) {
			return Constants.MOP_PREPAID_AND_COD;
		} else if (amountToBeCollected <= 0.0) {
			return Constants.MOP_PREPAID;
		} else if (amountToBeCollected > 0) {
			return Constants.MOP_COD;
		} else {
			log.error("Something wrong in finding MOP");
			return "";
		}
	}

	private HubManifest groupByDestinationAndSlNo(HubManifest printTripObject) {

		try {

			Map<String, HubManifestTripDetails> tripDetailsMap = new HashMap<>();

			for (HubManifestTripDetails hubManifestTripDetail : printTripObject.getHubManifestTripDetailSummary().getHubManifestTripDetails()) {
				String destinationDetails = hubManifestTripDetail.getDestinationDetails().concat(hubManifestTripDetail.getSlNo());
				HubManifestTripDetails populated = tripDetailsMap.get(destinationDetails);
				if (populated != null) {
					addToList(populated, hubManifestTripDetail);
				} else {
					addToList(hubManifestTripDetail, hubManifestTripDetail);
					tripDetailsMap.put(destinationDetails, hubManifestTripDetail);
				}
			}

			printTripObject.getHubManifestTripDetailSummary().getHubManifestTripDetails().clear();
            List<HubManifestTripDetails> sortedList = new ArrayList<>();

            for (HubManifestTripDetails value : tripDetailsMap.values()) {
                sortedList.add(value);
            }

            Collections.sort(sortedList);
            printTripObject.getHubManifestTripDetailSummary().getHubManifestTripDetails().addAll(sortedList);

		} catch (Exception e) {
			return printTripObject;
		}
		return printTripObject;
	}

	private void addToList(HubManifestTripDetails populated, HubManifestTripDetails received) {

		List<String> dataRow = new ArrayList<>();
		dataRow.add(received.getOrderDetails());
		dataRow.add(received.geteWayBillNumber());
		dataRow.add(String.join(",", received.getTotesPresent()));
		dataRow.add(String.join(",", received.getTotesMissing()));
		dataRow.add(received.getMop());
		dataRow.add(received.getDeliveryStatus());
		dataRow.add(received.getRemarks());

		populated.getDataTable().add(dataRow);

	}

}


