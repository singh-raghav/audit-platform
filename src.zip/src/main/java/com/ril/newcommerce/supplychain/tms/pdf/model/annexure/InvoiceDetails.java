package com.ril.newcommerce.supplychain.tms.pdf.model.annexure;

public class InvoiceDetails {
    private String invoiceNum;
    private String orderNum;
    private String eWayBillNum;
    private String invoiceDate;
    private String invoiceValue;
    private String customerName;
    private String cnNumber;
    private String countOfTotes;
    private String countOfBags;

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getInvoiceNum() {
        return invoiceNum;
    }

    public void setInvoiceNum(String invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public String geteWayBillNum() {
        return eWayBillNum;
    }

    public void seteWayBillNum(String eWayBillNum) {
        this.eWayBillNum = eWayBillNum;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getInvoiceValue() {
        return invoiceValue;
    }

    public void setInvoiceValue(String invoiceValue) {
        this.invoiceValue = invoiceValue;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCnNumber() {
        return cnNumber;
    }

    public void setCnNumber(String cnNumber) {
        this.cnNumber = cnNumber;
    }

    public String getCountOfTotes() {
        return countOfTotes;
    }

    public void setCountOfTotes(String countOfTotes) {
        this.countOfTotes = countOfTotes;
    }

    public String getCountOfBags() {
        return countOfBags;
    }

    public void setCountOfBags(String countOfBags) {
        this.countOfBags = countOfBags;
    }
}
