package com.ril.newcommerce.supplychain.tms.event.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripIdDetails;
import com.ril.newcommerce.supplychain.tms.enums.EwayBillStatus;
import com.ril.newcommerce.supplychain.tms.enums.FleetType;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.enums.TripType;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanCreator;
import com.ril.newcommerce.supplychain.tms.service.challan.ChallanRequest;
import com.ril.newcommerce.supplychain.tms.service.impl.CreateTrip;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;

@Component
@Qualifier(Constants.RETURN_SHUTTLE_TRIP_PROCESSOR_RETURN)
public class ReturnShuttleTripProcessor implements IUpdateOnlyProcessor{
	
	private static final Logger log = LoggerFactory.getLogger(ReturnShuttleTripProcessor.class);
	
	@Autowired
	private TripService tripService;
	
	@Autowired
	private CreateTrip createTrip;
	
	@Autowired
	private ChallanCreator challanCreator;

	@Override
	public void processEvent(TripEventInput event, Trip trip) {
    	createShuttleTrip(event, trip);
    	log.info("Shuttle trip for return orders is {}: ",trip.getTripId());
        event.setTripId(trip.getTripId());
        event.getChallanRequest().setTripId(trip.getTripId());
        event.getChallanRequest().setNodeId(event.getNodeId());
        event.getChallanRequest().setUserId(event.getModifiedBy());
        generateDeliveryChallan(event.getChallanRequest());
	}

	private void generateDeliveryChallan(ChallanRequest challanRequest) {
		challanCreator.createDeliveryChallan(challanRequest);
	}

	private void createShuttleTrip(TripEventInput event, Trip trip) {
		trip.setTripType(TripType.HUB_FC.getValue());
		trip.setSourceNode(event.getNodeId());
		trip.setPlannedStartTime(DateUtility.getCurrentDate(Constants.DATE_FORMAT));
		trip.setPlannedEndTime(DateUtility.getCurrentDate(Constants.DATE_FORMAT));
		trip.setStatus(TripState.CREATED.getValue());
		trip.setFleetType(FleetType.MARKET.getValue());
		trip.setExternalReferenceId(UUID.randomUUID().toString());
		trip.setFlowName(event.getFlowName());
		trip.setCreatedBy(event.getModifiedBy());
		trip.setMovementType(MovementType.SHUTTLE);		
		TripIdDetails tripIdDetails = getTripDate(DateUtility.convertTimeStampToString(trip.getPlannedStartTime(), Constants.DATE_FORMAT),event.getNodeId(),MovementType.SHUTTLE.getValue());
		setTripSequence(event,trip);
		createTrip.createShuttleTrip(trip, getTripAdditionalDetails(trip), null, null, null, tripIdDetails);			
	}

	private TripAdditionalDetail getTripAdditionalDetails(Trip trip) {
		TripAdditionalDetail additionalDetails = new TripAdditionalDetail();
		 additionalDetails.setNodeId(trip.getSourceNode());
		 additionalDetails.setKey(Constants.EWAYBILL);
		 additionalDetails.setValue(EwayBillStatus.SUCCESS.value());
		 return additionalDetails;
	}

	private void setTripSequence(TripEventInput event, Trip trip) {
		List<Hub> destinations = new ArrayList<Hub>();
		Hub hub = new Hub();
		hub.setNodeId(event.getDestinationNodeId());
		hub.setSequence(1);
		hub.setPlannedArrivalTime(trip.getPlannedStartTime());
		hub.setPlannedDispatchTime(trip.getPlannedEndTime());
		destinations.add(hub);
		trip.setHub(destinations);
	}

	private TripIdDetails getTripDate( String date, String nodeId,String movementType) {
			int sequence = tripService.getTripCountByGivenDate(date, nodeId,movementType);
			String tripDate = DateUtility.convertStringToFormattedDate(date, Constants.DATE_FORMAT, Constants.FORMAT_FOR_CREATE_TRIP_ID);			
			TripIdDetails deatils=new TripIdDetails();
			deatils.setSequence(sequence);
			deatils.setTripDate(tripDate);
			return deatils;
	}

}
