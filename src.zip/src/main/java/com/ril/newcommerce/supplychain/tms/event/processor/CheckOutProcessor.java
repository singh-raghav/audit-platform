package com.ril.newcommerce.supplychain.tms.event.processor;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.TripsDAO;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;

/**
B1.Divya
*/

@Component
@Qualifier(Constants.CHECK_OUT_PROCESSOR)
public class CheckOutProcessor implements IUpdateOnlyProcessor {

	@Autowired
	TripsDAO tripDAO;
	
	@Override
	public void processEvent(TripEventInput event, Trip trip) {
		
		Timestamp dispatchTime=DateUtility.convertStringToTimeStamp(event.getTripStatusUpdate().getEventTimeStamp(),
				Constants.EXTERNAL_SYSTEMS_DATE_FORMAT);
		tripDAO.updateActualDispatch(event.getTripId(), event.getNodeId(), dispatchTime, event.getFlowName());
		
	}

}
