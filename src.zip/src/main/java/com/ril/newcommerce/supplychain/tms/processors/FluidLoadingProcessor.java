package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;

import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.UnmarshalException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.enums.TripEvent;
import com.ril.newcommerce.supplychain.tms.event.processor.TripEventProcessor;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripStatusUpdate;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;

/**
 Nishant.Kamal
 */

@Service
@Qualifier("fluidLoadingProcessor")
public class FluidLoadingProcessor implements Processor {

    private static final Logger log = LoggerFactory.getLogger(FluidLoadingProcessor.class);

    @Autowired
    @Qualifier(Constants.TRIP_EVENT_PROCESSOR)
    private TripEventProcessor eventProcessor;

    @Autowired
    private JAXBContextConfig jAXBContextConfig;

    @Autowired
    private EvaluateMessage evaluateMessage;

    @Override
    public void processMessage(Message message, String flowName) throws ParsingException, Exception {
        try {
            StringReader reader = new StringReader(((TextMessage) message).getText());
            TripStatusUpdate tripStatus = (TripStatusUpdate) jAXBContextConfig.getJaxbContextInstance(TripStatusUpdate.class).createUnmarshaller().unmarshal(reader);
            log.info("Trip status feed :{} ",message);
            TripEventInput event = prepareEventInput(tripStatus, flowName);
            eventProcessor.processEvent(event);
        } catch (UnmarshalException par) {
            throw new ParsingException("Parsing error while parsing trip status feed", par);
        }
        catch(ValidationException validEx)
        {
            throw new ValidationException(validEx.getMessage());
        }
        catch (Exception e) {
            log.error("Error while processing trip status feed ", e);
            throw new Exception("Exception occurred while parsing trip status feed", e);
        }

    }

    private TripEventInput prepareEventInput(TripStatusUpdate tripStatus,String flowName)
    {
        TripEventInput event = new TripEventInput();

        event.setAction(getTripEvent(flowName));
        event.setEventCreationTime(DateUtility.convertStringToTimeStamp(tripStatus.getEventTimeStamp(),
                Constants.EXTERNAL_SYSTEMS_DATE_FORMAT));
        event.setNodeId(tripStatus.getNodeId());
        event.setTripId(tripStatus.getTripNo());
        event.setModifiedBy(flowName);
        event.setFlowName(flowName);
        event.setTripStatusUpdate(tripStatus);
        return event;
    }

    TripEvent getTripEvent(String flowname)
    {
        FlowName name = FlowName.get(flowname);
        switch (name) {

            case LOADINGSTART:
                return TripEvent.START_LOADING;

            case LOADINGCOMPLETE:
                return TripEvent.COMPLETE_LOADING;

            case UNLOADINGSTART:
                return TripEvent.UNLOADING_START;

            case UNLOADINGCOMPLETE:
                return TripEvent.UNLOADING_COMPLETE;

            case FLUIDLOADING:
                return TripEvent.FLUID_LOADING_COMPLETE;
            default:
                return null;
        }
    }
}

