package com.ril.newcommerce.supplychain.tms.entity.rest.userdetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.ril.newcommerce.supplychain.tms.enums.AccountStatus;
import com.ril.newcommerce.supplychain.tms.enums.UserRoles;
import lombok.*;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateUserRequest  implements Serializable {

    private static final long serialVersionUID = -422876268445093219L;

    @NotNull(message = "username should not blank")
    private String userName;

    @NotNull(message = "password should not blank")
    @Pattern(regexp="(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[@#$%^&+=])(?=\\S+$)[A-Za-z\\d@$!%*#?&]{8,30}$",message="password should contain alphanumeric ,special character and  of length 8-30 char")
    private String secret;

    @NotNull(message = "firstName should not blank")
    private String firstName;

    @NotNull(message = "lastName should not blank")
    private String lastName;

    @NotNull(message = "role should not blank")
    private UserRoles role;

    @NotNull(message = "mobileNo should not blank")
    @Pattern(regexp="(?=.*[0-9])(?=\\S+$)[\\d]{10,10}$",message="mobileNo should contain only digits and of length 10")
    private String mobileNo;

    private String address;

    @NotNull(message = "emailId should not blank")
    @Email(message = "emailId not valid")
    private String emailId;

    private String altContactPerson;
    private String altContactNo;
    private AccountStatus accountStatus;

    List<Cluster> clusters;

    @NotEmpty(message = "State should not blank")
    private String state;

    @Min(value = 100000, message = "Pincode should be 6 digit long")
    @Max(value = 999999, message = "Pincode should be 6 digit long")
    @NotNull(message = "Pincode should not blank")
    private Integer pincode;

}
