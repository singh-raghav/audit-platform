package com.ril.newcommerce.supplychain.tms.dao.mapper;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.response.OrderExcelViewResponse;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderExcelViewResponseMapper implements ResultSetExtractor<List<OrderExcelViewResponse>> {

    @Override
    public List<OrderExcelViewResponse> extractData(ResultSet rs) throws SQLException, DataAccessException {
        List<OrderExcelViewResponse> responses = new ArrayList<>();
        rs.setFetchSize(Constants.FETCH_SIZE);
        while (rs.next()) {
            OrderExcelViewResponse response = new OrderExcelViewResponse();
            response.setDate(rs.getString("DELIVERED_DATE"));
            response.setTripId(rs.getString("TRIP_ID"));
            response.setMid(rs.getString("ID"));
            response.setMerchantName(rs.getString("NAME"));
            response.setOrderId(rs.getString("FWD_ORDER_ID"));
            response.setMop(rs.getString("ORDER_CLASSIFICATION").equalsIgnoreCase(Constants.ORDER_RETURN) ? Constants.NA : rs.getString("MOP"));
            response.setClassification(rs.getString("ORDER_CLASSIFICATION"));
            response.setOrderStatus(rs.getString("ORDER_STATUS"));
            response.setRoundOffAmount(rs.getDouble("ROUND_OFF_AMOUNT"));
            response.setAmountPaid(rs.getDouble("AMOUNT_PAID"));
            response.setVehicleNumber(rs.getString("ASSIGNED_VEHICLE"));
            response.setRiderName(rs.getString("DP_ID"));
            responses.add(response);
        }
        return responses;
    }
}