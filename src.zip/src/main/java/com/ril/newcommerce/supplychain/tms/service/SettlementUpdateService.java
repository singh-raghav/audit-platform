/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.service;

import java.util.List;

import com.ril.newcommerce.supplychain.tms.entity.TripAdditionalDetails;
import com.ril.newcommerce.supplychain.tms.entity.TripSettleDetails;



/**
 * @author Raghav1.Singh
 *
 */
public interface SettlementUpdateService {
	
	public List<TripSettleDetails> getCodOrderDetails(String tripId);
	
	public List<TripAdditionalDetails> getTripAdditionalDetails(String tripId);
	
}
