/**
 * 
 */
package com.ril.newcommerce.supplychain.tms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.dao.SettlementUpdateDao;
import com.ril.newcommerce.supplychain.tms.entity.TripAdditionalDetails;
import com.ril.newcommerce.supplychain.tms.entity.TripSettleDetails;
import com.ril.newcommerce.supplychain.tms.exception.DataProcessingException;
import com.ril.newcommerce.supplychain.tms.service.SettlementUpdateService;

/**
 * @author Raghav1.Singh
 *
 */
@Service
public class SettlementUpdateServiceImpl implements SettlementUpdateService {
	
	private static final Logger log = LoggerFactory.getLogger(SettlementUpdateServiceImpl.class);
	
	@Autowired
	private SettlementUpdateDao settlementUpdateDao;

	@Override
	public List<TripSettleDetails> getCodOrderDetails(String tripId) {
		
		List<TripSettleDetails> list = new ArrayList<TripSettleDetails>();
		try {
			
			list = settlementUpdateDao.getOrderDetails(tripId);
			
		} catch (Exception e) {
			
			log.error("Exception occured while getting COD order details for trip {} ", tripId);
			throw new DataProcessingException("Exception ocurred getting CodOrder details ", e);
			
		}
		
		return list;
	}

	@Override
	public List<TripAdditionalDetails> getTripAdditionalDetails(String tripId) {
		
		List<TripAdditionalDetails> list = new ArrayList<TripAdditionalDetails>();
		
        try {
			
			list = settlementUpdateDao.getTripDetails(tripId);
			
		} catch (Exception e) {
			
			log.error("Exception occured while getting TripAdditional details for trip {} ", tripId);
			throw new DataProcessingException("Exception ocurred getting TripAdditional details ", e);
			
		}
		
		return list;
	}

}
