package com.ril.newcommerce.supplychain.tms.dao;

import java.util.List;
import java.util.Map;

import com.ril.newcommerce.supplychain.tms.entity.Trip;

/**
B1.Divya
*/

public interface TripSequenceDAO {

	public void insertToTripSequence(Trip trip);
	
	public Map<String,List<com.ril.newcommerce.supplychain.tms.entity.Hub>> getTripSequence(List<String> tripIds,List<String> nodeIds);
	
	public void deassociateTripSequence(String tripId, List<String> nodeIds);
}
