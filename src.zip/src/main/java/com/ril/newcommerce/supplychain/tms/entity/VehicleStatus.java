package com.ril.newcommerce.supplychain.tms.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 
 * @author jeevi.natarajan
 *
 */
@Data
@AllArgsConstructor
public class VehicleStatus {
	
	private String vehicleNo;
	private boolean assigned;

}
