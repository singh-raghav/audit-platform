package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import com.ril.newcommerce.supplychain.tms.enums.OrderState;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripSequenceService;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatusFeed;
import com.ril.newcommerce.supplychain.tms.tibco.entity.OrderStatuses;
import com.ril.newcommerce.supplychain.tms.util.CancelTripUtil;
import com.ril.newcommerce.supplychain.tms.util.OrderStatusFeedFactory;

import lombok.extern.slf4j.Slf4j;

@Qualifier(Constants.CANCEL_ORDER_PROCESSOR)
@Slf4j
@Service
public class CancelOrderProcessor implements Processor {

    @Autowired
    private JAXBContextConfig jAXBContextConfig;

    @Autowired
    private TripOrdersService tripOrderService;

    @Value("${tripapp.queue}")
	private String queueName;
	
	@Autowired
	private JMSPublisher jmsPublisher;
    
    @Autowired
    TripSequenceService tripSequenceService;
   
    @Override
    public void processMessage(Message message, String flowName) throws Exception {
        StringReader reader = new StringReader(((TextMessage) message).getText());
        OrderStatuses orderStatus = (OrderStatuses) jAXBContextConfig.getJaxbContextInstance(OrderStatuses.class)
                .createUnmarshaller().unmarshal(reader);
        List<OrderStatuses.OrderStatus.OrderItems.OrderLineItems> lineItems = orderStatus.getOrderStatus().getOrderItems().getOrderLineItems();
        boolean isCancelled = lineItems.stream()
                .allMatch(m -> OrderStatus.CANCELLED.getValue().toUpperCase().equals(m.getOrderLineStatus()));
        if (isCancelled) {
            String orderId = orderStatus.getOrderStatus().getOrderNo();
            log.debug("Cancel order request {}",orderId);
            tripOrderService.updateShipmentStatus(OrderStatus.SUSPEND.getValue(), Lists.newArrayList(orderId), flowName, flowName);
            
            publishOrderStatusFeed(orderId, OrderState.CANCELLED);
        }
    }
	
	
    private void publishOrderStatusFeed(String orderId, OrderState orderState) {
        log.info("Publishing order status update feed for order {}, state {} ", orderId, orderState.getValue());
        OrderDetails orderDetails = new OrderDetails();
        orderDetails.setOrderId(orderId);
        jmsPublisher.inputToQueue(queueName, OrderStatusFeedFactory.getInstance(Lists.newArrayList(orderDetails), orderState, Constants.CANCEL_ORDER_PROCESSOR), FlowName.ORDER_STATUS_UPDATE.getValue(), null, OrderStatusFeed.class);
    }
}
