package com.ril.newcommerce.supplychain.tms.service;

import com.ril.newcommerce.supplychain.tms.entity.rest.LoginRequest;
import com.ril.newcommerce.supplychain.tms.entity.rest.LoginResponse;

public interface LoginService {

    LoginResponse login(LoginRequest loginRequest);
}
