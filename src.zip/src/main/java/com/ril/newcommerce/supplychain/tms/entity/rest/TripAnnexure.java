package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.Date;
import java.util.List;

import lombok.Data;

/**
B1.Divya
*/
@Data
public class TripAnnexure {
	
	private String tripId;
	private String originNode;
	private Date tripDate;
	private String fcName;
	private String vehicleNo;
	private String driverName;
	private List<HubAnnexure> hubAnnexures;
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public String getOriginNode() {
		return originNode;
	}
	public void setOriginNode(String originNode) {
		this.originNode = originNode;
	}
	public Date getTripDate() {
		return tripDate;
	}
	public void setTripDate(Date tripDate) {
		this.tripDate = tripDate;
	}
	public String getFcName() {
		return fcName;
	}
	public void setFcName(String fcName) {
		this.fcName = fcName;
	}
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public List<HubAnnexure> getHubAnnexures() {
		return hubAnnexures;
	}
	public void setHubAnnexures(List<HubAnnexure> hubAnnexures) {
		this.hubAnnexures = hubAnnexures;
	}

}
