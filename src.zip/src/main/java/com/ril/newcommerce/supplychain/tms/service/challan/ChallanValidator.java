package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.entity.AssetMasterData;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
@Service
public class ChallanValidator {
	
	public void validateChallanRequest(ChallanRequest request) {
		
		List<AssetMasterData> validAssets = removeInvalidAssets(request.getAssets());
		request.setAssets(validAssets);
		validateAssetsForNull(request.getAssets());
		validateForAssetOrReturnPresence(request);
		validateForOrderId(request);
	}
	
	private List<AssetMasterData> removeInvalidAssets(List<AssetMasterData> assets) {
		if(CollectionUtils.isNotEmpty(assets)) {
			return assets.stream().filter(asset -> asset.getQuantity()>0).collect(Collectors.toList());
		}
		
		return null;
	}
	
	public void validateAssetsForNull(List<AssetMasterData> assets) {
		if(CollectionUtils.isNotEmpty(assets)) { //assets is allowed to be empty
			assets.forEach(asset -> {
				if(asset.getQuantity()==null)
					throw new ValidationException("Asset count cant be null!");
			});
		}
	}
	
	public void validateForAssetOrReturnPresence(ChallanRequest request) {
		if(CollectionUtils.isEmpty(request.getAssets()) &&  CollectionUtils.isEmpty(request.getReturnItems()))
			throw new ValidationException("Both Assets and ReturnItems can't be empty!");
	}
	
	public void validateForOrderId(ChallanRequest request) {
		if(CollectionUtils.isEmpty(request.getOrderIds()) && CollectionUtils.isNotEmpty(request.getReturnItems()))
			throw new ValidationException("orderIds is Mandatory!");	
	}
	
	public void validateNodeId(String nodeId) {
		if(StringUtils.isEmpty(nodeId))
			throw new ValidationException("Header NodeId is Mandatory!");
	}

}
