package com.ril.newcommerce.supplychain.tms.enums;

/**
B1.Divya
*/

public enum EwayBillStatus {
	
	NOT_GENERATED("NOT GENERATED"), 
	GENERATED("GENERATED"), 
	NOT_REQUIRED ("NOT REQUIRED"),
	FAILED("FAILED"),
	SUCCESS("SUCCESS"),
	PENDING("PENDING");
	
	private String value; 
	private EwayBillStatus(String value) {
		this.value = value;
	}
	
	public String value() {
		return value;
	}

}
