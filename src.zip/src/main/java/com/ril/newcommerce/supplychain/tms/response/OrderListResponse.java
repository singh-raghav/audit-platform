package com.ril.newcommerce.supplychain.tms.response;

import com.ril.newcommerce.supplychain.tms.entity.OrderDetails;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class OrderListResponse {
    private List<OrderViewResponse> orderList;
    private Integer orderCount;
}
