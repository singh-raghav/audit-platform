package com.ril.newcommerce.supplychain.tms.controller;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.impl.TripsDAOImpl;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.InvoicePdfDetail;
import com.ril.newcommerce.supplychain.tms.entity.rest.nodeDetails.NodeDetailsResponse;
import com.ril.newcommerce.supplychain.tms.enums.NodeType;
import com.ril.newcommerce.supplychain.tms.exception.NetworkCommunicationException;
import com.ril.newcommerce.supplychain.tms.response.HuCountResponse;
import com.ril.newcommerce.supplychain.tms.response.OrderListResponse;
import com.ril.newcommerce.supplychain.tms.response.OrderListResponseFluidLoading;
import com.ril.newcommerce.supplychain.tms.response.SDPSummaryResponse;
import com.ril.newcommerce.supplychain.tms.service.ConsignmentLabelService;
import com.ril.newcommerce.supplychain.tms.service.OrderDetailsService;
import com.ril.newcommerce.supplychain.tms.service.PdfDeletionService;
import com.ril.newcommerce.supplychain.tms.service.UserService;
import com.ril.newcommerce.supplychain.tms.service.impl.NodeDetailApiServiceImpl;
import com.ril.newcommerce.supplychain.tms.service.impl.TripServiceImpl;
import com.ril.newcommerce.supplychain.tms.util.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value = "/trip-mgmt/v1/orders")
public class OrderController {
	private static final Logger log = LoggerFactory.getLogger(TripServiceImpl.class);

	@Autowired
	OrderDetailsService orderService;

	@Autowired
	TripsDAOImpl tripsDAO;

	@Autowired
	UserService userService;

	@Autowired
	private HttpServletRequest httpServletRequest;

	@Autowired
	private ConsignmentLabelService consignmentLabelService;

    @Autowired
    private NodeDetailApiServiceImpl nodeDetailApiService;

	@Autowired
	private PdfDeletionService pdfDeletionService;

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getOrders(@RequestParam(value = "status", required = false) String status,HttpServletRequest request)
	{
		List<Consignment> consignments = new ArrayList<>();
		String nodeId = request.getHeader(Constants.NODE_ID);
		
		List<String> statusList = new ArrayList<String>();
		String s[] = status.split("\\|");
		
		statusList = Arrays.asList(s);
		try {
			String tripId=null;
			consignments = orderService.getTripOrderAndAdditionalDetails(null, nodeId, statusList, null,null);
			
			if (consignments.isEmpty())
				return Utility.getSuccessMsg(consignments, ErrorMessages.NO_ORDERS_FOUND);

			return Utility.getSuccessMsg(consignments, null);
		} catch (Exception e) {

			return Utility.getfailureMsg(e.getMessage());
		}
		
	}
	
	@GetMapping(value = "/unplan", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getUnplannedOrdersList(HttpServletRequest request)
	{
		List<Consignment> consignments = new ArrayList<>();
		String nodeId = request.getHeader(Constants.NODE_ID);
		
		List<String> statusList = new ArrayList<String>();
		//String s[] = status.split("\\|");
		
		//statusList = Arrays.asList(s);
		try {
			String tripId=null;
			consignments = orderService.getUnplannedOrderList(nodeId);
			
			if (consignments.isEmpty())
				return Utility.getSuccessMsg(consignments, ErrorMessages.NO_ORDERS_FOUND);

			return Utility.getSuccessMsg(consignments, null);
		} catch (Exception e) {

			return Utility.getfailureMsg(e.getMessage());
		}
		
	}

	@GetMapping(value = "/orderlist", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getTripsList(@RequestParam(value = "pageSize", required = false) Integer pageSize,
														@RequestParam(value = "pageIndex", required = false) Integer pageIndex,
														@RequestParam(value = "fromDate", required = false) String fromDate,
														@RequestParam(value = "toDate", required = false) String toDate,
														@RequestParam(value = "orderId", required = false) String orderId,
														@RequestParam(value = "orderStatus", required = false) String orderStatus,
														@RequestParam(value = "orderType", required = false) String orderType,
														@RequestParam(value = "movementType", required = false) String movementType,
														@RequestParam(value = "destHub", required = false) String destHub,
														HttpServletRequest request) {
		OrderListResponse orderListResponse;
		List<String> nodeIds = Arrays.asList(request.getHeader(Constants.NODE_ID).split("\\|"));

		if (!CollectionUtils.isEmpty(nodeIds) && nodeIds.size() > 1) {
			return Utility.getfailureMsg("Unsupported for multiple nodes.");
		}

		List<String> orderStatuses = new ArrayList<>();
		if (!StringUtils.isEmpty(orderStatus)) {
			orderStatuses = Arrays.asList(orderStatus.split("\\,"));
		}

		List<String> orderTypes = new ArrayList<>();
		if (!StringUtils.isEmpty(orderType)) {
			orderTypes = Arrays.asList(orderType.split("\\,"));
		}

		List<String> movementTypes = new ArrayList<>();
		if (!StringUtils.isEmpty(movementType)) {
			movementTypes = Arrays.asList(movementType.split("\\,"));
		}

		List<String> destHubs = new ArrayList<>();
		if (!StringUtils.isEmpty(destHub)) {
			destHubs = Arrays.asList(destHub.split("\\,"));
		}

		try {
			orderListResponse = orderService.getOrders(nodeIds, pageSize, pageIndex, fromDate, toDate, orderId, orderStatuses, orderTypes, movementTypes, destHubs);
			if (!CollectionUtils.isEmpty(orderListResponse.getOrderList()))
				return Utility.getSuccessMsg(orderListResponse);
			else
				return Utility.getSuccessMsg(orderListResponse, "No Order found");

		} catch (Exception e) {
			return Utility.getfailureMsg("Unable to fetch Order details");
		}
	}


	@GetMapping(value = "/getOrdersForFluidLoading", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> getOrdersForFluidLoading(@RequestParam(value = "pageSize", required = false) Integer pageSize,
																	@RequestParam(value = "pageIndex", required = false) Integer pageIndex,
																	@RequestParam(value = "fromDate", required = false) String fromDate,
																	@RequestParam(value = "toDate", required = false) String toDate,
																	@RequestParam(value = "orderId", required = false) String orderId,
																	@RequestParam(value = "orderStatus", required = false) String orderStatus,
																	@RequestParam(value = "pinCode", required = false) String pinCode,
																	@RequestParam(value = "mid", required = false) String mid,
																	@RequestParam(value = "destHub", required = false) String destHub,
																	@RequestParam(value = "viewType", required = false) String viewType,
																	HttpServletRequest request) {

		List<String> nodeIds = Arrays.asList(request.getHeader(Constants.NODE_ID).split("\\|"));

		if (CollectionUtils.isEmpty(nodeIds)) {
			return Utility.getfailureMsg("NodeId information is missing in the request");
		}

		List<String> orderStatuses = new ArrayList<>();
		if (!StringUtils.isEmpty(orderStatus)) {
			orderStatuses = Arrays.asList(orderStatus.split("\\,"));
		}

		List<String> destHubs = new ArrayList<>();
		if (!StringUtils.isEmpty(destHub)) {
			destHubs = Arrays.asList(destHub.split("\\,"));
		}

        try {

            OrderListResponseFluidLoading orderListResponse;

            if ( !StringUtils.isBlank(viewType)  &&  viewType.equalsIgnoreCase("Fluid-TripOrderView")) {
                 orderListResponse = orderService.tripOrderViewFluidLoading(nodeIds, pageSize, pageIndex, fromDate, toDate, orderId, orderStatuses, mid, pinCode, destHubs);
            } else {
                orderListResponse = orderService.consignmentViewFluidLoading(nodeIds, pageSize, pageIndex, fromDate, toDate, orderId, orderStatuses, mid, pinCode, destHubs);
            }

			List<HuCountResponse> huCountResponses = consignmentLabelService.huCountForSDP(nodeIds, fromDate, toDate, null, null, null, null, destHubs);
			OrderDetailsUtil.setHuDetails(huCountResponses, orderListResponse);

			if (!CollectionUtils.isEmpty(orderListResponse.getOrderList())) {
				return Utility.getSuccessMsg(orderListResponse);
			} else {
				return Utility.getSuccessMsg(orderListResponse, "No Order found");
			}

		} catch (Exception e) {
			return Utility.getfailureMsg("Unable to fetch Order details");
		}
	}

	@GetMapping("/getInvoice/{orderId}")
	public ResponseEntity getInvoice(@PathVariable String orderId,
								   @RequestParam(value = "shipmentNo", required = false) String shipmentNo) {
		try {
			if (StringUtils.isEmpty(orderId)) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Constants.INVOICE_NOT_AVAILABLE);
			}
			InvoicePdfDetail invoicePdfDetail = orderService.getInvoiceDetail(orderId, shipmentNo);
			if (invoicePdfDetail.getEncodedPdfUrl() != null) {
				String uri = URLDecoder.decode(invoicePdfDetail.getEncodedPdfUrl(), "UTF-8");
				return ResponseEntity.status(HttpStatus.TEMPORARY_REDIRECT).location(new URI(uri)).build();
			} else {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Constants.INVOICE_NOT_AVAILABLE);
			}
		} catch (UnsupportedEncodingException | JAXBException | RestClientException | NetworkCommunicationException
				| URISyntaxException e) {
			log.error("Internal server error ", e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Constants.INVOICE_NOT_AVAILABLE);
		}
	}

	@GetMapping("/planTripSummary")
	public ResponseEntity planTripSummary(@RequestParam(value = "fromDate", required = false) String fromDate,
										  @RequestParam(value = "toDate", required = false) String toDate,
										  HttpServletRequest request) {

		List<String> nodeIds = Arrays.asList(request.getHeader(Constants.NODE_ID).split("\\|"));
		NodeDetailsResponse nodeResponse = nodeDetailApiService.getNodeDetails(nodeIds.get(0), NodeType.FC, true);
		List<String> sdpIds = nodeResponse.getNodeDetails().get(0).getChildNodes().stream().map(nodeDetails -> nodeDetails.getNodeId()).collect(Collectors.toList());

		try {
			List<SDPSummaryResponse> sdpSummaryResponseList = orderService.getSDPSummary(nodeIds, sdpIds, fromDate, toDate);

			if (!CollectionUtils.isEmpty(sdpSummaryResponseList)) {
				return Utility.getSuccessMsg(sdpSummaryResponseList);
			} else {
				return Utility.getSuccessMsg(sdpSummaryResponseList, "No record found");
			}

		} catch (Exception e) {
			return Utility.getfailureMsg("Unable to fetch records");
		}
	}


	@GetMapping(value = "/getConsignmentOrderPdf", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity getConsignmentOrderPdf(@RequestParam(value = "pageSize", required = false) Integer pageSize,
												@RequestParam(value = "pageIndex", required = false) Integer pageIndex,
												@RequestParam(value = "fromDate", required = false) String fromDate,
												@RequestParam(value = "toDate", required = false) String toDate,
												@RequestParam(value = "orderId", required = false) String orderId,
												@RequestParam(value = "orderStatus", required = false) String orderStatus,
												@RequestParam(value = "pinCode", required = false) String pinCode,
												@RequestParam(value = "mid", required = false) String mid,
												@RequestParam(value = "destHub", required = false) String destHub,
												HttpServletRequest request) {

		List<String> nodeIds = Arrays.asList(request.getHeader(Constants.NODE_ID).split("\\|"));
		if (CollectionUtils.isEmpty(nodeIds)) {
			return Utility.getfailureMsg("NodeId information is missing in the request");
		}

		List<String> orderStatuses = new ArrayList<>();
		if (!StringUtils.isEmpty(orderStatus)) {
			orderStatuses = Arrays.asList(orderStatus.split("\\,"));
		}

		List<String> destHubs = new ArrayList<>();
		if (!StringUtils.isEmpty(destHub)) {
			destHubs = Arrays.asList(destHub.split("\\,"));
		}

		try {
			OrderListResponseFluidLoading orderListResponse = orderService.tripOrderViewFluidLoading(nodeIds, pageSize, pageIndex, fromDate,
					toDate, orderId, orderStatuses, mid, pinCode, destHubs);
			if (!CollectionUtils.isEmpty(orderListResponse.getOrderList())) {
				return orderService.getConsignmentOrderPdf(orderListResponse);
			} else {
				return Utility.getSuccessMsg(orderListResponse, "No Order found");
			}

		} catch (Exception e) {
			log.info("Error while creating PDF for consignment order ",  e);
			return ResponseEntityFactory.textResponse(String.format("Error while creating PDF for consignment order "));
		}finally {
			pdfDeletionService.deletePDf();
		}
	}
}
