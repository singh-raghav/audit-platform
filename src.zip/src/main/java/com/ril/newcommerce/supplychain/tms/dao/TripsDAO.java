package com.ril.newcommerce.supplychain.tms.dao;


import java.sql.Timestamp;
import java.util.*;

import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripIdDetails;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.response.TripAmount;
import com.ril.newcommerce.supplychain.tms.response.TripCountResponse;
import com.ril.newcommerce.supplychain.tms.response.TripLazyLoadResponse;
import com.ril.newcommerce.supplychain.tms.settlement.entity.ReconcileArticle;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.Driver;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripEventInput;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.Vehicle;
import com.ril.newcommerce.supplychain.tms.util.DestinationNodesDeliveryZoneIds;

/**
B1.Divya
*/

public interface TripsDAO {
	
	List<Trip> getTrip(HashMap<String, Object> filter);
	
	public void updateTripStatus(String tripId,TripState status);
	
	Map<String,Integer> getTripCountOnTripStatus(List<String> nodeIds,String toDate, String fromDate, String tripId, MovementType mvType, Map<String, Object> filters);
	
	List<TripAdditionalDetail> getTripAdditionalDetails(List<String> tripId, String key);
	
	List<Trip> getTripsInfo(List<String> nodeName,Map<String,Object> filters);

	List<Trip> getTripsInfoWithAmountToBeCollected(List<String> nodeName, Map<String, Object> filters);

	List<Trip> getTripsInfoWithAmountCollected(List<String> nodeName, Map<String, Object> filters);

	List<Trip> getInboundTrips(List<String> nodeName,Map<String,Object> filters);
	
	Map<String, List<String>> getNumberOfChildTrips(List<String> tripIds);
	
	public Map<String, List<String>> getChildTripIds(List<String> referenceIds);
	
	public void updateStartKm(String tripId, double startKM,String modifiedBy);
	
	public void updateEndKm(String tripId, Double endKM,String modifiedBy);
	
	public String getEwayBillStatus(String tripId);
	
	public void updateDriverDetails(String tripId , Driver driver , Vehicle vehicle,String modifiedBy);
	
	public void insertTripAdditionalDetails(List<TripAdditionalDetail> additionalDetails);
	
	public List<String> getVehicleAssignmentStatus(List<String> vehicleIds); 
	
	public void insertEvent(TripEventInput event);
	
	
	public void insertToTrip(Trip trip,TripIdDetails tripIdDetails,int count);
	
	public void insertToTripHierarchy(String tripId, Set<String> secTripId,String system);
	
	public void insertToTripHierarchy(Set<String> prevTripId, String tripId,String system);
	
	public void deassociateTripHierarchy(Map<String,String> tripIds);
	public void batchUpdateToTripHierarchy(String tripId, Set<String> secTripId,String system);
	
	public void batchUpdateToTripHierarchy(Set<String> prevTripId, String tripId,String system);
	
	public int getTripCountOnGivenDate(String date,String nodeId,String movementType);
	
	public int updateTripModifedDetails(String flowName,String modifiedBy, String tripId);
	
	public Trip getTripById(String tripId);
	
	public String getInitialAmount(String tripId);
	
    List<Trip> getTripDetails(List<String> tripId);

	public void updateFcTripDetailsOnSettlement(String tripId, Double endKm, String flowName,String modifiedBy);

	public void updateActualArrival(String tripId, String nodeId,Timestamp arrivalTime,String flowname);
	
	public void updateActualDispatch(String tripId, String nodeId,Timestamp arrivalTime,String flowname);
	
	public void updateTripAdditionalDetails(TripAdditionalDetail additionalDetails);
	
	public void deleteTripAdditionalDetails(String tripId, String nodeId, String key);
	
	public void deleteTripAdditionalDetailsByTrip(String tripId, List<String> key);
	
	public void updateTripVersion(String tripId,String flowName,String modifedBy);
	
	public List<Map<String, Object>> getActualDispatchTime(String tripId) ;

	public List<String> getDeliveredOrders(String tripId);

	List<ReconcileArticle> getReturnItems(List<String> orderIds);

	void updateReturnItems(List<ReconcileArticle> reconcileArticles, String nodeId, String tripId);

	List<TripLazyLoadResponse> getTripDetailsForGivenOrders(String shipmentNo, String nodeId);
	
	public void updateVehicleDetails(String tripId, String vehicleId, String driverId , String driverName ,String userId);

	int getStartedTripCount(String shipmentNo);

	public Map<String, String> getDriverNumber(List<String> tripIds);

	public String getDriverNumberByTrip(String tripId);

	public List<Trip> getTripsTobeCancelled(List<String> tripStatus,List<String> shipmentstatus,String unit,int fetchSize,int interval);

	public List<TripAmount> getTripAmount(String startDate, String endDate, String nodeId);

    List<TripCountResponse> getTripCountForSDP(List<String> nodeIds, List<String> sdpIds, String startDate, String endDate);

	public Integer getLoadedOrderCount(String tripId);

	public Integer getLoadedHUCount(String tripId);

	public Map<String, DestinationNodesDeliveryZoneIds> getDeliveryZonesAndDestinationNodesForTrips(
															List<String> nodeIds, Map<String,Object> filters);
}
