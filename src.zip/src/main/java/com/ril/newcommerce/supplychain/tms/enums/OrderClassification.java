package com.ril.newcommerce.supplychain.tms.enums;

/**
B1.Divya
*/

public enum OrderClassification {
	Forward("Forward"),
	Return("Return"),
	DSR("Dsr");
	
	private String value;
	
	private OrderClassification(String value){
		this.value=value;
	}
	
	public String getValue(){
		return this.value;
	}

}
