package com.ril.newcommerce.supplychain.tms.enums;

public enum PaymentMethodType 
{
	JPB("JPB"),
	COD("COD"),
	CREDIT("CREDIT");
	
	private String value;
	
	private PaymentMethodType(String value){
		this.value=value;
	}
	
	public String getValue(){
		return this.value;
	}
}
