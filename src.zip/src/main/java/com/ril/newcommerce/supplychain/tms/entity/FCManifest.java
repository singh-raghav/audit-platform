package com.ril.newcommerce.supplychain.tms.entity;

import java.util.List;

/**
 * 
 * @author Jeevi.Natarajan
 *
 */
public class FCManifest {
	
	private String tripId;
	private String fcName;
	private String vechicleNumber;
	private String driverName;
	private String driverMobileNumber;
	private String startKm;
	private String endKm;
	private String vehicleType;
	private String mode;
	private String truckOperator; //vendor Name
	
	private int totalOrders;
	private int totalHUs;
	
	private List<HubDetail> hubDetails;

	public String getTripId() {
		return tripId;
	}

	public void setTripId(String tripId) {
		this.tripId = tripId;
	}

	public String getFcName() {
		return fcName;
	}

	public void setFcName(String fcName) {
		this.fcName = fcName;
	}

	public String getVechicleNumber() {
		return vechicleNumber;
	}

	public void setVechicleNumber(String vechicleNumber) {
		this.vechicleNumber = vechicleNumber;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getDriverMobileNumber() {
		return driverMobileNumber;
	}

	public void setDriverMobileNumber(String driverMobileNumber) {
		this.driverMobileNumber = driverMobileNumber;
	}

	public String getStartKm() {
		return startKm;
	}
	
	public void setStartKm(String startKm) {
		this.startKm = startKm;
	}
	
	public String getEndKm() {
		return endKm;
	}
	
	public void setEndKm(String endKm) {
		this.endKm = endKm;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public int getTotalOrders() {
		return totalOrders;
	}

	public void setTotalOrders(int totalOrders) {
		this.totalOrders = totalOrders;
	}

	public int getTotalHUs() {
		return totalHUs;
	}

	public void setTotalHUs(int totalHUs) {
		this.totalHUs = totalHUs;
	}

	public List<HubDetail> getHubDetails() {
		return hubDetails;
	}

	public String getTruckOperator() {
		return truckOperator;
	}
	
	public void setTruckOperator(String truckOperator) {
		this.truckOperator = truckOperator;
	}
	
	
	public void setHubDetails(List<HubDetail> hubDetails) {
		this.hubDetails = hubDetails;
	}

}
