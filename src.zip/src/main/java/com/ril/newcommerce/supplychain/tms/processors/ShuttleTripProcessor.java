package com.ril.newcommerce.supplychain.tms.processors;

import java.io.StringReader;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.tms.constants.Constants;
import com.ril.newcommerce.supplychain.tms.dao.TripOrdersDAO;
import com.ril.newcommerce.supplychain.tms.entity.Consignment;
import com.ril.newcommerce.supplychain.tms.entity.Hub;
import com.ril.newcommerce.supplychain.tms.entity.NodeOrdeRoute;
import com.ril.newcommerce.supplychain.tms.entity.Trip;
import com.ril.newcommerce.supplychain.tms.entity.TripConsignmentInfo;
import com.ril.newcommerce.supplychain.tms.entity.TripIdDetails;
import com.ril.newcommerce.supplychain.tms.enums.EwayBillStatus;
import com.ril.newcommerce.supplychain.tms.enums.MovementType;
import com.ril.newcommerce.supplychain.tms.enums.OrderStatus;
import com.ril.newcommerce.supplychain.tms.enums.TripState;
import com.ril.newcommerce.supplychain.tms.exception.ParsingException;
import com.ril.newcommerce.supplychain.tms.exception.TripApplicationException;
import com.ril.newcommerce.supplychain.tms.exception.ValidationException;
import com.ril.newcommerce.supplychain.tms.listeners.FlowName;
import com.ril.newcommerce.supplychain.tms.listeners.JAXBContextConfig;
import com.ril.newcommerce.supplychain.tms.service.NodeOrderRouteService;
import com.ril.newcommerce.supplychain.tms.service.TripOrdersService;
import com.ril.newcommerce.supplychain.tms.service.TripService;
import com.ril.newcommerce.supplychain.tms.service.impl.CreateTrip;
import com.ril.newcommerce.supplychain.tms.statemachine.actions.JMSPublisher;
import com.ril.newcommerce.supplychain.tms.statemachine.entity.TripAdditionalDetail;
import com.ril.newcommerce.supplychain.tms.tibco.entity.TripPublish;
import com.ril.newcommerce.supplychain.tms.tibco.entity.Trip.Orders.Order;
import com.ril.newcommerce.supplychain.tms.util.DateUtility;
import com.ril.newcommerce.supplychain.tms.util.Utility;

/**
B1.Divya
*/

@Service
@Qualifier(Constants.SHUTTLE_TRIP_PROCESSOR)
public class ShuttleTripProcessor implements Processor
{
	private static final Logger log = LoggerFactory.getLogger(ShuttleTripProcessor.class);

	@Autowired 
	private JAXBContextConfig jAXBContextConfig;
	
	@Autowired
	private TripService tripService;

	@Autowired
	private TripOrdersService tripOrderService;
	
	@Autowired
	private CreateTrip createTrip;
	
	@Autowired
	private NodeOrderRouteService nodeOrderRouteservice;
	
	@Autowired
	private TripOrdersDAO tripOrderDAO;
	
	@Autowired
	private JMSPublisher jmsPublisher;
	
	@Value("${tripapp.queue}")
	private String queueName;
	
	@Override
	public void processMessage(Message message, String flowName) throws ParsingException, Exception 
	{
		StringReader reader = new StringReader(((TextMessage) message).getText());
		
		TripPublish tripPublishRequest = (TripPublish) jAXBContextConfig.getJaxbContextInstance(TripPublish.class)
				.createUnmarshaller().unmarshal(reader);
		
		String tripId = tripPublishRequest.getTrip().getId();
		int version = tripPublishRequest.getTrip().getVersion();
		
		Trip trip = tripService.getTrip(tripId);
		String referenceId=trip.getExternalReferenceId();
		Utility.validate(trip, version, tripId);
		
		log.info("Shuttle trip manual trip creation for parent trip {} ",trip.getTripId());
		List<String> status = new ArrayList<>();
		status.add(OrderStatus.INPROGRESS.getValue());

		List<TripConsignmentInfo> tripconsignmentInfo = tripOrderService.getTripConsignmentInfo(tripId, status);
		
		trip=getTripDetails(trip, tripconsignmentInfo,flowName);
		TripIdDetails tripIdDetails=getTripDate( trip.getPlannedStartTime(),  trip.getSourceNode(),MovementType.SHUTTLE.getValue());
		TripAdditionalDetail additionalDetails = gettripAdditionalDetails(trip);
		
		updateExternalReferenceId(trip,tripconsignmentInfo,referenceId,tripId);
		
		List<String> ordersIds=tripconsignmentInfo.stream().map(m->m.getOrderId()).collect(Collectors.toList());
		List<NodeOrdeRoute> orderRoute = nodeOrderRouteservice.getRouteIdsByNodeAndOrder(trip.getSourceNode(), ordersIds);

		Set<String> nextRouteIds = orderRoute.stream().map(mapper -> mapper.getNextRouteId())
				.collect(Collectors.toSet());
		Set<String> prevRouteIds = orderRoute.stream().map(mapper -> mapper.getPreviousRouteId())
				.collect(Collectors.toSet());
		
		//create Trip
		createTrip.createtrip(trip, additionalDetails, nextRouteIds, prevRouteIds, null, tripIdDetails);
		
		log.info("Manual Shuttle trip created with tripid {}",trip.getTripId());
		TripPublish tripPublishMeaage=Utility.createMessageToPublishTrip(trip.getTripId(),Constants.ONE,trip.isAdhocTrip());
		publishTripMessage(tripPublishMeaage);
		
	}
	
	private void updateExternalReferenceId(Trip trip, List<TripConsignmentInfo> tripconsignmentInfo, String referenceId,String tripId)
	{
		List<String> ordersIds=tripconsignmentInfo.stream().map(m->m.getOrderId()).collect(Collectors.toList());
		List<String> shipmentNos=tripconsignmentInfo.stream().map(m->m.getShipmentNo()).collect(Collectors.toList());
		
		Map<String, List<String>> tripWithOrdersList=new HashMap<>();
		tripWithOrdersList.put(referenceId, ordersIds);
		
		nodeOrderRouteservice.updateNextRouteId(tripWithOrdersList, trip.getExternalReferenceId());
		nodeOrderRouteservice.updatePreviousRouteId(tripWithOrdersList, trip.getExternalReferenceId());
		tripOrderDAO.deleteTripConsignmentByTripId(shipmentNos, tripId);
		
	}

	private Trip getTripDetails(Trip trip,List<TripConsignmentInfo> tripconsignmentInfo,String flowName)
	{
		trip.setCreatedBy(Constants.TRIP_APP);
		trip.setFlowName(flowName);
		trip.setExternalReferenceId(UUID.randomUUID().toString());
		trip.setAdhocTrip(true);
		trip.setStatus(TripState.CREATED.getValue());
		
		List<Consignment> consignments=new ArrayList<>();
		Map<Integer, Hub> hubSequence = new HashMap<Integer, Hub>();
		if(!CollectionUtils.isEmpty(tripconsignmentInfo))
		{
		for (TripConsignmentInfo con : tripconsignmentInfo) {
			Consignment consignment = new Consignment();
			consignment.setOrderId(con.getOrderId());
			consignment.setShipmentNo(con.getShipmentNo());
			consignment.setNextNodeId(con.getNextNodeId());
			consignment.setLatitude(con.getLatitude());
			consignment.setLongitute(con.getLongitute());
			consignment.setSlotStart(con.getSlotStart());
			consignment.setSlotEnd(con.getSlotEnd());
			consignment.setShipmentStatus(OrderStatus.ACTIVE.getValue());
			consignment.setCreatedBy(Constants.TRIP_APP);
			consignment.setModifiedBy(Constants.TRIP_APP);
			consignment.setDeliveryZoneId(con.getDeliveryZoneId());
			if (null == hubSequence.get(Integer.valueOf(con.getSequenceNo()))) {
				Hub hub = new Hub();
				hub.setNodeId(con.getNextNodeId());
				hub.setSequence(Integer.valueOf(con.getSequenceNo()));
				hub.setPlannedArrivalTime(con.getPlannedArrival());
				hub.setPlannedDispatchTime(con.getPlanneddispatch());
				hubSequence.put(Integer.valueOf(con.getSequenceNo()), hub);
			}
			consignments.add(consignment);
		}
		}
		trip.setConsignment(consignments);
		List<Hub> hubs = new ArrayList<>(hubSequence.values());
		trip.setHub(hubs);
		return trip;
	}

	private TripIdDetails getTripDate( Timestamp date, String nodeId,String movementType)
	{
			String plannedStart = DateUtility.convertTimeStampToString(date,Constants.DATE_FORMAT);
			int sequence = tripService.getTripCountByGivenDate(plannedStart, nodeId,movementType);
			String tripDate = DateUtility.convertStringToFormattedDate(plannedStart, Constants.DATE_FORMAT,
					Constants.FORMAT_FOR_CREATE_TRIP_ID);
			
			TripIdDetails deatils=new TripIdDetails();
			deatils.setSequence(sequence);
			deatils.setTripDate(tripDate);
			return deatils;
	}
	
	private TripAdditionalDetail gettripAdditionalDetails(Trip trip)
	{
		TripAdditionalDetail additionalDetails = new TripAdditionalDetail();
		 additionalDetails.setNodeId(trip.getSourceNode());
		 additionalDetails.setKey(Constants.EWAYBILL);
		 additionalDetails.setValue(EwayBillStatus.SUCCESS.value());
		 return additionalDetails;
	}
	
	private void publishTripMessage(TripPublish tripPublishRequest) throws Exception
	{
		jmsPublisher.inputToQueue(queueName, tripPublishRequest, FlowName.PUBLISHTRIP.getValue(),
				Utility.getMap(Constants.BUSINESS_KEY_ONE, Constants.TRIP_NUMBER, Constants.BUSINESS_VALUE_ONE,
						tripPublishRequest.getTrip().getId()),TripPublish.class);	
	}
}
