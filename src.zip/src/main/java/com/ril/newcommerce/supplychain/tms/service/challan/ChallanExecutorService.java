package com.ril.newcommerce.supplychain.tms.service.challan;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Takes care of lifecycle of executor pool used to create delivery challans
 * 
 * Default scope is singleton
 * @author Jeevi.Natarajan
 *
 */

@Configuration
public class ChallanExecutorService {

	private static final Logger log = LoggerFactory.getLogger(ChallanExecutorService.class);
	    
	private ExecutorService challanExecutor;
	
	@Value("${challan.threadpool.size}")
	private Integer poolSize;
	
	public ChallanExecutorService() {
		challanExecutor =  Executors.newFixedThreadPool(poolSize==null?10:poolSize);
	}
	
	public ExecutorService getChallanExecutor() {
		return challanExecutor;
	}
	
	public void shutdownChallanExecutor() {
		
		try {
			challanExecutor.shutdown();
			challanExecutor.awaitTermination(5000,TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			log.error("Exception occured on shutting doown challanExecutor");
		}
		
		log.info("Shutdown of challanExecutor Successfull!");
	}
	
}
