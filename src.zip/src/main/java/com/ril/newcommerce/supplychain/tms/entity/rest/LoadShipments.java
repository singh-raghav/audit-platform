package com.ril.newcommerce.supplychain.tms.entity.rest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/*@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"LoadShipment"
})*/
public class LoadShipments {

	@JsonProperty("LoadShipment")
	private List<LoadShipment> loadShipment = null;

	@JsonProperty("LoadShipment")
	public List<LoadShipment> getLoadShipment() {
		return loadShipment;
	}

	@JsonProperty("LoadShipment")
	public void setLoadShipment(List<LoadShipment> loadShipment) {
		this.loadShipment = loadShipment;
	}
}
