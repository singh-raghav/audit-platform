package com.ril.newcommerce.supplychain.tms.exception;

/**
 * @author jeevi.natarajan
 *
 */
public class NetworkCommunicationException  extends RuntimeException{
	
	private static final long serialVersionUID = -3486964146281062990L;

	public NetworkCommunicationException(String message) {
		super(message);
	}
	
	
	public NetworkCommunicationException(String message,Throwable th) {
		super(message,th);
	}
	
	public NetworkCommunicationException(Throwable th) {
		super(th);
	}
}

