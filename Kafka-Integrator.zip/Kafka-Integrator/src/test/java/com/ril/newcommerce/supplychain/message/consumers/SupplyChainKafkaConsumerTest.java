package com.ril.newcommerce.supplychain.message.consumers;

import static org.junit.Assert.assertNotNull;

import java.util.Arrays;

import org.junit.Test;

import com.ril.newcommerce.supplychain.message.config.SupplyChainConsumerConfig;
import com.ril.newcommerce.supplychain.message.consumers.SupplyChainKafkaConsumer;
import com.ril.newcommerce.supplychain.message.processors.DummyProcessor;
import com.ril.newcommerce.supplychain.message.processors.SupplyChainMessageProcessor;

@SuppressWarnings("unused")
public class SupplyChainKafkaConsumerTest {
		
	@Test
	public void validate() {
		
		SupplyChainConsumerConfig config = new SupplyChainConsumerConfig();

		config.setDestinationDetails("localhost:9092");
		config.setApplicationId("test-consumer");
		config.setConsumerGroupId("consumer-tutorial");
		config.setTopics(Arrays.asList("test"));
		
		SupplyChainMessageProcessor<String, String> processor = new DummyProcessor<String, String>();
		SupplyChainKafkaConsumer<String, String> consumer = new SupplyChainKafkaConsumer<String, String>(processor, config);

		assertNotNull(consumer);
	}
	
	
	@Test
	public void validateMissingDestination() {
		
		SupplyChainConsumerConfig config = new SupplyChainConsumerConfig();

		config.setApplicationId("test-consumer");
		config.setConsumerGroupId("consumer-tutorial");
		config.setTopics(Arrays.asList("test"));
		
		SupplyChainMessageProcessor<String, String> processor = new DummyProcessor<String, String>();

		Exception expected = null;
		
		try {
			SupplyChainKafkaConsumer<String, String> consumer = new SupplyChainKafkaConsumer<String, String>(processor, config);
		}
		catch (Exception ex) {
			expected = ex;
		}
		
		assertNotNull(expected);
	}
	
	@Test
	public void validateMissingApplicationId() {
		
		SupplyChainConsumerConfig config = new SupplyChainConsumerConfig();

		config.setDestinationDetails("localhost:9092");
		config.setConsumerGroupId("consumer-tutorial");
		config.setTopics(Arrays.asList("test"));
		
		SupplyChainMessageProcessor<String, String> processor = new DummyProcessor<String, String>();

		Exception expected = null;
		
		try {
			SupplyChainKafkaConsumer<String, String> consumer = new SupplyChainKafkaConsumer<String, String>(processor, config);
		}
		catch (Exception ex) {
			expected = ex;
		}
		
		assertNotNull(expected);
	}
	
	@Test
	public void validateMissingConsumerGroup() {
		
		SupplyChainConsumerConfig config = new SupplyChainConsumerConfig();

		config.setDestinationDetails("localhost:9092");
		config.setApplicationId("test-consumer");
		config.setTopics(Arrays.asList("test"));
		
		SupplyChainMessageProcessor<String, String> processor = new DummyProcessor<String, String>();

		Exception expected = null;
		
		try {
			SupplyChainKafkaConsumer<String, String> consumer = new SupplyChainKafkaConsumer<String, String>(processor, config);
		}
		catch (Exception ex) {
			expected = ex;
		}
		
		assertNotNull(expected);
	}
	
	@Test
	public void validateMissingTopic() {
		
		SupplyChainConsumerConfig config = new SupplyChainConsumerConfig();

		config.setDestinationDetails("localhost:9092");
		config.setApplicationId("test-consumer");
		config.setConsumerGroupId("consumer-tutorial");
		
		SupplyChainMessageProcessor<String, String> processor = new DummyProcessor<String, String>();

		Exception expected = null;
		
		try {
			SupplyChainKafkaConsumer<String, String> consumer = new SupplyChainKafkaConsumer<String, String>(processor, config);
		}
		catch (Exception ex) {
			expected = ex;
		}
		
		assertNotNull(expected);
	}
}
