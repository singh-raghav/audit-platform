package com.ril.newcommerce.supplychain.message.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class TestUtil {

	public static void invokePrivateMethod(Class<?> targetClass, Object targetInstance,
			String methodName, Class<?>[] argClasses, Object[] argObjects)
	{

		try {

			Method method = targetClass.getDeclaredMethod(methodName,
					argClasses);
			method.setAccessible(true);
			method.invoke(targetInstance, argObjects);
		}
		catch (NoSuchMethodException e) {

			throw new FailedTestException(e);
		}
		catch (SecurityException e) {

			throw new FailedTestException(e);
		}
		catch (IllegalAccessException e) {

			throw new FailedTestException(e);
		}
		catch (IllegalArgumentException e) {

			throw new FailedTestException(e);

		} catch (InvocationTargetException e) {

			throw new FailedTestException(e);
		}
	}
	
	public static void invokeStaticMethod(Class<?> targetClass,
			String methodName, Class<?>[] argClasses, Object[] argObjects)
	{

		try {

			Method method = targetClass.getDeclaredMethod(methodName,
					argClasses);
			method.setAccessible(true);
			method.invoke(null, argObjects);
		}
		catch (NoSuchMethodException e) {

			throw new FailedTestException(e);
		}
		catch (SecurityException e) {

			throw new FailedTestException(e);
		}
		catch (IllegalAccessException e) {

			throw new FailedTestException(e);
		}
		catch (IllegalArgumentException e) {

			throw new FailedTestException(e);

		} catch (InvocationTargetException e) {

			throw new FailedTestException(e);
		}
	}
}
