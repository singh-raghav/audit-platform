package com.ril.newcommerce.supplychain.message.util;

import com.ril.newcommerce.supplychain.message.config.SupplyChainMessagingConfig;
import com.ril.newcommerce.supplychain.message.consumers.SupplyChainRetryableKafkaConsumer;
import com.ril.newcommerce.supplychain.message.processors.DummyProcessor;
import com.ril.newcommerce.supplychain.message.processors.SupplyChainMessageProcessor;

public class SupplyChainRetryableKafkaConsumerRunner {

	public static void main(String[] args) {

		/**
		 * DummyProcessor is a sample class created just for reference.
		 * The integrating applications should provide a suitable implementation of the 
		 * RILGroceryMessageProcessor<K, V> interface
		 */
		SupplyChainMessageProcessor<String, String> processor = new DummyProcessor<String, String>();
		
		SupplyChainMessagingConfig config = new SupplyChainMessagingConfig();

		config.setDestinationDetails("localhost:9092");
		config.setApplicationId("test-consumer");
		config.setConsumerGroupId("consumer-tutorial");
		config.setFailureTopic("failure");
		config.setRecoveryRetryCount(3);
		config.setRetryDelayInMillis(5000);
		config.setRetryTopic("retry");
		config.setSourceTopic("test");

		SupplyChainRetryableKafkaConsumer<String, String> messageProcessor = 
				new SupplyChainRetryableKafkaConsumer<String, String>(processor, config);
		
		messageProcessor.start();
	}
}
