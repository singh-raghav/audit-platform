package com.ril.newcommerce.supplychain.message.serde;

import java.io.Serializable;

public class User implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;
	private int age;
	
	public User() {
	}
	public User(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return this.name;
	}
	public int getAge() {
		return this.age;
	}
	@Override public String toString() {
		return "User(" + name + ", " + age + ")";
	}
}