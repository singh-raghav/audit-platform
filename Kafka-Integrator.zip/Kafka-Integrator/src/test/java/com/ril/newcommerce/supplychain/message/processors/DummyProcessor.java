package com.ril.newcommerce.supplychain.message.processors;

import org.apache.commons.lang3.StringUtils;

import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.exceptions.RecoverableMessageProcessingException;
import com.ril.newcommerce.supplychain.message.exceptions.UnrecoverableMessageProcessingException;
import com.ril.newcommerce.supplychain.message.processors.SupplyChainMessageProcessor;

public class DummyProcessor<K, V> implements SupplyChainMessageProcessor<K, V> {

	private SupplyChainMessage<K, V> content;
	
	public DummyProcessor() {	}
	
	public DummyProcessor(SupplyChainMessage<K, V> content) {
		this.content = content;
	}


	@Override
	public void process(SupplyChainMessage<K, V> message)
			throws UnrecoverableMessageProcessingException, RecoverableMessageProcessingException {
		
		this.content = message;
		
		if(StringUtils.isBlank(message.getMessage().toString())) {
			throw new RuntimeException("Testing");
		}
		
		if("retry".equals(message.getMessage().toString())) {
			throw new RecoverableMessageProcessingException("Test");
		}
	}

	public SupplyChainMessage<K, V> getContent() {
		return content;
	}

	@Override
	public void onFailure(SupplyChainMessage<K, V> message) {
		
		System.out.println("Failed... generating alert!!");
	}
}
