package com.ril.newcommerce.supplychain.message.serde;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.util.Map;

import org.apache.kafka.common.serialization.Deserializer;

public class UserDeserializer implements Deserializer<User> {

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User deserialize(String topic, byte[] data) {
		
		User user = null;
		
		ByteArrayInputStream bis = new ByteArrayInputStream(data);
		ObjectInput in = null;
		try {
		  in = new ObjectInputStream(bis);
		  user = (User)in.readObject(); 

		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
		  try {
		    if (in != null) {
		      in.close();
		    }
		  } catch (IOException ex) {
		    // ignore close exception
		  }
		}
		
		return user;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

}
