package com.ril.newcommerce.supplychain.message.serde;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.Map;

import org.apache.kafka.common.serialization.Serializer;

public class UserSerializer implements Serializer<User> {


	@Override 
	public void close() { }

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) { }


	@Override
	public byte[] serialize(String topic, User user) {
		
		byte[] toReturn = null;
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutput out = null;
		
		try {
			out = new ObjectOutputStream(bos);
			out.writeObject(user);
			out.flush();
			
			toReturn = bos.toByteArray();

		} catch (IOException e1) {
			
			e1.printStackTrace();   
		} finally {
		  try {
		    bos.close();
		  } catch (IOException ex) { }
		}
		
		return toReturn;
	}
}
