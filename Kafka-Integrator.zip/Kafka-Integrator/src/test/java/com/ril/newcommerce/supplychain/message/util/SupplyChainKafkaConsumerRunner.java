package com.ril.newcommerce.supplychain.message.util;

import java.util.Arrays;

import com.ril.newcommerce.supplychain.message.config.SupplyChainConsumerConfig;
import com.ril.newcommerce.supplychain.message.consumers.SupplyChainKafkaConsumer;
import com.ril.newcommerce.supplychain.message.processors.DummyProcessor;
import com.ril.newcommerce.supplychain.message.processors.SupplyChainMessageProcessor;

public class SupplyChainKafkaConsumerRunner {
	
	public static void main(String[] args) {

		/**
		 * DummyProcessor is a sample class created just for reference.
		 * The integrating applications should provide a suitable implementation of the 
		 * RILGroceryMessageProcessor<K, V> interface
		 */
		SupplyChainMessageProcessor<String, String> processor = new DummyProcessor<String, String>();
		SupplyChainConsumerConfig config = new SupplyChainConsumerConfig();

		config.setDestinationDetails("localhost:9092");
		config.setApplicationId("test-consumer");
		config.setConsumerGroupId("consumer-tutorial");
		config.setTopics(Arrays.asList("test"));

		SupplyChainKafkaConsumer<String, String> consumer = new SupplyChainKafkaConsumer<String, String>(processor, config);
		consumer.start();
	}
}
