package com.ril.newcommerce.supplychain.message.producers;

import java.util.Properties;

import org.junit.Test;

public class SupplyChainKafkaProducerTest {
	

	@Test
	public void validate() throws Exception {
		
	}

	private Properties brokerConfig() {
		
		Properties props = new Properties();
		props.put("offsets.topic.replication.factor", "1");
		props.put("delete.topic.enable", "true");
		props.put("group.initial.rebalance.delay.ms", "0");
		props.put("port", "9042");
		props.put("auto.create.topics.enable", "true");
		props.put("group.min.session.timeout.ms", "0");
		props.put("zookeeper.connect", "127.0.0.1:2181");
		props.put("broker.id", "0");
		props.put("log.cleaner.dedupe.buffer.size", "2097152");
		
		return props;
	}
}
