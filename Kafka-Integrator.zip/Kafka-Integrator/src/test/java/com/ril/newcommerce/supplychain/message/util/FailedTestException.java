package com.ril.newcommerce.supplychain.message.util;

public class FailedTestException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public FailedTestException(String message) {
		super(message);
	}
	
	public FailedTestException(String message, Throwable th) {
		super(message,th);
	}
	
	public FailedTestException(Throwable th) {
		super(th);
	}
}
