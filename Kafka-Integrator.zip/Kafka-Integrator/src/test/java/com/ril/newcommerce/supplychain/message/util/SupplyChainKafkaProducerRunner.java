package com.ril.newcommerce.supplychain.message.util;

import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.config.SupplyChainProducerConfig;
import com.ril.newcommerce.supplychain.message.producers.SupplyChainKafkaProducer;

public class SupplyChainKafkaProducerRunner {

	public static void main(String[] args) {
		
		SupplyChainProducerConfig config = new SupplyChainProducerConfig();

		config.setDestinationDetails("localhost:9092");
		config.setApplicationId("test-consumer");

		SupplyChainKafkaProducer<String, String> rgProducer = new SupplyChainKafkaProducer<String, String>(config);
		
		SupplyChainMessage<String, String> message = new SupplyChainMessage<>();
		
		message.setKey("Key 2");
		message.setMessage("retry");
		
		rgProducer.send(message, "test");
	}
}
