package com.ril.newcommerce.supplychain.message.exceptions;

public class RecoverableMessageProcessingException extends Exception {

	private static final long serialVersionUID = 1L;

	public RecoverableMessageProcessingException(String message) {
		super(message);
	}
	
	public RecoverableMessageProcessingException(String message, Throwable th) {
		super(message,th);
	}
	
	public RecoverableMessageProcessingException(Throwable th) {
		super(th);
	}
}
