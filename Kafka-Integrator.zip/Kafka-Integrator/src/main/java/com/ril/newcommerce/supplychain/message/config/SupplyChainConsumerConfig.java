package com.ril.newcommerce.supplychain.message.config;

import java.util.ArrayList;
import java.util.List;

public class SupplyChainConsumerConfig {
	
	/**
	 * Id of the integrating application/consumer. This is the name with which the
	 * integrating application would be known (logged) with.
	 */
	private String applicationId;
	
	/**
	 * Expects the server hostname:port combination as comma separated string
	 */
	private String destinationDetails;
	
	private String keyDeserializer;
	
	private String valueDeserializer;

	private String consumerGroupId;
	
	private List<String> topics;
	
	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getDestinationDetails() {
		return destinationDetails;
	}

	public void setDestinationDetails(String destinationDetails) {
		this.destinationDetails = destinationDetails;
	}

	public String getKeyDeserializer() {
		return keyDeserializer;
	}

	public void setKeyDeserializer(String keySerializer) {
		this.keyDeserializer = keySerializer;
	}

	public String getValueDeserializer() {
		return valueDeserializer;
	}

	public void setValueDeserializer(String valueSerializer) {
		this.valueDeserializer = valueSerializer;
	}
	
	public List<String> getTopics() {
		return topics;
	}

	public void setTopics(List<String> source) {
		this.topics = source;
	}
	
	public String getConsumerGroupId() {
		return consumerGroupId;
	}

	public void setConsumerGroupId(String consumerGroupId) {
		this.consumerGroupId = consumerGroupId;
	}
}
