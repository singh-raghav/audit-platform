package com.ril.newcommerce.supplychain.message.producers;

import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.errors.RetriableException;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.config.SupplyChainProducerConfig;
import com.ril.newcommerce.supplychain.message.exceptions.ConfigurationValidationException;
import com.ril.newcommerce.supplychain.message.exceptions.PublishFailureException;
import com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants;
import com.ril.newcommerce.supplychain.message.util.KafkaIntegrationUtil;
import com.ril.newcommerce.supplychain.message.util.ProducerResultMetadata;

public class SupplyChainKafkaProducer<K, V> {

	private static final Logger logger = LoggerFactory.getLogger(SupplyChainKafkaProducer.class);
	
	private static final String propertyFile = "producer.properties";
	
	private Producer<K, V> producer;
	private long shutdownWaitInMillis = 30000;
	private long sendTimeout = 10000;
	private int retryCount = 3;
	
	public SupplyChainKafkaProducer (SupplyChainProducerConfig config) {
		
		validate(config);
		
		Properties props = initialize();

		configureProducer(props, config);

		this.producer = new KafkaProducer<K, V>(props);
		
		addShutdownHook(this.producer);
	}

	/**
	 * Sends the message to the topic synchronously but doesn't block forever. 
	 * The method times out after the set timeout. @see #sendTimeout. 
	 * 
	 * @param message
	 * @param topic
	 * @return
	 * @throws PublishFailureException
	 */
	public ProducerResultMetadata send(SupplyChainMessage<K, V> message, String topic) {
		
		ProducerResultMetadata metadata = new ProducerResultMetadata();
		return sendWithRetry(message, topic, retryCount, metadata);
	}
	/**
	 * Asynchronously sends the message to the topic.
	 * 
	 * @param message
	 * @param topic
	 */
	public void sendAsync(SupplyChainMessage<K, V> message, String topic) {
		
		ProducerRecord<K, V> record = new ProducerRecord<>(topic, message.getMessageKey(), message.getMessage());
		this.producer.send(record);
	}
	
	private ProducerResultMetadata sendWithRetry(SupplyChainMessage<K, V> message, 
			String topic, int remainingAttempts, ProducerResultMetadata metadata) {
		
		logger.debug("Sending message {} to topic {}, remaining attemps {}",
				message, topic, remainingAttempts);
		
		if(remainingAttempts > 0) {
			
			Headers headers = new RecordHeaders();
			
			if(!message.getMessageHeaders().isEmpty()) {
				
				message.getMessageHeaders().forEach((key, value)->{
					
					headers.add(key, value.getBytes());
				});
			}
			
			ProducerRecord<K, V> record = new ProducerRecord<>(topic, null, null,
					message.getMessageKey(), message.getMessage(), headers);
			
			try {
				
				Future<RecordMetadata> metadataFuture = this.producer.send(record);
				RecordMetadata recordMeta = metadataFuture.get(sendTimeout, TimeUnit.MILLISECONDS);
				
				metadata.setOffset(recordMeta.offset());
				metadata.setPartition(recordMeta.partition());
				metadata.setTopic(recordMeta.topic());
				
				return metadata;
				
			} catch (InterruptedException e) {
				
				logger.error("Thread was interrupted", e);
				
				throw new PublishFailureException(e);
				
			} catch (ExecutionException e) {
				
				logger.error("Execution error", e);
				
				throw new PublishFailureException(e);
				
			} catch (TimeoutException e) {
				
				logger.error("Operation timedout, retrying...", e);
				
				return sendWithRetry(message, topic, remainingAttempts - 1, metadata);
			}
			catch (RetriableException e) {
				
				logger.error("Kafka threw retriable exception, retrying...", e);
				
				return sendWithRetry(message, topic, remainingAttempts - 1, metadata);
			}
			catch (Exception e) {
				
				logger.error("Exception thrown while sending the message", e);
				
				throw new PublishFailureException(e);	
			}
		}
		else {
			logger.error("Failed to publish the message {} to the topic {}", message, topic);
			throw new PublishFailureException("Messsage publishing failed");
		}
	}


	private void addShutdownHook(Producer<K, V> producer2) {
		
		Runtime.getRuntime().addShutdownHook(new Thread() {
			
			@Override
		    public void run() {
				producer2.close(Duration.ofMillis(shutdownWaitInMillis));
		    }
		});
	}

	private Properties initialize() {
		
		return KafkaIntegrationUtil.loadProperties(propertyFile);
	}

	private void configureProducer(Properties props, SupplyChainProducerConfig config) {
		
		props.put(KafkaIntegrationConstants.BOOT_SERVERS, config.getDestinationDetails());

		props.put(KafkaIntegrationConstants.CLIENT_ID,config.getApplicationId());

		String keySerializer = StringSerializer.class.getName();
		
		if(!StringUtils.isBlank(config.getKeySerializer())) {
			keySerializer = config.getKeySerializer();
		}

		String valueSerializer = StringSerializer.class.getName();
		
		if(!StringUtils.isBlank(config.getValueSerializer())) {
			valueSerializer = config.getValueSerializer();
		}

		props.put(KafkaIntegrationConstants.KEY_SERIAL, keySerializer);
		props.put(KafkaIntegrationConstants.VALUE_SERIAL, valueSerializer);
	}

	
	private void validate(SupplyChainProducerConfig config) {
		
		StringBuilder builder = new StringBuilder();

		if(StringUtils.isBlank(config.getDestinationDetails())) {
			builder.append("\nBootstrap servers not defined");
		}

		if(StringUtils.isBlank(config.getApplicationId())) {
			builder.append("\nApplication Id (client Id) not defined");
		}

		if(!StringUtils.isBlank(builder.toString())) {
			throw new ConfigurationValidationException(builder.toString());
		}

		if(StringUtils.isBlank(config.getKeySerializer())) {
			logger.warn("No key serializer is defined, defaulting to StringSerializer");
		}

		if(StringUtils.isBlank(config.getValueSerializer())) {
			logger.warn("No value serializer is defined, defaulting to StringSerializer");
		}
	}
}
