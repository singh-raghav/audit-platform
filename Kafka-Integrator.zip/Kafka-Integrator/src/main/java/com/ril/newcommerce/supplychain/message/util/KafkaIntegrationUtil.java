package com.ril.newcommerce.supplychain.message.util;

import static com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants.OFFSET;
import static com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants.PARTITION;
import static com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants.TIMESTAMP;
import static com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants.TIMESTAMP_TYPE;
import static com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants.TOPIC;

import java.io.InputStream;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.exceptions.DefaultInitializationException;

public class KafkaIntegrationUtil {

	private KafkaIntegrationUtil() {}
	
	public static Properties loadProperties(String propertyFile) {

		try {
			InputStream inputStream = KafkaIntegrationUtil.class.getClassLoader().getResourceAsStream(propertyFile);
			Properties props = new Properties();
			props.load(inputStream);
			return props;
		}
		catch(Exception ex) {
			throw new DefaultInitializationException(ex);
		}
	}

	public static <K, V> void inflateMessage(SupplyChainMessage<K, V> message, ConsumerRecord<K, V> record) {
		
		message.setKey(record.key());
		message.setMessage(record.value());
		message.setProperty(TOPIC, record.topic());
		message.setProperty(PARTITION, record.partition()+"");
		message.setProperty(OFFSET, record.offset()+"");
		message.setProperty(TIMESTAMP, record.timestamp()+"");
		message.setProperty(TIMESTAMP_TYPE, record.timestampType()+"");
	}
}
