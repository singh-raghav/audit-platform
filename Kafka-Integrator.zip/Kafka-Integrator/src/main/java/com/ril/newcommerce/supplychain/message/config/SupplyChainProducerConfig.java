package com.ril.newcommerce.supplychain.message.config;

public class SupplyChainProducerConfig {
	
	/**
	 * Id of the integrating application/consumer. This is the name with which the
	 * integrating application would be known (logged) with.
	 */
	private String applicationId;
	
	/**
	 * Expects the server hostname:port combination as comma separated string
	 */
	private String destinationDetails;
		
	private String keySerializer;
	private String valueSerializer;

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getDestinationDetails() {
		return destinationDetails;
	}

	public void setDestinationDetails(String destinationDetails) {
		this.destinationDetails = destinationDetails;
	}

	public String getKeySerializer() {
		return keySerializer;
	}

	public void setKeySerializer(String keySerializer) {
		this.keySerializer = keySerializer;
	}

	public String getValueSerializer() {
		return valueSerializer;
	}

	public void setValueSerializer(String valueSerializer) {
		this.valueSerializer = valueSerializer;
	}
}
