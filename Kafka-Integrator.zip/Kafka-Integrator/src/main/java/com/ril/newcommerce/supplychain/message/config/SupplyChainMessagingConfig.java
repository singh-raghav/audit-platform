package com.ril.newcommerce.supplychain.message.config;

public class SupplyChainMessagingConfig {
	
	/**
	 * Id of the integrating application/consumer. This is the name with which the
	 * integrating application would be known (logged) with.
	 */
	private String applicationId;
	
	/**
	 * Expects the server hostname:port combination as comma separated string
	 */
	private String destinationDetails;
	
	private int recoveryRetryCount = 3;
	
	private long retryDelayInMillis = 300000;
	
	private String keyDeserializer;
	
	private String valueDeserializer;

	private String keySerializer;
	
	private String valueSerializer;

	private String consumerGroupId;
	
	private String sourceTopic;
	
	private String retryTopic;
	
	private String failureTopic;

	
	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getDestinationDetails() {
		return destinationDetails;
	}

	public void setDestinationDetails(String destinationDetails) {
		this.destinationDetails = destinationDetails;
	}

	public int getRecoveryRetryCount() {
		return recoveryRetryCount;
	}

	public void setRecoveryRetryCount(int retryCount) {
		this.recoveryRetryCount = retryCount;
	}

	public String getKeyDeserializer() {
		return keyDeserializer;
	}

	public void setKeyDeserializer(String keyDeserializer) {
		this.keyDeserializer = keyDeserializer;
	}

	public String getValueDeserializer() {
		return valueDeserializer;
	}

	public void setValueDeserializer(String valueDeserializer) {
		this.valueDeserializer = valueDeserializer;
	}
	
	public String getKeySerializer() {
		return keySerializer;
	}

	public void setKeySerializer(String keySerializer) {
		this.keySerializer = keySerializer;
	}

	public String getValueSerializer() {
		return valueSerializer;
	}

	public void setValueSerializer(String valueSerializer) {
		this.valueSerializer = valueSerializer;
	}
	
	public String getSourceTopic() {
		return sourceTopic;
	}

	public void setSourceTopic(String source) {
		this.sourceTopic = source;
	}

	public String getRetryTopic() {
		return retryTopic;
	}

	public void setRetryTopic(String retryTopic) {
		this.retryTopic = retryTopic;
	}
	
	public String getFailureTopic() {
		return failureTopic;
	}

	public void setFailureTopic(String failureTopic) {
		this.failureTopic = failureTopic;
	}

	public String getConsumerGroupId() {
		return consumerGroupId;
	}

	public void setConsumerGroupId(String consumerGroupId) {
		this.consumerGroupId = consumerGroupId;
	}

	public void setRetryDelayInMillis(long delayInMillis) {
		this.retryDelayInMillis = delayInMillis;
	}
	
	public long getRetryDelayInMillis() {
		return retryDelayInMillis;
	}
}
