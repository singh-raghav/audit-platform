package com.ril.newcommerce.supplychain.message.consumers;

import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ril.newcommerce.supplychain.message.config.SupplyChainConsumerConfig;
import com.ril.newcommerce.supplychain.message.config.SupplyChainMessagingConfig;
import com.ril.newcommerce.supplychain.message.config.SupplyChainProducerConfig;
import com.ril.newcommerce.supplychain.message.exceptions.ConfigurationValidationException;
import com.ril.newcommerce.supplychain.message.processors.SupplyChainMessageProcessor;
import com.ril.newcommerce.supplychain.message.producers.SupplyChainKafkaProducer;
import com.ril.newcommerce.supplychain.message.retry.handlers.RetryDeliveryExceptionHandler;
import com.ril.newcommerce.supplychain.message.retry.handlers.RetryDeliveryScheduleHandler;

public class SupplyChainRetryableKafkaConsumer<K, V> {

	private static final Logger logger = LoggerFactory.getLogger(SupplyChainKafkaConsumer.class);
	
	private SupplyChainKafkaConsumer<K, V> simpleConsumer;
	private SupplyChainDelayableKafkaConsumer<K, V> delayableConsumer;
	
	private RetryDeliveryExceptionHandler<K, V> exceptionHandler;
	private RetryDeliveryScheduleHandler<K, V> scheduleHandler;
	
	private final long delayPollTimeout = 1000l;
	
	public SupplyChainRetryableKafkaConsumer(SupplyChainMessageProcessor<K, V> messageProcessor, 
			SupplyChainMessagingConfig config) {
	
		validate(config);
		
		SupplyChainConsumerConfig sourceConsumerConfig = createConsumerConfig(config);
		sourceConsumerConfig.setTopics(Arrays.asList(config.getSourceTopic()));
		
		this.simpleConsumer = new SupplyChainKafkaConsumer<>(messageProcessor, sourceConsumerConfig);
				
		SupplyChainConsumerConfig retryConsumerConfig = createConsumerConfig(config);
		retryConsumerConfig.setTopics(Arrays.asList(config.getRetryTopic()));

		this.delayableConsumer = new SupplyChainDelayableKafkaConsumer<>(messageProcessor, retryConsumerConfig);

		SupplyChainProducerConfig producerConfig = createProducerConfig(config);
		
		SupplyChainKafkaProducer<K, V> producer = new SupplyChainKafkaProducer<>(producerConfig);
		
		this.exceptionHandler = new RetryDeliveryExceptionHandler<>(producer, messageProcessor,
				config.getRecoveryRetryCount(), config.getRetryDelayInMillis(),
				config.getRetryTopic(), config.getFailureTopic());
		
		this.scheduleHandler = new RetryDeliveryScheduleHandler<K, V>(delayPollTimeout);
	}
	
	private void validate(SupplyChainMessagingConfig config) {
		
		StringBuilder builder = new StringBuilder();

		String retryTopic = config.getRetryTopic();
		if(StringUtils.isBlank(retryTopic)) {
			builder.append("\nRetry topic not defined");
		}

		String failureTopic = config.getFailureTopic();
		if(StringUtils.isBlank(failureTopic)) {
			builder.append("\nFailure topic not defined");
		}

		if(!StringUtils.isBlank(builder.toString())) {
			throw new ConfigurationValidationException(builder.toString());
		}
	}

	private SupplyChainProducerConfig createProducerConfig(SupplyChainMessagingConfig config) {
		
		SupplyChainProducerConfig producerConfig = new SupplyChainProducerConfig();

		producerConfig.setApplicationId(config.getApplicationId());
		producerConfig.setDestinationDetails(config.getDestinationDetails());
		producerConfig.setKeySerializer(config.getKeySerializer());
		producerConfig.setValueSerializer(config.getValueSerializer());
		
		return producerConfig;
	}

	public void start() {
	
		this.simpleConsumer.start(exceptionHandler);
		this.delayableConsumer.start(exceptionHandler, scheduleHandler);
		
		logger.info("Message processor started...");
	}
	
	private SupplyChainConsumerConfig createConsumerConfig(SupplyChainMessagingConfig config) {
		
		SupplyChainConsumerConfig consumerConfig = new SupplyChainConsumerConfig();
		
		consumerConfig.setApplicationId(config.getApplicationId());
		consumerConfig.setConsumerGroupId(config.getConsumerGroupId());
		consumerConfig.setDestinationDetails(config.getDestinationDetails());
		consumerConfig.setKeyDeserializer(config.getKeyDeserializer());
		consumerConfig.setValueDeserializer(config.getValueDeserializer());
		
		return consumerConfig;
	}
}
