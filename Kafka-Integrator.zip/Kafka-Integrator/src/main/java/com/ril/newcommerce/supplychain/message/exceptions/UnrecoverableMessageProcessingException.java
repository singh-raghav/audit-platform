package com.ril.newcommerce.supplychain.message.exceptions;

public class UnrecoverableMessageProcessingException extends Exception {

	private static final long serialVersionUID = 1L;

	public UnrecoverableMessageProcessingException(String message) {
		super(message);
	}
	
	public UnrecoverableMessageProcessingException(String message, Throwable th) {
		super(message,th);
	}
	
	public UnrecoverableMessageProcessingException(Throwable th) {
		super(th);
	}
}
