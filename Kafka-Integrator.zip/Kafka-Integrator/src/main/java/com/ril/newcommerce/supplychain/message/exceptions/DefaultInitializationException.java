package com.ril.newcommerce.supplychain.message.exceptions;

public class DefaultInitializationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DefaultInitializationException(String message) {
		super(message);
	}
	
	public DefaultInitializationException(String message, Throwable th) {
		super(message,th);
	}
	
	public DefaultInitializationException(Throwable th) {
		super(th);
	}
}
