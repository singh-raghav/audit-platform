package com.ril.newcommerce.supplychain.message.processors;

import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.exceptions.RecoverableMessageProcessingException;
import com.ril.newcommerce.supplychain.message.exceptions.UnrecoverableMessageProcessingException;

public interface SupplyChainMessageProcessor<K, V> {

	void process(SupplyChainMessage<K, V> message) throws UnrecoverableMessageProcessingException, RecoverableMessageProcessingException;
	
	void onFailure(SupplyChainMessage<K, V> message);
}
