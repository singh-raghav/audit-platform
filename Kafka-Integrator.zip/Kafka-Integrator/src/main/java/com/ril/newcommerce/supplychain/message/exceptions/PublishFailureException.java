package com.ril.newcommerce.supplychain.message.exceptions;

public class PublishFailureException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public PublishFailureException(String message) {
		super(message);
	}
	
	public PublishFailureException(String message, Throwable th) {
		super(message,th);
	}
	
	public PublishFailureException(Throwable th) {
		super(th);
	}
}
