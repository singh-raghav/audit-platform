package com.ril.newcommerce.supplychain.message.retry.handlers;

import static com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants.RETRY_TIME;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;

import com.ril.newcommerce.supplychain.message.SupplyChainDelayedMessage;
import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.exceptions.DelayedPollException;

public class RetryDeliveryScheduleHandler<K, V> {

	private DelayQueue<SupplyChainDelayedMessage<K, V>> delayQueue;
	private long timeoutInMillis;
	
	public RetryDeliveryScheduleHandler(long timeout) {
		
		this.timeoutInMillis = timeout;
		delayQueue = new DelayQueue<SupplyChainDelayedMessage<K, V>>();
	}
	
	public void schedule(SupplyChainMessage<K, V> message) {
		
		long retryTime = System.currentTimeMillis();
		
		if(!StringUtils.isBlank(message.getHeader(RETRY_TIME))) {
			
			retryTime = Long.parseLong(message.getHeader(RETRY_TIME));
		}
		
		SupplyChainDelayedMessage<K, V> delayedMessage = new SupplyChainDelayedMessage<K, V>(message, retryTime);
		
		delayQueue.offer(delayedMessage);
	}

	public boolean hasNext() {
		
		return !this.delayQueue.isEmpty();
	}

	public SupplyChainMessage<K, V> next() {
		
		SupplyChainMessage<K, V> message = null;
		
		try {
			SupplyChainDelayedMessage<K, V> delayedMessage = this.delayQueue.poll(timeoutInMillis, 
					TimeUnit.MILLISECONDS);
			
			if(delayedMessage != null) {
				message = delayedMessage.getEncapMessage();
			}
		}
		catch(Exception ex) {
			throw new DelayedPollException(ex);
		}
		
		return message;
	}
}
