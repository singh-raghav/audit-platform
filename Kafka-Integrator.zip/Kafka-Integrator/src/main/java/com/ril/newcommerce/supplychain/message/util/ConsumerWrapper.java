package com.ril.newcommerce.supplychain.message.util;

import java.util.List;

import org.apache.kafka.clients.consumer.Consumer;

public class ConsumerWrapper<K, V> {

	private Consumer<K, V> consumer;
	private List<String> topics;
	
	public Consumer<K, V> getConsumer() {
		return consumer;
	}
	public void setConsumer(Consumer<K, V> consumer) {
		this.consumer = consumer;
	}
	public List<String> getTopics() {
		return topics;
	}
	public void setTopics(List<String> topics) {
		this.topics = topics;
	}	
}
