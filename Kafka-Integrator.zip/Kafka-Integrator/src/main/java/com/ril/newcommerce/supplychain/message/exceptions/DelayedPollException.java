package com.ril.newcommerce.supplychain.message.exceptions;

public class DelayedPollException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DelayedPollException(String message) {
		super(message);
	}
	
	public DelayedPollException(String message, Throwable th) {
		super(message,th);
	}
	
	public DelayedPollException(Throwable th) {
		super(th);
	}
}
