package com.ril.newcommerce.supplychain.message.retry.handlers;

import static com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants.RETRY_COUNT;
import static com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants.RETRY_TIME;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.exceptions.RecoverableMessageProcessingException;
import com.ril.newcommerce.supplychain.message.processors.SupplyChainMessageProcessor;
import com.ril.newcommerce.supplychain.message.producers.SupplyChainKafkaProducer;
import com.ril.newcommerce.supplychain.message.util.ProducerResultMetadata;

public class RetryDeliveryExceptionHandler<K, V> {

	private static final Logger logger = LoggerFactory.getLogger(RetryDeliveryExceptionHandler.class);

	private SupplyChainKafkaProducer<K, V> producer;
	private SupplyChainMessageProcessor<K, V> messageProcessor;
	private String retryTopic;
	private String failureTopic;
	private int maxRetryAttempts;
	private long retryDelayInMillis;

	
	public RetryDeliveryExceptionHandler(SupplyChainKafkaProducer<K, V> producer, 
			SupplyChainMessageProcessor<K, V> messageProcessor,
			int maxRetryAttempts, long retryDelayInMillis,
			String retryTopic, String failureTopic) {
		
		this.producer = producer;
		this.messageProcessor = messageProcessor;
		this.retryTopic = retryTopic;
		this.retryDelayInMillis = retryDelayInMillis;
		this.failureTopic = failureTopic;
		this.maxRetryAttempts = maxRetryAttempts;
	}
	
	public ProducerResultMetadata handle(Throwable issue, SupplyChainMessage<K, V> message) {
		
		if(issue instanceof RecoverableMessageProcessingException) {
			
			return handleRecoverableException(message);
		}
		
		return handleUnrecoverableException(message);
	}
	
	private ProducerResultMetadata handleRecoverableException(SupplyChainMessage<K, V> message) {
		
		int retryAttemptCount = 0;
		
		if(!StringUtils.isBlank(message.getHeader(RETRY_COUNT))) {
			retryAttemptCount = Integer.valueOf(message.getHeader(RETRY_COUNT));
		}
		
		if(retryAttemptCount >= maxRetryAttempts) {
			return handleUnrecoverableException(message);
		}		
			
		retryAttemptCount+=1;
		message.setHeader(RETRY_COUNT, retryAttemptCount+"");
		
		long retryTime = System.currentTimeMillis() + this.retryDelayInMillis;
		
		message.setHeader(RETRY_TIME, retryTime+"");
		
		logger.warn("Redirecting the message {} to the retry topic {}", message, this.retryTopic);
		return this.producer.send(message, this.retryTopic);
		
	}

	private ProducerResultMetadata handleUnrecoverableException(SupplyChainMessage<K, V> message) {
		
		logger.warn("Redirecting the message {} to the failure topic {}", message, this.failureTopic);
		ProducerResultMetadata result = this.producer.send(message, this.failureTopic);
		
		this.messageProcessor.onFailure(message);
		
		return result;
	}
}
