package com.ril.newcommerce.supplychain.message.exceptions;

public class ConfigurationValidationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ConfigurationValidationException(String message) {
		super(message);
	}
	
	public ConfigurationValidationException(String message, Throwable th) {
		super(message,th);
	}
	
	public ConfigurationValidationException(Throwable th) {
		super(th);
	}
}
