package com.ril.newcommerce.supplychain.message.util;

public final class KafkaIntegrationConstants {

	public static final String BOOT_SERVERS = "bootstrap.servers";
	
	public static final String GROUP_ID = "group.id";
	
	public static final String CLIENT_ID = "client.id";
	
	public static final String KEY_DESERIAL = "key.deserializer";
	
	public static final String VALUE_DESERIAL = "value.deserializer";
	
	public static final String KEY_SERIAL = "key.serializer";
	
	public static final String VALUE_SERIAL = "value.serializer";
	
	public static final String TOPIC = "TOPIC";
	
	public static final String OFFSET = "OFFSET";
	
	public static final String PARTITION = "PARTITION";
	
	public static final String RETRY_COUNT = "RETRY_COUNT";
	
	public static final String RETRY_TIME = "RETRY_TIME";
	
	public static final String TIMESTAMP = "TIMESTAMP";
	
	public static final String TIMESTAMP_TYPE = "TIMESTAMP_TYPE";
}
