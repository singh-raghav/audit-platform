package com.ril.newcommerce.supplychain.message;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

public class SupplyChainDelayedMessage<K, V> implements Delayed {

	private SupplyChainMessage<K, V> encapMessage;
	private long startTime;
	
	public SupplyChainDelayedMessage(SupplyChainMessage<K, V> message, long retryTime) {
		this.encapMessage = message;
		this.startTime = retryTime;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int compareTo(Delayed o) {
		return (int)(this.startTime - ((SupplyChainDelayedMessage<K, V>) o).startTime);
	}

	@Override
	public long getDelay(TimeUnit unit) {
		long diff = this.startTime - System.currentTimeMillis();
		return unit.convert(diff, TimeUnit.MILLISECONDS);
	}

	public SupplyChainMessage<K, V> getEncapMessage() {
		return encapMessage;
	}
}
