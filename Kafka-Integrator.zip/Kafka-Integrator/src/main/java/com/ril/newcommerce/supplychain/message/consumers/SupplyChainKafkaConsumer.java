package com.ril.newcommerce.supplychain.message.consumers;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.config.SupplyChainConsumerConfig;
import com.ril.newcommerce.supplychain.message.exceptions.ConfigurationValidationException;
import com.ril.newcommerce.supplychain.message.processors.SupplyChainMessageProcessor;
import com.ril.newcommerce.supplychain.message.retry.handlers.RetryDeliveryExceptionHandler;
import com.ril.newcommerce.supplychain.message.util.ConsumerWrapper;
import com.ril.newcommerce.supplychain.message.util.KafkaIntegrationConstants;
import com.ril.newcommerce.supplychain.message.util.KafkaIntegrationUtil;

public class SupplyChainKafkaConsumer<K, V> {

	private static final Logger logger = LoggerFactory.getLogger(SupplyChainKafkaConsumer.class);

	private static final String propertyFile = "consumer.properties";
	
	protected static final String CONSUMER_NAME_PREFIX = "Consumer_On_Topic(s)_";

	private int concurrency = 1; //TODO: May consider exposing it to the integrating applications later
	
	private long shutdownWaitInMillis = 30000l;

	protected List<ConsumerWrapper<K, V>> consumers;
	protected ExecutorService exServ;
	protected SupplyChainMessageProcessor<K, V> processor;
	

	public SupplyChainKafkaConsumer(SupplyChainMessageProcessor<K, V> processor, SupplyChainConsumerConfig config) {

		validate(config);

		Properties props = initialize();

		configureConsumer(props, config);

		this.processor = processor;
		
		this.consumers = new ArrayList<>(concurrency);
		
		for(int i = 0; i < concurrency; i++) {
			
			ConsumerWrapper<K, V> consumer = createConsumer(props, config.getTopics());
			consumers.add(consumer);
		}
				
		this.exServ = Executors.newFixedThreadPool(concurrency);
		
		addShutdownHook(consumers, exServ);
	}
	
	public void start() {
	
		start(this.consumers, this.processor, this.exServ, null);
	}
	
	void start(RetryDeliveryExceptionHandler<K, V> exceptionHandler) {
		
		start(this.consumers, this.processor, this.exServ, exceptionHandler);
	}
	
	private void start(List<ConsumerWrapper<K, V>> consumers, SupplyChainMessageProcessor<K, V> processor, 
			ExecutorService exServ, RetryDeliveryExceptionHandler<K, V> exceptionHandler) {
		
		consumers.forEach(consumer -> {
			
			exServ.submit(new Runnable() {

				@Override
				public void run() {
					startConsumer(consumer, processor, exceptionHandler);
				}
			});
		});
	}
	
	private void startConsumer(ConsumerWrapper<K, V> consumerWrapper, SupplyChainMessageProcessor<K, V> messageProcessor,
			RetryDeliveryExceptionHandler<K, V> exceptionHandler) {
		
		Thread.currentThread().setName(CONSUMER_NAME_PREFIX+consumerWrapper.getTopics());
		
		Duration duration = Duration.ofMillis(Long.MAX_VALUE);

		try {

			while(true) {

				Consumer<K, V> consumer = consumerWrapper.getConsumer();
				consumer.subscribe(consumerWrapper.getTopics());
				
				ConsumerRecords<K, V> records = consumer.poll(duration);

				records.forEach(record -> {

					SupplyChainMessage<K, V> message = new SupplyChainMessage<K, V>();

					KafkaIntegrationUtil.inflateMessage(message, record);

					record.headers().forEach(header -> {
						
						message.setHeader(header.key(), new String(header.value()));
					});
					
					try {
						messageProcessor.process(message);
					}
					catch (Exception e) {

						logger.error("Exception thrown while processing the message {}", e);
						
						if(exceptionHandler != null) {
						
							exceptionHandler.handle(e, message);
						}
					}
				});

				consumer.commitSync(duration);
			}
		}
		catch(WakeupException we) {
			
			logger.error("WakeupException thrown, probably shutting down the consumer", we);
		}
		finally {
			
			logger.info("Closing the consumer...");
			consumerWrapper.getConsumer().close();
		}
	}

	private void addShutdownHook(List<ConsumerWrapper<K, V>> consumers, ExecutorService exServ) {

		Runtime.getRuntime().addShutdownHook(new Thread() {

			@Override
			public void run() {

				consumers.forEach(consumer -> {
					
					consumer.getConsumer().wakeup();
				});
				
				exServ.shutdown();
				
				try {
					exServ.awaitTermination(shutdownWaitInMillis, TimeUnit.MILLISECONDS);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
	}

	private ConsumerWrapper<K, V> createConsumer(Properties props, List<String> sourceTopics) {

		logger.info("Creating consumer with the config {} and topic {}", props, sourceTopics);

		Consumer<K, V> consumer = new KafkaConsumer<>(props);

		ConsumerWrapper<K, V> consumerWrap = new ConsumerWrapper<>();
		consumerWrap.setConsumer(consumer);
		consumerWrap.setTopics(sourceTopics);
		
		return consumerWrap;
	}

	private void validate(SupplyChainConsumerConfig config) {

		StringBuilder builder = new StringBuilder();

		if(config.getTopics() == null || config.getTopics().isEmpty()) {
			builder.append("\nSource topic(s) not defined");
		}

		if(StringUtils.isBlank(config.getDestinationDetails())) {
			builder.append("\nBootstrap servers not defined");
		}

		if(StringUtils.isBlank(config.getConsumerGroupId())) {
			builder.append("\nConsumer group(GroupId) not defined");
		}

		if(StringUtils.isBlank(config.getApplicationId())) {
			builder.append("\nApplication Id (client Id) not defined");
		}

		if(!StringUtils.isBlank(builder.toString())) {
			throw new ConfigurationValidationException(builder.toString());
		}

		if(StringUtils.isBlank(config.getKeyDeserializer())) {
			logger.warn("No key deserializer is defined, defaulting to StringDeserializer");
		}

		if(StringUtils.isBlank(config.getValueDeserializer())) {
			logger.warn("No value deserializer is defined, defaulting to StringDeserializer");
		}
	}

	private Properties initialize() {

		return KafkaIntegrationUtil.loadProperties(propertyFile);
	}

	private void configureConsumer(Properties props, SupplyChainConsumerConfig config) {

		props.put(KafkaIntegrationConstants.BOOT_SERVERS, config.getDestinationDetails());

		props.put(KafkaIntegrationConstants.GROUP_ID, config.getConsumerGroupId());

		props.put(KafkaIntegrationConstants.CLIENT_ID, config.getApplicationId());

		String keyDeserializer = StringDeserializer.class.getName();
		if(!StringUtils.isBlank(config.getKeyDeserializer())) {
			keyDeserializer = config.getKeyDeserializer();
		}

		String valueDeserializer = StringDeserializer.class.getName();
		if(!StringUtils.isBlank(config.getValueDeserializer())) {
			valueDeserializer = config.getValueDeserializer();
		}

		props.put(KafkaIntegrationConstants.KEY_DESERIAL, keyDeserializer);
		props.put(KafkaIntegrationConstants.VALUE_DESERIAL, valueDeserializer);
	}
}
