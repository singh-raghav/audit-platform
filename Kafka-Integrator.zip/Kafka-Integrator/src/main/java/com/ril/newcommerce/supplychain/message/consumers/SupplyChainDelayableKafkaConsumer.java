package com.ril.newcommerce.supplychain.message.consumers;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutorService;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.config.SupplyChainConsumerConfig;
import com.ril.newcommerce.supplychain.message.processors.SupplyChainMessageProcessor;
import com.ril.newcommerce.supplychain.message.retry.handlers.RetryDeliveryExceptionHandler;
import com.ril.newcommerce.supplychain.message.retry.handlers.RetryDeliveryScheduleHandler;
import com.ril.newcommerce.supplychain.message.util.ConsumerWrapper;
import com.ril.newcommerce.supplychain.message.util.KafkaIntegrationUtil;


class SupplyChainDelayableKafkaConsumer<K, V> extends SupplyChainKafkaConsumer<K, V> {

	private static final Logger logger = LoggerFactory.getLogger(SupplyChainDelayableKafkaConsumer.class);
		
	
	public SupplyChainDelayableKafkaConsumer(SupplyChainMessageProcessor<K, V> processor, SupplyChainConsumerConfig config) {
		super(processor, config);
	}
	
	@Override
	public void start() {
	
		start(this.consumers, this.processor, this.exServ, null, null);
	}
	
	void start(RetryDeliveryExceptionHandler<K, V> exceptionHandler, 
			RetryDeliveryScheduleHandler<K, V> scheduleHandler) {
		
		start(this.consumers, this.processor, this.exServ, exceptionHandler, scheduleHandler);
	}
	
	private void start(List<ConsumerWrapper<K, V>> consumers, SupplyChainMessageProcessor<K, V> processor, 
			ExecutorService exServ, RetryDeliveryExceptionHandler<K, V> exceptionHandler, 
			RetryDeliveryScheduleHandler<K, V> scheduleHandler) {
		
		consumers.forEach(consumer -> {
			
			exServ.submit(new Runnable() {

				@Override
				public void run() {
					startConsumer(consumer, processor, exceptionHandler, scheduleHandler);
				}
			});
		});
	}
	
	private void startConsumer(ConsumerWrapper<K, V> consumerWrapper, SupplyChainMessageProcessor<K, V> messageProcessor,
			RetryDeliveryExceptionHandler<K, V> exceptionHandler, RetryDeliveryScheduleHandler<K, V> scheduleHandler) {
		
		Thread.currentThread().setName(CONSUMER_NAME_PREFIX+consumerWrapper.getTopics());
		
		Duration duration = Duration.ofMillis(Long.MAX_VALUE);
		
		try {

			while(true) {

				Consumer<K, V> consumer = consumerWrapper.getConsumer();
				consumer.subscribe(consumerWrapper.getTopics());
				
				ConsumerRecords<K, V> records = consumer.poll(duration);

				records.forEach(record -> {
					
					SupplyChainMessage<K, V> message = new SupplyChainMessage<K, V>();

					KafkaIntegrationUtil.inflateMessage(message, record);
					
					record.headers().forEach(header -> {
						message.setHeader(header.key(), new String(header.value()));
					}); 
					
					scheduleHandler.schedule(message);
					
				});
				
				processScheduledMessages(consumer, duration, messageProcessor, 
						exceptionHandler, scheduleHandler);
			}
		}
		catch(Exception we) {
			
			logger.error("Exception thrown, closing down the consumer", we);
		}
		finally {
			
			logger.info("Closing the consumer...");
			consumerWrapper.getConsumer().close();
		}
	}

	private void processScheduledMessages(Consumer<K, V> consumer, Duration duration, 
			SupplyChainMessageProcessor<K, V> messageProcessor,
			RetryDeliveryExceptionHandler<K, V> exceptionHandler, 
			RetryDeliveryScheduleHandler<K, V> scheduleHandler) {
		
			
		while(scheduleHandler.hasNext()) {
			
			SupplyChainMessage<K, V> message = scheduleHandler.next();
			
			if(message != null) {
				
				try {
					messageProcessor.process(message);				
				}
				catch (Exception e) {

					logger.error("Exception thrown while processing the message {}", e);
					
					if(exceptionHandler != null) {
					
						exceptionHandler.handle(e, message);
					}
				}
			}
		}
		
		consumer.commitSync(duration);
	}
}
