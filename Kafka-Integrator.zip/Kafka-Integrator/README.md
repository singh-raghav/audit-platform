The repository is a wrapper around the Apache Kafka producer and consumer libraries. The intent of this library is to build a consistent Kafka integration pattern for RIL Grocery applications.

The library takes a biased view of the configuration that should suit the majority of RIL Grocery applications. It saves the applications from going through the configuration glut making Kafka integration simple.

Besides this, the library also provides the mechanism of delayed redelivery feature helpful under transient failures.

Following are the capabilities exposed by this library -

	1. Kafka Producer 
	2. Kafka Consumer
	3. Retryable Kafka Consumer
	
Please refer to the following sample classes (under src/test/java) to understand how to use the library -

	1. RILGroceryKafkaProducerRunner.java
	2. RILGroceryKafkaConsumerRunner.java
	3. RILGroceryRetryableKafkaConsumerRunner.java
	
