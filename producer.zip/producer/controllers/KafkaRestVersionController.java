package com.ril.newcommerce.supplychain.kafka.rest.producer.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.Properties;

@RestController

public class KafkaRestVersionController {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaRestVersionController.class);

    private Properties version = new Properties();

    @RequestMapping(value = "/version",method = RequestMethod.GET)
    public String displayVersionOfDeployedArtifact( ){
        return version.getProperty("version.number");
    }





    @PostConstruct
    private void initialize(){
        Resource resource = new ClassPathResource("/version.properties");
        try {
            version = PropertiesLoaderUtils.loadProperties(resource);
        } catch (IOException e) {
            LOGGER.error("Unable to load version.properties" , e);
        }

        LOGGER.info("Loaded version.properties");
    }


}
