package com.ril.newcommerce.supplychain.kafka.rest.producer.controllers;


import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.ril.newcommerce.supplychain.kafka.rest.producer.errors.KafkaRestProducerException;


@RestController
@RequestMapping(value = "/restKafka")
public interface KafkaRestController {


    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    @RequestMapping(value = "/v1/producer", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<?> publish(
            @RequestHeader(value = "clientId") String clientId,
            @RequestHeader(value = "serviceName") String serviceName,
            @RequestHeader(value = "apiKey") String apiKey,
            @RequestParam(value = "partitionKey", required = false) final String partitionkey,
            @RequestBody JsonNode message)

            throws KafkaRestProducerException;


    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    @RequestMapping(value = "/v1/xml/producer", method = RequestMethod.POST, consumes = MediaType.APPLICATION_XML_VALUE)
    ResponseEntity<?> publish(
            @RequestHeader(value = "clientId") String clientId,
            @RequestHeader(value = "serviceName") String serviceName,
            @RequestHeader(value = "apiKey") String apiKey,
            @RequestParam(value = "partitionKey", required = false) final String partitionkey,
            @RequestBody String message)

            throws KafkaRestProducerException;

}

