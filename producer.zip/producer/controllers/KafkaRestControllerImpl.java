package com.ril.newcommerce.supplychain.kafka.rest.producer.controllers;


import java.util.List;

import com.ril.newcommerce.supplychain.kafka.rest.producer.services.ConfigurationService;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.ril.newcommerce.supplychain.kafka.rest.producer.engine.Producer;
import com.ril.newcommerce.supplychain.kafka.rest.producer.errors.ErrorResponse;
import com.ril.newcommerce.supplychain.kafka.rest.producer.errors.Errors;
import com.ril.newcommerce.supplychain.kafka.rest.producer.errors.KafkaRestProducerException;
import com.ril.newcommerce.supplychain.kafka.rest.producer.models.ProducerResult;
import com.ril.newcommerce.supplychain.kafka.rest.producer.services.AuthorizationService;
import com.ril.newcommerce.supplychain.kafka.rest.producer.transformers.MessageTransformer;
import com.ril.newcommerce.supplychain.kafka.rest.producer.transformers.MessageTransformerFactory;
import com.ril.newcommerce.supplychain.kafka.rest.producer.transformers.TransformerResult;
import com.ril.newcommerce.supplychain.kafka.rest.producer.validators.MessageValidator;
import com.ril.newcommerce.supplychain.kafka.rest.producer.validators.ValidatorFactory;


@Controller
public class KafkaRestControllerImpl implements KafkaRestController {


    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaRestControllerImpl.class);
    

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private ValidatorFactory validatorFactory;

    @Autowired
    private MessageTransformerFactory transformerFactory;


    @Autowired
    private ConfigurationService configService;


    private final Producer producer;

    private final String SERVICE_NAME = "serviceName";
    private final String CLIENT_ID = "clientId";

    @Autowired
    KafkaRestControllerImpl(Producer producer) {
        this.producer = producer;
    }


    @Override
    public ResponseEntity<?> publish(@RequestHeader(value = "clientId") String clientId,
                                     @RequestHeader(value = "serviceName") String serviceName,
                                     @RequestHeader(value = "apiKey") String apiKey,
                                     @RequestParam(value = "partitionKey", required = false) final String partitionkey,
                                     @RequestBody JsonNode message) throws KafkaRestProducerException {

        return sendMessage(clientId, serviceName, apiKey, partitionkey, message != null ? message.toString() : "");
    }



    @Override
    public  ResponseEntity<?> publish(
            @RequestHeader(value = "clientId") String clientId,
            @RequestHeader(value = "serviceName") String serviceName,
            @RequestHeader(value = "apiKey") String apiKey,
            @RequestParam(value = "partitionKey", required = false) final String partitionkey,
            @RequestBody String message){
        return sendMessage(clientId, serviceName, apiKey, partitionkey, message != null ? message : "");
    }

    private ResponseEntity<?> sendMessage(String clientId, String serviceName, String apiKey, String partitionkey, String messageString)
            throws KafkaRestProducerException {

        LOGGER.info("Publish request received for clientId {}, service {}", clientId, serviceName);
        LOGGER.debug("message {}", messageString);

        ProducerResult result = null;

        boolean isAuthorized = authorizationService.isAuthorized(clientId, apiKey);

        if (isAuthorized) {
            Headers headers = new RecordHeaders();
            headers.add(SERVICE_NAME, serviceName.getBytes());
            headers.add(CLIENT_ID, clientId.getBytes());


            List<MessageValidator<String>> validators = validatorFactory.getInboundValidators(clientId, serviceName);

            for (MessageValidator<String> validator : validators) {

                if (!validator.isValid(messageString)) {

                    LOGGER.error("Inbound message validation failed: Validator - {}. Message - {}", validator.name(), messageString);

                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                            HttpStatus.BAD_REQUEST.getReasonPhrase(),
                            new ErrorResponse.ApiError(Errors.INBOUND_SCHEMA_VALIDATION_FAILED)));
                }
            }


            List<MessageTransformer<String, TransformerResult<String>>> transformers = transformerFactory.getMessageTransformers(clientId, serviceName);

            for (MessageTransformer<String, TransformerResult<String>> transformer : transformers) {

                TransformerResult<String> transformResult = transformer.transform(messageString);

                if (transformResult.hasException()) {

                    LOGGER.error("Message transformation failed: Validator - {}. Message - {}", transformer.name(), messageString);

                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                            HttpStatus.BAD_REQUEST.getReasonPhrase(),
                            new ErrorResponse.ApiError(Errors.TRANSFORMATION_FAILED)));
                } else {
                    messageString = transformResult.getTransformedResult();
                }
            }

            List<MessageValidator<String>> outboundValidators = validatorFactory.getOutboundValidators(clientId, serviceName);

            for (MessageValidator<String> validator : outboundValidators) {

                if (!validator.isValid(messageString)) {
                    LOGGER.warn("Post transformation validation failed: Validator - {}. Message - {}", validator.name(), messageString);

                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                            HttpStatus.BAD_REQUEST.getReasonPhrase(),
                            new ErrorResponse.ApiError(Errors.OUTBOUND_SCHEMA_VALIDATION_FAILED)));
                }
            }

            result = this.producer.sendMessage(messageString, clientId, serviceName, partitionkey, headers);

            LOGGER.info("Publish request processed for clientId {}, service {} with response {}", clientId, serviceName, result.toString());

            return new ResponseEntity<ProducerResult>(result, HttpStatus.valueOf(result.getStatusCode()));

        } else {
            LOGGER.warn("{} not authorized to access the api", clientId);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new ErrorResponse(HttpStatus.UNAUTHORIZED.value(),
                    HttpStatus.UNAUTHORIZED.getReasonPhrase(),
                    new ErrorResponse.ApiError(Errors.UNAUTHORIZED)));
        }
    }

}

