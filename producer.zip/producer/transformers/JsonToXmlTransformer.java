package com.ril.newcommerce.supplychain.kafka.rest.producer.transformers;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.odysseus.staxon.json.JsonXMLConfig;
import de.odysseus.staxon.json.JsonXMLConfigBuilder;
import de.odysseus.staxon.json.JsonXMLInputFactory;

/**
 * 
 * @author amit1.pundir
 *
 */
public class JsonToXmlTransformer implements MessageTransformer<String, TransformerResult<String>> {

	private static Logger logger= LoggerFactory.getLogger(JsonToXmlTransformer.class);

	@Override
	public String name() {
		return getClass().getName();
	}

	@Override
	public TransformerResult<String> transform(String input)  {
		
		TransformerResult<String> result = new TransformerResult<>();
		
		XMLEventReader xmlEventReader = null;
		XMLEventWriter xmlEventWriter = null;
		StringWriter stringWriter = null;
				
		try {
			
			JsonXMLConfig config = new JsonXMLConfigBuilder().multiplePI(false).build();
			
			xmlEventReader = new JsonXMLInputFactory(config).createXMLEventReader(new StringReader(input));
			
			stringWriter = new StringWriter();
			
			xmlEventWriter = XMLOutputFactory.newInstance().createXMLEventWriter(stringWriter);
						
			xmlEventWriter.add(xmlEventReader);
			
			result.setTransformedResult(stringWriter.toString());
		} catch (Exception ps){
			logger.error("unable to parse JSON to XML",ps);
			result.setException(ps);
		} finally {
			
			if(stringWriter != null) { 
				
				try {
					stringWriter.close();
				} catch (IOException e) {
					logger.error("",e);
				}
			}
			
			if(xmlEventWriter != null) { 
			
				try {
					xmlEventWriter.close();
				} catch (XMLStreamException e) {
					logger.error("",e);
				}
			}
			
			if(xmlEventReader != null) { 
				
				try {
					xmlEventReader.close();
				} catch (XMLStreamException e) {
					logger.error("",e);
				}
			}
		}
		
		return result;
	}
}
