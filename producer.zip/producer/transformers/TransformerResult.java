package com.ril.newcommerce.supplychain.kafka.rest.producer.transformers;

/**
 * 
 * @author amit1.pundir
 *
 * @param <T>
 */
public class TransformerResult<T> {

	private T transformedResult;
	
	private Exception exception;


	public T getTransformedResult() {
		return transformedResult;
	}

	public void setTransformedResult(T transformedResult) {
		this.transformedResult = transformedResult;
	}

	public Exception getException() {
		return exception;
	}

	public void setException(Exception exception) {
		this.exception = exception;
	}
	
	public boolean hasException() {
		return exception != null;
	}

	@Override
	public String toString() {
		return "TransformerResult [transformedResult=" + transformedResult + ", exception=" + exception + "]";
	}
}
