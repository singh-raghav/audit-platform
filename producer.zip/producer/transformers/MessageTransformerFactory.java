package com.ril.newcommerce.supplychain.kafka.rest.producer.transformers;


import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.kafka.rest.producer.services.ConfigurationService;

/**
 * 
 * @author amit1.pundir
 *
 * @param <K>
 * @param <T>
 */
@Component
public class MessageTransformerFactory {

	@Autowired
	private ConfigurationService configService;
	
	private static final String DOT = ".";
		
	private Map<String, List<MessageTransformer<String, TransformerResult<String>>>> messageTransformerMap = new HashMap<>();
	
	
	private MessageTransformerFactory() {}
	
	
	@PostConstruct
	private void initialize() {
		
		//TODO: This can be made generic but will do so after we have a better configuration management system
		List<String> clients = configService.getXmlTransformationClients();
		
		clients.forEach(client -> {
			
			messageTransformerMap.put(client, new LinkedList<MessageTransformer<String, TransformerResult<String>>>());
			
			MessageTransformer<String, TransformerResult<String>> transformer = new JsonToXmlTransformer();
						
			messageTransformerMap.get(client).add((transformer));
			
		});
	}

	public List<MessageTransformer<String, TransformerResult<String>>> getMessageTransformers(String clientId, String serviceName) {
		
		List<MessageTransformer<String, TransformerResult<String>>> transformers = new LinkedList<>();
		
		String key = new StringBuilder(clientId).append(DOT).append(serviceName).toString();
		
		if(messageTransformerMap.containsKey(key)) {
			
			transformers.addAll(messageTransformerMap.get(key));
		}
		
		return transformers;
	}
}
