package com.ril.newcommerce.supplychain.kafka.rest.producer.transformers;

/**
 * This class was created to cover for default transformation of input to build
 * a consistent application flow but deemed overhead during initialization so has
 * been deprecated for now.
 * 
 * @author amit1.pundir
 *
 * @param <K>
 */
@Deprecated
public class PassThroughTransformer<K> implements MessageTransformer<K, TransformerResult<K>> {

	@Override
	public String name() {
		return getClass().getName();
	}


	@Override
	public TransformerResult<K> transform(K input) {

		TransformerResult<K> result = new TransformerResult<K>();
		result.setTransformedResult(input);
		
		return result;
	}
}
