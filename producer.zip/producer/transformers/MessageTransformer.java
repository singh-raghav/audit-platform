package com.ril.newcommerce.supplychain.kafka.rest.producer.transformers;

/**
 * 
 * @author amit1.pundir
 *
 * @param <K>
 * @param <T>
 */
public interface MessageTransformer<K, T> {

	String name();
	
	T transform(K input);
}
