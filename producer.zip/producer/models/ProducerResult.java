package com.ril.newcommerce.supplychain.kafka.rest.producer.models;

public class ProducerResult {

    int statusCode;

    boolean success;

    private long offset;

    String topic;

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public long getOffset() {
        return offset;
    }

    public void setOffset(long offset) {
        this.offset = offset;
    }


    public void setSuccess(boolean success) {
        this.success = success;
    }

    public boolean isSuccess() {
        return success;
    }

    public ProducerResult() {
    }


    public ProducerResult(boolean success, long offset,int statusCode) {
        this.success = success;
        this.offset = offset;
        this.statusCode=statusCode;
    }



    @Override
    public String toString() {
        return "ProducerResult{" +
                "statusCode=" + statusCode +
                ", success=" + success +
                ", offset=" + offset +
                ", topic='" + topic + '\'' +
                '}';
    }
}
