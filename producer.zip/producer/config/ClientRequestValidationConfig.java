package com.ril.newcommerce.supplychain.kafka.rest.producer.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;

/**
 * 
 * @author amit1.pundir
 *
 *
 */
public class ClientRequestValidationConfig {

	@Value("#{${validate.json.schema:{'':''}}}")
	private Map<String/*ClientId*/, String/*SchemaFileName*/> clientJsonSchemaMap;
	
	@Value("#{${validate.xml.schema:{'':''}}}")
	private Map<String/*ClientId*/, String/*SchemaFileName*/> clientXmlSchemaMap;
	
	@Value("#{'${consumer.json.schema:}'.split(',')}")
	private List<String/*SchemaFileName*/> clientJsonSchemaFileList;
	
	@Value("#{'${consumer.xml.schema:}'.split(',')}")
	private List<String/*SchemaFileName*/> clientXmlSchemaFileList;

	@Value("#{'${transform.json.xml:}'.split(',')}")
	private List<String/*SchemaFileName*/> xmlTransformationClients;


	
	public Map<String, String> getClientJsonSchemaMap() {
		return new HashMap<>(clientJsonSchemaMap);
	}

	public Map<String, String> getClientXmlSchemaMap() {
		return new HashMap<>(clientXmlSchemaMap);
	}
	
	public List<String> getClientJsonSchemaFiles() {
		
		return new ArrayList<>(clientJsonSchemaFileList);
	}

	public List<String> getClientXmlSchemaFiles() {
		
		return new ArrayList<>(clientXmlSchemaFileList);
	}
	
	public List<String> getXmlTransformationClients() {
		
		return new ArrayList<>(xmlTransformationClients);
	}

	@Override
	public String toString() {
		return "ClientRequestValidationConfig [clientJsonSchemaMap=" + clientJsonSchemaMap + ", clientXmlSchemaMap="
				+ clientXmlSchemaMap + ", clientJsonSchemaFileList=" + clientJsonSchemaFileList
				+ ", clientXmlSchemaFileList=" + clientXmlSchemaFileList + ", xmlTransformationClients="
				+ xmlTransformationClients +"]";
	}
}
