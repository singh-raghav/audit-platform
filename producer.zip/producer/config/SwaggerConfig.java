package com.ril.newcommerce.supplychain.kafka.rest.producer.config;


import java.util.Arrays;
import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
	
    private static final  String MODEL_REF_TYPE="string";
    private static final String PARAM_TYPE="header";

    @Bean
    public Docket api() {

        return new Docket(DocumentationType.SWAGGER_2)
                .globalOperationParameters(Arrays.asList(
                        new ParameterBuilder()
                                .name("clientId")
                                .description("Client Id is required to authorize the client/consumer of this api")
                                .modelRef(new ModelRef(MODEL_REF_TYPE))
                                .parameterType(PARAM_TYPE)
                                .required(false)
                                .build(),
                        new ParameterBuilder()
                                .name("serviceName")
                                .description("Service name is the flow specific to which the client configuration is picked up")
                                .modelRef(new ModelRef(MODEL_REF_TYPE))
                                .parameterType(PARAM_TYPE)
                                .required(false)

                                .build(),
                        new ParameterBuilder()
                                .name("apiKey")
                                .description("API Key shared with the client to authorize the same")
                                .modelRef(new ModelRef(MODEL_REF_TYPE))
                                .parameterType(PARAM_TYPE)
                                .required(false)
                                .build()

                ))
                .groupName("Kafka-REST-Producer-Version-1.0")
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.ril.newcommerce.supplychain.kafka.rest.producer.controllers"))
                .paths(PathSelectors.ant("/restKafka/v1/**"))

                .build()
               .useDefaultResponseMessages(false)
               . apiInfo(apiInfo());
    }



    private ApiInfo apiInfo() {
        return new ApiInfo(
                "Reliance Retail E-Commerce Kafka REST Producer",
                "This REST API allows clients to publish messages to kafka topics.",
                "API ",
                "Terms of service",
                new Contact("Anshu jindal", "www.example.com", "anshu.jindal@ril.com"),
                "License of API", "API license URL", Collections.emptyList());
    }

//in case we need to add another version we should add another docektBean for the same

}
