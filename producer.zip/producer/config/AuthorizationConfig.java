package com.ril.newcommerce.supplychain.kafka.rest.producer.config;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

/**
 * 
 * @author amit1.pundir
 * TODO: Get rid of this class
 *
 */
public class AuthorizationConfig {

	private static Logger logger = LoggerFactory.getLogger(AuthorizationConfig.class);

	
	@Value("#{'${authorized.consumer.application.ids:}'.split(',')}")
	private List<String> consumerList;
	
	private Map<String, String> clientApiKeyMap = new HashMap<>();
	
	private static final String COLON = ":";
	private static final String UTF_8 = "UTF-8";

	
	@PostConstruct
	private void initialize() {
		
		if(consumerList != null && !consumerList.isEmpty()) {
			
			consumerList.forEach(consumer -> {
				
				consumer = StringUtils.trimWhitespace(consumer);
				
				if(!StringUtils.isEmpty(consumer)) {
					
					try {
						clientApiKeyMap.put(consumer, createApiKey(consumer));
					} 
					catch (UnsupportedEncodingException e)
					{
						logger.error("Unable to initialize client api",e);
					}
				}
			});
		}
		
		if(consumerList == null || consumerList.isEmpty()) {
			logger.info("No consumer is authorized to consume the api. Is that OK??");
		}
	}
	
	private String createApiKey(String clientId) throws UnsupportedEncodingException {
		
		String clientIdReverse = new StringBuilder(clientId).reverse().toString();
		
		byte[] bytes = new StringBuilder(clientId).append(COLON).append(clientIdReverse).toString().getBytes(UTF_8);
				
		return  Base64.getEncoder().encodeToString(bytes);
		
	}
	
	public String getClientApiKey(String clientId) {
		return clientApiKeyMap.get(clientId);
	}
	
	public Set<String> getAuthorizedClients() {
		return new HashSet<>(clientApiKeyMap.keySet());
	}

	@Override
	public String toString() {
		return "AuthorizationConfig [consumerList=" + consumerList + ", clientApiKeyMap=" + clientApiKeyMap + "]";
	}

}
