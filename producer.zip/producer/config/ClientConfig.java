package com.ril.newcommerce.supplychain.kafka.rest.producer.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 
 * @author amit1.pundir
 *
 *
 */
@Configuration
public class ClientConfig {

	@Bean
	public AuthorizationConfig authorizationConfigBuilder() {
		return new AuthorizationConfig();
	}
	
	@Bean
	public ClientRequestValidationConfig validationConfigBuilder() {
		return new ClientRequestValidationConfig();
	}
}
