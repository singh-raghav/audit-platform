package com.ril.newcommerce.supplychain.kafka.rest.producer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class KafkaRestProducerApiApplication {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaRestProducerApiApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(KafkaRestProducerApiApplication.class, args);
        
        LOGGER.info("Kafka REST Producer started...");
    }
}
