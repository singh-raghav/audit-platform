package com.ril.newcommerce.supplychain.kafka.rest.producer.services;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.ril.newcommerce.supplychain.kafka.rest.producer.config.AuthorizationConfig;



/**
 * 
 * @author amit1.pundir
 *
 */
@Service
public class AuthorizationService {


	@Autowired
	private AuthorizationConfig authConfig;
	
	
	public boolean isAuthorized(String clientId, String apiKey) {
	
		boolean isAuthorized = false;
		
		if(!StringUtils.isEmpty(authConfig.getClientApiKey(clientId)) 
				&& authConfig.getClientApiKey(clientId).equals(apiKey)) {
			
			isAuthorized = true;
		}
		
		return isAuthorized;
	}

	public Set<String> getAuthorizedClients() {
		return authConfig.getAuthorizedClients();
	} 
}
