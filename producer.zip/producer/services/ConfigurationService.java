package com.ril.newcommerce.supplychain.kafka.rest.producer.services;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.kafka.rest.producer.config.ClientRequestValidationConfig;

/**
 * 
 * @author amit1.pundir
 *
 */
@Service
public class ConfigurationService {

	@Autowired
	private ClientRequestValidationConfig requestValidatorConfig;

	public Set<String> getValidationOptingClients() {
		
		Set<String> allClients = new HashSet<>();
		
		allClients.addAll(requestValidatorConfig.getClientJsonSchemaMap().keySet());
		allClients.addAll(requestValidatorConfig.getClientXmlSchemaMap().keySet());
		
		return allClients;
	}

	public String getJsonSchemaForClient(String client) {
		return requestValidatorConfig.getClientJsonSchemaMap().get(client);
	}

	public String getXmlSchemaForClient(String client) {
		return requestValidatorConfig.getClientXmlSchemaMap().get(client);
	}
	
	public List<String> getJsonSchemaList() {
		return requestValidatorConfig.getClientJsonSchemaFiles();
	}

	public List<String> getXmlSchemaList() {
		return requestValidatorConfig.getClientXmlSchemaFiles();
	}
	
	public List<String> getXmlTransformationClients() {
		return requestValidatorConfig.getXmlTransformationClients();
	}


}
