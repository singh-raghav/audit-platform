package com.ril.newcommerce.supplychain.kafka.rest.producer.validators;

/**
 * 
 * @author amit1.pundir
 *
 * @param <T>
 */
public interface MessageValidator<T> {

	String name();
	
	boolean isValid(T message);
}
