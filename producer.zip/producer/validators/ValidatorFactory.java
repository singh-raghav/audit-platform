package com.ril.newcommerce.supplychain.kafka.rest.producer.validators;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.ril.newcommerce.supplychain.kafka.rest.producer.schema.SchemaRepository;
import com.ril.newcommerce.supplychain.kafka.rest.producer.services.ConfigurationService;

/**
 * 
 * @author amit1.pundir
 *
 */
@Component
public class ValidatorFactory {

	
	@Autowired
	private ConfigurationService configService;
	
	@Autowired
	private SchemaRepository repository;
	

	private static final String DOT = ".";
	
	private Map<String, List<MessageValidator<String>>> inboundValidatorMap = new HashMap<>();
	
	private Map<String, List<MessageValidator<String>>> outboundValidatorMap = new HashMap<>();
	
	
	private ValidatorFactory() {}
	
	
	@PostConstruct
	private void initialize() {
		
		Set<String> validatingClients = configService.getValidationOptingClients();
		
		validatingClients.forEach(client -> {
			
			inboundValidatorMap.put(client, new LinkedList<>());
			outboundValidatorMap.put(client, new LinkedList<>());
			
			String jsonSchema = configService.getJsonSchemaForClient(client);
			
			if(!StringUtils.isEmpty(jsonSchema)) {
				inboundValidatorMap.get(client).add(new SchemaValidator(repository.getSchema(jsonSchema)));
			}
			
			String xmlSchema = configService.getXmlSchemaForClient(client);
			
			if(!StringUtils.isEmpty(xmlSchema)) {
				outboundValidatorMap.get(client).add(new SchemaValidator(repository.getSchema(xmlSchema)));
			}
		});
	}

	public List<MessageValidator<String>> getInboundValidators(String clientId, String serviceName) {
		
		List<MessageValidator<String>> validatorList = new LinkedList<>();

		if(clientId==null || serviceName == null){
			return validatorList;
		}

		String key = new StringBuilder(clientId).append(DOT).append(serviceName).toString();
		
		if(inboundValidatorMap.get(key) != null) {
			
			validatorList.addAll(inboundValidatorMap.get(key));
		}
		return validatorList;	
	}


	public List<MessageValidator<String>> getOutboundValidators(String clientId, String serviceName) {
		
		List<MessageValidator<String>> validatorList = new LinkedList<>();

		if(clientId==null || serviceName == null){
			return validatorList;
		}

		String key = new StringBuilder(clientId).append(DOT).append(serviceName).toString();
		
		if(outboundValidatorMap.get(key) != null) {
			
			validatorList.addAll(outboundValidatorMap.get(key));
		}
		return validatorList;
	}
}
