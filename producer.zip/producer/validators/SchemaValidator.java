package com.ril.newcommerce.supplychain.kafka.rest.producer.validators;

import com.ril.newcommerce.supplychain.kafka.rest.producer.schema.RILGrocerySchema;

/**
 * 
 * @author amit1.pundir
 *
 */
public class SchemaValidator implements MessageValidator<String> {
	
	private RILGrocerySchema grSchema;
	
	
	public SchemaValidator(RILGrocerySchema schema) {
		
		grSchema = schema;
	}

	@Override
	public boolean isValid(String message) {
		
		return grSchema.validate(message);
	}

	@Override
	public String name() {
		return this.grSchema.getClass().getSimpleName();
	}
}
