package com.ril.newcommerce.supplychain.kafka.rest.producer.notificationservice;

public class FormattedMessage {
	private String emailMessage;
	private String smsMessage;

	public String getEmailMessage() {
		return emailMessage;
	}

	public void setEmailMessage(String emailMessage) {
		this.emailMessage = emailMessage;
	}

	public String getSmsMessage() {
		return smsMessage;
	}

	public void setSmsMessage(String smsMessage) {
		this.smsMessage = smsMessage;
	}

	@Override
	public String toString() {
		return "ClassPojo [emailMessage = " + emailMessage + ", smsMessage = "
				+ smsMessage + "]";
	}

}
