package com.ril.newcommerce.supplychain.kafka.rest.producer.notificationservice;

public class NotificationResponse {
	private String message;
	private String status;

	@Override
	public String toString() {
		return "ClassPojo[message = " + message + ", status = " + status + "]";
	}


	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
