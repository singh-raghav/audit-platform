package com.ril.newcommerce.supplychain.kafka.rest.producer.notificationservice;

public class Body {
	private Notification notification;

	public Notification getNotification() {
		return notification;
	}

	public void setNotification(Notification notification) {
		this.notification = notification;
	}

	@Override
	public String toString() {
		return "ClassPojo [notification = " + notification + "]";
	}

}
