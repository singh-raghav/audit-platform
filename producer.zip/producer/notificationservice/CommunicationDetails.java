package com.ril.newcommerce.supplychain.kafka.rest.producer.notificationservice;

public class CommunicationDetails {
	
	private String ccEmailId;
	private String subject;
	private String toEmailId;
	private String bccEmailId;
	private long mobileNo;
	private String fromEmail;

	@Override
	public String toString() {
			return "ClassPojo [ccEmailId = "+ccEmailId+", subject = "+subject+", toEmailId = "+toEmailId+", bccEmailId = "+bccEmailId+", mobileNo = "+mobileNo+", fromEmail = "+fromEmail+"]";
		}

	public String getCcEmailId() {
		return ccEmailId;
	}

	public void setCcEmailId(String ccEmailId) {
		this.ccEmailId = ccEmailId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getToEmailId() {
		return toEmailId;
	}

	public void setToEmailId(String toEmailId) {
		this.toEmailId = toEmailId;
	}

	public String getBccEmailId() {
		return bccEmailId;
	}

	public void setBccEmailId(String bccEmailId) {
		this.bccEmailId = bccEmailId;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}


}
