package com.ril.newcommerce.supplychain.kafka.rest.producer.notificationservice;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;


@Service
public class EmailNotificationService {
	@Autowired
	private MessageSource messageSource;

	private static final Logger logger = LogManager
			.getLogger(EmailNotificationService.class);

	private static final String SEPARATOR="\n"+"-----------------------------------STACK TRACE-----------------------------------"+"\n";

	@Value("${ne.rest.url}")
	private String neUrl;

	@Value("${ne.transaction.id}")
	private String transactionId;

	@Value("${ne.sourcesystem}")
	private String sourceSystem;

	@Value("${ne.appkey}")
	private String appKey;

	@Value("${ne.appname}")
	private String appName;

	@Value("${ne.enterprise.id}")
	private String enterpriseId;

	@Value("${ne.fromemail}")
	private String fromEmailId;

	@Value("${ne.toemail}")
	private String toEmailId;

	@Value("${ne.messagegroup}")
	private String messageGroup;


	@Value("${krp.notification.eventtype}")
	private String EVENT_TYPE;

	@Value("${krp.notification.event.detail}")
	private String EVENT_DETAIL;

	@Value("${krp.notification.subject}")
	private String MAIL_SUBJECT;


	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public void setNeUrl(String neUrl) {
		this.neUrl = neUrl;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	public void setFromEmailId(String fromEmailId) {
		this.fromEmailId = fromEmailId;
	}

	public void setToEmailId(String toEmailId) {
		this.toEmailId = toEmailId;
	}


	private ResponseEntity<String> postNotificationEmail(String eventType,String eventDetails, String subject) throws URISyntaxException {

		ResponseEntity<String> result=null;
		logger.info("EmailNotificationService: postNotificationEmail method starts.....");

		NotificationRequest neRequest = new NotificationRequest();
		Body requestBody = new Body();
		Notification notification = new Notification();
		NotificationType notificationType = new NotificationType();
		MessageContent messageContent = new MessageContent();
		CommunicationDetails communicationDetails = new CommunicationDetails();
		Header header = new Header();
		FormattedMessage formattedMessage = new FormattedMessage();

       //feeding data to send NE service
		neRequest.setAppName(appName);
		neRequest.setAppKey(appKey);
		neRequest.setEnterpriseId(enterpriseId);
		communicationDetails.setToEmailId(toEmailId);
		communicationDetails.setFromEmail(fromEmailId);
		communicationDetails.setSubject(subject);

		notificationType.setEmail(true);

		formattedMessage.setEmailMessage(eventDetails);

		messageContent.setFormattedMessage(formattedMessage);

		notification.setCommunicationDetails(communicationDetails);
		notification.setNotificationType(notificationType);
		notification.setMessageContent(messageContent);

		requestBody.setNotification(notification);

		header.setDateTime(ZonedDateTime.now().toEpochSecond());
		header.setMessageGroup(messageGroup);
		header.setMessageType(eventType);
		header.setSourceSystem(sourceSystem);
		header.setTransactionId(transactionId
				+ new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss")
						.format(new Date()));


		neRequest.setBody(requestBody);
		neRequest.setHeader(header);

		RestTemplate restTemplate = new RestTemplate();
		URI uri = new URI(neUrl);
		try {


			logger.info("NE uri is--" + uri + "-Requestbody is--------->>>>>>" + new ObjectMapper().writeValueAsString(neRequest));
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity(neRequest, headers);
			result = restTemplate.postForEntity(uri, request, String.class);
			logger.info("NE response is------------<<<<<<<" + new ObjectMapper().writeValueAsString(result));
		} catch (JsonProcessingException e) {
			logger.error("EmailNotificationService: postNotificationEmail throw exception....",e);
		}

		logger.info("EmailNotificationService: postNotificationEmail method ends.....");
		return result;
}


	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		EmailNotificationService that = (EmailNotificationService) o;
		return neUrl.equals(that.neUrl) &&
				transactionId.equals(that.transactionId) &&
				appKey.equals(that.appKey) &&
				appName.equals(that.appName) &&
				enterpriseId.equals(that.enterpriseId) &&
				fromEmailId.equals(that.fromEmailId) &&
				toEmailId.equals(that.toEmailId);
	}

	@Override
	public int hashCode() {
		return Objects.hash(neUrl, transactionId, appKey, appName, enterpriseId, fromEmailId, toEmailId);
	}


	public void notification(String eventType, String eventDetails, String subject) throws Exception {
		try {
			postNotificationEmail(eventType,
					eventDetails, subject);
		} catch (Exception ex) {
			logger.error(
					"Exception in proccessing notification method ",
					ex);
			throw new Exception();
		}
	}


	public void onFailure( Exception ex ,String message, String clientService) {
		String eventType = EVENT_TYPE;
		String eventDetails = EVENT_DETAIL + message;
		eventDetails=eventDetails+SEPARATOR+ex;
		String subject = MAIL_SUBJECT+clientService;
		try {
			notification(eventType, eventDetails, subject);
		} catch (Exception e) {
			logger.error("Exception occured on calling notification method ", e);
		}

	}


}
