package com.ril.newcommerce.supplychain.kafka.rest.producer.engine;

import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import com.ril.newcommerce.supplychain.kafka.rest.producer.notificationservice.EmailNotificationService;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.util.concurrent.ListenableFuture;

import com.ril.newcommerce.supplychain.kafka.rest.producer.errors.Errors;
import com.ril.newcommerce.supplychain.kafka.rest.producer.errors.KafkaProducerRecoverableException;
import com.ril.newcommerce.supplychain.kafka.rest.producer.errors.KafkaRestProducerException;
import com.ril.newcommerce.supplychain.kafka.rest.producer.models.ProducerResult;

@Service
public class Producer {

	private static final Logger LOGGER = LoggerFactory.getLogger(Producer.class);


	@Value("#{${topicMaps}}")
	private Map<String, String> topicMaps;

	@Value("${nim.kafka.producer.wait.timeout.ms}")
	private long timeout;


	@Autowired
	EmailNotificationService emailNotificationService;

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@Retryable(value = KafkaProducerRecoverableException.class, maxAttemptsExpression = "${nim.kafka.producer.max.retry}", 
			backoff = @Backoff(delayExpression = "${nim.kafka.producer.retry.backoff.ms}"))

	public ProducerResult sendMessage(String message, String clientId, String serviceName,
									  String messageKey , Headers headers) {



		String topic = topicMaps.get(clientId + "." + serviceName);

		if(StringUtils.isEmpty(StringUtils.trimWhitespace(topic))) {

			LOGGER.error("Topic is null for clientId {}, serviceName {}",clientId,serviceName);
			throw new KafkaRestProducerException("Topic not found in the consumer configuration", Errors.MISSING_TOPIC_CONFIG,message,clientId+"-"+serviceName);
		}

		ProducerResult res = publishMessage(message, topic, messageKey,headers,clientId+"-"+serviceName);

		LOGGER.info("ProducerResult => {} for client {}, service {}, Message => {}", res, clientId, serviceName, message);

		return res;
	}


	public ProducerResult publishMessage(String message, String topic, String messageKey , Headers headers , String clientService ) {



		ProducerResult res = new ProducerResult();
		
		LOGGER.debug("Topic {},  Message {}", topic, message);
		
		try {
			ListenableFuture<SendResult<String, String>> future =null;
			if(headers != null){

				ProducerRecord<String, String> record = new ProducerRecord<>(topic, null, null,
						messageKey, message, headers);
				future=kafkaTemplate.send(record);

			}
			else{
				future = kafkaTemplate.send(topic, messageKey, message);
			}


			SendResult<String, String> sendResult = future.get(timeout, TimeUnit.MILLISECONDS);

			if(sendResult.getRecordMetadata() != null) {

				res.setSuccess(true);
				res.setTopic(sendResult.getRecordMetadata().topic());
				res.setStatusCode(HttpStatus.CREATED.value());
				res.setOffset(sendResult.getRecordMetadata().offset());
			}
			else {
				LOGGER.warn("The send operation returned gracefully but record metadata was null, retrying...");
				throw new KafkaProducerRecoverableException("Indeterministic operation outcome");
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			LOGGER.error("Thread Interupted", e);
			throw new KafkaRestProducerException("Publish failed : current thread was interrupted while waiting", Errors.INTERRUPTED_ERROR,message,clientService);

		} catch (ExecutionException | TimeoutException e) {
			LOGGER.error(e.getMessage(), e);
			throw new KafkaProducerRecoverableException("Publish failed : execution errored or timed out", Errors.EXECUTION_ERROR,message,clientService);
		}

		return res;
	}



    @Recover
	public ProducerResult sendMessage(KafkaProducerRecoverableException ex, String message, String clientId, String serviceName,
									  String messageKey , Headers headers) {

		emailNotificationService.onFailure(ex,message,clientId+"-"+serviceName);
		ProducerResult result= new ProducerResult();
		result.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		return result;

	}


}