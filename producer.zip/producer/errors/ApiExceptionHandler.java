package com.ril.newcommerce.supplychain.kafka.rest.producer.errors;

import java.util.ArrayList;
import java.util.List;

import com.ril.newcommerce.supplychain.kafka.rest.producer.notificationservice.EmailNotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.xml.sax.SAXException;

/**
 * Exception handler that catches all exceptions thrown by the REST layer
 * and convert them to the appropriate ErrorResponses with a
 * suitable HTTP status code.
 *
 * @see ErrorCode

 * @see ErrorResponse
 *
 *
 */
@ControllerAdvice
class ApiExceptionHandler {

    @Autowired
    EmailNotificationService emailNotificationService;


	    
    private static final Logger LOGGER = LoggerFactory.getLogger(ApiExceptionHandler.class);




    @ExceptionHandler({SAXException.class})
    ResponseEntity<ErrorResponse> handleServiceExceptions(SAXException exception) {
      List<ErrorResponse.ApiError> errorsFound = new ArrayList<>();
      errorsFound.add(new ErrorResponse.ApiError(HttpStatus.BAD_REQUEST.toString(),exception.getMessage()));
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                HttpStatus.BAD_REQUEST.getReasonPhrase(), errorsFound);
        LOGGER.error(exception.getMessage(),exception);
        LOGGER.error(errorResponse.toString());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST.value()).body(errorResponse);
    }


    @ExceptionHandler({RuntimeException.class})
    ResponseEntity<ErrorResponse> handleRumtimeExceptions(RuntimeException exception) {
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), new ArrayList<ErrorResponse.ApiError>());

        LOGGER.error(exception.getMessage(),exception);
        LOGGER.error(errorResponse.toString());

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR.value()).body(errorResponse);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationExceptions(MethodArgumentNotValidException exception) {

        BindingResult bindingResult = exception.getBindingResult();
        List<FieldError> fieldErrors = bindingResult.getFieldErrors();
        List<ErrorResponse.ApiError> errorsFound = new ArrayList<>();
        fieldErrors.forEach(o-> errorsFound.add(new ErrorResponse.ApiError(o.getField(),o.getDefaultMessage())));
        
        LOGGER.error(exception.getMessage(),exception);

        return ResponseEntity.badRequest().body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                HttpStatus.BAD_REQUEST.getReasonPhrase(), errorsFound));
    }




    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> handleServerConnectionExceptions(HttpMessageNotReadableException exception){

        LOGGER.error(exception.getMessage(),exception);
        
        return ResponseEntity.badRequest().body(new ErrorResponse(HttpStatus.BAD_REQUEST.value(),
                HttpStatus.BAD_REQUEST.getReasonPhrase(),
                new ErrorResponse.ApiError(HttpStatus.BAD_REQUEST.toString(),exception.getCause().getMessage()) ));

    }


    @ExceptionHandler(KafkaProducerException.class)
    public ResponseEntity<ErrorResponse> handleKafkaProducerExceptions(KafkaProducerException exception){

        emailNotificationService.onFailure(exception,exception.getMessage(),null);
        LOGGER.error(exception.getMessage(),exception);

        return ResponseEntity.badRequest().body(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                new ErrorResponse.ApiError(HttpStatus.INTERNAL_SERVER_ERROR.toString(),exception.getCause().getMessage()) ));

    }

    @ExceptionHandler(KafkaRestProducerException.class)
    public ResponseEntity<ErrorResponse> handleKafkaExceptions(KafkaRestProducerException exception){
    	
        LOGGER.error(exception.getMessage(),exception);
        emailNotificationService.onFailure(exception , exception.getFeed(),exception.getClientService());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                new ErrorResponse.ApiError(exception.getCode().code(),exception.getCode().getMessage())));
    }

    @ExceptionHandler(KafkaProducerRecoverableException.class)
    public ResponseEntity<ErrorResponse> handleKafkaExceptions(KafkaProducerRecoverableException exception){
    	
        LOGGER.error(exception.getMessage(),exception);
        emailNotificationService.onFailure(exception , exception.getFeed(),exception.getClientService());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                new ErrorResponse.ApiError(exception.getCode().code(), exception.getCode().getMessage())));
    }



}