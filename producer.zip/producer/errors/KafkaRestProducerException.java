package com.ril.newcommerce.supplychain.kafka.rest.producer.errors;

public class KafkaRestProducerException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	String message;

    Errors errorCode;

    String feed;

    String clientService;

    public KafkaRestProducerException(String message,String feed,String clientService) {
        super(message);
       this.feed=feed;
       this.clientService=clientService;
    }

    public KafkaRestProducerException(String message, Errors errorCode,String feed,String clientService) {
        super(message);
        this.errorCode=errorCode;
        this.feed=feed;
        this.clientService=clientService;
    }

    public KafkaRestProducerException(String message, Throwable ex, Errors errorCode,String feed,String clientService) {
    	
        super(message, ex);
        this.errorCode=errorCode;
        this.feed=feed;
        this.clientService=clientService;
    }
    
    public Errors getCode() {
        return errorCode;
    }

    public void setCode(Errors code) {
        this.errorCode = code;
    }

    public String getFeed() {
        return feed;
    }

    public void setFeed(String feed) {
        this.feed = feed;
    }

    public String getClientService() {
        return clientService;
    }

    public void setClientService(String clientService) {
        this.clientService = clientService;
    }
}
