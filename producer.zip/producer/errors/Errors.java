package com.ril.newcommerce.supplychain.kafka.rest.producer.errors;

import org.springframework.http.HttpStatus;

public enum Errors implements ErrorCode {

	NOT_FOUND("10000", "Requested resource not found"),
	KAFKA_SERVER_CONNECTION_FAILURE("100001", "Unable to connect to kafka broker"),
	DB_SERVER_CONNECTION_FAILURE("100002", "Unable to connect to database server"),
	REQUEST_PARSING_FAILED("100003","Request is invalid as per schema defined"),
	EXECUTION_ERROR("100004","Unable to process the request. Please check with service provider"),
	VALIDATION_SCHEMA_UNAVAILABLE("100005","Validation schema unavailable"),
	TIMEOUT_ERROR("100006","Unable to serve your request, please try later"),
	INTERRUPTED_ERROR("100007","Unable to serve your request, please retry later"),
	UNAUTHORIZED("100008","You are not authorized to use this service. Please check with service provider"),
	TRANSFORMATION_FAILED("100009", "Failed to transform the input message"),
	INBOUND_SCHEMA_VALIDATION_FAILED("100010", "Inbound schema validation failed"),
	OUTBOUND_SCHEMA_VALIDATION_FAILED("100011", "Target schema validation failed"),
	MISSING_TOPIC_CONFIG("100012", "Topic configuration missing for the client");


	public static Errors getByCode(String code) {
		for(Errors e : values()) {
			if(e.code.equals( code)) return e;
		}
		return null;
	}


	Errors(String code) {
		this.code = code;
	}

	Errors(String code, String message) {
		this.code = code;
		this.message = message;
	}

	Errors(String message, HttpStatus httpStatus) {
		this.message = message;
		this.httpStatus = httpStatus;
	}

	private String code;
	private String message;
	private HttpStatus httpStatus;



	public  String getMessageByCode(String code){
		for(Errors err: values() ){
			
			if(err.code==code){
				return err.message;
			}
		}
		return null;
	}

	public String getMessage() {
		return message;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}


	@Override
	public String code() {
		return code;
	}

	@Override
	public HttpStatus httpStatus() {
		return httpStatus;
	}

}
