package com.ril.newcommerce.supplychain.kafka.rest.producer.errors;

import static com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility.ANY;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;


@JsonAutoDetect(fieldVisibility = ANY)
public class ErrorResponse {

    private final int statusCode;


    private final String reasonPhrase;


    private final List<ApiError> errors;

    /**
     * Construct a valid instance of the {@linkplain ErrorResponse}
     *
     * @throws IllegalArgumentException If one of passed parameters is null or invalid
     */
    public ErrorResponse(int statusCode, String reasonPhrase, List<ApiError> errors) {

        this.statusCode = statusCode;
        this.reasonPhrase = reasonPhrase;
        this.errors = errors;
    }

    public ErrorResponse(int statusCode, String reasonPhrase, ApiError error) {

        this.statusCode = statusCode;
        this.reasonPhrase = reasonPhrase;
        List<ApiError> errors= new ArrayList<>();
        errors.add(error);
        this.errors = errors;
    }


    @JsonAutoDetect(fieldVisibility = ANY)
    public static class ApiError {

        private final String code;


        private  String message="";

       public ApiError(String code, String message) {
            this.code = code;
            this.message = message;
        }

        ApiError(String code){
            this.code= code;
        }

       public ApiError(Errors e){
           this.code= e.code();
           this.message=e.getMessage();

        }
    }

    @Override
    public String toString() {
        return "ErrorResponse{" +
                "statusCode=" + statusCode +
                ", reasonPhrase='" + reasonPhrase + '\'' +
                ", errors=" + errors +
                '}';
    }
}