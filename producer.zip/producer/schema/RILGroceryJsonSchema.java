package com.ril.newcommerce.supplychain.kafka.rest.producer.schema;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonValidator;

/**
 * 
 * @author amit1.pundir
 *
 */
public class RILGroceryJsonSchema implements RILGrocerySchema {


private static Logger logger = LoggerFactory.getLogger(RILGroceryXMLSchema.class);
	
	private JsonNode schemaNode;
	
	private JsonValidator jsonValidator;
	
	
	public RILGroceryJsonSchema(JsonNode schema, JsonValidator validator) {
		
		this.schemaNode = schema;
		this.jsonValidator = validator;
	}


	@Override
	public boolean validate(String message) {
		
	    boolean isValid = false;
		
		try {
			ProcessingReport report = jsonValidator.validate(schemaNode, JsonLoader.fromString(message));
			isValid = report.isSuccess();
			
			if(!isValid) {
				logger.info(">> Failure Reason: {}" , report);
			}
		} 
		catch (ProcessingException | IOException e) {
			logger.error("Unable to validate the message :",e);
		}
		
		return isValid;
	}
}
