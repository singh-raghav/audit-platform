package com.ril.newcommerce.supplychain.kafka.rest.producer.schema;

/**
 * 
 * @author amit1.pundir
 *
 */
public interface RILGrocerySchema {

	boolean validate(String message);

}
