package com.ril.newcommerce.supplychain.kafka.rest.producer.schema;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.github.fge.jsonschema.main.JsonValidator;
import com.ril.newcommerce.supplychain.kafka.rest.producer.services.ConfigurationService;

/**
 * @author amit1.pundir
 */
@Component
public class SchemaRepository {

    public static final Logger Logger = LoggerFactory.getLogger(SchemaRepository.class);

    @Autowired
    private ConfigurationService configService;


    private Map<String, RILGrocerySchema> schemaMap = new HashMap<>();

    private SchemaRepository() {
    }


    @PostConstruct
    private void initialize() {

        List<String> jsonSchema = configService.getJsonSchemaList();

        if (jsonSchema != null && !jsonSchema.isEmpty()) {

            jsonSchema.forEach(schema -> {

                schema = StringUtils.trimWhitespace(schema);

                if (!StringUtils.isEmpty(schema)) {
                    schemaMap.put(schema, createJsonSchema(schema));
                }

            });
        }

        List<String> xmlSchema = configService.getXmlSchemaList();

        if (xmlSchema != null && !xmlSchema.isEmpty()) {

            xmlSchema.forEach(schema -> {

                schema = StringUtils.trimWhitespace(schema);

                if (!StringUtils.isEmpty(schema)) {
                    schemaMap.put(schema, createXmlSchema(schema));
                }
            });
        }
    }

    private RILGrocerySchema createXmlSchema(String schemaFile) {

        RILGrocerySchema grcSchema = new RILGroceryNullSchema();

        try (InputStream  inputStream =  new ClassPathResource(schemaFile).getInputStream()) {
        	
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Source streamSource = new StreamSource(inputStream);

            Schema schema = factory.newSchema(streamSource);
            grcSchema = new RILGroceryXMLSchema(schema);
        }
        catch (IOException e) {
            Logger.error("Schema creation failed",e);
        } catch (SAXException e) {
            Logger.error("Schema parsing failed",e);
        }
        
       return grcSchema;
    }

    private RILGrocerySchema createJsonSchema(String schemaFile) {

        RILGrocerySchema grcSchema = new RILGroceryNullSchema();
        try(
                InputStream inputStream= new ClassPathResource(schemaFile).getInputStream();
                Reader inputStreamReader = new InputStreamReader(inputStream);
        ){
            JsonSchemaFactory factory = JsonSchemaFactory.byDefault();

            JsonNode schema = JsonLoader.fromReader(inputStreamReader);
            JsonValidator validator = factory.getValidator();

            grcSchema = new RILGroceryJsonSchema(schema, validator);

        }
        catch (IOException e) {
            Logger.error("Schema creation failed",e);
        }

        return grcSchema;
    }

    public RILGrocerySchema getSchema(String schema) {

        return schemaMap.get(schema);
    }

    @Override
    public String toString() {
        return "SchemaRepository [schemaMap=" + schemaMap + "]";
    }


}
