package com.ril.newcommerce.supplychain.kafka.rest.producer.schema;

/**
 * 
 * @author amit1.pundir
 *
 */
public class RILGroceryNullSchema implements RILGrocerySchema{

	@Override
	public boolean validate(String message) {
		return false;
	}
}
