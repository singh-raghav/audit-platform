package com.ril.newcommerce.supplychain.kafka.rest.producer.schema;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

/**
 * 
 * @author amit1.pundir
 *
 */
public class RILGroceryXMLSchema implements RILGrocerySchema {

	private static Logger logger = LoggerFactory.getLogger(RILGroceryXMLSchema.class);
	private Schema schema;
	
	public RILGroceryXMLSchema(Schema xmlSchema) {
		this.schema = xmlSchema;
	}

	@Override
	public boolean validate(String message) {
		
		boolean isValid = false;
		
		try {
			schema.newValidator().validate(new StreamSource(new StringReader(message)));
			isValid = true;
		} 
		catch (SAXException | IOException e) {
			logger.error("Unable to validate the message :",e);
		}

		return isValid;
	}
}
