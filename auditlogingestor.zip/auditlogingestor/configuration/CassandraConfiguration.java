/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.configuration;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;



/**
 * @author Raghav1.Singh
 *
 */

@Configuration
public class CassandraConfiguration {
	
	@Value("${cassandra.host}")
	private String host;
	
	@Value("${cassandra.cluster.name}")
	private String clusterName;
	
	@Value("${cassandra.port}")
	private int port;
	
	@Value("${cassandra.keyspace}")
	private String keyspace;
	
	@Bean	
	public Session session() throws IOException {
		
	    final Session session = Cluster.builder().addContactPoint(StringUtils.trim(host))
	    		                .withPort(port)
	    		                .withClusterName(StringUtils.trim(clusterName))
	    		                .withoutJMXReporting()
	    		                .build()
	    		                .connect(StringUtils.trim(keyspace));
	    
		return session;
	
	}	

}
