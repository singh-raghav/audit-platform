/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.auditlogingestor.constant.Constants;

/**
 * @author Raghav1.Singh
 *
 */

@Configuration
public class JacksonObjectMapperConfiguration {
	
	@Bean
	@Qualifier(Constants.JACKSON_MAPPER)
	public ObjectMapper getObjectMapper() {
		
		return new ObjectMapper();
	}
	
}
