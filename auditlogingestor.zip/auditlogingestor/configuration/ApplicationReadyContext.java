/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.ril.newcommerce.supplychain.message.consumers.SupplyChainRetryableKafkaConsumer;

/**
 * @author Raghav1.Singh
 *
 */

@Component
public class ApplicationReadyContext {
	
	private static final Logger logger = LoggerFactory.getLogger(ApplicationReadyContext.class);
	
	@Autowired
	private SupplyChainRetryableKafkaConsumer<String, String> consumer;
	
	@EventListener
	public void applicationReady(ApplicationReadyEvent applicationReady) {
		
		logger.info("Application is ready to serve requests... start the Kafka retryable Consumer...");
		
		consumer.start();
		
		logger.info("Sucessfully started the kafka retryable consumer..");
	}

}
