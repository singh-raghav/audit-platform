/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.configuration;


import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ril.newcommerce.supplychain.auditlogingestor.eventprocessor.EventProcessor;
import com.ril.newcommerce.supplychain.message.config.SupplyChainMessagingConfig;
import com.ril.newcommerce.supplychain.message.consumers.SupplyChainRetryableKafkaConsumer;

/**
 * @author Raghav1.Singh
 *
 */

@Configuration
public class KafkaConfiguration {
	
    @Value("${kafka.bootstrap-servers}")
	private String destinationDetails;
	
    @Value("${kafka.client-id}")
	private String applicationId;
	
    @Value("${kafka.consumer-group-id}")
	private String consumerGroupId;
	
    @Value("${kafka.source-topic}")
	private String sourceTopic;
	
    @Value("${kafka.retry-topic}")
	private String retryTopic;
	
    @Value("${kafka.failure-topic}")
	private String failureTopic;
	
    @Value("${kafka.retry-count}")
	private int retryCount;
	
    @Value("${kafka.retry-delay}")
	private long retryDelay;
    
    @Autowired
    private EventProcessor eventProcessor;
    
    @Bean
    public SupplyChainRetryableKafkaConsumer<String, String> getRetryableKafkaConsumer(){
    	
    	return new SupplyChainRetryableKafkaConsumer<>(eventProcessor, messageConfig());
    }
	
	private SupplyChainMessagingConfig messageConfig() {
		
		SupplyChainMessagingConfig msgConfig = new SupplyChainMessagingConfig();
		
		msgConfig.setDestinationDetails(StringUtils.trim(destinationDetails));
		msgConfig.setApplicationId(StringUtils.trim(applicationId));
		msgConfig.setConsumerGroupId(StringUtils.trim(consumerGroupId));
		msgConfig.setSourceTopic(StringUtils.trim(sourceTopic));
		msgConfig.setRetryTopic(StringUtils.trim(retryTopic));
		msgConfig.setFailureTopic(StringUtils.trim(failureTopic));
		msgConfig.setRecoveryRetryCount(retryCount);
		msgConfig.setRetryDelayInMillis(retryDelay);
		
		return msgConfig;
	}

}
