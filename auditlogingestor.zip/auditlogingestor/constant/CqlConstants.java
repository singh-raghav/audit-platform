/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.constant;

/**
 * @author Raghav1.Singh
 *
 */

public class CqlConstants {
	
	private CqlConstants() {
		
	}
	
	public static final String AUDIT_LOG_INSERT = "insert into audit_log(event_source,business_operation,tracking_id,event_creation_time,event) values(?,?,?,?,?)";

}
