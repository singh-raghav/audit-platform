/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.constant;

/**
 * @author Raghav1.Singh
 *
 */

public class Constants {
	
	private Constants() {
		
	}
	
	public static final String JACKSON_MAPPER="jacksonMapper";

}
