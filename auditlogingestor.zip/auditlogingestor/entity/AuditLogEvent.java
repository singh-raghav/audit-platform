/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author Raghav1.Singh
 *
 */

@JsonInclude(value=Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class AuditLogEvent {
	
	private String eventSource;
	
	private String businessOperation;
	
	private String trackingId;
	
	private Date eventCreationTime;
	
	private String event;

	public String getEventSource() {
		return eventSource;
	}

	public void setEventSource(String eventSource) {
		this.eventSource = eventSource;
	}

	public String getBusinessOperation() {
		return businessOperation;
	}

	public void setBusinessOperation(String businessOperation) {
		this.businessOperation = businessOperation;
	}

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public Date getEventCreationTime() {
		return eventCreationTime;
	}

	public void setEventCreationTime(Date eventCreationTime) {
		this.eventCreationTime = eventCreationTime;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

}
