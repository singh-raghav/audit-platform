/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.service;

import com.ril.newcommerce.supplychain.auditlogingestor.entity.AuditLogEvent;

/**
 * @author Raghav1.Singh
 *
 */

public interface AuditLogEventService {
	
	public void ingestAuditLogEvent(AuditLogEvent auditLogEvent);	

}
