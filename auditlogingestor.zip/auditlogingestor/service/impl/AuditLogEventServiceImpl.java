/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.service.impl;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.newcommerce.supplychain.auditlogingestor.dao.AuditLogEventDAO;
import com.ril.newcommerce.supplychain.auditlogingestor.entity.AuditLogEvent;
import com.ril.newcommerce.supplychain.auditlogingestor.exception.InvalidEventException;
import com.ril.newcommerce.supplychain.auditlogingestor.service.AuditLogEventService;

/**
 * @author Raghav1.Singh
 *
 */

@Service
public class AuditLogEventServiceImpl implements AuditLogEventService {
	
	private static final Logger logger = LoggerFactory.getLogger(AuditLogEventServiceImpl.class);
	
	@Autowired
	private AuditLogEventDAO auditLogEventDAO;

	@Override
	public void ingestAuditLogEvent(AuditLogEvent auditLogEvent) {
		
		logger.info("Inside Ingestion Service Impl");
		
		if(auditLogEvent.getEventSource()==null || auditLogEvent.getEventSource().isEmpty() ||
		   auditLogEvent.getTrackingId()==null  || auditLogEvent.getTrackingId().isEmpty()  ||
		   auditLogEvent.getBusinessOperation()==null || auditLogEvent.getBusinessOperation().isEmpty()){
			
			logger.error("Either EventSource or TrackingId or BusinessOperation found to be null..");
			throw new InvalidEventException("EventSource & TrackingId cannot be null");
		}
		
		auditLogEventDAO.insertAuditLogEvent(auditLogEvent);
		
		logger.info("Exiting Ingestion Service Impl");
		
	}	

}
