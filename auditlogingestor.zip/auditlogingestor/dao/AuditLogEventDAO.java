/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.dao;

import com.ril.newcommerce.supplychain.auditlogingestor.entity.AuditLogEvent;

/**
 * @author Raghav1.Singh
 *
 */

public interface AuditLogEventDAO {
	
	public void insertAuditLogEvent (AuditLogEvent auditLogEvent);

}
