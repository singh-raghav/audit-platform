/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.exceptions.InvalidTypeException;
import com.datastax.driver.core.exceptions.NoHostAvailableException;
import com.datastax.driver.core.exceptions.QueryExecutionException;
import com.datastax.driver.core.exceptions.QueryValidationException;
import com.datastax.driver.core.exceptions.UnsupportedFeatureException;
import com.ril.newcommerce.supplychain.auditlogingestor.constant.CqlConstants;
import com.ril.newcommerce.supplychain.auditlogingestor.dao.AuditLogEventDAO;
import com.ril.newcommerce.supplychain.auditlogingestor.entity.AuditLogEvent;
import com.ril.newcommerce.supplychain.auditlogingestor.exception.AuditException;
import com.ril.newcommerce.supplychain.auditlogingestor.exception.InvalidEventException;

/**
 * @author Raghav1.Singh
 *
 */
@Repository
public class AuditLogEventDAOImpl implements AuditLogEventDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(AuditLogEventDAOImpl.class);
	
	@Autowired
	private Session session;

	@Override
	public void insertAuditLogEvent(AuditLogEvent auditLogEvent) {
		
		PreparedStatement preparedStatement = null;
				
		try {
			
			preparedStatement = session.prepare(CqlConstants.AUDIT_LOG_INSERT);
			
			BoundStatement boundStatement = preparedStatement.bind(auditLogEvent.getEventSource(), auditLogEvent.getBusinessOperation(),
					                        auditLogEvent.getTrackingId(), auditLogEvent.getEventCreationTime(),
					                        auditLogEvent.getEvent());
			
			ResultSet rs = session.execute(boundStatement);
			
		} catch (NoHostAvailableException e) {
			
			logger.error("No host avialable to prepare the query..");
			throw new AuditException(e);
			
		}catch (IllegalArgumentException| InvalidTypeException| NullPointerException e) {
			
			logger.error("Invalid query parameters passed as input..");
			throw new InvalidEventException(e);
			
		}catch (QueryExecutionException| QueryValidationException| UnsupportedFeatureException e) {
			
			logger.error("Query cannot be executed successfully");
			throw new AuditException(e);
		}
		
		logger.info("AuditLog Event inserted successfully..");		                        

	}

}
