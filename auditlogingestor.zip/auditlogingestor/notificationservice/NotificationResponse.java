/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.notificationservice;

/**
 * @author Raghav1.Singh
 *
 */


public class NotificationResponse {
	
	private String message;
	private String status;

	@Override
	public String toString() {
		return "ClassPojo[message = " + message + ", status = " + status + "]";
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
