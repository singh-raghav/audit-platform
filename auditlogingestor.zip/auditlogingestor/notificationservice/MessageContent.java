/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.notificationservice;

/**
 * @author Raghav1.Singh
 *
 */

public class MessageContent {
	private String unFormattedMessage;
	private FormattedMessage FormattedMessage;

	@Override
	public String toString() {
		{
			return "ClassPojo [unFormattedMessage = " + unFormattedMessage
					+ ", FormattedMessage = " + FormattedMessage + "]";
		}
	}

	public String getUnFormattedMessage() {
		return unFormattedMessage;
	}

	public void setUnFormattedMessage(String unFormattedMessage) {
		this.unFormattedMessage = unFormattedMessage;
	}

	public FormattedMessage getFormattedMessage() {
		return FormattedMessage;
	}

	public void setFormattedMessage(FormattedMessage formattedMessage) {
		FormattedMessage = formattedMessage;
	}
}
