/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.notificationservice;

/**
 * @author Raghav1.Singh
 *
 */

public class Header {

	private long dateTime;
	private String messageType;
	private String sourceSystem;
	private String messageGroup;
	private String transactionId;

	@Override
	public String toString() {
		return "ClassPojo [dateTime = " + dateTime + ", messageType = "
				+ messageType + ", sourceSystem = " + sourceSystem
				+ ", messageGroup = " + messageGroup + "transactionId = "
				+ transactionId + "]";
	}

	public long getDateTime() {
		return dateTime;
	}

	public void setDateTime(long dateTime) {
		this.dateTime = dateTime;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getMessageGroup() {
		return messageGroup;
	}

	public void setMessageGroup(String messageGroup) {
		this.messageGroup = messageGroup;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

}
