/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.notificationservice;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;


/**
 * @author Raghav1.Singh
 *
 */

@Service
public class EmailNotificationService {
	
	private static final Logger log = LoggerFactory.getLogger(EmailNotificationService.class);
	
	@Value("${ne.rest.url}")
	private String neUrl;

	@Value("${ne.transaction.id}")
	private String transactionId;

	@Value("${ne.sourcesystem}")
	private String sourceSystem;

	@Value("${ne.appkey}")
	private String appKey;

	@Value("${ne.appname}")
	private String appName;

	@Value("${ne.enterprise.id}")
	private String enterpriseId;

	@Value("${ne.fromemail}")
	private String fromEmailId;

	@Value("${ne.toemail}")
	private String toEmailId;

	public void postNotificationEmail(String eventType, String eventDetails,
			String subject) throws URISyntaxException, JsonGenerationException, JsonMappingException, IOException {

		log.info("EmailNotificationService: postNotificationEmail method starts.....");

		NotificationRequest neRequest = new NotificationRequest();
		Body requestBody = new Body();
		Notification notification = new Notification();
		NotificationType notificationType = new NotificationType();
		MessageContent messageContent = new MessageContent();
		CommunicationDetails communicationDetails = new CommunicationDetails();
		Header header = new Header();
		FormattedMessage formattedMessage = new FormattedMessage();

		
		neRequest.setAppName(appName);
		neRequest.setAppKey(appKey);
		neRequest.setEnterpriseId(enterpriseId);

		communicationDetails.setToEmailId(toEmailId);
		communicationDetails.setFromEmail(fromEmailId);
		communicationDetails.setSubject(subject);

		notificationType.setEmail(true);

		formattedMessage.setEmailMessage(eventDetails);

		messageContent.setFormattedMessage(formattedMessage);

		notification.setCommunicationDetails(communicationDetails);
		notification.setNotificationType(notificationType);
		notification.setMessageContent(messageContent);

		requestBody.setNotification(notification);

		header.setDateTime(ZonedDateTime.now().toEpochSecond());
		header.setMessageGroup("INTERNALEVENT");
		header.setMessageType(eventType);
		header.setSourceSystem("CAP");
		header.setTransactionId("CAP"
				+ new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss")
						.format(new Date()));

		neRequest.setBody(requestBody);
		neRequest.setHeader(header);

		RestTemplate restTemplate = new RestTemplate();
		URI uri = new URI(neUrl);
		
		ObjectMapper mapper = new ObjectMapper();		
		mapper.writeValue(System.out, neRequest);		
		
		log.info("NE uri is--" + uri + "-Requestbody is--------->>>>>>");
		
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
		headers.add("Content-Type", "application/json");
		
		HttpEntity<NotificationRequest> request = new HttpEntity<NotificationRequest>(neRequest, headers);

		String result = restTemplate.postForObject(uri, request, String.class);
		
		log.info("NE response is------------<<<<<<<" + result);
		
		log.info("EmailNotificationService: postNotificationEmail method ends.....");
	}

}
