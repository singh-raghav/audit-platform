/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.notificationservice;

/**
 * @author Raghav1.Singh
 *
 */


public class NotificationType {
	
	private boolean sms;
	private boolean email;

	@Override
	public String toString() {
		return "NotificationType [sms=" + sms + ", email=" + email + "]";
	}

	public boolean isSms() {
		return sms;
	}

	public void setSms(boolean sms) {
		this.sms = sms;
	}

	public boolean isEmail() {
		return email;
	}

	public void setEmail(boolean email) {
		this.email = email;
	}
}
