/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.notificationservice;

/**
 * @author Raghav1.Singh
 *
 */

public class Body {
	private Notification notification;

	@Override
	public String toString() {
		return "ClassPojo [notification = " + notification + "]";
	}

	public Notification getNotification() {
		return notification;
	}

	public void setNotification(Notification notification) {
		this.notification = notification;
	}

}
