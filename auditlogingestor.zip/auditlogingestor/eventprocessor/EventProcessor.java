/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.eventprocessor;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ril.newcommerce.supplychain.auditlogingestor.entity.AuditLogEvent;
import com.ril.newcommerce.supplychain.auditlogingestor.exception.AuditException;
import com.ril.newcommerce.supplychain.auditlogingestor.exception.InvalidEventException;
import com.ril.newcommerce.supplychain.auditlogingestor.notificationservice.EmailNotificationService;
import com.ril.newcommerce.supplychain.auditlogingestor.service.AuditLogEventService;
import com.ril.newcommerce.supplychain.message.SupplyChainMessage;
import com.ril.newcommerce.supplychain.message.exceptions.RecoverableMessageProcessingException;
import com.ril.newcommerce.supplychain.message.exceptions.UnrecoverableMessageProcessingException;
import com.ril.newcommerce.supplychain.message.processors.SupplyChainMessageProcessor;

/**
 * @author Raghav1.Singh
 *
 */

@Component
public class EventProcessor implements SupplyChainMessageProcessor<String, String>{
	
	private static Logger logger = LoggerFactory.getLogger(EventProcessor.class);
    
	@Autowired
	private ObjectMapper mapper;
	
	@Autowired
	private AuditLogEventService auditLogEventService;
	
	@Autowired
	private EmailNotificationService emailNotificationService;

	@Override
	public void process(SupplyChainMessage<String, String> message)
			throws UnrecoverableMessageProcessingException, RecoverableMessageProcessingException {
		
		logger.debug("Recieved message : {}" , message.toString());
				
		try {
			
			AuditLogEvent auditLogEvent = getAuditLogEvent(message.getMessage());
			auditLogEventService.ingestAuditLogEvent(auditLogEvent);
			
		} catch (InvalidEventException e) {
			
			throw new UnrecoverableMessageProcessingException(e);
			
		} catch (AuditException e) {
			
			throw new RecoverableMessageProcessingException(e);
		}
		
		logger.info("Processing of message completed... ");
		
	}
	
	@Override
	public void onFailure(SupplyChainMessage<String, String> message) {
		
		String eventType = "CAP_ERROR";
		String eventDetails = "Exception occured due to ::" + message; 
		String subject = "EXCEPTION OCCURED IN CAP while processing message ";
		try {
			notification(eventType, eventDetails, subject);
		} catch (Exception e) {
			logger.error("Exception occured on calling notification method ",e);
		}
		
	}
	
	public void notification(String eventType, String eventDetails, String subject) throws Exception{
		
		try {
			
			emailNotificationService.postNotificationEmail(eventType,eventDetails, subject);
			
		} catch (Exception ex) {
			
			logger.error("Exception in proccessing notification method ",ex);
			throw new AuditException(ex);
			
		}
	}

	
	private AuditLogEvent getAuditLogEvent(String message) {
		
		AuditLogEvent auditLogEvent = null;
		
		try {
			
			auditLogEvent = mapper.readValue(message, AuditLogEvent.class);
			
		} catch (IOException e) {
			
			logger.error("Error occurred while converting String to POJO ", e);
			throw new InvalidEventException("INVALID EVENT...");
			
		} 
		return auditLogEvent;
	}

}
