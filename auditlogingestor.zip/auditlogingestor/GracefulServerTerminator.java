/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.catalina.connector.Connector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;

/**
 * @author Raghav1.Singh
 *
 */

public class GracefulServerTerminator implements TomcatConnectorCustomizer, ApplicationListener<ContextClosedEvent> {
	
	private static final Logger logger = LoggerFactory.getLogger(GracefulServerTerminator.class);
	
	private volatile Connector connector;
	
	@Value("${server.graceful-shutdown-wait-timeout-ms:30000}")
	private long timeout;

	@Override
	public void customize(Connector connector) {
		// TODO Auto-generated method stub
		this.connector = connector;
		
	}

	@Override
	public void onApplicationEvent(ContextClosedEvent event) {
		// TODO Auto-generated method stub
		logger.info("Tomcat shutting down, allowing {} millis for threadpool to shutdown gracefully",timeout);
		
		this.connector.pause();
		
		Executor executor = this.connector.getProtocolHandler().getExecutor();
		
        if(executor instanceof ThreadPoolExecutor) {
			
			try {
				
				 ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) executor;
	             threadPoolExecutor.shutdown();
	             
	             if (!threadPoolExecutor.awaitTermination(timeout, TimeUnit.SECONDS)) {
	                	
	                	logger.warn("Tomcat thread pool did not shut down gracefully within {} milli-seconds. "
	                			+ "Proceeding with forceful shutdown", timeout);
	                }

				
			}catch(InterruptedException ex) {
				Thread.currentThread().interrupt();
				
			}
		}
		
	}

	
	
	
	

}
