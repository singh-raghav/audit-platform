/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.exception;

/**
 * @author Raghav1.Singh
 *
 */
public class InvalidEventException extends RuntimeException {

	private static final long serialVersionUID = 4943325557046415063L;
	
	public InvalidEventException(String message) {
		super(message);
	}
	
	public InvalidEventException(String message, Throwable th) {
		super(message, th);
	}
	
	public InvalidEventException(Throwable th) {
		super(th);
	}

}
