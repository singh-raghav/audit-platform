/**
 * 
 */
package com.ril.newcommerce.supplychain.auditlogingestor.exception;

/**
 * @author Raghav1.Singh
 *
 */

public class AuditException extends RuntimeException {

	private static final long serialVersionUID = 8635892304333173987L;
	
	public AuditException(String message) {
		super(message);
	}
	
	public AuditException(String message, Throwable th) {
		super(message,th);
	}
	
	public AuditException(Throwable th) {
		super(th);
	}

}
