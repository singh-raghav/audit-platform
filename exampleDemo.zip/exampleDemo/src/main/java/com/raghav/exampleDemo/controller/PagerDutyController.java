/**
 * 
 */
package com.raghav.exampleDemo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.raghav.exampleDemo.entity.Developer;
import com.raghav.exampleDemo.entity.Team;
import com.raghav.exampleDemo.service.PagerDutyService;
import com.raghav.exampleDemo.util.ResponseMessage;
import com.raghav.exampleDemo.util.Utility;

/**
 * @author Raghav1.Singh
 *
 */
@RestController
@RequestMapping(value="/pager-duty/v1/create")
public class PagerDutyController {
	
	@Autowired
	private PagerDutyService pageDutyService;
	
	/*To map team and list of developers and create corresponding entries */
	
	@PostMapping(produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> createTeam(@RequestBody String teamName,
			                                          @RequestBody List<Developer> developers,
			                                          HttpServletRequest request){
		
        try {
        	
        	Team team  = new Team();
        	team.setName(teamName);
			pageDutyService.processTeam(team, developers);
			
			return Utility.getSuccessMessage(null, String.valueOf(team.getId()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return Utility.getfailureMsg("Creation of team failed..");
		}
		
		
	}
	
	
	
	

}
