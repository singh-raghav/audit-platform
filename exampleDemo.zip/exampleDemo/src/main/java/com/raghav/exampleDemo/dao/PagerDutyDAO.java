/**
 * 
 */
package com.raghav.exampleDemo.dao;

import java.util.List;

import com.raghav.exampleDemo.entity.Developer;
import com.raghav.exampleDemo.entity.Team;

/**
 * @author Raghav1.Singh
 *
 */
public interface PagerDutyDAO {
	
    public void insertToTeam(Team team);
	
	public void insertToDeveloper(List<Developer> developerList);

}
