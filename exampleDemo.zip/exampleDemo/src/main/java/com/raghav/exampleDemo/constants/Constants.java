/**
 * 
 */
package com.raghav.exampleDemo.constants;

/**
 * @author Raghav1.Singh
 *
 */
public class Constants {

}
