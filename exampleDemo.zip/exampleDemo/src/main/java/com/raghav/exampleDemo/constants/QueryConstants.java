/**
 * 
 */
package com.raghav.exampleDemo.constants;

/**
 * @author Raghav1.Singh
 *
 */
public class QueryConstants {
	
	private QueryConstants() {
		
	}
	
	public static final String INSERT_TO_TEAM = "insert into team values (?,?)";
	
	public static final String INSERT_TO_DEVELOPER = "insert into developer values (?,?,?,?);";

}
