/**
 * 
 */
package com.raghav.exampleDemo.exception;

/**
 * @author Raghav1.Singh
 *
 */
public class DemoException extends RuntimeException {

	private static final long serialVersionUID = -5334815967211655877L;
	
	public DemoException(String message) {
		super(message);		
	}
	
	public DemoException(String message, Throwable th) {
		super(message,th);		
	}
	
	public DemoException(Throwable th) {
		super(th);
	}

}
