/**
 * 
 */
package com.raghav.exampleDemo.service;

/**
 * @author Raghav1.Singh
 *
 */
public interface DemoService {

}
