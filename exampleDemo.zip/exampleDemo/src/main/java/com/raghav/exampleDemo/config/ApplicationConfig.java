/**
 * 
 */
package com.raghav.exampleDemo.config;

/**
 * @author Raghav1.Singh
 *
 */
public class ApplicationConfig {

}
