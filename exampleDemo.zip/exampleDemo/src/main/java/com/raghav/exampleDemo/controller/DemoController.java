/**
 * 
 */
package com.raghav.exampleDemo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Raghav1.Singh
 *
 */
public class DemoController {
	
	private static final Logger log = LoggerFactory.getLogger(DemoController.class);

}
