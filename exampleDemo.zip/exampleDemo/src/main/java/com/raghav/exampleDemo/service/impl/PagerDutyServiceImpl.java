/**
 * 
 */
package com.raghav.exampleDemo.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.raghav.exampleDemo.dao.PagerDutyDAO;
import com.raghav.exampleDemo.entity.Developer;
import com.raghav.exampleDemo.entity.Team;
import com.raghav.exampleDemo.exception.DemoException;
import com.raghav.exampleDemo.service.PagerDutyService;


@Service
public class PagerDutyServiceImpl implements PagerDutyService {
	
	private static final Logger log =  LoggerFactory.getLogger(PagerDutyServiceImpl.class);
	
	@Autowired
	private PagerDutyDAO pageDutyDAO;

	@Override
	public void processTeam(Team team, List<Developer> developers) {
		 
		try {
			
			pageDutyDAO.insertToTeam(team);
			
			pageDutyDAO.insertToDeveloper(developers);
			
		} catch (Exception e) {
			
			log.error("Processing of Teams failed for team id {}", team.getId());
			throw new DemoException("Processing in PagerDutyServiceImpl failed",e);
		}
		
		log.info("Processing of team for team id: {} successful..", team.getId());
		
	}
	
	

	
	

}
