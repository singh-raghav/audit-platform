/**
 * 
 */
package com.raghav.exampleDemo.dao;

/**
 * @author Raghav1.Singh
 *
 */
public interface DemoDAO {

}
