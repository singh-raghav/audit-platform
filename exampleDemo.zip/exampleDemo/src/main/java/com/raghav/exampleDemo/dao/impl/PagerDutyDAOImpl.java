/**
 * 
 */
package com.raghav.exampleDemo.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.raghav.exampleDemo.constants.QueryConstants;
import com.raghav.exampleDemo.dao.PagerDutyDAO;
import com.raghav.exampleDemo.entity.Developer;
import com.raghav.exampleDemo.entity.Team;
import com.raghav.exampleDemo.exception.DemoException;

/**
 * @author Raghav1.Singh
 *
 */
@Repository
public class PagerDutyDAOImpl implements PagerDutyDAO {
	
	private static final Logger log =  LoggerFactory.getLogger(PagerDutyDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void insertToTeam(Team team) {
		// TODO 
		try {
			
			jdbcTemplate.update(QueryConstants.INSERT_TO_TEAM, team.getId(), team.getName());
			
		} catch (Exception e) {	
			
			log.error("Unable to insert data to team for id {}",team.getId());
			throw new DemoException("Insertion in team table failed..", e);
		}
	}

	@Override
	public void insertToDeveloper(List<Developer> developerList) {
		// TODO 
		
		try {
			
			List<Object[]> devList = new ArrayList<Object[]>();
			for (Developer developer : developerList) {
				
				Object[] temp = {developer.getId(), developer.getTeamId(), developer.getName(),
						         developer.getPhoneNumber()};
				devList.add(temp);
				
			}
			jdbcTemplate.batchUpdate(QueryConstants.INSERT_TO_DEVELOPER, devList);
			
		} catch (Exception e) {
			
			log.error("Unable to insert to Developer for team id" );
			throw new DemoException("Insertion in Developer table failed..", e);
		}
		
	}
	
	

}
