/**
 * 
 */
package com.raghav.exampleDemo.util;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Raghav1.Singh
 *
 */
public class Error {
	
	private String errorCode; //discuss with UI team
    private String errorMessage;
    private Map<String, Object> moreDetails = new HashMap<>();

    public Map<String, Object> getMoreDetails() {
        return moreDetails;
    }

    public void setMoreDetails(Map<String, Object> moreDetails) {
        this.moreDetails = moreDetails;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }


}
