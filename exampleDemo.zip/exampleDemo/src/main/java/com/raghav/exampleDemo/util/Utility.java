/**
 * 
 */
package com.raghav.exampleDemo.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


/**
 * @author Raghav1.Singh
 *
 */
public class Utility {
	
	private static final Logger log = LoggerFactory.getLogger(Utility.class);

	private Utility() {}
	
	public static ResponseEntity<ResponseMessage> getSuccessMsg(Object data) {
		return getSuccessMsg(data, null);
	}
	
	public static ResponseEntity<ResponseMessage> getSuccessMessage(Object data, String tripId){
		return getSuccessMessage(data, tripId, null);
	}
	
	public static ResponseEntity<ResponseMessage> getSuccessMessage(Object data, String tripId, String msg){
		ResponseMessage message = new ResponseMessage();
		message.setStatus(ResponseMessage.SUCCESS);
		message.setStatusCode(0);
		message.setData(data);
		message.setMessage(msg);
		message.setTripId(tripId);
		return new ResponseEntity<ResponseMessage>(message, HttpStatus.OK);
	}

	public static ResponseEntity<ResponseMessage> getSuccessMsg(Object data, String msg) {
		ResponseMessage message = new ResponseMessage();
		message.setStatus(ResponseMessage.SUCCESS);
		message.setStatusCode(0);
		message.setData(data);
		message.setMessage(msg);
		return new ResponseEntity<>(message,HttpStatus.OK);
	}
	
	public static ResponseEntity<ResponseMessage> getSuccessMsg(String msg, HttpStatus httpStatus) {
		
		ResponseMessage message = new ResponseMessage();
		message.setStatus(ResponseMessage.SUCCESS);
		message.setStatusCode(0);
		message.setMessage(msg);
		return new ResponseEntity<>(message,httpStatus);
		
	}
	
	public static ResponseEntity<ResponseMessage> getfailureMsg(String msg){
		return getfailureMsg(msg, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	public static ResponseEntity<ResponseMessage> getfailureMsg(String msg, HttpStatus httpStatus) {
		
		ResponseMessage message = new ResponseMessage();
		List<Error> errors=new ArrayList<Error>();
		Error error=new Error();
		error.setErrorMessage(msg);
		errors.add(error);
		
		message.setErrors(errors);
		message.setStatusCode(-1);
		message.setStatus(ResponseMessage.FAILURE);
		message.setMessage(msg);
		
		return new ResponseEntity<>(message,httpStatus);
	}

	public static ResponseEntity<ResponseMessage> getfailureMsg(String msg, HttpStatus httpStatus, Map<String, Object> moreDetailsMap) {
		ResponseMessage message = new ResponseMessage();
		List<Error> errors=new ArrayList<Error>();
		Error error=new Error();
		error.setErrorMessage(msg);
		error.getMoreDetails().putAll(moreDetailsMap);
		errors.add(error);

		message.setErrors(errors);
		message.setStatusCode(-1);
		message.setStatus(ResponseMessage.FAILURE);
		message.setMessage(msg);

		return new ResponseEntity<>(message,httpStatus);
	}

	public static ResponseEntity<ResponseMessage> getfailureMsg(String msg, List<String> errorList, HttpStatus httpStatus) {

		ResponseMessage message = new ResponseMessage();
		List<Error> errors=new ArrayList<Error>();

		for(String errorMessage : errorList){
			Error error=new Error();
			error.setErrorMessage(errorMessage);
			errors.add(error);
		}
		message.setErrors(errors);
		message.setStatusCode(-1);
		message.setStatus(ResponseMessage.FAILURE);
		message.setMessage(msg);

		return new ResponseEntity<>(message,httpStatus);
	}
	
	public static ResponseEntity<ResponseMessage> getWarningMsg(String msg) {
		
		ResponseMessage message = new ResponseMessage();
		List<Error> errors=new ArrayList<Error>();
		Error error=new Error();
		error.setErrorMessage(msg);
		errors.add(error);
		
		message.setErrors(errors);
		message.setStatusCode(2);
		message.setStatus(ResponseMessage.WARNING);
		message.setMessage(msg);
		
		return new ResponseEntity<>(message,HttpStatus.EXPECTATION_FAILED);
	}


}
