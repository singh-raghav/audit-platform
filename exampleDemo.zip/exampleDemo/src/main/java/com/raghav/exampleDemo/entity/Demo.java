/**
 * 
 */
package com.raghav.exampleDemo.entity;

/**
 * @author Raghav1.Singh
 *
 */
public class Demo {

}
