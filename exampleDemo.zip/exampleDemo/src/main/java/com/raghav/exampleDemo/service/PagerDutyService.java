/**
 * 
 */
package com.raghav.exampleDemo.service;

import java.util.List;

import com.raghav.exampleDemo.entity.Developer;
import com.raghav.exampleDemo.entity.Team;

/**
 * @author Raghav1.Singh
 *
 */
public interface PagerDutyService {
	
	public void processTeam(Team team, List<Developer> developers);
	
}
